package customMarkupForAFC.EFEMassCheck;


import java.io.*;

import customMarkupForAFC.TimeConvertor;
import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassCheckErrorCollection;

public class MassCheckLog 
{
	private static String FileName;
	private static BufferedWriter bw;
	private static int errorNumber = 1;
	private static boolean count_mode = false;
	private static String fontPrefix = "<font color = \"#";
	static public void createLog(String folderName) throws IOException 
	{
		TimeConvertor time = new TimeConvertor();
		FileName = folderName + "\\" + time.getTimeStamp() + ".html";
		bw = new BufferedWriter(new FileWriter(FileName));
	}
	static public void TurnOnCountMode()
	{
		count_mode = true;
	}
	static public void TurnOffCountMode()
	{
		count_mode = false;
	}
	
	
	static public void WriteToLogFile(String data,int errorType ) throws IOException
	{  
		try 
		{
			if( count_mode )
			{
				String color = MassCheckErrorCollection.getColorbyType(errorType);
				data = "<p>" + fontPrefix + color + "\">" + "(" + errorNumber++ + ")" + data + "</font></p>";
			}
			else
			{
				if( errorType == MassCheckErrorCollection.HYPER_LINK)
					data = "<a href = \"" + data + "\">" + data + "</a>";
				else
					data = "<p>" + data + "</p>";
				errorNumber = 1;
			}
		    bw.write(data);
		    bw.flush();
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	static public void CloseFile()
	{
		/*try 
		{
			bw.flush();
		} catch (IOException e1) 
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		try {
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}