package customMarkupForAFC.EFEMassCheck;

import java.util.Vector;
import org.w3c.dom.Node;

import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassAddressChecker;
import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassFreeChecker;
import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassHiddenChecker;
import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassInfoChecker;
import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassSummaryChecker;
import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassTableChecker;
import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassTextFieldChecker;
import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassTitleChecker;

public class EFEMassCheckDispatcher
{
	private Node HiddenSubform = null;
	private Vector<Node> titleSets = null;
	private Vector<Node> infoBlockHeader = null;
	private Vector<Node> addressBlockSubformSets = null;
	private Vector<Node> tableheaderSubformSets = null;
	private Vector<Node> tableRemarkSubformSets = null;
	private Vector<Node> tableOuterMostSubformSets = null;
	private Vector<Node> freeBlockSubformSets = null;
	private Vector<Node> summBlockSubformSets = null;
	private Vector<Node> allOtherTextFields = null;
	public void fillTask(Node Hide,Vector<Node> title,Vector<Node> info,Vector<Node> address,Vector<Node> header,
			Vector<Node> remark,Vector<Node> table,Vector<Node> free,Vector<Node> summ,Vector<Node> textfield)
	{
		HiddenSubform = Hide;
		titleSets = title;
		infoBlockHeader = info;
		addressBlockSubformSets = address;
		tableheaderSubformSets = header;
		tableRemarkSubformSets = remark;
		tableOuterMostSubformSets = table;
		freeBlockSubformSets = free;
		summBlockSubformSets = summ;
		allOtherTextFields = textfield;
	}
	private void MassCheckTextField()
	{
		MassTextFieldChecker textChecker = new MassTextFieldChecker(allOtherTextFields);
		textChecker.check();
	}
	private void MassCheckTitle()
	{
		MassTitleChecker titleChecker = new MassTitleChecker(titleSets);
		titleChecker.check();
	}
	private void MassCheckInfoBlock()
	{
		MassInfoChecker infoChecker = new MassInfoChecker(infoBlockHeader);
		infoChecker.check();
	}
	private void MassCheckTable()
	{
		MassTableChecker tableChecker = new MassTableChecker(tableOuterMostSubformSets,
				tableheaderSubformSets,tableRemarkSubformSets);
		tableChecker.check();
	}
	private void MassCheckFreeBlock()
	{
		MassFreeChecker freeblockChecker = new MassFreeChecker(freeBlockSubformSets);
		freeblockChecker.check();
	}
	private void MassCheckSummary()
	{
		MassSummaryChecker summaryChecker = new MassSummaryChecker(summBlockSubformSets);
		summaryChecker.check();
	}
	private void MassCheckAddressBlock()
	{
		MassAddressChecker addressChecker = new MassAddressChecker(addressBlockSubformSets);
		addressChecker.check();
	}
	private void MassCheckHidden()
	{
		MassHiddenChecker hiddenChecker = new MassHiddenChecker(HiddenSubform);
		hiddenChecker.check();	
	}
	private void MassCheckHiddenAndFreeBlock()
	{
		/* 2008-09-10 do not use frmFloatfields now
		 * 
		if( HiddenSubform == null )
		{
			// 2008-09-02 change from infoblockSets to freeBlockSubformSets
			if( !freeBlockSubformSets.isEmpty() )
			{
				String error = "You Must Create a Hidden Subform and Copy the Fields from InfoBlock into Hidden Subform!";
				Tool.writeLog(error,MassCheckErrorCollection.HIDDEN_SUBFORM_MISSING);
			}
		}*/
	}
	public void dispatch()
	{
		MassCheckTitle();
		MassCheckInfoBlock();
		/*
		 * Disable on 2009-04-14: FP2.0 do not implement AddressBlock 
		   MassCheckAddressBlock();
		   */
		MassCheckHidden();
		MassCheckHiddenAndFreeBlock();
		MassCheckTable();
		MassCheckFreeBlock();
		/*
		 * Disable on 2009-04-14: FP2.0 do not implement Summary
		 MassCheckSummary();
		 */
		MassCheckTextField();
	}
}