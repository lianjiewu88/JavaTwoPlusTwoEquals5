package customMarkupForAFC.EFEMassCheck.MassCheckUtilities;

import java.util.Vector;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utilities.DisplayTool;
import utilities.Tool;
public class MassAddressChecker
{
	private Vector<Node> addressSubformSets = null;
	public MassAddressChecker(Vector<Node> input)
	{
		addressSubformSets = input;
	}
	public void check()
	{
		if( addressSubformSets.isEmpty())
			return;
		checkAddressBlock();
	}
	private void checkAddressBlock()
	{
		int size = addressSubformSets.size();
		for( int i = 0 ; i < size;i++)
		{
			checkEachAddressBlock(addressSubformSets.elementAt(i));
		}
	}
	
	private boolean checkEachAddressBlock(Node node)
	{
		String error = null;
		String subformName = Tool.getAttributeValue("name", node);
		// 2008-09-11: Currently Address Block Subform is forbidden to have Markup
		if( Tool.getA1SNodeNumber(node) != 0 )
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.ADDRESS_FIELD_HAS_MARKUP, subformName);
			Tool.writeLog(error,MassCheckErrorCollection.ADDRESS_FIELD_HAS_MARKUP);
			DisplayTool.display(error);
		}
		NodeList children = node.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals("subform"))
			{
				checkEachAddressBlock(item);
			}
			else if( item.getNodeName().equals("field") || item.getNodeName().equals("draw"))
			{
				String name = Tool.getAttributeValue("name", item);
				if ( Tool.getA1SNodeNumber(item) != 0)
				{
					error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.ADDRESS_FIELD_HAS_MARKUP, name);
					Tool.writeLog(error,MassCheckErrorCollection.ADDRESS_FIELD_HAS_MARKUP);
					DisplayTool.display(error);
				}
				if ( !Tool.isFieldReadOnly(item,true) )
				{
					error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.READ_ONLY,name);
					Tool.writeLog(error,MassCheckErrorCollection.READ_ONLY);
					DisplayTool.display(error);
				}
			}
		}
		return true;
	}
}