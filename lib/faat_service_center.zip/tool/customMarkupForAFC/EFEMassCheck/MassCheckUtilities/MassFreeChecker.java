package customMarkupForAFC.EFEMassCheck.MassCheckUtilities;

import java.util.Vector;

import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.DisplayTool;
import utilities.FieldMappingChecker;
import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;
import customMarkupForAFC.markupProcessor.internalObject.FormFieldCaption;

public class MassFreeChecker
{
	private Vector<Node> freeBlockSubformCol = null;
	private Vector<String> FieldIDCol = null;
	private int drawNumber = 0;
	public MassFreeChecker(Vector<Node> task)
	{
		freeBlockSubformCol = task; 
		FieldIDCol = new Vector<String>();
	}
	
	public boolean check()
	{
		if( freeBlockSubformCol.isEmpty() )
			return true;
		int size = freeBlockSubformCol.size();
		for( int i = 0 ; i < size;i++)
		{
			checkEachFreeBlock(freeBlockSubformCol.elementAt(i));
			// 2008-10-13 fixed one issue raised by Arnold
			drawNumber = 0;
		}
		return true;
	}
	
	private boolean isDescriptionValidFormat(String Description)
	{
		if( ConfigDom.DescriptionCheckOn == false)
			return true;
		if( Description.contains("#"))
			return false;
		String condensed = Tool.condense(Description);
		String defaultValue = CustomMarkupConfigDom.getFreeTextBlockDescriptionDefaultValue();
		int length = defaultValue.length();
		if( condensed.length() < length)
			return false;
		return condensed.substring(0,length).equals(defaultValue);
	}
	
	private boolean checkEachFreeBlock(Node subform)
	{
		String error = null;
		String freeblockName = Tool.getAttributeValue("name",subform);
		String itemName = null;
		if( Tool.hasA1SNode(subform) == false)
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE,freeblockName);
			Tool.writeLog(error,MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE);
			DisplayTool.display(error);
			return false;
		}
		if( !Tool.isSingleA1SNode(subform))
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, freeblockName);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
			DisplayTool.display(error);
		}
		if( checkFreeBlockDescription(subform) == false )
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.FREE_DESP_INVALID,freeblockName);
			Tool.writeLog(error,MassCheckErrorCollection.FREE_DESP_INVALID);
			DisplayTool.display(error);
		}
		FieldIDCol.clear();
		// supposed there is none nested subform in free text block
		NodeList children = subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			itemName = Tool.getAttributeValue("name", item);
			if( item.getNodeName().equals("draw"))
			{
				drawNumber++;
				if( !Tool.isExDataExist(item))
				{
					error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.NO_EXDATA_EXIST,itemName);
					Tool.writeLog(error,MassCheckErrorCollection.NO_EXDATA_EXIST);
					DisplayTool.display(error);
				}
				if( !LayoutTestReuseComponent.isHeightExpandToFit(item,true))
				{
					error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DRAW_EXPAND_TO_FIT_FREETEXT,itemName);
					Tool.writeLog(error,MassCheckErrorCollection.DRAW_EXPAND_TO_FIT_FREETEXT);
					DisplayTool.display(error);
				}
			}
			checkMapping(item);
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.NESTED_SUBFORM_FREE_TEXT,itemName);
				Tool.writeLog(error,MassCheckErrorCollection.NESTED_SUBFORM_FREE_TEXT);
				DisplayTool.display(error);
			}
			if( (!item.getNodeName().equals("draw")) && (!item.getNodeName().equals("field")))
				continue;
			if( !Tool.isSingleA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE,itemName);
				Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
				DisplayTool.display(error);
			}
			if( !Tool.NodehasID(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.POSSIBLE_FIELD_NO_ID, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.POSSIBLE_FIELD_NO_ID);
				DisplayTool.display(error);
			}
			String ID = Tool.getAttributeValue("id",item);
			if( ID != null)
			{
				if( !ID.equals("untitledField"))
					FieldIDCol.add(ID);
			}
			if( !Tool.isFieldReadOnly(item,true))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.READ_ONLY,itemName);
				Tool.writeLog(error,MassCheckErrorCollection.READ_ONLY);
				DisplayTool.display(error);
			}
			if( !Tool.DoesPossibleFieldsHaveA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.POSSIBLE_FIELD_NO_A1SNOE, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.POSSIBLE_FIELD_NO_A1SNOE);
				DisplayTool.display(error);
			}
			if( !FormFieldCaption.checkPossibieFieldsDescriptionMaintained(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.POSSIBLE_FIELD_NO_DESP,itemName);
				Tool.writeLog(error,MassCheckErrorCollection.POSSIBLE_FIELD_NO_DESP);
				DisplayTool.display(error);
			}
			if( Tool.getItemCustomMarkupType(item) != CustomMarkupConfigDom.FREEBLOCK_FIELD)
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.MARKUP_TYPE_WRONG,itemName);
				Tool.writeLog(error,MassCheckErrorCollection.MARKUP_TYPE_WRONG);
				DisplayTool.display(error);
			}
		}
		if( drawNumber != 1)
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_DRAW,freeblockName);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_DRAW);
			DisplayTool.display(error);
		}
		if( Tool.hasDuplicateID(FieldIDCol))
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_FIELD_ID,freeblockName);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_FIELD_ID);
			DisplayTool.display(error);
		}
		return true;
	}
	
	private void checkMapping(Node node)
	{
		FieldMappingChecker.init(node);
		int checkResult = FieldMappingChecker.check();
		String itemName = Tool.getAttributeValue("name", node);
		String error = null;
		if( checkResult == ConfigDom.NO_MAPPING)
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.POSSIBLE_FIELD_NO_MAPPING,itemName);
			Tool.writeLog(error,MassCheckErrorCollection.POSSIBLE_FIELD_NO_MAPPING);
			DisplayTool.display(error);
		}
		else if ( checkResult == ConfigDom.INVALID_RELATIVE_MAPPING)
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.INVALID_RELATIVE_MAPPING,itemName);
			Tool.writeLog(error,MassCheckErrorCollection.INVALID_RELATIVE_MAPPING);
			DisplayTool.display(error);
		}
	}
	/* 2008-08-21 now SM requires that the description for building blocks must be mandatory,
	 * so this description now must be input by developers manually by tool, and 
	 * tool must check whether it is null or not
	 */
	
	private boolean checkFreeBlockDescription( Node subform)
	{
		Node a1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),subform);
		if( a1s == null )
			return false;
		Node freeblock = Tool.getNodebyRoot(CustomMarkupConfigDom.getFreeTextBlockSubformNodeName(),a1s);
		if( freeblock == null)
			return false;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),freeblock);
		if( title == null)
			return false;
		String description = title.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0 )
			return false;
		return isDescriptionValidFormat(description);
	}
}