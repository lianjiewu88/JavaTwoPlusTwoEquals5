package customMarkupForAFC.EFEMassCheck.MassCheckUtilities;
import utilities.Tool;
public class MassCheckErrorCollection
{
	static public final int READ_ONLY = 1;
	static public final int INFO_SPLIT_CAPTION = 2;
	static public final int INFO_DESP_INVALID = 3;
	static public final int HIDDEN_HAS_A1SNODE = 4;
	static public final int PAGE_OUTSIDE_INFO = 5;
	static public final int DUPLICATE_A1SNODE = 6;
	static public final int VISIBLE_FIELD_NO_A1SNODE = 7;
	static public final int INFO_ONE_COPY_ATTR = 8;
	static public final int TABLE_DESP_INVALID = 9;
	static public final int TABLE_TARGET_WIDTH_ERROR = 10;
	static public final int TABLE_ONE_COPY_ATTR = 11;
	static public final int FREE_DESP_INVALID = 12;
	static public final int SUMM_DESP_INVALID = 13;
	static public final int POSSIBLE_FIELD_NO_A1SNOE = 14;
	static public final int NO_TITLE = 15;
	static public final int HYPER_LINK = 16;
	static public final int HIDDEN_SUBFORM_MISSING = 17;
	static public final int POSSIBLE_FIELD_NO_ID = 18;
	static public final int DUPLICATE_FIELD_ID = 19;
	static public final int MARKUP_TYPE_WRONG = 20;
	static public final int ADDRESS_FIELD_HAS_MARKUP = 21;
	static public final int POSSIBLE_FIELD_NO_DESP = 22;
	static public final int TABLE_HEADER_TEXT_FIELD = 23;
	static public final int TABLE_HEADER_ACC = 24;
	static public final int ALLOW_MULTIPLE_LINE = 25;
	static public final int HEIGHT_EXPAND_TO_FIT = 26;
	static public final int HIDDEN_SUBFORM_EXIST = 27;
	static public final int NESTED_SUBFORM_FREE_TEXT = 28;
	static public final int DUPLICATE_DRAW = 29;
	static public final int NO_EXDATA_EXIST = 30;
	static public final int POSSIBLE_FIELD_NO_MAPPING = 31;
	static public final int INVALID_RELATIVE_MAPPING = 32;
	static public final int DRAW_EXPAND_TO_FIT_FREETEXT = 33;
	
	static public String getColorbyType(int type)
	{
		String color = null;
		switch ( type )
		{
			case READ_ONLY:
				color = "8A2BE2";
				break;
			case INFO_SPLIT_CAPTION:
				color = "9932CC";
				break;
			case INFO_DESP_INVALID:
				color = "00BFFF";
				break;
			case HIDDEN_HAS_A1SNODE:
				color = "0000CD";
				break;
			case PAGE_OUTSIDE_INFO:
				color = "A0522D";
				break;
			case DUPLICATE_A1SNODE:
				color = "8B008B";
				break;
			case VISIBLE_FIELD_NO_A1SNODE:
				color = "8B0000";
				break;
			case INFO_ONE_COPY_ATTR:
				color = "CD5C5C";
				break;
			case TABLE_DESP_INVALID:
				color = "FFA07A";
				break;
			case TABLE_TARGET_WIDTH_ERROR:
				color = "FF7F50";
				break;
			case TABLE_ONE_COPY_ATTR:
				color = "BA55D3";
				break;
			case FREE_DESP_INVALID:
				color = "20B2AA";
				break;
			case SUMM_DESP_INVALID:
				color = "4169E1";
				break;
			case POSSIBLE_FIELD_NO_A1SNOE:
				color = "9ACD32";
				break;
			case NO_TITLE:
				color = "FF0000";
				break;
			case HIDDEN_SUBFORM_MISSING:
				color = "A52A2A";
				break;
			case POSSIBLE_FIELD_NO_ID:
				color = "A52A2A";
				break;
			case DUPLICATE_FIELD_ID:
				color = "A52A2A";
				break;
			case MARKUP_TYPE_WRONG:
				color = "A52A2A";
				break;
			case ADDRESS_FIELD_HAS_MARKUP:
				color = "A52A2A";
				break;
			case POSSIBLE_FIELD_NO_DESP:
				color = "A52A2A";
				break;
			case TABLE_HEADER_TEXT_FIELD:
				color = "A52A2A";
				break;
			case TABLE_HEADER_ACC:
				color = "A52A2A";
				break;
			case ALLOW_MULTIPLE_LINE:
				color = "A52A2A";
				break;
			case HEIGHT_EXPAND_TO_FIT:
				color = "A52A2A";
				break;
			case HIDDEN_SUBFORM_EXIST:
				color = "FF0000";
				break;
			case NESTED_SUBFORM_FREE_TEXT:
				color = "20B2AA";
				break;
			case DUPLICATE_DRAW:
				color = "20B2AA";
				break;
			case NO_EXDATA_EXIST:
				color = "20B2AA";
				break;
			case POSSIBLE_FIELD_NO_MAPPING:
				color = "A52A2A";
				break;
			case INVALID_RELATIVE_MAPPING:
				color = "A52A2A";
				break;
			case DRAW_EXPAND_TO_FIT_FREETEXT:
				color = "A52A2A";
				break;
			default:
				Tool.InfoReport("Unknown ErrorType: " + type);
				Tool.stopApplication();
		}
		return color;
	}
	static public String getErrorDescription(int type,String fieldName)
	{
		String error = "Node: " + fieldName + " ";
		switch ( type )
		{
			case READ_ONLY:
				error += "must be set to READ ONLY!";
				break;
			case INFO_SPLIT_CAPTION:
				error += "in infoblock has SPLIT CAPTION!";
				break;
			case INFO_DESP_INVALID:
				error += "subform description invalid!";
				break;
			case HIDDEN_HAS_A1SNODE:
				error += "is a hidden field, it mustn't have any EFE markup maintained!";
				break;
			case PAGE_OUTSIDE_INFO:
				error += "is a page field, must be put outside infoblock!";
				break;
			case DUPLICATE_A1SNODE:
				error += "has duplicated EFE markup, must delete!";
				break;
			case VISIBLE_FIELD_NO_A1SNODE:
				error += "is a visible field,but does not have EFE markup maintained!";
				break;
			case INFO_ONE_COPY_ATTR:
				error += "info block must only have one field CopyFromCustomFields = true!";
				break;
			case TABLE_DESP_INVALID:
				error += "table description invalid!";
				break;
			case TABLE_TARGET_WIDTH_ERROR:
				error += "table target width attribute error!";
				break;
			case TABLE_ONE_COPY_ATTR:
				error += "table header must only have one CopyFromCustomFields = true!";
				break;
			case FREE_DESP_INVALID:
				error += "free text block description invalid!";
				break;
			case SUMM_DESP_INVALID:
				error += "summary block description invalid!";
				break;
			case POSSIBLE_FIELD_NO_A1SNOE:
				error += "possible fields for free text block have no sapa1s Node";
				break;
			case POSSIBLE_FIELD_NO_ID:
				error += "must have ID attribute for field insertion!";
				break;
			case DUPLICATE_FIELD_ID:
				error += "duplicate field id existing!";
				break;
			case MARKUP_TYPE_WRONG:
				error += "has wrong markup type added!";
				break;
			case ADDRESS_FIELD_HAS_MARKUP:
				error += "in address block,mustn't have any EFE markup currently!";
				break;
			case POSSIBLE_FIELD_NO_DESP:
				error += "in free text block,must have description maintained!";
				break;
			case TABLE_HEADER_TEXT_FIELD:
				error += "must use text field instead of draw!";
				break;
			case TABLE_HEADER_ACC:
				error += "accessibility must be set to none";
				break;
			case ALLOW_MULTIPLE_LINE:
				error += "must allow multiple lines!";
				break;
			case HEIGHT_EXPAND_TO_FIT:
				error += "height must expand to fit!";
				break;
			case HIDDEN_SUBFORM_EXIST:
				error += "hidden subform must be deleted!";
				break;
			case NESTED_SUBFORM_FREE_TEXT:
				error += "must be moved outside free text block!";
				break;
			case DUPLICATE_DRAW:
				error += "each free text block must have exactly one draw!";
				break;
			case NO_EXDATA_EXIST:
				error += "draw must have exData subnode to allow possible field insertion!";
				break;
			case POSSIBLE_FIELD_NO_MAPPING:
				error += "possible field in free text block must have mapping!";
				break;
			case INVALID_RELATIVE_MAPPING:
				error += "possible field has invalid relative mapping path!";
				break;
			case DRAW_EXPAND_TO_FIT_FREETEXT:
				error += "draw in free text block must set expand to fit in Height!";
				break;
			default:
				error += "unknown error type!";
		}
		return error;
	}
}