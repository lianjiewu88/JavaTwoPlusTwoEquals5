package customMarkupForAFC.EFEMassCheck.MassCheckUtilities;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import configuration.CustomMarkupConfigDom;

import utilities.DisplayTool;
import utilities.Tool;

public class MassHiddenChecker
{
	private Node HiddenSubform = null;
	public MassHiddenChecker(Node task)
	{
		HiddenSubform = task; 
	}
	
	public boolean check()
	{
		if( HiddenSubform == null)
			return true;
		String error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.HIDDEN_SUBFORM_EXIST,
				CustomMarkupConfigDom.getHiddenSubformNamingConvention());
		Tool.writeLog(error,MassCheckErrorCollection.HIDDEN_SUBFORM_EXIST);
		DisplayTool.display(error);
		return false;
		//return checkAllPossibleFields();
	}
	
	public boolean checkAllPossibleFields()
	{
		NodeList children = HiddenSubform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		String error = null;
		String name = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( (!item.getNodeName().equals("field")) && (!item.getNodeName().equals("draw")))
				continue;
			name = Tool.getAttributeValue("name",item);
			if( !Tool.isSingleA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, name);
				Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
				DisplayTool.display(error);
			}
			if( Tool.DoesPossibleFieldsHaveA1SNode(item) == false)
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.POSSIBLE_FIELD_NO_A1SNOE, name);
				Tool.writeLog(error,MassCheckErrorCollection.POSSIBLE_FIELD_NO_A1SNOE);
				DisplayTool.display(error);
			}
			/* 2008-09-04 All possible fields needn't to be 
			 * hidden since they inherit the presence of their subform
			if( !Tool.isFieldHidden(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			*/
		}
		return true;
	}
}