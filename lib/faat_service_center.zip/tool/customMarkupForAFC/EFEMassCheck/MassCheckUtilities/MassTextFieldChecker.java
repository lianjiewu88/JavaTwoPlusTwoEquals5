package customMarkupForAFC.EFEMassCheck.MassCheckUtilities;

import java.util.Vector;
import org.w3c.dom.Node;

import utilities.DisplayTool;
import utilities.Tool;
import configuration.ConfigDom;

public class MassTextFieldChecker
{
	private Vector<Node> textFieldSets = null;
	public MassTextFieldChecker(Vector<Node> input)
	{
		textFieldSets = input;
	}
	public void check()
	{
		if( textFieldSets.isEmpty() )
			return;
		int size = textFieldSets.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachTextField(textFieldSets.elementAt(i)))
			{
				String name = Tool.getAttributeValue("name",textFieldSets.elementAt(i));
				String error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.READ_ONLY,name);
				Tool.writeLog(error,MassCheckErrorCollection.READ_ONLY);
				DisplayTool.display(error);
			}
		}
	}
	private boolean checkEachTextField(Node node)
	{
		if( !node.getNodeName().equals("field"))
			return true;
		if( Tool.isBarCode(node))
			return true;
		String name = Tool.getAttributeValue("name", node);
		if( name != null)
		{
			if( name.contains(ConfigDom.getFormLogoNamePostfix()))
				return true;
		}
		String readOnly = Tool.getAttributeValue("access", node);
		if( readOnly == null)
			return false;
		if( !readOnly.equals(ConfigDom.getFieldAccessReadOnly()))
			return false;
		return true;
	}
}