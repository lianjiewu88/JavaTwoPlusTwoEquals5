package customMarkupForAFC.EFEMassCheck.MassCheckUtilities;

import java.util.Vector;

import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.DisplayTool;
import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;

public class MassTableChecker
{
	private Vector<Node> TableSubformCol = null;
	private Vector<Node> TableHeaderCol = null;
	private Vector<Node> TableRemarkRow = null;
	public MassTableChecker(Vector<Node> tableOuter,Vector<Node> TableHeader,Vector<Node> RemarkRow)
	{
		TableSubformCol = tableOuter;
		TableHeaderCol = TableHeader;
		TableRemarkRow = RemarkRow;
	}
	
	private boolean checkRemarkRow()
	{
		if( TableRemarkRow.isEmpty() )
			return true;
		int size = TableRemarkRow.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachRemarkRow(TableRemarkRow.elementAt(i)))
				return false;
		}
		return true;
	}
	
	//	 2008-08-26: do not check remark subform's description for the moment
	private boolean checkEachRemarkRow(Node subform)
	{
		String name = Tool.getAttributeValue("name",subform);
		String itemName = null;
		String error = null;
		if( !Tool.isSingleA1SNode(subform))
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE,name);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
			DisplayTool.display(error);
		}
		NodeList children = subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( (!item.getNodeName().equals("draw")) && (!item.getNodeName().equals("field")))
				continue;
			/* add 2008-09-05:according to Thierry
			 * hidden field must not have sapa1s node!!
			 */
			itemName = Tool.getAttributeValue("name", item);
			if( Tool.isFieldHidden(item) && Tool.hasA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.HIDDEN_HAS_A1SNODE, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.HIDDEN_HAS_A1SNODE);
				DisplayTool.display(error);
			}
			if( !Tool.isFieldHidden(item) && !Tool.hasA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE);
				DisplayTool.display(error);
			}
			if( !Tool.isSingleA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
				DisplayTool.display(error);
			}
			if( !Tool.isFieldReadOnly(item,true))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.READ_ONLY, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.READ_ONLY);
				DisplayTool.display(error);
			}
		}
		return true;
	}
	
	private boolean checkTableHeader()
	{
		// add 2008-06-03 to support multiple table situations
		if( TableHeaderCol.isEmpty() )
			return true;
		int size = TableHeaderCol.size();
		Node item = null;
		for( int i = 0 ; i < size; i++)
		{
			item = TableHeaderCol.elementAt(i);
			checkEachTableHeader(item);
		}
		return true;
	}
	

	public void check()
	{
		checkTableSubformDescription();
		checkTableHeader();
		checkRemarkRow();
	}
	private boolean checkEachTableSubformDescription(Node node)
	{
		Node a1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( a1s == null )
			return false;
		Node table = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableSubformNodeName(),a1s);
		if( table == null)
			return false;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),table);
		if( title == null)
			return false;
		String description = title.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0 )
			return false;
		if( !Tool.isSingleA1SNode(node))
		{
			String subformName = Tool.getAttributeValue("name", node);
			String error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, subformName);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
			DisplayTool.display(error);
		}
		return isDescriptionValidFormat(description);
	}
	
	private boolean isDescriptionValidFormat(String Description)
	{
		if( ConfigDom.DescriptionCheckOn == false)
			return true;
		if( Description.contains("#"))
			return false;
		String condensed = Tool.condense(Description);
		String defaultValue = CustomMarkupConfigDom.getTableDescriptionDefaultValue();
		int length = defaultValue.length();
		if( condensed.length() < length)
			return false;
		return condensed.substring(0,length).equals(defaultValue);
	}
	
	/* add 2008-08-21: check Table outer-most subform description now
	 * only outer-most subform need to check, ignore all those nested subforms
	 */
	private void checkTableSubformDescription()
	{
		if( TableSubformCol.isEmpty())
			return;
		int size = TableSubformCol.size();
		Node item = null;
		String error = null;
		String TableSubformName = null;
		for( int i = 0 ; i < size;i++)
		{
			item = TableSubformCol.elementAt(i);
			TableSubformName = Tool.getAttributeValue("name",item);
			if( !checkEachTableSubformDescription(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.TABLE_DESP_INVALID, TableSubformName);
				Tool.writeLog(error,MassCheckErrorCollection.TABLE_DESP_INVALID);
				DisplayTool.display(error);
			}
			if( !checkEachTableTargetWidthAttr(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.TABLE_TARGET_WIDTH_ERROR, TableSubformName);
				Tool.writeLog(error,MassCheckErrorCollection.TABLE_TARGET_WIDTH_ERROR);
				DisplayTool.display(error);
			}
		}
	}
	
	private boolean checkEachTableTargetWidthAttr(Node node)
	{
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( sapa1s == null)
			return false;
		Node table = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableSubformNodeName(),sapa1s);
		if( table == null)
			return false;
		String targetWidth = table.getAttributes().getNamedItem(CustomMarkupConfigDom.getTableTargetWidthAttributeName()).getNodeValue();
		if( targetWidth == null)
			return false;
		if( targetWidth.equals(CustomMarkupConfigDom.TableTargetWidthType1))
			return true;
		if( targetWidth.equals(CustomMarkupConfigDom.TableTargetWidthType2))
			return true;
		if( targetWidth.equals(CustomMarkupConfigDom.TableTargetWidthType3))
			return true;
		if( targetWidth.equals(CustomMarkupConfigDom.TableTargetWidthType4))
			return true;
		return false;
	}
	//	 input: the table header subform node
	private void checkEachTableHeader(Node node)
	{
		Node item = null;
		Node sapa1s = null;
		String name = Tool.getAttributeValue("name", node);
		String itemName = null;
		String error = null;
		if( !Tool.isSingleA1SNode(node))
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, name);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
			DisplayTool.display(error);
		}
		NodeList headers = node.getChildNodes();
		String attri = null;
		int TrueNumber = 0;
		int size = headers.getLength();
		for( int i = 0 ; i < size;i++)
		{
			item = headers.item(i);
			if( !item.getNodeName().equals("field") && !item.getNodeName().equals("draw"))
				continue;
			/*
			 * 2008-09-01 Do not check this, or else the table 
			 * caption will be displayed abnormally in some situation
			if( !checkCaptionSplit(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}*/
			itemName = Tool.getAttributeValue("name",item);
			if( !Tool.isFieldReadOnly(item,true))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.READ_ONLY,itemName);
				Tool.writeLog(error,MassCheckErrorCollection.READ_ONLY);
				DisplayTool.display(error);
			}
			if( !Tool.isSingleA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
				DisplayTool.display(error);
			}
			/* add 2008-09-05: According to Thierry hidden field must not have 
			 * EFE markup! Delete it!
			 */
			if( Tool.isFieldHidden(item) && ( Tool.hasA1SNode(item)))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.HIDDEN_HAS_A1SNODE, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.HIDDEN_HAS_A1SNODE);
				DisplayTool.display(error);
			}
			// add 2008-09-05: visible fields have no sapa1s node, error happens!
			if( !Tool.isFieldHidden(item) && !Tool.hasA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE);
				DisplayTool.display(error);
			}
			// add 2008-09-23: table header must use text fields now, or long description will be cut off!
			if( item.getNodeName().equals("draw"))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.TABLE_HEADER_TEXT_FIELD,itemName);
				Tool.writeLog(error, MassCheckErrorCollection.TABLE_HEADER_TEXT_FIELD);
				DisplayTool.display(error);
			}
			if( !LayoutTestReuseComponent.isFieldAllowMultipleLine(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.ALLOW_MULTIPLE_LINE, itemName);
				Tool.writeLog(error, MassCheckErrorCollection.ALLOW_MULTIPLE_LINE);
				DisplayTool.display(error);
			}
			if( !LayoutTestReuseComponent.isHeightExpandToFit(item,false))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.HEIGHT_EXPAND_TO_FIT, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.HEIGHT_EXPAND_TO_FIT);
				DisplayTool.display(error);
			}
			//	add 2008-09-23: add ACC check
			String acc = LayoutTestReuseComponent.getNodeAccessibilitySetting(item);
			if( !acc.equals(ConfigDom.getDefaultAccRightSetting()))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.TABLE_HEADER_ACC, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.TABLE_HEADER_ACC);
				DisplayTool.display(error);
			}
			sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),item);
			if( sapa1s == null)
				continue;
			Node header = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableHeaderNodeName(),sapa1s);
			if( header == null)
				continue;
			attri = header.getAttributes().getNamedItem(CustomMarkupConfigDom.getCopyAttributeName()).getNodeValue();
			if( attri == null)
				continue;
			if( attri.equals("true"))
				TrueNumber++;
		}
		if( TrueNumber == 1)
			return;
		error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.TABLE_ONE_COPY_ATTR,name);
		Tool.writeLog(error,MassCheckErrorCollection.TABLE_ONE_COPY_ATTR);
		DisplayTool.display(error);
	}
	
	/* 2008-08-26: Is there anythign in the spec about this?  
	 *This problem was also observed in many other forms.
	 * check if there is caption-split situation in infoblock
	 * in table header, both Field and Draw are possible to be used
	 */
	/* 2008-09-01: Arnold found one issue that if the table header split 
	 * is resolved, the table header will not be displayed so well, so
	 * in the table header this caption split check is not done any more
	 */
	/*private boolean checkCaptionSplit(Node node)
	{
		String name = Tool.getAttributeValue("name", node);
		if( name == null)
			name = "defaultFieldName";
		Node value = Tool.getNodebyRoot("value",node);
		if( value == null)
		// have caption but have no value, error happended!
		{
			Tool.ErrorReport("Field: " + name + " Does Not Have Value Node!");
			return false;
		}
		Node exData = Tool.getNodebyRoot("exData",value);
		if( exData != null)
		{
			Tool.ErrorReport("Field: " + name + " Has Splited Caption!Please Resolve it into Format: Value.Text!");
			return false;
		}
		return true;
	}*/
}