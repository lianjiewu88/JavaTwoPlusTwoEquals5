package customMarkupForAFC.EFEMassCheck.MassCheckUtilities;

import java.util.Vector;
import org.w3c.dom.Node;
import customMarkupForAFC.markupProcessor.internalObject.FormTitle;
import utilities.Tool;
import utilities.DisplayTool;
public class MassTitleChecker
{
	private Vector<Node> titleSets = null;
	public MassTitleChecker(Vector<Node> input)
	{
		titleSets = input;
	}
	public void check()
	{
		String error = null;
		if( titleSets.isEmpty())
		{
			error = "No form title existing!\n";
			Tool.writeLog(error,MassCheckErrorCollection.NO_TITLE);
			DisplayTool.display(error);
			return;
		}
		checkTitle();
	}
	private void checkTitle()
	{
		int size = titleSets.size();
		Node item = null;
		for( int i = 0 ; i < size;i++)
		{
			item = titleSets.elementAt(i);
			checkEachFormTitle(item);
		}
	}
	private void checkEachFormTitle(Node node)
	{
		String name = Tool.getAttributeValue("name", node);
		String error = null;
		if( Tool.isFieldHidden(node))
		// 2008-09-09 Form actually have no title, just put some hidden dummy table
		// do not check this!
			return;
		if( Tool.isSingleA1SNode(node) == false)
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE,name);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
			DisplayTool.display(error);
		}
		if( Tool.hasA1SNode(node) == false)
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE,name);
			Tool.writeLog(error,MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE);
			DisplayTool.display(error);
		}
		String config = FormTitle.getConfigurableAttr(node);
		if( config == null)
			return;
		/* 2008-11-21 
		 * didn't check title configurable attribute now because EFE already support it
		if( config.equals("true"))
		{
			// must be static title
			if( !FormTitle.isStaticTitle(node))
			{
				error = "Form Title is Not a Static Title,Configurable Attribute Must Set to \"false\"!";
				Tool.writeLog(error,MassCheckErrorCollection.NO_TITLE);
				DisplayTool.display(error);
			}
		}
		else if ( config.equals("false"))
		{
			if( FormTitle.isStaticTitle(node))
			{
				error = "Static Form Title Must Set Configurable Attribute to \"true\"!";
				Tool.writeLog(error,MassCheckErrorCollection.NO_TITLE);
				DisplayTool.display(error);
			}
		}
		else
		{
			error = "Form Title Unknown Configurable Attribute!";
			Tool.writeLog(error,MassCheckErrorCollection.NO_TITLE);
			DisplayTool.display(error);
		}*/
		return;
	}
}