package customMarkupForAFC.EFEMassCheck.MassCheckUtilities;

import java.util.Vector;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;
import utilities.DisplayTool;
import utilities.Tool;
public class MassInfoChecker
{
	private Vector<Node> infoSets = null;
	public MassInfoChecker(Vector<Node> input)
	{
		infoSets = input;
	}
	public void check()
	{
		if( infoSets.isEmpty())
			return;
		checkInfoBlock();
	}
	private void checkInfoBlock()
	{
		int size = infoSets.size();
		for( int i = 0 ; i < size;i++)
		{
			checkEachInfoBlock(infoSets.elementAt(i));
		}
	}
	private boolean checkCaptionSplit(Node node)
	{
		Node caption = Tool.getNodebyRoot("caption",node);
		if( caption == null)
		// no caption, such situation can not happen?
			return true;
		Node value = Tool.getNodebyRoot("value",caption);
		if( value == null)
		// have caption but have no value, error happended!
		// such situation does exist in DeliveryNote@Address block!
		{
			return true;
		}
		Node exData = Tool.getNodebyRoot("exData",value);
		if( exData != null)
			return false;
		return true;
	}
	private void checkEachInfoBlock(Node subform)
	{
		Node item = null;
		Node sapa1s = null;
		Node info = null;
		NodeList infoChildren = null;
		String attri = null;
		String InfoblockName = Tool.getAttributeValue("name",subform);
		String error = null;
		// add 2008-9-1;if the node has no A1SNode,it failes to be found in
		// markup object
		if( Tool.hasA1SNode(subform) == false )
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE,InfoblockName);
			Tool.writeLog(error,MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE);
			DisplayTool.display(error);
			return;
		}
		if( Tool.isSingleA1SNode(subform) == false)
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE,InfoblockName);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
			DisplayTool.display(error);
		}
		if( checkInfoBlockDescription(subform) == false )
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.INFO_DESP_INVALID,InfoblockName);
			Tool.writeLog(error,MassCheckErrorCollection.INFO_DESP_INVALID);
			DisplayTool.display(error);
		}
		int TrueNumber = 0;
		infoChildren = subform.getChildNodes();
		int size = infoChildren.getLength();
		for( int i = 0; i < size; i++)
		{
			item = infoChildren.item(i);
			if( !item.getNodeName().equals("field") && !item.getNodeName().equals("draw"))
				continue;
			String name = Tool.getAttributeValue("name",item);
			/* add 2008-09-05: According to Thierry that hidde subform in infoblock must not be added with 
			 * xml markup
			 */
			if( !checkCaptionSplit(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.INFO_SPLIT_CAPTION,name);
				Tool.writeLog(error,MassCheckErrorCollection.INFO_SPLIT_CAPTION);
				DisplayTool.display(error);
			}
			if( Tool.isFieldHidden(item) && Tool.hasA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.HIDDEN_HAS_A1SNODE,name);
				Tool.writeLog(error,MassCheckErrorCollection.HIDDEN_HAS_A1SNODE);
				DisplayTool.display(error);
			}
			if( !Tool.isFieldReadOnly(item,true))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.READ_ONLY,name);
				Tool.writeLog(error,MassCheckErrorCollection.READ_ONLY);
				DisplayTool.display(error);
			}
			if( Tool.checkPageFieldExist(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.PAGE_OUTSIDE_INFO, name);
				Tool.writeLog(error,MassCheckErrorCollection.PAGE_OUTSIDE_INFO);
				DisplayTool.display(error);
			}
			if( !Tool.isSingleA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, name);
				Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
				DisplayTool.display(error);
			}
			/* add 2008-09-05: according to Thierry's issue:137
			 * unhidden field must have xml markup mandatory!
			 */
			if( !Tool.isFieldHidden(item) && !Tool.hasA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE, name);
				Tool.writeLog(error,MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE);
				DisplayTool.display(error);
			}
			int type = Tool.getItemCustomMarkupType(item);
			if( Tool.hasA1SNode(item) && type != CustomMarkupConfigDom.INFOBLOCK_FIELD)
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.MARKUP_TYPE_WRONG,name);
				Tool.writeLog(error,MassCheckErrorCollection.MARKUP_TYPE_WRONG);
				DisplayTool.display(error);
			}
			sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),item);
			if( sapa1s == null)
				continue;
			info = Tool.getNodebyRoot(CustomMarkupConfigDom.getInfoBlockItemNodeName(),sapa1s);
			if( info == null)
				continue;
			attri = info.getAttributes().getNamedItem(CustomMarkupConfigDom.getCopyAttributeName()).getNodeValue();
			if( attri == null)
				continue;
			if( attri.equals("true"))
				TrueNumber++;
		}
		if( TrueNumber == 1)
			return;
		error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.INFO_ONE_COPY_ATTR,InfoblockName);
		Tool.writeLog(error,MassCheckErrorCollection.INFO_ONE_COPY_ATTR);
		DisplayTool.display(error);
	}
	private boolean checkInfoBlockDescription( Node subform)
	{
		Node a1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),subform);
		if( a1s == null )
			return true;
		Node infoblock = Tool.getNodebyRoot(CustomMarkupConfigDom.getInfoBlockSubformNodeName(),a1s);
		if( infoblock == null)
			return false;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),infoblock);
		if( title == null)
			return false;
		String description = title.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0 )
			return false;
		/* 2008-08-22 should check whether description follows the format defined by Gia duong 
		 * Info Block1,2....
		 */
		if( !Tool.isSingleA1SNode(subform))
			return false;
		return isDescriptionValidFormat(description);
	}
	private boolean isDescriptionValidFormat(String Description)
	{
		if( ConfigDom.DescriptionCheckOn == false)
			return true;
		if( Description.contains("#"))
			return false;
		String condensed = Tool.condense(Description);
		String defaultValue = CustomMarkupConfigDom.getInfoBlockDescriptionDefaultValue();
		int length = defaultValue.length();
		if( condensed.length() < length)
			return false;
		return condensed.substring(0,length).equals(defaultValue);
	}
}