package customMarkupForAFC.EFEMassCheck.MassCheckUtilities;

import java.util.Vector;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.DisplayTool;
import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;

// 2008-08-26 it is possible that Summary block has nested subform,
// must handle with such situation 
public class MassSummaryChecker
{
	private Vector<Node> summaryBlockSubformCol = null;
	public MassSummaryChecker(Vector<Node> task)
	{
		summaryBlockSubformCol = task; 
	}
	
	public boolean check()
	{
		if( summaryBlockSubformCol.isEmpty() )
			return true;
		int size = summaryBlockSubformCol.size();
		for( int i = 0 ; i < size;i++)
		{
			checkEachSummBlock(summaryBlockSubformCol.elementAt(i));
		}
		return true;
	}
	
	private boolean isDescriptionValidFormat(String Description)
	{
		if( ConfigDom.DescriptionCheckOn == false)
			return true;
		if( Description.contains("#"))
			return false;
		String condensed = Tool.condense(Description);
		String defaultValue = CustomMarkupConfigDom.getSummaryBlockDescriptionDefaultValue();
		int length = defaultValue.length();
		if( condensed.length() < length)
			return false;
		return condensed.substring(0,length).equals(defaultValue);
	}
	
	private boolean checkEachSummBlock(Node subform)
	{
		String name = Tool.getAttributeValue("name",subform);
		String error = null;
		if( Tool.hasA1SNode(subform) == false)
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE, name);
			Tool.writeLog(error,MassCheckErrorCollection.VISIBLE_FIELD_NO_A1SNODE);
			DisplayTool.display(error);
		}
		if( !Tool.isSingleA1SNode(subform))
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, name);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
			DisplayTool.display(error);
		}
		if( checkSummBlockDescription(subform) == false )
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.SUMM_DESP_INVALID, name);
			Tool.writeLog(error,MassCheckErrorCollection.SUMM_DESP_INVALID);
			DisplayTool.display(error);
		}
		return checkAllFields(subform);
	}
	
	// 2008-08-25 it is impossible the nested subform has certain sapa1s node,so just
	// ignore nested subform
	private boolean checkAllFields(Node subform)
	{
		String name = Tool.getAttributeValue("name",subform);
		String error = null;
		String itemName = null;
		if( !Tool.isSingleA1SNode(subform))
		{
			error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, name);
			Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
			DisplayTool.display(error);
		}
		NodeList children = subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			itemName = Tool.getAttributeValue("name", item);
			if( item.getNodeName().equals("subform"))
			{
				if( !checkAllFields(item))
					return false;
			}
			if( (!item.getNodeName().equals("draw")) && (!item.getNodeName().equals("field")))
				continue;
			if( Tool.isFieldHidden(item) && Tool.hasA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.HIDDEN_HAS_A1SNODE, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.HIDDEN_HAS_A1SNODE);
				DisplayTool.display(error);
			}
			if( !Tool.isSingleA1SNode(item))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.DUPLICATE_A1SNODE, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.DUPLICATE_A1SNODE);
				DisplayTool.display(error);
			}
			if( !Tool.isFieldReadOnly(item,true))
			{
				error = MassCheckErrorCollection.getErrorDescription(MassCheckErrorCollection.READ_ONLY, itemName);
				Tool.writeLog(error,MassCheckErrorCollection.READ_ONLY);
				DisplayTool.display(error);
			}
		}
		return true;
	}
	/* 2008-08-25 now SM requires that the description for building blocks must be mandatory,
	 * so this description now must be input by developers manually by tool, and 
	 * tool must check whether it is null or not
	 */
	
	private boolean checkSummBlockDescription( Node subform)
	{
		Node a1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),subform);
		if( a1s == null )
			return false;
		Node summblock = Tool.getNodebyRoot(CustomMarkupConfigDom.getSummaryBlockSubformName(),a1s);
		if( summblock == null)
			return false;
		Node Desp = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),summblock);
		if( Desp == null)
			return false;
		String description = Desp.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0 )
			return false;
		return isDescriptionValidFormat(description);
	}
}