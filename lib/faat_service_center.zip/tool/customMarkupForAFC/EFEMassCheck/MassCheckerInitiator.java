package customMarkupForAFC.EFEMassCheck;

import java.io.File;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JList;

import customMarkupForAFC.EFEMassCheck.MassCheckUtilities.MassCheckErrorCollection;

import utilities.DisplayTool;
import utilities.Tool;

public class MassCheckerInitiator
{
	private Vector<String> AbsoluteFilePaths = null;
	private DefaultListModel ListMode = null;
	private JList jList = null;
	public MassCheckerInitiator(DefaultListModel mode,JList list)
	{
		AbsoluteFilePaths = new Vector<String>();
		ListMode = mode;
		jList = list;
		DisplayTool.init(ListMode, jList);
	}

	public int AssginTask(File[] FolderName)
	{
		int FileNumber = FolderName.length;
		String inputXDPName = null;
		boolean isDirectory = false;
		for( int i = 0; i < FileNumber;i++)
		{
			inputXDPName = FolderName[i].getAbsolutePath();
			isDirectory = FolderName[i].isDirectory();
			if( !isDirectory)	// is a file
			{
				if( Tool.isValidTemplate(inputXDPName) )
				{
					AbsoluteFilePaths.add(inputXDPName);
				}
			}
			else
				TraversePath(FolderName[i]);
		}
		return AbsoluteFilePaths.size();
	}
	
	private void TraversePath(File Directory)
	{
		File[] filecollection = Directory.listFiles();
		int filenumber = filecollection.length;
		File item = null;
		boolean isFileDirectory = false;
		for( int i = 0 ; i < filenumber; i++)
		{
			item = filecollection[i];
			isFileDirectory = item.isDirectory();
			if( !isFileDirectory)
			{
				if( Tool.isValidTemplate(item.getAbsolutePath()) )
				{
					AbsoluteFilePaths.add(item.getAbsolutePath());
				}
			}
			else
				TraversePath(item);
		}
	}
	public void fetchTimeStamp()
	{
		if( AbsoluteFilePaths.isEmpty() )
			return;
		String info = null;
		String timestamp = null;
		int size = AbsoluteFilePaths.size();
		FormScanner formScanner = new FormScanner();
		for( int i = 0;i<size;i++)
		{
			info = "Template: " + AbsoluteFilePaths.elementAt(i);
			DisplayTool.display(info);
			//Tool.writeLog(info,MassCheckErrorCollection.HYPER_LINK);
			timestamp = formScanner.getTimeStamp(AbsoluteFilePaths.elementAt(i));
			if( timestamp != null)
			{
				info = "Timestamp: " + timestamp;
				DisplayTool.display(info);
				//Tool.newLine();
				//Tool.writeLog(info,9999);
			}
			DisplayTool.newLine();
			//Tool.newLine();
		}
	}
	public void run()
	{
		Tool.TurnOnSilentMode();
		DisplayTool.setFont(15);
		String info = null;
		if( AbsoluteFilePaths.isEmpty() )
		{
			info = "None Form Template Needs to be Checked in Given Folder!";
			Tool.writeLog(info,9999);
			DisplayTool.display(info);
			Tool.closeLog();
		}
		int size = AbsoluteFilePaths.size();
		boolean ret = false;
		FormScanner formScanner = new FormScanner();
		for( int i = 0;i<size;i++)
		{
			ret = formScanner.getAllAdobeFields(AbsoluteFilePaths.elementAt(i));
			if( ret )
			{
				info = Tool.getCurrentLocalTime();
				Tool.TurnOffCountMode();
				Tool.writeLog(info,9999);
				DisplayTool.TurnOffCountMode();
				DisplayTool.display(info);
				info = AbsoluteFilePaths.elementAt(i);
				Tool.writeLog(info,MassCheckErrorCollection.HYPER_LINK);
				DisplayTool.display(info);
				Tool.TurnOnCountMode();
				DisplayTool.TurnOnCountMode();
				EFEMassCheckDispatcher dispatcher = new EFEMassCheckDispatcher();
				dispatcher.fillTask(formScanner.getHiddenSubformNode(),
						formScanner.gettitleSets(),formScanner.getinfoBlockHeader(),formScanner.getAddressBlockSets(),formScanner.gettableheaderSubformSets(),
						formScanner.gettableRemarkSubformSets(),formScanner.gettableOuterMostSubformSets(),
						formScanner.getfreeBlockSubformSets(),formScanner.getsummBlockSubformSets(),formScanner.getOtherTextFields());
				dispatcher.dispatch();
				Tool.newLine();
				DisplayTool.newLine();
			}
		}
		Tool.closeLog();
		Tool.ResetSwitch();
	}
}