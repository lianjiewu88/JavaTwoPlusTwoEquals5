package customMarkupForAFC.EFEMassCheck;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import configuration.ConfigDom;
import utilities.FileCopyFactory;
import utilities.Tool;
import utilities.FieldLocation;

public class FormScanner
{
	private FileCopyFactory filecopy;
	private Document doc;
	private DocumentBuilder dombuilder;
	private DocumentBuilderFactory domfac;
	private Node HiddenSubform = null;
	private Vector<Node> titleSets = null;
	private Vector<Node> infoBlockHeader = null;
	private Vector<Node> addressBlockSubformSets = null;
	private Vector<Node> tableheaderSubformSets = null;
	private Vector<Node> tableRemarkSubformSets = null;
	private Vector<Node> tableOuterMostSubformSets = null;
	private Vector<Node> freeBlockSubformSets = null;
	private Vector<Node> summBlockSubformSets = null;
	private Vector<Node> allOtherTextField = null;
	
	public FormScanner()
	{
		domfac = DocumentBuilderFactory.newInstance();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
			titleSets = new Vector<Node>();
			infoBlockHeader = new Vector<Node>();
			tableheaderSubformSets = new Vector<Node>();
			tableOuterMostSubformSets = new Vector<Node>();
			freeBlockSubformSets = new Vector<Node>();
			summBlockSubformSets = new Vector<Node>();
			tableRemarkSubformSets = new Vector<Node>();
			addressBlockSubformSets = new Vector<Node>();
			allOtherTextField = new Vector<Node>();
			HiddenSubform = null;
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}
	public Node getHiddenSubformNode()
	{
		return HiddenSubform;
	}
	public Vector<Node> gettitleSets()
	{
		return titleSets;
	}
	public Vector<Node> getinfoBlockHeader()
	{
		return infoBlockHeader;
	}
	public Vector<Node> gettableheaderSubformSets()
	{
		return tableheaderSubformSets;
	}
	public Vector<Node> gettableRemarkSubformSets()
	{
		return tableRemarkSubformSets;
	}
	public Vector<Node> gettableOuterMostSubformSets()
	{
		return tableOuterMostSubformSets;
	}
	public Vector<Node> getfreeBlockSubformSets()
	{
		return freeBlockSubformSets;
	}
	public Vector<Node> getsummBlockSubformSets()
	{
		return summBlockSubformSets;
	}
	public Vector<Node> getAddressBlockSets()
	{
		return addressBlockSubformSets;
	}
	public Vector<Node> getOtherTextFields()
	{
		return allOtherTextField;
	}
	private void initialize()
	{
		titleSets.clear();
		infoBlockHeader.clear();
		addressBlockSubformSets.clear();
		tableheaderSubformSets.clear();
		tableOuterMostSubformSets.clear();
		freeBlockSubformSets.clear();
		summBlockSubformSets.clear();
		tableRemarkSubformSets.clear();
		allOtherTextField.clear();
		HiddenSubform = null;
	}
	public String getTimeStamp(String inputXDPName)
	{
		try 
		{
			filecopy = new FileCopyFactory();
			if( Tool.CheckInputXDPFileExistence(inputXDPName) == false)
				return null;
			String OutputXMLFile = filecopy.copyFile(inputXDPName);
			if (OutputXMLFile == null)
				return null;
			InputStream inputXML = new FileInputStream(OutputXMLFile);
			doc = dombuilder.parse(inputXML);
			Element root = doc.getDocumentElement();
			
			// but only template DOM is our concern...
			filecopy.DeleteUnusedXML(OutputXMLFile);
			return Tool.getAttributeValue("timeStamp",root);
		}
		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
		return null;
	}
	public boolean getAllAdobeFields(String inputXDPName)
	{
		try 
		{
			initialize();
			filecopy = new FileCopyFactory();
			if( Tool.CheckInputXDPFileExistence(inputXDPName) == false)
				return false;
			String OutputXMLFile = filecopy.copyFile(inputXDPName);
			if (OutputXMLFile == null)
				return false;
			InputStream inputXML = new FileInputStream(OutputXMLFile);
			doc = dombuilder.parse(inputXML);
			Element root = doc.getDocumentElement();
			
			// but only template DOM is our concern...
			filecopy.DeleteUnusedXML(OutputXMLFile);
			Node template = Tool.getNodebyRoot("template",root);
			if( template == null)
				return false;
			// main modifications are here
			Scan(template);
		}
		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
		return true;
	}

	private void Scan(Node parent)
	{
		NodeList child = parent.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		String subformName = null;
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				subformName = Tool.getAttributeValue("name",item);
				if( subformName == null)
					continue;
				// 2008-08-18: must display "frmFloatFields" now
				int type = FieldLocation.getSubformLocation(subformName);
				if( (Tool.isFieldHidden(item) ) && ( type != FieldLocation.HIDDEN_SUBFORM ))
					continue;
				if( type == FieldLocation.BODY_PAGE) 
					Scan(item);	
				else if ( type == FieldLocation.TABLE_OUTER_SUBFORM) 
				{
					// add 2008-08-21: Collect all table outer-most subforms here
					tableOuterMostSubformSets.add(item);
					getTableA1SNode(item);
				} 
				else if ( type == FieldLocation.ADDRESS_BLOCK)
				{
					addressBlockSubformSets.add(item);
				}
				else if( type == FieldLocation.INFO_BLOCK )
				{
					HandleWithInfoBlockForA1SNode(item,true);	
				}
				// add April 21st,2008: handlement with free text block
				// make sapa1s node shown in UI
				else if ( type == FieldLocation.FREE_TEXT_BLOCK )
				{
					freeBlockSubformSets.add(item);
				}
				// 2008-08-18 display UI for user to change possible fields
				// in the free text block
				else if ( type == FieldLocation.HIDDEN_SUBFORM)
				{
					HiddenSubform = item;
				}
				else if( type == FieldLocation.SUMMARY_BLOCK)
				{
					summBlockSubformSets.add(item);
				}
				else  
				{
					Scan(item);
				}
			} 
			else if (item.getNodeName().equals("pageSet")) 
			{
				HandlePageSet(item);
			}
			else if (item.getNodeName().equals("field"))
			{
				// 2008-10-07:
				allOtherTextField.add(item);
				getA1SNodeforField(item);
			}
			else if (item.getNodeName().equals("draw"))
			{
				getA1SNodeforDraw(item);
			}
		}
	}
	
	//	 2008-09-10: add recursively for Service Request by Belle
	private void HandlePageSet(Node pageSet)
	{
		NodeList masterChild = pageSet.getChildNodes();
		Node masterPageitem = null;
		int masterChildLength = masterChild.getLength();
		for (int j = 0; j < masterChildLength; j++) 
		{
			masterPageitem = masterChild.item(j);
			if (masterPageitem.getNodeName().equals("pageArea"))
			{
				HandlePageAreaForA1SNode(masterPageitem);
			}
			else if ( masterPageitem.getNodeName().equals("pageSet"))
			{
				HandlePageSet(masterPageitem);
			}
		}
	}
	private void getA1SNodeforField(Node node)
	{
		
	}
	private void getA1SNodeforDraw(Node node)
	{
		// handle with nodes which is neither in info block nor
		// free text block nor table
		/*String name = getAttributeValue("name",node);
		ResultDescription.add(name);
		*/
		String name = Tool.getAttributeValue("name", node);
		if( name == null)
			return;
		if( name.equals(ConfigDom.getTitleNamingConvention()))
		{
			titleSets.add(node);
		}
	}
	
	private void HandlePageAreaForA1SNode(Node PageArea) 
	{
		NodeList child = PageArea.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				String SubformName = Tool.getAttributeValue("name",item);
				int type = FieldLocation.getSubformLocation(SubformName);
				if( type == FieldLocation.INFO_BLOCK)
				{
					// this function can handle with all the nodes into that subform
					HandleWithInfoBlockForA1SNode(item,true);	
				}
				else if ( type == FieldLocation.ADDRESS_BLOCK)
					addressBlockSubformSets.add(item);
				else // summary block,free text block
				{
					Scan(item);
				}
			} 
			else if (item.getNodeName().equals("field")) 
			{
				allOtherTextField.add(item);
				getA1SNodeforField(item);
			} 
			else if (item.getNodeName().equals("draw")) 
			{
				getA1SNodeforDraw(item);
			}
		}
	}
	private void HandleWithInfoBlockForA1SNode(Node node,boolean isFirstEntry)
	{
		if( Tool.isFieldHidden(node) == true)
		// do not handle with the hidden subform
			return;		
		if( isFirstEntry)
			infoBlockHeader.add(node);
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for(int i = 0; i < childLength;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
				HandleWithInfoBlockForA1SNode(item,false);
			// no need to get fields inside the infoblock anymore
		}
	}
	
	private void getTableContentRowA1SNode(Node node)
	{
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);

			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				// nested table
				if( Tool.isFieldHidden(item))
					continue;
				String SubformName = Tool.getAttributeValue("name",item);
				// add 2008-06-03 hidden subform in the table must be ignored.
				if( Tool.isFieldHidden(item) == true)
					continue;
				int type = FieldLocation.getSubformLocation(SubformName);
				if( type == FieldLocation.TABLE_OUTER_SUBFORM)
					getTableA1SNode(item);
				else if ( type == FieldLocation.TABLE_CONTENT_SUBFORM)
				{
					getTableContentRowA1SNode(item);
				} 
				else if ( type == FieldLocation.REMARK_ROW)
				{
					tableRemarkSubformSets.add(item);
				}
				else 
				{
					System.out.println("Traverse into the subform in the content row!");
					Scan(item);
				}
			}
		}
	}
	private void getTableA1SNode(Node parent) 
	{
		NodeList child = parent.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				String SubformName = Tool.getAttributeValue("name",item); 
				int type = FieldLocation.getSubformLocation(SubformName);
				if( type == FieldLocation.TABLE_HEADER_SUBFORM)
				{
					tableheaderSubformSets.add(item);
				}
				else if ( type == FieldLocation.TABLE_CONTENT_SUBFORM)
				{
					getTableContentRowA1SNode(item);
				}
				else if ( type == FieldLocation.TABLE_OUTER_SUBFORM)
				{
					getTableA1SNode(item);
				}
				else 
				{
					Scan(item);
				}
			}
		}
	}
}