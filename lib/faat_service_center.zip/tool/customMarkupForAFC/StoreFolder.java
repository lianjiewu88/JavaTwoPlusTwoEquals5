package customMarkupForAFC;

import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import java.awt.Dimension;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import javax.swing.JTextField;
import java.awt.Cursor;

public class StoreFolder extends JDialog {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel jHelpLabel = null;

	private JButton jSelectButton = null;

	private JButton jOKButton = null;

	private JButton jCancelButton = null;

	private JPanel jButtonPanel = null;

	private JTextField jResult = null;
	
	private String StoreFolderPath = null;
	
	private boolean isReadyForProcessing = false;
	
	private int XPosition;
	private int YPosition;

	public String getStoreFolderPath()
	{
		return StoreFolderPath;
	}
	public int GetXPosition()
	{
		return XPosition;
	}
	public int GetYPosition()
	{
		return YPosition;
	}
	/**
	 * This method initializes jSelectButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	public boolean IsStoreOK()
	{
		return isReadyForProcessing;
	}
	private JButton getJSelectButton() {
		if (jSelectButton == null) {
			jSelectButton = new JButton();
			jSelectButton.setText("Select");
			jSelectButton.setPreferredSize(new Dimension(80, 26));
			jSelectButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser jFileChooser = new JFileChooser();
					jFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					 int option = jFileChooser.showOpenDialog(null);
				     if (option == JFileChooser.APPROVE_OPTION) 
				     {
				    	 SetBold(jResult);
				    	 jResult.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	 jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	 StoreFolderPath = jFileChooser.getSelectedFile().getAbsolutePath();
				    	 
				     }
				     else 
				     {
				    	 jResult.setText("You canceled.");
				     }
				}
			});
		}
		return jSelectButton;
	}

	private void SetBold(JTextField textfield)
	{
		JTextField input = textfield;
		Font oldFont = textfield.getFont();
		Font newFont = new Font(oldFont.getFontName(),oldFont.getStyle() | Font.BOLD,14);
		input.setFont(newFont);
	}
	/**
	 * This method initializes jOKButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJOKButton() {
		if (jOKButton == null) {
			jOKButton = new JButton();
			jOKButton.setText("OK");
			jOKButton.setPreferredSize(new Dimension(80, 26));
			jOKButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					isReadyForProcessing = true;
					CloseDialog();
				}
			});
		}
		return jOKButton;
	}
	private void CloseDialog()
	{
		this.dispose();
	}
	/**
	 * This method initializes jCancelButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJCancelButton() {
		if (jCancelButton == null) {
			jCancelButton = new JButton();
			jCancelButton.setText("Cancel");
			jCancelButton.setPreferredSize(new Dimension(80, 26));
			jCancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					CloseDialog();
				}
			});
		}
		return jCancelButton;
	}

	/**
	 * This method initializes jButtonPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJButtonPanel() {
		if (jButtonPanel == null) {
			jButtonPanel = new JPanel();
			jButtonPanel.setLayout(new FlowLayout());
			jButtonPanel.setBounds(new Rectangle(42, 62, 366, 36));
			jButtonPanel.add(getJSelectButton(), null);
			jButtonPanel.add(getJOKButton(), null);
			jButtonPanel.add(getJCancelButton(), null);
		}
		return jButtonPanel;
	}

	/**
	 * This method initializes jResult	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJResult() {
		if (jResult == null) {
			jResult = new JTextField();
			jResult.setEditable(false);
			jResult.setAutoscrolls(false);
			jResult.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			jResult.setBounds(new Rectangle(13, 107, 437, 27));
		}
		return jResult;
	}

	/**
	 * @param args
	 */


	/**
	 * @param owner
	 */
	public StoreFolder(Frame owner,int x,int y) {
		super(owner);
		XPosition = x;
		YPosition = y;
		initialize();
		this.setLocation(x,y);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(472, 172);
		this.setName("Select Template Store Folder");
		this.setModal(true);
		this.setContentPane(getJContentPane());
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jHelpLabel = new JLabel();
			jHelpLabel.setText("  Please select a folder to store all the modified template");
			jHelpLabel.setBounds(new Rectangle(43, 19, 366, 32));
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(jHelpLabel, null);
			jContentPane.add(getJButtonPanel(), null);
			jContentPane.add(getJResult(), null);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
