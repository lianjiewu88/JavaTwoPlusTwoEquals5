package customMarkupForAFC;

import org.w3c.dom.Node;
import utilities.Tool;
import configuration.*;

public class MarkupDescriptionHandler
{
	private  MarkupObject markupObject = null;
	private  Input newInput = null;
	
	public MarkupDescriptionHandler(MarkupObject obj)
	{
		markupObject = obj;
	}
	public void SetTask(Input input)
	{
		newInput = input;
	}
	public boolean WriteNewDescription()
	{
		int type  = markupObject.getType();
		System.out.println("Type: " + type);
		switch (type)
		{
			case CustomMarkupConfigDom.INFOBLOCK_FIELD:
				HandleInfoBlock();
				break;
			case CustomMarkupConfigDom.INFOBLOCK_SUBFORM: 
				HandleInfoBlockSubform();
				break;
			case CustomMarkupConfigDom.FREEBLOCK_FIELD:
				HandleFreeBlockItem();
				break;
			case CustomMarkupConfigDom.FREEBLOCK_SUBFORM:
				HandleFreeblockSubform();
				break;
			/* delete 2008 -06-10
			case TABLE_COLUMN:
				HandleTableRow();
				break;
			*/
			case CustomMarkupConfigDom.TABLE_SUBFORM:
				HandleTableSubform();
				break;
			case CustomMarkupConfigDom.TABLE_HEADER_FIELD:
				HandleTableHeader();
				break;
			case CustomMarkupConfigDom.REMARK_FIELD:
				HandleTableRemarkField();
				break;
			case CustomMarkupConfigDom.SUMM_LABEL:
				HandleSummaryLabel();
				break;
			case CustomMarkupConfigDom.SUMM_SUBFORM:
				HandleSummaryBlock();
				break;
			default:
				return false;
		}
		return true;
	}
		
	private boolean HandleSummaryLabel()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node InfoBlockItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getSummaryLabelName(),A1SNode);
		if( InfoBlockItem == null)
			return false;
		Node Description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),InfoBlockItem);
		if( Description == null)
			return false;
		Description.setTextContent(newInput.getDescription());
		return true;
	}
	private boolean HandleSummaryBlock()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node InfoBlockItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getSummaryBlockSubformName(),A1SNode);
		if( InfoBlockItem == null)
			return false;
		Node Description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),InfoBlockItem);
		if( Description == null)
			return false;
		Description.setTextContent(newInput.getDescription());
		return true;
	}
	private boolean HandleTableSubform()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node Table = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableSubformNodeName(),A1SNode);
		if( Table == null)
			return false;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),Table);
		if( title == null)
			return false;
		title.setTextContent(newInput.getDescription());
		String newTargetwidth = newInput.gettargetWidth();
		Table.getAttributes().getNamedItem(CustomMarkupConfigDom.getTableTargetWidthAttributeName()).setNodeValue(newTargetwidth);
		markupObject.SetTargetWidth(newTargetwidth);
		return true;
	}
	private boolean HandleTableRemarkField()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node InfoBlockItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableRemarkFieldName(),A1SNode);
		if( InfoBlockItem == null)
			return false;
		Node Description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),InfoBlockItem);
		if( Description == null)
			return false;
		Description.setTextContent(newInput.getDescription());
		return true;
	}
	private boolean HandleFreeblockSubform()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node InfoBlockItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getFreeTextBlockSubformNodeName(),A1SNode);
		if( InfoBlockItem == null)
			return false;
		Node Description = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),InfoBlockItem);
		if( Description == null)
			return false;
		Description.setTextContent(newInput.getDescription());
		return true;
	}
	private boolean HandleFreeBlockItem()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node InfoBlockItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getFreeTextItem(),A1SNode);
		if( InfoBlockItem == null)
			return false;
		Node Description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),InfoBlockItem);
		if( Description == null)
			return false;
		Description.setTextContent(newInput.getDescription());
		return true;
	}
	private boolean HandleInfoBlockSubform()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node InfoBlockItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getInfoBlockSubformNodeName(),A1SNode);
		if( InfoBlockItem == null)
			return false;
		Node Description = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),InfoBlockItem);
		if( Description == null)
			return false;
		Description.setTextContent(newInput.getDescription());
		return true;
	}
	private boolean HandleTableHeader()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node TableRowItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableHeaderNodeName(),A1SNode);
		if( TableRowItem == null)
			return false;
		Node Description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),TableRowItem);
		if( Description == null)
			return false;
		Description.setTextContent(newInput.getDescription());
		TableRowItem.getAttributes().getNamedItem(CustomMarkupConfigDom.getCopyAttributeName()).setNodeValue(newInput.getCopyAttribute());
		markupObject.SetCopyAttribute(newInput.getCopyAttribute());
		TableRowItem.getAttributes().getNamedItem(CustomMarkupConfigDom.getfixedWidthAttributeName()).setNodeValue(newInput.getFixWidthValue());
		markupObject.SetFixWidthAttribute(newInput.getFixWidthValue());
		TableRowItem.getAttributes().getNamedItem(CustomMarkupConfigDom.getTableminiumWidthNodeName()).setNodeValue(newInput.getminiumWidth());
		markupObject.SetMiniumWidth(newInput.getminiumWidth());
		return true;
	}
	/* delete 2008-06-10 No need this function
	private boolean HandleTableRow()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node TableRowItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableColumnNodeName(),A1SNode);
		if( TableRowItem == null)
			return false;
		Node Description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),TableRowItem);
		if( Description == null)
			return false;
		Description.setTextContent(newInput.getDescription());
		return true;
	}
	*/

	private boolean HandleInfoBlock()
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),markupObject.getNode());
		if( A1SNode == null)
			return false;
		Node InfoBlockItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getInfoBlockItemNodeName(),A1SNode);
		if( InfoBlockItem == null)
			return false;
		Node Description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),InfoBlockItem);
		if( Description == null)
			return false;
		Description.setTextContent(newInput.getDescription());
		String newCopy = newInput.getCopyAttribute();
		System.out.println("New: " + newCopy);
		InfoBlockItem.getAttributes().getNamedItem(CustomMarkupConfigDom.getCopyAttributeName()).setNodeValue(newCopy);
		markupObject.SetCopyAttribute(newCopy);
		return true;
	}
}