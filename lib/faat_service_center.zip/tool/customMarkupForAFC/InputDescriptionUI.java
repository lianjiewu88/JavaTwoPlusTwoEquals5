/* UI Text Are Maintained in this file ! 
 * 
 */

package customMarkupForAFC;
import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.Rectangle;
import javax.swing.JButton;
import java.awt.Point;
import java.util.Vector;
import javax.swing.JComboBox;

import utilities.Tool;
import configuration.CustomMarkupConfigDom;
import customMarkupForAFC.markupProcessor.internalObject.FormFieldCaption;
import java.awt.event.KeyEvent;

public class InputDescriptionUI extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;

	private JLabel jOldLabel = null;

	private JLabel jNewLabel = null;

	private JTextField jNewTextField = null;

	private JButton jOKButton = null;

	private JButton jCancelButton = null;

	private JTextField jOldTextField = null;
	
	private Input newinputbyDeveloper = null;
	
	private MarkupObject markupObject = null;
	
	private MarkupDescriptionHandler markHandler = null;
	
	private boolean isChangeOK = false;

	private JComboBox jComboBox = null;

	private JLabel jLabel = null;

	private JLabel jFixLabel = null;

	private JComboBox jFixComboBox = null;
	
	Vector<String> header = null;

	private JLabel jMiniLabel = null;

	private JTextField jMiniumWTextField = null;

	private JLabel jTargetWidth = null;

	private JTextArea outputField = null;
	
	private final int FALSE_INDEX = 1;
	private JLabel jUnitLabel2 = null;
	private JComboBox jComboBox1 = null;

	/**
	 * This method initializes jNewTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJNewTextField() {
		if (jNewTextField == null) {
			jNewTextField = new JTextField();
			jNewTextField.setLocation(new Point(4, 59));
			jNewTextField.setSize(new Dimension(324, 20));
			if( markupObject.getType() == CustomMarkupConfigDom.FORM_TITLE )
				jNewTextField.setEnabled(false);
		}
		return jNewTextField;
	}

	public boolean getChangeStatus()
	{
		return isChangeOK;
	}

	public String getNewDescription()
	{
		if( newinputbyDeveloper == null)
			return null;
		return newinputbyDeveloper.getDescription();
	}
	private void CloseDialog()
	{
		this.dispose();
	}
	private void ErrorReport(String Message)
	{
	    JOptionPane.showMessageDialog(new JFrame(), Message, "ERROR",
	        JOptionPane.ERROR_MESSAGE);
	}
	/**
	 * This method initializes jOKButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJOKButton() {
		if (jOKButton == null) {
			jOKButton = new JButton();
			jOKButton.setText("OK");
			jOKButton.setSize(new Dimension(73, 22));
			jOKButton.setLocation(new Point(230, 91));
			jOKButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					if( markupObject.getType() == CustomMarkupConfigDom.FORM_TITLE)
						return;
					// get new description from user input and write back this change
					String newDescription = jNewTextField.getText();
					// get new copyfromCustomFields from UI
					String copyFromCustomFields = jComboBox.getSelectedItem().toString();
					String fixedWidth = jFixComboBox.getSelectedItem().toString();
					String miniumWidth = jMiniumWTextField.getText();
					String TargetWidth = jComboBox1.getSelectedItem().toString();
					if( newDescription == null)
					{
						System.out.println("You should not assign null description to this field!");
						CloseDialog();
						return;
					}
					/* April 30,2008:Needn't this handlement any more,because
					 * Thierry has asked all the default value are "" 
					 * if( newDescription.trim().equals(""))
					{
						System.out.println("You should not assign empty description to this field!");
						CloseDialog();
						return;
					}*/
					if( (markupObject.isValidNumber(miniumWidth) == null) && (markupObject.isTableHeader()) )
					{
						//System.out.println("MiniumWidth: " + miniumWidth);
						ErrorReport("You Must Input An Integer!");
						return;
					}
					newinputbyDeveloper = new Input(markupObject,newDescription,copyFromCustomFields,fixedWidth,miniumWidth,TargetWidth);
					/* 2008-08-26 issue reported by Thierry: targetWidth must be the sensitive string,not the mm
					if( (markupObject.isTableOuterSubform()) && (markupObject.isValidNumber(TargetWidth) == null) )
					{
						ErrorReport("You Must Input An Integer!");
						return;
					}*/
					/* REPLAYED by NEW FUNCTION isValidNumber 2008-05-30
					 * if( markupObject.isTableHeader() && !newinputbyDeveloper.VerifyMiniumWidth())
					{
						ErrorReport("You must input the new Width without \"mm\" ");
						return;
					}*/
					markHandler.SetTask(newinputbyDeveloper);
					isChangeOK = markHandler.WriteNewDescription();
					newDescription = "\n\t" + "New Description: " + newDescription;
					outputField.setText(newDescription);
					if( isChangeOK )
						System.out.println("New Description: " + newDescription + " Write Back Successfully!");
					CloseDialog();
				}
			});
		}
		return jOKButton;
	}

	/**
	 * This method initializes jCancelButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJCancelButton() {
		if (jCancelButton == null) {
			jCancelButton = new JButton();
			jCancelButton.setLocation(new Point(230, 122));
			jCancelButton.setText("Cancel");
			jCancelButton.setSize(new Dimension(73, 21));
			jCancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					CloseDialog();
				}
			});
		}
		return jCancelButton;
	}

	/**
	 * This method initializes jOldTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJOldTextField() {
		if (jOldTextField == null) {
			jOldTextField = new JTextField();
			jOldTextField.setLocation(new Point(4, 15));
			jOldTextField.setEditable(false);
			jOldTextField.setSize(new Dimension(324, 20));
			/*jOldTextField.addActionListener(new java.awt.event.ActionListener() 
			{
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});*/
		}
		return jOldTextField;
	}

	
	public InputDescriptionUI(Frame owner,MarkupObject obj,JTextArea field) {
		super(owner);
		markupObject = obj;
		markHandler = new MarkupDescriptionHandler(obj);
		header = new Vector<String>();
		header.add("true");
		header.add("false");
		outputField = field;
		/* 2008-08-25 must set the default value according to type of obj
		 * to guide the user better
		 */
		initialize();
	}
	private void setTitle()
	{
		int type = markupObject.getType();
		switch (type)
		{
			case CustomMarkupConfigDom.FORM_TITLE:
				this.setTitle("Form Title Specific Setting");
				jNewTextField.setText("Currently No Setting Can be Supported for Form Title");
				break;
			case CustomMarkupConfigDom.INFOBLOCK_SUBFORM:
				this.setTitle("InfoBlock Subform Specific Setting");
				jNewTextField.setText("Info Block#");
				break;
			case CustomMarkupConfigDom.INFOBLOCK_FIELD:
				this.setTitle("InfoBlock Field Specific Setting");
				jNewTextField.setText(FormFieldCaption.getNodeFormattedCaption(markupObject.getNode()));
				break;
			case CustomMarkupConfigDom.FREEBLOCK_SUBFORM:
				this.setTitle("Free Text Block Subform Specific Setting");
				jNewTextField.setText("Free Text Block#");
				break;
			case CustomMarkupConfigDom.FREEBLOCK_FIELD:
				this.setTitle("Free Text Block Field Specific Setting");
				jNewTextField.setText(FormFieldCaption.getNodeFormattedCaption(markupObject.getNode()));
				break;
			case CustomMarkupConfigDom.TABLE_SUBFORM:
				this.setTitle("Table Subform Specific Setting");
				jNewTextField.setText("Table#");
				break;
			case CustomMarkupConfigDom.TABLE_HEADER_FIELD:
				this.setTitle("Table Header Field Specific Setting");
				break;
			case CustomMarkupConfigDom.REMARK_FIELD:
				this.setTitle("Table Remark Field Specific Setting");
				break;
			case CustomMarkupConfigDom.SUMM_LABEL:
				this.setTitle("Summary Label Field Specific Setting");
				break;
			case CustomMarkupConfigDom.SUMM_SUBFORM:
				this.setTitle("Summary Block Subform Specific Setting");
				jNewTextField.setText("Summary Block#");
				break;
		}
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(346, 230);
		this.setResizable(false);
		this.setModal(true);
		this.setContentPane(getJContentPane());
		setTitle();
		jOldTextField.setText(markupObject.getDescription());
		// 2009-01-19: suggested by Arnold
		if( markupObject.getType() != CustomMarkupConfigDom.TABLE_HEADER_FIELD)
			return;
		String description = Tool.getTableCaptionasDescription(markupObject.getNode());
		if( description != null)
			jNewTextField.setText(description);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jUnitLabel2 = new JLabel();
			jUnitLabel2.setText("mm");
			jUnitLabel2.setLocation(new Point(209, 151));
			jUnitLabel2.setSize(new Dimension(38, 16));
			jTargetWidth = new JLabel();
			jTargetWidth.setText("TargetWidth:");
			jTargetWidth.setLocation(new Point(10, 172));
			jTargetWidth.setSize(new Dimension(89, 17));
			jMiniLabel = new JLabel();
			jMiniLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			jMiniLabel.setSize(new Dimension(89, 17));
			jMiniLabel.setLocation(new Point(10, 151));
			jMiniLabel.setText("MiniumWidth:");
			jFixLabel = new JLabel();
			jFixLabel.setBounds(new Rectangle(10, 119, 89, 19));
			jFixLabel.setText("FixedWidth:");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(9, 84, 89, 34));
			jLabel.setText("copyForCustomFields:");
			jNewLabel = new JLabel();
			jNewLabel.setText("New Description");
			jNewLabel.setLocation(new Point(4, 44));
			jNewLabel.setSize(new Dimension(104, 16));
			jOldLabel = new JLabel();
			jOldLabel.setBounds(new Rectangle(4, -1, 103, 16));
			jOldLabel.setText("Old Description");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.setName("Change Description");
			jContentPane.add(jOldLabel, null);
			jContentPane.add(jNewLabel, null);
			jContentPane.add(getJNewTextField(), null);
			jContentPane.add(getJOKButton(), null);
			jContentPane.add(getJCancelButton(), null);
			jContentPane.add(getJOldTextField(), null);
			jContentPane.add(getJComboBox(), null);
			jContentPane.add(jLabel, null);
			jContentPane.add(jFixLabel, null);
			jContentPane.add(getJFixComboBox(), null);
			jContentPane.add(jMiniLabel, null);
			jContentPane.add(getJMiniumWTextField(), null);
			jContentPane.add(jTargetWidth, null);
			jContentPane.add(jUnitLabel2, null);
			jContentPane.add(getJComboBox1(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBox() {
		if (jComboBox == null) 
		{
			jComboBox = new JComboBox(header);
			jComboBox.setSize(new Dimension(94, 25));
			jComboBox.setLocation(new Point(108, 85));
			if( !markupObject.hasCopyFromAttribute())
				jComboBox.setEnabled(false);
			else if( markupObject.getCopyAttributeValue().equals("false"))
				jComboBox.setSelectedIndex(FALSE_INDEX);
		}
		return jComboBox;
	}

	/**
	 * This method initializes jFixComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJFixComboBox() {
		if (jFixComboBox == null) {
			jFixComboBox = new JComboBox(header);
			jFixComboBox.setPreferredSize(new Dimension(32, 25));
			jFixComboBox.setSize(new Dimension(94, 25));
			jFixComboBox.setLocation(new Point(108, 119));
			if( !markupObject.hasFixWidthAttribute())
				jFixComboBox.setEnabled(false);
			else if ( markupObject.getFixWidthAttributeValue().equals("false"))
				jFixComboBox.setSelectedIndex(FALSE_INDEX);
		}
		return jFixComboBox;
	}

	/**
	 * This method initializes jMiniumWTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJMiniumWTextField() {
		if (jMiniumWTextField == null) {
			jMiniumWTextField = new JTextField();
			jMiniumWTextField.setSize(new Dimension(94, 17));
			jMiniumWTextField.setLocation(new Point(108, 151));
			if( !markupObject.hasFixWidthAttribute())
				jMiniumWTextField.setEditable(false);
			else
			{
				String width = markupObject.getMiniumWidth();
				if( width != null)
					jMiniumWTextField.setText(width);
				else
					ErrorReport("You Must Input An Integer!");
			}
		}
		return jMiniumWTextField;
	}
	

	/**
	 * This method initializes jComboBox1	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBox1() {
		if (jComboBox1 == null) 
		{
			Vector<String> header = new Vector<String>();
			header.add(CustomMarkupConfigDom.TableTargetWidthType1);
			header.add(CustomMarkupConfigDom.TableTargetWidthType2);
			header.add(CustomMarkupConfigDom.TableTargetWidthType3);
			header.add(CustomMarkupConfigDom.TableTargetWidthType4);
			jComboBox1 = new JComboBox(header);
			jComboBox1.setSize(new Dimension(124, 23));
			jComboBox1.setLocation(new Point(108, 174));
			jComboBox1.setEnabled(false);
			if( markupObject.isTableOuterSubform())
				jComboBox1.setEnabled(true);
		}
		return jComboBox1;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
