package customMarkupForAFC;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
import utilities.Tool;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextArea;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import utilities.FileCopyFactory;
import utilities.FieldLocation;
import configuration.*;
import customMarkupForAFC.EFECheckUltilities.*;
import customMarkupForAFC.EFECorrection.SaveVerification;

public class MarkupUI
{
	private DocumentBuilderFactory domfac;

	private DocumentBuilder dombuilder;

	private FileCopyFactory filecopy;
	
	private ArrayList<MarkupObject> ResultDescription;

	private Document doc;
	
	private Vector<Node> titleSets = null;
	
	private Vector<Node> AddressBlockSets = null;
	
	private Vector<Node> infoBlockHeader = null;
	
	private Vector<Node> tableheaderSubformSets = null;
	
	private Vector<Node> tableRemarkSubformSets = null;
	
	private Vector<Node> tableOuterMostSubformSets = null;
	
	private Vector<Node> freeBlockSubformSets = null;
	
	private Vector<Node> summBlockSubformSets = null;
	
	private Vector<Node> allOtherTextfields = null;
	
	private Node HiddenSubform = null;
	
	private Node bodyPageNode = null;
	
	private int NodeIndex = 0;
	
	private HashMap<DefaultMutableTreeNode,String> hashMap = null;
	
	private ArrayList<Node> NodeList = null;			// used for search backup node
	
	private ArrayList<DefaultMutableTreeNode> ModuleTreeBackUpList = null;

	private DefaultTreeModel TreeMode;
	
	private DefaultMutableTreeNode root;
	
	private DefaultMutableTreeNode parentNode;
	
	private DefaultListModel ListMode = null;
	
	private JList jList = null;
	
	private JTextArea outputField = null;
	
	private final String INVALIDCOPYATTRI = "invalidCopyAttribute";
	
	// must be the same as those in MarkupObject.java
	
	public MarkupUI(DefaultListModel mode,JList list,JTextArea field) 
	{  
		ListMode = mode;
		jList = list;
		outputField = field;
		ResultDescription = new ArrayList<MarkupObject>();
		hashMap = new HashMap<DefaultMutableTreeNode,String>();
		NodeList = new ArrayList<Node>();
		ModuleTreeBackUpList = new ArrayList<DefaultMutableTreeNode>();
		titleSets = new Vector<Node>();
		infoBlockHeader = new Vector<Node>();
		tableheaderSubformSets = new Vector<Node>();
		tableOuterMostSubformSets = new Vector<Node>();
		freeBlockSubformSets = new Vector<Node>();
		summBlockSubformSets = new Vector<Node>();
		tableRemarkSubformSets = new Vector<Node>();
		AddressBlockSets = new Vector<Node>();
		allOtherTextfields = new Vector<Node>();
		domfac = DocumentBuilderFactory.newInstance();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}
	// occurance at least 1 ( itself )
	public int getOccurance(int indexInListBox)
	{
		MarkupObject Obj = ResultDescription.get(indexInListBox);
		if( Obj == null)
			return -1;
		if( Obj.getObjectName() == null)
			return -1;
		int occurance = 0;
		MarkupObject item = null;
		int size = ResultDescription.size();
		for( int i = 0 ; i < size;i++)
		{
			item = ResultDescription.get(i);
			if( item.getObjectName() == null )
				continue;
			if( item.getObjectName().equals(Obj.getObjectName()))
				occurance++; 
		}
		return occurance;
	}
	public int convertAbsolute2RelativeIndex(int AbsoluteIndex)
	{
		String hitName = ResultDescription.get(AbsoluteIndex).getObjectName();
		int size = ResultDescription.size();
		String name = null;
		ArrayList<Integer> temp = new ArrayList<Integer>();
		for( int i = 0 ; i < size;i++)
		{
			name = ResultDescription.get(i).getObjectName();
			if( name == null)
				continue;
			if( name.equals(hitName))
				temp.add(i);
		}
		// find relative index
		// System.out.println("AbsoluteIndex: " + AbsoluteIndex);
		// System.out.println("All found number: " + temp.size());
		int match = temp.indexOf(AbsoluteIndex);
		match++;
		temp.clear();
		temp = null;
		return match;
	}
	public String getInvalidCopyFlag()
	{
		return INVALIDCOPYATTRI;
	}
	public void display()
	{
		ListMode.clear();
		jList.setEnabled(true);
		int ListDataSize = ResultDescription.size();
		MarkupObject object = null;
		String data = null;
		for(int k = 0 ; k < ListDataSize; k ++ )
		{
			object = ResultDescription.get(k);
			data = object.FormatOutput();
			ListMode.addElement(data);
			outputField.setText(object.getDescription());
		}
		jList.updateUI();
	}

	public void UpdateDescriptionCollection(int index,String newDescription)
	{
		MarkupObject modified = ResultDescription.get(index);//.clone();
		modified.SetNewDescription(newDescription);
		modified.setStatus(true);
		//ResultDescription.remove(index);
		//ResultDescription.add(index,modified);
	}
	private String FormatSavePath(String path)
	{
		int index = path.lastIndexOf('.');
		if( index != -1)
			return path;
		String newPath = path + ".xdp";
		return newPath;
	}

	private boolean checkFormTitle()
	{
		EFEFormTitleChecker titleChecker = new EFEFormTitleChecker(titleSets,jList,ResultDescription);
		boolean ret = titleChecker.run();
		titleChecker = null;
		return ret;
	}
	private boolean checkTexTFieldReadOnly()
	{
		EFEReadOnlyChecker readChecker = new EFEReadOnlyChecker(allOtherTextfields);
		boolean ret = readChecker.run();
		readChecker = null;
		return ret;
	}
	private boolean checkInfoblock()
	{
		EFEInfoblockChecker infoBlockChecker = new EFEInfoblockChecker(infoBlockHeader,jList,ResultDescription);
		boolean ret = infoBlockChecker.run();
		infoBlockChecker = null;
		return ret;
	}
	private boolean checkAddressBlock()
	{
		EFEAddressBlockChecker addressChecker = new EFEAddressBlockChecker(AddressBlockSets,jList,ResultDescription);
		boolean ret = addressChecker.run();
		addressChecker = null;
		return ret;
	}
	private boolean checkTable()
	{
		EFETableChecker tableChecker = new EFETableChecker(tableOuterMostSubformSets,tableheaderSubformSets,tableRemarkSubformSets,jList,ResultDescription);
		boolean ret = tableChecker.run();
		tableChecker = null;
		return ret;
	}
	private boolean checkFreeTextBlock()
	{
		EFEFreeBlockChecker freeBlockChecker = new EFEFreeBlockChecker(freeBlockSubformSets,jList,ResultDescription);
		boolean ret = freeBlockChecker.run();
		freeBlockChecker = null;
		return ret;
	}
	private boolean checkSummBlock()
	{
		EFESummaryChecker summBlockChecker = new EFESummaryChecker(summBlockSubformSets,jList,ResultDescription);
		boolean ret = summBlockChecker.run();
		summBlockChecker = null;
		return ret;
	}
	
	private boolean checkHiddenSubform()
	{
		// 2008-08-29 added for Yang's issue, must check if there is the infoblock,but 
		// hidden subform is missing
		/*if( HiddenSubform == null )
		{
			// 2008-09-02 change from infoblockSets to freeBlockSubformSets
			if( !freeBlockSubformSets.isEmpty() )
			{
				String error = "You Must Create a Hidden Subform and\n";
				error += "Copy the Fields from InfoBlock into Hidden Subform!";
				Tool.ErrorReport(error);
				return false;
			}
			return true;
		}
		EFEHiddenSubformChecker hiddenChecker = new EFEHiddenSubformChecker(HiddenSubform,jList,ResultDescription);
		boolean ret = hiddenChecker.run();
		hiddenChecker = null;
		return ret;
		*/
		if( HiddenSubform != null)
		{
			Tool.ErrorReport("You must Remove Hidden Subform: " + CustomMarkupConfigDom.getHiddenSubformNamingConvention());
			return false;
		}
		return true;
	}
	
	// add Aug,28 2008: update timestamp:
	private boolean updateTimeStamp()
	{
		TimeConvertor timeConvertor = new TimeConvertor();
		String newTimeStamp = timeConvertor.getCETTime();
		if( newTimeStamp == null)
		{
			Tool.ErrorReport("TimeStamp Updated Error!");
			return false;
		}
		return SetTimeStamp(newTimeStamp);
	}
	
	private boolean SetTimeStamp(String time)
	{
		Element root = doc.getDocumentElement();
		if( root.getAttributes().getNamedItem("timeStamp") == null )
			return false;
		root.getAttributes().getNamedItem("timeStamp").setNodeValue(time);
		return true;
	}
	// add Aug,28 2008: to enhance the error automatic detection, interface must be 
	// extend: original interface: public String SaveAs(String path)
	

	public String SaveAsAnyway(String path)
	{
		String formattedPath = FormatSavePath(path);
		File newFile = new File(formattedPath);
		if( newFile.exists())
			return null;
		if( !updateTimeStamp())
			return null;
		SaveVerification.Verify(bodyPageNode,false);
		try
		{   
             TransformerFactory tff = TransformerFactory.newInstance();   
             Transformer tf = tff.newTransformer();   
             DOMSource source = new DOMSource(doc);
             File newXDPFile = new File(formattedPath);
             StreamResult rs = new StreamResult(newXDPFile);
             tf.transform(source,rs);  
             tf.reset();
             String info = "Finally You must Use Save Menu to Save Template\n";
             info += ("Templates Saved by " + "\"Save Anyway\" Are NOT EFE-Compatible Form!");
             Tool.InfoReport(info);
             
		}
		catch(Exception   e1)
		{
			e1.printStackTrace();   
        }  
		return path;
	}
	
	public String SaveAs(String path)
	{
		if( true)
		{			
			// MAIN CHECK LOGIC HERE
			if ( !checkFormTitle())
			{
				System.out.println("Check form title error!");
				return INVALIDCOPYATTRI;
			}
			if ( !checkInfoblock())
			{
				// 2008-08-21 report this error message in lower function now 
				// ErrorReport("Info Block Can Only Have One \"CopyFromCustomFields\" be true");
				System.out.println("Check form infoblock error!");
				return INVALIDCOPYATTRI;
			}
			/*
			 * Disable on 2009-04-14: FP2.0 do not implement AddressBlock 
			/if( !checkAddressBlock())
			{
				System.out.println("Check form address block error!");
				return INVALIDCOPYATTRI;
			}
			*/
			/* 2008-09-10 do not use frmFloatfields now*/
			// 2008-09-27:must make sure that hidden subform is deleted!
			if( !checkHiddenSubform())
			{
				System.out.println("Check form hidden subform error!");
				return INVALIDCOPYATTRI;
			}
			if ( !checkFreeTextBlock())
			{
				System.out.println("Check form free text block error!");
				return INVALIDCOPYATTRI;
			}
			if ( !checkTable())
			{
				// 2008-08-21 report this error message in lower function now 
				// ErrorReport("Table Header Can Only Have One \"CopyFromCustomFields\" be true");
				System.out.println("Check form table error!");
				return INVALIDCOPYATTRI;
			}
			/*
			 * Disable on 2009-04-14: FP2.0 do not implement SummaryBlock 
			if ( !checkSummBlock() )
			{
				System.out.println("Check form summary block error!");
				return INVALIDCOPYATTRI;
			}*/
			// 2008-10-07 must check all text fields whether they are read only or not
			if ( !checkTexTFieldReadOnly() )
			{
				System.out.println("Check form text field read only error!");
				return INVALIDCOPYATTRI;
			}
		}
		SaveVerification.Verify(bodyPageNode,true);
		String formattedPath = FormatSavePath(path);
		File newFile = new File(formattedPath);
		if( newFile.exists())
			return null;
		if( !updateTimeStamp())
			return null;
		try
		{   
             TransformerFactory tff = TransformerFactory.newInstance();   
             Transformer tf = tff.newTransformer();   
             DOMSource source = new DOMSource(doc);
             File newXDPFile = new File(formattedPath);
             StreamResult rs = new StreamResult(newXDPFile);
             tf.transform(source,rs);  
             tf.reset();
		}
		catch(Exception e1)
		{
			e1.printStackTrace();   
        }  
		return path;
	}
	public ArrayList<MarkupObject> getDescription()
	{
		return ResultDescription;
	}
	public DefaultTreeModel getTreeMode()
	{
		return TreeMode;
	}
	
	public Document getDocument()
	{
		return doc;
	}
	public DefaultMutableTreeNode GetRootNode()
	{
		return root;
	}

	public boolean getAllDescriptions(String inputXDPName) 
	{
		try 
		{
			filecopy = new FileCopyFactory();
			if( Tool.CheckInputXDPFileExistence(inputXDPName) == false)
			{
				Tool.ErrorReport("You select a file which does not exist!");
				return false;
			}
			String OutputXMLFile = filecopy.copyFile(inputXDPName);
			if (OutputXMLFile == null)
				return false;
			InputStream inputXML = new FileInputStream(OutputXMLFile);
			doc = dombuilder.parse(inputXML);
			Element root = doc.getDocumentElement();
			
			// but only template DOM is our concern...
			filecopy.DeleteUnusedXML(OutputXMLFile);
			Node template = Tool.getNodebyRoot("template",root);
			if( template == null)
				return false;
			CreateRootNodeForTree(template);
			// main modifications are here
			traverseNodeForA1SNode(template);
		}
		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
		return true;
	}
	
	private void traverseNodeForA1SNode(Node parent)
	{
		NodeList child = parent.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		SetParent(parent);
		String subformName = null;
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				subformName = Tool.getAttributeValue("name",item);
				if( subformName == null)
					continue;
				int type = FieldLocation.getSubformLocation(subformName);
				// 2008-08-18: must display "frmFloatFields" now
				// latest: 2008-10-10: some free text block might be hidden in design
				// for example payment advice, the free text block presence is judged according to
				// indicator via script
				if( Tool.isFieldHidden(item) && (type != FieldLocation.FREE_TEXT_BLOCK))
					continue;
				insertSubform(item);
				if( type == FieldLocation.BODY_PAGE)
				{
					bodyPageNode = item;
					traverseNodeForA1SNode(item);	
				}
				else if (type == FieldLocation.TABLE_OUTER_SUBFORM)
				{
					// add 2008-08-21: Collect all table outer-most subforms here
					tableOuterMostSubformSets.add(item);
					getTableA1SNode(item);
				} 
				else if( type == FieldLocation.INFO_BLOCK)
				{
					HandleWithInfoBlockForA1SNode(item,true);	
				}
				else if( type == FieldLocation.ADDRESS_BLOCK)
				{
					AddressBlockSets.add(item);
				}
				// add April 21st,2008: handlement with free text block
				// make sapa1s node shown in UI
				else if ( type == FieldLocation.FREE_TEXT_BLOCK)
				{
					freeBlockSubformSets.add(item);
					HandleWithFreeBlockForA1SNode(item,true);
				}
				// 2008-08-18 display UI for user to change possible fields
				// in the free text block
				else if ( type == FieldLocation.HIDDEN_SUBFORM)
				{
					HiddenSubform = item;
					HandleWithFreeBlockForA1SNode(item,false);
				}
				else if ( type == FieldLocation.SUMMARY_BLOCK)
				{
					summBlockSubformSets.add(item);
					getSummaryBlockA1SNode(item);
				}
				else  
				{
					traverseNodeForA1SNode(item);
				}
			} 
			else if (item.getNodeName().equals("pageSet")) 
			{
				HandlePageSets(item);
			}
			else if (item.getNodeName().equals("field"))
			{
				insertLeaf(item);
				getA1SNodeforField(item);
				// 2008-10-07:
				allOtherTextfields.add(item);
			}
			else if (item.getNodeName().equals("draw"))
			{
				insertLeaf(item);
				//drawCorrection(item);
				getA1SNodeforDraw(item);
			}
		}
		BackTrace();
	}
	private void HandlePageSets(Node pageSet)
	{
		SetParent(pageSet);
		insertSubform(pageSet);
		NodeList masterChild = pageSet.getChildNodes();
		Node masterPageitem = null;
		int masterChildLength = masterChild.getLength();
		for (int j = 0; j < masterChildLength; j++) 
		{
			masterPageitem = masterChild.item(j);
			if (masterPageitem.getNodeName().equals("pageArea"))
			{
				HandlePageAreaForA1SNode(masterPageitem);
			}
			else if ( masterPageitem.getNodeName().equals("pageSet"))
			{
				// 2008-09-10: add recursively for Service Request by Belle
				HandlePageSets(masterPageitem);
			}
		}
		BackTrace();
	}
	
	private void insertSubformbyName(String subformName,Node node)
	{
		DefaultMutableTreeNode child = new DefaultMutableTreeNode(subformName);
		int index = parentNode.getChildCount();
		TreeMode.insertNodeInto(child, parentNode, index);
		NodeList.add(node);
		String nodeindex = ""+ NodeIndex++;
		hashMap.put(child,nodeindex);
	}
	

	public void insertSubform(Node subform)
	{
		insertSubformbyName(GetNodeName(subform),subform);
	}
	private String GetNodeName(Node node)
	{
		if( node == null)
		{
			System.out.println("Nill!");
			System.exit(0);
		}
		if( node.getAttributes().getNamedItem("name") == null)
			return "XDP";
		return node.getAttributes().getNamedItem("name").getNodeValue();
	}
	public void insertLeaf(Node field)
	{
		String name = GetNodeName(field);
		DefaultMutableTreeNode child = new DefaultMutableTreeNode(name);
		parentNode.add(child);
		NodeList.add(field);
		String nodeindex = ""+ NodeIndex++;
		hashMap.put(child,nodeindex);
	}
	
	private void getSummaryBlockA1SNode(Node node)
	{
		NodeList child = node.getChildNodes();
		getSummblockSubformA1SNode(node);
		Node item = null;
		int childLength = child.getLength();
		SetParent(node);
		for(int i = 0; i < childLength;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				if(Tool.isFieldHidden(item))
					continue;
				insertSubform(item);
				getSummaryBlockA1SNode(item);
			}
			else if (item.getNodeName().equals("field") || item.getNodeName().equals("draw"))
			{
				insertLeaf(item);
				getA1SNodeforSummaryLabel(item);
			}
		}
		BackTrace();
	}

	private void getA1SNodeforSummaryLabel(Node node)
	{
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( sapa1s == null)
			return;
		Node label = Tool.getNodebyRoot(CustomMarkupConfigDom.getSummaryLabelName(),sapa1s);
		if( label == null)
			return;
		Node description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),label);
		if( description == null)
			return;
		MarkupObject obj = new MarkupObject(node,description.getTextContent(),CustomMarkupConfigDom.SUMM_LABEL);
		ResultDescription.add(obj);
	}
	private void getA1SNodeforField(Node node)
	{
		// handle with nodes which is neither in info block nor
		// free text block nor table
		/*
		String name = getAttributeValue("name",node);
		ResultDescription.add(name);
		*/
	}
	
	private void getA1SNodeforDraw(Node node)
	{
		// handle with nodes which is neither in info block nor
		// free text block nor table
		/*String name = getAttributeValue("name",node);
		ResultDescription.add(name);
		*/
		String name = Tool.getAttributeValue("name", node);
		if( name == null)
			return;
		if( name.equals(ConfigDom.getTitleNamingConvention()))
		{
			titleSets.add(node);
			getA1SNodeforFormTitle(node);
		}
	}
	private void getA1SNodeforFormTitle(Node node)
	{
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( sapa1s == null)
			return;
		Node formTitle = Tool.getNodebyRoot(CustomMarkupConfigDom.getFormTitleNodeName(),sapa1s);
		if( formTitle == null)
			return;
		// workaround 2008-9-3 current no description for form title
		MarkupObject obj = new MarkupObject(node,"Form Title",CustomMarkupConfigDom.FORM_TITLE);
		ResultDescription.add(obj);
	}
	
	private void getTableHeaderA1SNode(Node node) 
	{
		SetParent(node);
		NodeList childs = node.getChildNodes();
		Node child_node = null;
		int childLength = childs.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			child_node = childs.item(i);
			// the subnode in the table header
			if (child_node.getNodeName().equals("draw") || child_node.getNodeName().equals("field")) 
			{
				// get A1S Node for table header
				insertLeaf(child_node);
				Node A1SNode = Tool.getNodebyRoot("sapa1s",child_node);
				if( A1SNode == null)
					continue;
				Node tableColumn = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableHeaderNodeName(),A1SNode);
				if( tableColumn == null)
					continue;
				Node description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),tableColumn);
				if( description == null)
					continue;
				MarkupObject obj = new MarkupObject(child_node,description.getTextContent(),CustomMarkupConfigDom.TABLE_HEADER_FIELD);
				String copy = Tool.getAttributeValue(CustomMarkupConfigDom.getCopyAttributeName(),tableColumn);
				obj.SetCopyAttribute(copy);
				String fixWidth = Tool.getAttributeValue(CustomMarkupConfigDom.getfixedWidthAttributeName(),tableColumn);
				obj.SetFixWidthAttribute(fixWidth);
				String miniumWidth = Tool.getAttributeValue(CustomMarkupConfigDom.getTableminiumWidthNodeName(),tableColumn);
				obj.SetMiniumWidth(miniumWidth);
				ResultDescription.add(obj);
			}
		}
		BackTrace();
	}
	private void getTableOuterSubformA1SNode(Node node)
	{
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( sapa1s == null)
			return;
		Node table = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableSubformNodeName(),sapa1s);
		if( table == null)
			return;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),table);
		if( title == null)
			return;
		MarkupObject obj = new MarkupObject(node,title.getTextContent(),CustomMarkupConfigDom.TABLE_SUBFORM);
		String targetWidth = Tool.getAttributeValue(CustomMarkupConfigDom.getTableTargetWidthAttributeName(),table);
		obj.SetTargetWidth(targetWidth);
		ResultDescription.add(obj);
	}
	private void getTableA1SNode(Node parent) 
	{
		NodeList child = parent.getChildNodes();
		Node item = null;
		SetParent(parent);
		getTableOuterSubformA1SNode(parent);
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) {
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				// Should check if the subform is info block or table or root
				// node
				String SubformName = item.getAttributes().getNamedItem("name")
						.getNodeValue();
				/* hidden accessibility should be considered now
				if( isFieldHidden(item) == true)
					continue;
					*/
				insertSubform(item);
				int type = FieldLocation.getSubformLocation(SubformName);
				if ( type == FieldLocation.TABLE_HEADER_SUBFORM)
				{
					tableheaderSubformSets.add(item);
					getTableHeaderA1SNode(item);
				}
				if ( type == FieldLocation.TABLE_CONTENT_SUBFORM)
				{
					getTableContentRowA1SNode(item);
				}
				if ( type == FieldLocation.TABLE_OUTER_SUBFORM)
				{
					getTableA1SNode(item);
				}
				if ( type == FieldLocation.REMARK_ROW)
				{
					/*
					 * 2008-09-12:
					  de-active this according to Fiato: in some form the remark row does
					  not nest within the content row
					  System.exit(0);
					 */
					getRemarkRowA1SNode(item);
				}
				if ( type == FieldLocation.DEFAULT_SUBFORM)
				{
					traverseNodeForA1SNode(item);
				}
			}
		}
		BackTrace();
	}
	private void getRemarkRowA1SNode(Node node)
	{
		NodeList child = node.getChildNodes();
		Node item = null;
		SetParent(node);
		// 2008-08-25 decide not to display remark row subform for the moment
		/*
		MarkupObject obj = new MarkupObject(node,"",CustomMarkupConfigDom.REMARK_SUBFORM);
		ResultDescription.add(obj);
		*/
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// assume there is exactly one field in the simple remark row
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
				getRemarkRowA1SNode(item);
			else if (item.getNodeName().equals("field")) 
			{
				insertLeaf(item);
				getRemarkFieldA1SNode(item);
			} 
		}
		BackTrace();
	}
	private void getRemarkFieldA1SNode(Node node)
	{
		Node A1SNode = Tool.getNodebyRoot("sapa1s",node);
		if( A1SNode == null)
			return;
		Node tableColumn = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableRemarkFieldName(),A1SNode);
		if( tableColumn == null)
			return;
		Node description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),tableColumn);
		if( description == null)
			return;
		MarkupObject obj = new MarkupObject(node,description.getTextContent(),CustomMarkupConfigDom.REMARK_FIELD);
		ResultDescription.add(obj);
	}
	private void getTableContentRowA1SNode(Node node)
	{
		NodeList child = node.getChildNodes();
		Node item = null;
		SetParent(node);
		int childLength = child.getLength();
		System.out.println("Content Row name 333333333333: " + Tool.getAttributeValue("name", node));
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);

			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				// nested table
				// 2008-09-08 Arnold report, must ignore hidden subform
				if( Tool.isFieldHidden(item))
					continue;
				String SubformName = item.getAttributes().getNamedItem("name")
						.getNodeValue();
				// add 2008-06-03 hidden subform in the table must be ignored.
				insertSubform(item);
				if( Tool.isFieldHidden(item) == true)
					continue;
				int type = FieldLocation.getSubformLocation(SubformName);
				if ( type == FieldLocation.TABLE_OUTER_SUBFORM) 
				{
					getTableA1SNode(item);
				} 
				else if (type == FieldLocation.TABLE_CONTENT_SUBFORM) 
				{
					System.out.println("Traverse in the nested content row:"
							+ SubformName);
					if( SubformName.equals("rowMaintable"))
						System.out.println("here");
					getTableContentRowA1SNode(item);
				} 
				// 2008-06-02 feedback by Kullab, Ahmed
				// it is possible that table header occurs in the subform set
				else if (type == FieldLocation.TABLE_HEADER_SUBFORM)
					getTableHeaderA1SNode(item);
				else if (type == FieldLocation.REMARK_ROW)
				{
					tableRemarkSubformSets.add(item);
					getRemarkRowA1SNode(item);
				}
				else if (type == FieldLocation.DEFAULT_SUBFORM) 
				{
					System.out.println("Traverse into the subform in the content row!");
					traverseNodeForA1SNode(item);
				}

			}
			// field type
			else if (item.getNodeName().equals("field")) 
			{
				insertLeaf(item);
				getContentRowFieldA1SNode(item);
			} 
			else if (item.getNodeName().equals("draw")) 
			{
				insertLeaf(item);
				getContentRowDrawA1SNode(item);
			}
		}
		BackTrace();
	}

	private void getContentRowFieldA1SNode(Node node)
	{
		Node A1SNode = Tool.getNodebyRoot("sapa1s",node);
		if( A1SNode == null)
			return;
		Node tableColumn = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableColumnNodeName(),A1SNode);
		if( tableColumn == null)
			return;
		Node description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),tableColumn);
		if( description == null)
			return;
		MarkupObject obj = new MarkupObject(node,description.getTextContent(),CustomMarkupConfigDom.TABLE_HEADER_FIELD);
		ResultDescription.add(obj);
	}
	
	private void getContentRowDrawA1SNode(Node node)
	{
		getContentRowFieldA1SNode(node);
	}
	private void HandleWithInfoBlockForA1SNode(Node node,boolean isFirstEntry)
	{
		if( Tool.isFieldHidden(node) == true)
		// do not handle with the hidden subform
			return;		
		if( isFirstEntry)
			infoBlockHeader.add(node);
		getInfoblockSubformA1SNode(node);
		NodeList child = node.getChildNodes();
		Node item = null;
		SetParent(node);
		int childLength = child.getLength();
		for(int i = 0; i < childLength;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				insertSubform(item);
				HandleWithInfoBlockForA1SNode(item,false);
			}
			else if (item.getNodeName().equals("field"))
			{
				insertLeaf(item);
				getInfoblockA1SNodeforField(item);
			}
			else if (item.getNodeName().equals("draw"))
			{
				insertLeaf(item);
				getInfoblockA1SNodeforDraw(item);
			}
		}
		BackTrace();
	}
	
	private void getFreeblockSubformA1SNode(Node node)
	{
		Node A1SNode = Tool.getNodebyRoot("sapa1s",node);
		if( A1SNode == null)
			return;
		Node freeSubform = Tool.getNodebyRoot(CustomMarkupConfigDom.getFreeTextBlockSubformNodeName(),A1SNode);
		if( freeSubform == null)
			return;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),freeSubform);
		if( title == null)
			return;
		MarkupObject obj = new MarkupObject(node,title.getTextContent(),CustomMarkupConfigDom.FREEBLOCK_SUBFORM);
		ResultDescription.add(obj);
	}
	
	/* adapt function interface on 2008-08-18 to distinguish the situation
	 * about A.really in a free text block
	 *       B.in hidden subform "frmFloatFields
	 */
	private void HandleWithFreeBlockForA1SNode(Node node,boolean isInFreeTextBlock)
	{
		/*if ((Tool.isFieldHidden(node)) && isInFreeTextBlock)
			// do not handle with the hidden subform
			return;
		*/			
		getFreeblockSubformA1SNode(node);
		NodeList child = node.getChildNodes();
		Node item = null;
		SetParent(node);
		int childLength = child.getLength();
		for(int i = 0; i < childLength;i++)
		{
			item = child.item(i);
            /* there must not be any nested subform in the free text block,
             * so just disable this part
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				insertSubform(item);
				HandleWithInfoBlockForA1SNode(item);
			}*/
			if (item.getNodeName().equals("field") || item.getNodeName().equals("draw"))
			{
				insertLeaf(item);
				//fieldLayoutAccCorrection(item);
				getfreeblockA1SNodeforField(item);
			}
		}
		BackTrace();
	}
	
	private void getfreeblockA1SNodeforField(Node node)
	{
		Node A1SNode = Tool.getNodebyRoot("sapa1s",node);
		if( A1SNode == null)
			return;
		Node InfoItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getFreeTextItem(),A1SNode);
		if( InfoItem == null)
			return;
		Node description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),InfoItem);
		if( description == null)
			return;
		MarkupObject obj = new MarkupObject(node,description.getTextContent(),CustomMarkupConfigDom.FREEBLOCK_FIELD);
		ResultDescription.add(obj);
	}
	private void getInfoblockA1SNodeforField(Node node)
	{
		Node A1SNode = Tool.getNodebyRoot("sapa1s",node);
		if( A1SNode == null)
			return;
		Node InfoItem = Tool.getNodebyRoot(CustomMarkupConfigDom.getInfoBlockItemNodeName(),A1SNode);
		if( InfoItem == null)
			return;
		Node description = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),InfoItem);
		if( description == null)
			return;
		MarkupObject obj = new MarkupObject(node,description.getTextContent(),CustomMarkupConfigDom.INFOBLOCK_FIELD);
		String copyValue = Tool.getAttributeValue(CustomMarkupConfigDom.getCopyAttributeName(),InfoItem);
		obj.SetCopyAttribute(copyValue);
		ResultDescription.add(obj);
	}

	private void getSummblockSubformA1SNode(Node node)
	{
		Node A1SNode = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( A1SNode == null)
			return;
		Node InfoSubform = Tool.getNodebyRoot(CustomMarkupConfigDom.getSummaryBlockSubformName(),A1SNode);
		if( InfoSubform == null)
			return;
		Node desp = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),InfoSubform);
		if( desp == null)
			return;
		MarkupObject obj = new MarkupObject(node,desp.getTextContent(),CustomMarkupConfigDom.SUMM_SUBFORM);
		ResultDescription.add(obj);
	}
	private void getInfoblockSubformA1SNode(Node node)
	{
		Node A1SNode = Tool.getNodebyRoot("sapa1s",node);
		if( A1SNode == null)
			return;
		Node InfoSubform = Tool.getNodebyRoot(CustomMarkupConfigDom.getInfoBlockSubformNodeName(),A1SNode);
		if( InfoSubform == null)
			return;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),InfoSubform);
		if( title == null)
			return;
		MarkupObject obj = new MarkupObject(node,title.getTextContent(),CustomMarkupConfigDom.INFOBLOCK_SUBFORM);
		ResultDescription.add(obj);
	}
	private void getInfoblockA1SNodeforDraw(Node node)
	{
		getInfoblockA1SNodeforField(node);
	}
	private void HandlePageAreaForA1SNode(Node PageArea) 
	{
		NodeList child = PageArea.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		SetParent(PageArea);
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				String SubformName = Tool.getAttributeValue("name",item);
				int type = FieldLocation.getSubformLocation(SubformName);
				if( type == FieldLocation.INFO_BLOCK)
				{
					// this function can handle with all the nodes into that subform
					insertSubform(item);
					HandleWithInfoBlockForA1SNode(item,true);	
				}
				else if ( type == FieldLocation.ADDRESS_BLOCK)
					AddressBlockSets.add(item);
				else // summary block,free text block
				{
					insertSubform(item);
					traverseNodeForA1SNode(item);
				}
			} 
			else if (item.getNodeName().equals("field")) 
			{
				insertLeaf(item);
				getA1SNodeforField(item);
				// add 2008-10-07:
				allOtherTextfields.add(item);
			} 
			else if (item.getNodeName().equals("draw")) 
			{
				insertLeaf(item);
				getA1SNodeforDraw(item);
			}
		}
		BackTrace();
	}
	public void ModuleTree()
	{
		DefaultMutableTreeNode a = root.getNextNode();
		DefaultMutableTreeNode b = a.getNextNode();
		while(( a != null) && ( b != null))
		{
			if( a.toString().equals(b.toString()))
			{
				if( a.isLeaf())
				{
					// remove a:
					TreeMode.removeNodeFromParent(a);
					ModuleTreeBackUpList.add(a);
					a = b;
					b = b.getNextNode();
				}
				else if( b.isLeaf())
				{
					a = b.getNextNode();
					TreeMode.removeNodeFromParent(b);
					ModuleTreeBackUpList.add(b);
					b = a.getNextNode();
				}
			}
			else
			{
				a = b;
				b = b.getNextNode();
			}
		}
	}
	private void SetParent(Node parent)
	{
		DefaultMutableTreeNode oldParent =  parentNode;
		int childNumber = oldParent.getChildCount();
		if(true )
		{
			parentNode = new DefaultMutableTreeNode(GetNodeName(parent));
			TreeMode.insertNodeInto(parentNode, oldParent,childNumber);
		}
	}
	
	private void BackTrace()
	{
		parentNode = (DefaultMutableTreeNode)parentNode.getParent();	
	}
	private void CreateRootNodeForTree(Node Template)
	{
		NodeList child = Template.getChildNodes();
		int Length = child.getLength();
		Node item = null;
		for( int i = 0; i < Length; i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform"))
			{
				root = new DefaultMutableTreeNode(item.getAttributes().getNamedItem("name").getNodeValue());
				TreeMode = new DefaultTreeModel(root);
			}
		}
		parentNode = root;
	}
	
	
}