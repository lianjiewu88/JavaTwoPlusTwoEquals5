package customMarkupForAFC.markupProcessor;
import configuration.*;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.Tool;

public class SummaryBlockprocessor

{
	Node node = null;
	boolean isSummMarkupExist = false;
	public void AssignTask(Node task)
	{
		node = task;
		isSummMarkupExist = false;
	}
	
	
	public void StartAddingSummMarkup(Node task)
	{
		AssignTask(task);
		AddCustomMarkup();
		if( node == null)
		{
			System.out.println("Currently no task assigned to processor!");
			return;
		}
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		String itemName = null;
		String itemTechnicalName = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			itemName = item.getNodeName();
			System.out.println("Node name:" + itemName);
			if( itemName.equalsIgnoreCase("subform"))
				HandleWithSubNode(item);
			// Add 2008-06-03 : according to naming convention "lbl" now 
			// if( itemName.equalsIgnoreCase("draw") )
			if( !itemName.equals("field") && !itemName.equals("draw"))
				continue;
			itemTechnicalName = Tool.getAttributeValue("name",item);
			if( itemTechnicalName == null )
				continue;
			if( itemTechnicalName.length() <= 3)
				continue;
			if( itemTechnicalName.equals("lblTax"))
				System.out.println("here");
			if( itemTechnicalName.substring(0,3).equalsIgnoreCase(CustomMarkupConfigDom.getSummaryBlockNamingConvention()))	
				AddCustomSummMarkupToSingleField(item);
			if( itemName.equalsIgnoreCase(CustomMarkupConfigDom.getCustomNodeName()))
			// custom markup already exist
			{
				isSummMarkupExist = true;
			}
		}
	}

	
	private void HandleWithSubNode(Node node)
	{
		NodeList child = node.getChildNodes();
		int number = child.getLength();
		Node item = null;
		String itemName = null;
		// disable in 2008-08-25
		//boolean isCustomMarkupExist = false;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( Tool.isFieldHidden(item) == true)
				continue;
			itemName = item.getNodeName();
			/*
			if( itemName.equalsIgnoreCase(CustomMarkupConfigDom.getCustomNodeName()))
				isCustomMarkupExist = true;
			*/
			if( itemName.equalsIgnoreCase("subform"))
				HandleWithSubNode(item);
			// directly ignore all fields - obsolete
			// add 2008 -06 -03 using naming convention instead
			if( !itemName.equals("field") && !itemName.equals("draw"))
				continue;
			String itemTechnicalName = Tool.getAttributeValue("name",item);
			System.out.println("Summary Field Name: " + itemTechnicalName);
			if( itemTechnicalName == null )
				continue;
			if( itemTechnicalName.length() <= 3)
				continue;
			if( itemTechnicalName.equals("lblTax"))
				System.out.println("here");
			if( itemTechnicalName.substring(0,3).equalsIgnoreCase(CustomMarkupConfigDom.getSummaryBlockNamingConvention()))	
				AddCustomSummMarkupToSingleField(item);
		}
		// 2008-08-25: only the outer-most subform needs to be added with
		// EFE markup!!
		/*
		if( !isCustomMarkupExist)
			AddCustomMarkup(node);
		*/
	}

	// 2008-08-25 disable it: only the outer-most subform needs to be added with custom markup
	/*
	private void AddCustomMarkup(Node node)
	{
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element summaryNode = A1SDocument.createElement(CustomMarkupConfigDom.getSummaryBlockSubformName());
		Attr config = A1SDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue(CustomMarkupConfigDom.getDefaultAttrValue());
		summaryNode.setAttributeNode(config);
		A1SNode.appendChild(summaryNode);
		
		Element description = A1SDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		description.setAttributeNode(lang);
		description.setNodeValue(CustomMarkupConfigDom.getDefaultDescriptionValue());
		description.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		summaryNode.appendChild(description);
	}
	*/
	
	
	private void AddCustomSummMarkupToSingleField(Node node)
	{
		String name = node.getAttributes().getNamedItem("name").getNodeValue();
		System.out.println("Operation on Node: " + name);
		if( Tool.isFieldHidden(node) )
			return;
		if( Tool.isA1SNodeAlreadyExist(node))
			return;
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);

		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element summlabelNode = A1SDocument.createElement(CustomMarkupConfigDom.getSummaryLabelName());
		A1SNode.appendChild(summlabelNode);
		
		Attr configurable = AssistNodeParentDocument.createAttribute("configurable");
		configurable.setNodeValue("true");
		summlabelNode.setAttributeNode(configurable);
		
		Element desp = A1SDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		desp.setAttributeNode(lang);
		desp.setNodeValue(CustomMarkupConfigDom.getDefaultDescriptionValue());
		desp.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		summlabelNode.appendChild(desp);
	}

	private void AddCustomMarkup()
	{
		// 2008-08-25 add check logic
		if( Tool.isFieldHidden(node) )
			return;
		if( Tool.isA1SNodeAlreadyExist(node))
			return;
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element summblockNode = A1SDocument.createElement(CustomMarkupConfigDom.getSummaryBlockSubformName());
		Attr config = A1SDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue(CustomMarkupConfigDom.getDefaultAttrValue());
		summblockNode.setAttributeNode(config);
		A1SNode.appendChild(summblockNode);
		
		Element desp = A1SDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		desp.setAttributeNode(lang);
		desp.setNodeValue(CustomMarkupConfigDom.getDefaultDescriptionValue());
		desp.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		summblockNode.appendChild(desp);
	}
}