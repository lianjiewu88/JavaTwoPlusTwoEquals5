package customMarkupForAFC.markupProcessor.internalObject;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import configuration.CustomMarkupConfigDom;
import utilities.Tool;

public class FormFieldCaption
{
	static private String DEFAULT_TEXTFIELD = "Text Field";
	static private String DEFAULT_DECIMAL = "Decimal Field";
	static private String DEFAULT_NUMERIC = "Numeric Field";
	static private String DEFAULT_DATE = "Date/Time Field";
	static public String getNodeFormattedCaption(Node node)
	{
		String caption = getNodeCaption(node);
		if( caption == null)
			return getDescriptionbyMappingPath(node);
		if(  caption.charAt(caption.length() - 1) == ':')
			caption = caption.substring(0,caption.length() -1);
		if( isDefaultCaption(caption))
			caption = getDescriptionbyMappingPath(node);
		return caption;
	}
	static private String getDescriptionbyMappingPath(Node node)
	{
		Node bind = Tool.getNodebyRoot("bind",node);
		if( bind == null)
			return null;
		String path = Tool.getAttributeValue("ref",bind);
		if( path == null)
			return null;
		return handlePath(path);
		// sample: $record.BillOfExchangePayable.DrawerID
		// $record.BillOfExchangePayable.PaymentTransactionInitiatorParty.
		// ContactPerson.FormAddress.FacsimileNumberExtensionID
	}
	static private String handlePath(String path)
	{
		String[] col = path.split("\\.");
		String result = null;
		int length = col.length;
		switch (length)
		{
			case 1:
				result = path;
				break;
			case 2:
				result = path;
				break;
			case 3:
				result = col[1] + "." + col[2];
				break;
			default:
				if( length >= 4)
					result = col[length-3] + "." + col[length-2] + "." + col[length-1];
		}
		return result;
	}
	static private String getNodeCaption(Node node)
	{
		Node caption = Tool.getNodebyRoot("caption", node);
		if( caption == null)
			return null;
		Node value = Tool.getNodebyRoot("value",caption);
		if( value == null)
			return null;
		Node text = Tool.getNodebyRoot("text",value);
		if( text == null)
		{
			Node exData = Tool.getNodebyRoot("exData",value);
			if( exData == null)
				return null;
			Node body = Tool.getNodebyRoot("body",exData);
			if( body == null)
				return null;
			NodeList children = body.getChildNodes();
			int length = children.getLength();
			Node item = null;
			String result = "";
			for( int i = 0 ; i < length; i++)
			{
				item = children.item(i);
				if( !item.getNodeName().equals("p"))
					continue;
				result += item.getTextContent();
			}
			return result;
		}
		else
			return text.getTextContent();
	}
	static public boolean checkPossibieFieldsDescriptionMaintained(Node node)
	{
		if( node.getNodeName().equals("draw"))
			return true;
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		// because sapa1s' exsitence has been checked in DoesPossibleFieldsHaveA1SNode,
		// so here do not report error if sapa1s does not exist
		if( sapa1s == null)
			return false;
		Node free = Tool.getNodebyRoot(CustomMarkupConfigDom.getFreeTextItem(),sapa1s);
		if( free == null)
			return false;
		Node desp = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),free);
		if( desp == null)
			return false;
		String description = desp.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0)
			return false;
		// must check if description are just some dummy one - not acceptable
		if( isDefaultCaption(description))
			return false;
		return true;
	}
	static private boolean isDefaultCaption(String description)
	{
		if( description.equalsIgnoreCase(DEFAULT_TEXTFIELD))
			return true;
		if( description.equalsIgnoreCase(DEFAULT_DECIMAL))
			return true;
		if( description.equalsIgnoreCase(DEFAULT_NUMERIC))
			return true;
		if( description.equalsIgnoreCase(DEFAULT_DATE))
			return true;
		return false;
	}
}