package customMarkupForAFC.markupProcessor.internalObject;

import org.w3c.dom.Node;
import configuration.CustomMarkupConfigDom;
import utilities.*;

public class FormTitle
{
	static public boolean isStaticTitle(Node node)
	{
		Node value = Tool.getNodebyRoot("value",node);
		if( value == null)
			return false;
		Node text = Tool.getNodebyRoot("text",value);
		if( text != null)
			return true;
		return false;
	}
	static public String getFormTitleContent(Node node)
	{
		Node value = Tool.getNodebyRoot("value",node);
		if( value == null)
			return null;
		Node text = Tool.getNodebyRoot("text",value);
		if( text == null)
			return null;
		return text.getTextContent();
	}
	static public String getConfigurableAttr(Node node)
	{
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( sapa1s == null)
			return null;
		Node formTitle = Tool.getNodebyRoot(CustomMarkupConfigDom.getFormTitleNodeName(), sapa1s);
		if( formTitle == null)
			return null;
		if( formTitle.getAttributes().getNamedItem(CustomMarkupConfigDom.getConfigureAttrName()) == null)
			return null;
		return formTitle.getAttributes().getNamedItem(CustomMarkupConfigDom.getConfigureAttrName()).getNodeValue();
	}
	static public boolean setConfigurableAttribute(Node task,String value)
	{
		Node node = task;
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( sapa1s == null)
		{
			Tool.ErrorReport("Form Title Has No EFE Markup!You Need to Click \"Custom Markup Format\" to Add it First!");
			return false;
		}
		Node formTitle = Tool.getNodebyRoot(CustomMarkupConfigDom.getFormTitleNodeName(),sapa1s);
		formTitle.getAttributes().getNamedItem(CustomMarkupConfigDom.getConfigureAttrName()).setNodeValue(value);
		return true;
	}
}