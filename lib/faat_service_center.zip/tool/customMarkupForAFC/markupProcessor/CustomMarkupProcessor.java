package customMarkupForAFC.markupProcessor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import utilities.FieldLocation;
import utilities.FileCopyFactory;
import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;

public class CustomMarkupProcessor
{
	private FileCopyFactory filecopy = null;
	private Document doc = null;
	private DocumentBuilder dombuilder = null;
	private DocumentBuilderFactory domfac = null;
	private TitleMarkupProcessor titleProcessor = null;
	private InfoMarkupProcessor infoProcessor = null;
	private TableMarkupProcessor tableProcessor = null;
	private FreeTextProcessor freeProcessor = null;
	// add in 2008-08-18 add xml markup for hidden subform
	private FreeTextProcessor hiddenSubformProcessor = null;
	private SummaryBlockprocessor summProcessor = null;
	private String StoreFolderPath = null;
	private Vector<String> AbsoluteFilePathCollection = null;
	public CustomMarkupProcessor(String path)
	{
		StoreFolderPath = path;
		domfac = DocumentBuilderFactory.newInstance();
		AbsoluteFilePathCollection = new Vector<String>();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
		titleProcessor = new TitleMarkupProcessor();
		infoProcessor = new InfoMarkupProcessor();
		tableProcessor = new TableMarkupProcessor();
		freeProcessor = new FreeTextProcessor();
		summProcessor = new SummaryBlockprocessor();
		hiddenSubformProcessor = new FreeTextProcessor();
	}
	
	public Vector<String> getFileCollection()
	{
		return AbsoluteFilePathCollection;
	}
	
	public boolean CheckInputXDPFileExistence(String filename)
	{
		File ForChecking = new File(filename);
		return ForChecking.exists();
	}
	
	private String getRelativePath(String AbsolutePath)
	{
		int index = AbsolutePath.lastIndexOf("\\");
		System.out.println("Store Path:" + StoreFolderPath);
		System.out.println("index: " + index + " length: " + AbsolutePath.length());
		String RelativePath = AbsolutePath.substring(index,AbsolutePath.length());
		System.out.println("Path: " + RelativePath);
		// should modify name a little to remind developer
		index = RelativePath.lastIndexOf('.');
		RelativePath = RelativePath.substring(0,index) + ConfigDom.getEFEPostFix() + RelativePath.substring(index,RelativePath.length());
		System.out.println("Modified Path: " + RelativePath);
		return RelativePath;
	}
	//public void DoActions(String inputXDPName)
	public int AssginTaskArrayList(File[] FileCollection)
	{
		int FileNumber = FileCollection.length;
		System.out.println("Template Number: " + FileNumber);
		String inputXDPName = null;
		boolean isDirectory = false;
		for( int i = 0; i < FileNumber;i++)
		{
			inputXDPName = FileCollection[i].getAbsolutePath();
			isDirectory = FileCollection[i].isDirectory();
			if( !isDirectory)	// is a file
			{
				if( Tool.isValidTemplate(inputXDPName) )
				{
					AbsoluteFilePathCollection.add(inputXDPName);
					System.out.println("FilePath:>" + inputXDPName);
				}
			}
			else
				TraversePath(FileCollection[i]);
		}
		System.out.println("Total Task Number: " + AbsoluteFilePathCollection.size());
		return AbsoluteFilePathCollection.size();
	}
	

	private void TraversePath(File Directory)
	{
		File[] filecollection = Directory.listFiles();
		int filenumber = filecollection.length;
		File item = null;
		boolean isFileDirectory = false;
		for( int i = 0 ; i < filenumber; i++)
		{
			item = filecollection[i];
			isFileDirectory = item.isDirectory();
			if( !isFileDirectory)
			{
				if( Tool.isValidTemplate(item.getAbsolutePath()) )
				{
					AbsoluteFilePathCollection.add(item.getAbsolutePath());
					System.out.println("FilePath:> " + item.getAbsolutePath());
				}
			}
			else
				TraversePath(item);
		}
	}
	public void DoActions(File[] FileCollection)
	{
		int FileNumber = AbsoluteFilePathCollection.size();
		String inputXDPName = null;
		for( int i = 0; i < FileNumber;i++)
		{
			inputXDPName = AbsoluteFilePathCollection.elementAt(i);
			filecopy = new FileCopyFactory();
			System.out.println("Input XDP : " + inputXDPName);
			String RelativePath = getRelativePath(inputXDPName);
			if( CheckInputXDPFileExistence(inputXDPName) == false)
			{
				Tool.ErrorReport("You select a file which does not exist!");
				continue;
			}
			String OutputXMLFile = null;
			try 
			{
				OutputXMLFile = filecopy.copyFile(inputXDPName);
			} 
			catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (OutputXMLFile == null)
				continue;
			InputStream inputXML = null;
			try 
			{
				inputXML = new FileInputStream(OutputXMLFile);
			} 
			catch (FileNotFoundException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try 
			{
				doc = dombuilder.parse(inputXML);
			} 
			catch (SAXException e) 
			{
				e.printStackTrace();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			Element root = doc.getDocumentElement();
			// but only template DOM is our concern...
			filecopy.DeleteUnusedXML(OutputXMLFile);
			Node template = Tool.getNodebyRoot("template",root);
			if( template == null)
				continue;
			if( isAlreadyEFECompatibleForm(template))
			{
				Tool.ErrorReport("ATTENTION:This File Already Have Custom Node!");
				/* comment 2008-06-11 
				 * some colleague needs to change the form after it is EFEd.
				return;
				*/
			}
			traverseNode(template);
			// should add additional xml namespace here
			//logfile.CloseFile();
			System.out.println("Add custom markup succesfully");
			String newFilePath = StoreFolderPath + RelativePath;
			SaveModifiedTemplate(newFilePath);
		}
	}
	

	private boolean isAlreadyEFECompatibleForm(Node template)
	{
		NodeList children = template.getChildNodes();
		int size = children.getLength();
		Node item = null;
		for( int i = 0 ; i < size; i++)
		{
			item = children.item(i);
			if( item.getNodeType() != Node.ELEMENT_NODE)
				continue;
			if( FindCustomNode(item))
				return true;
		}
		return false;
	}
		
	// input: Element
	private boolean FindCustomNode(Node node)
	{
		String name = node.getNodeName();
		if( name.equals(CustomMarkupConfigDom.getCustomNodeName()))
			return true;
		NodeList children= node.getChildNodes();
		int size = children.getLength();
		for( int i = 0 ; i < size; i++)
		{
			if( children.item(i).getNodeType() != Node.ELEMENT_NODE)
				continue;
			if ( FindCustomNode(children.item(i)))
				return true;
		}
		return false;
	}
	private void SaveModifiedTemplate(String path)
	{
		
		TransformerFactory tff = TransformerFactory.newInstance();   
        Transformer tf = null;
		try 
		{
			tf = tff.newTransformer();
			DOMSource source = new DOMSource(doc);
	        File newXDPFile = new File(path);
	        StreamResult rs = new StreamResult(newXDPFile);
	        tf.transform(source,rs);
	        tf.reset();
		} 
		catch (TransformerConfigurationException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
        catch (TransformerException e) 
        {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	}
	
	private void traverseNode(Node template)
	{
		NodeList child = template.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				if( item.getAttributes().getNamedItem("name") == null)
				{
					Tool.ErrorReport("Subform should have a name attribute!");
					continue;
				}
				String SubformName = Tool.getAttributeValue("name",item);
				int type = FieldLocation.getSubformLocation(SubformName);
				if( type == FieldLocation.BODY_PAGE)
				{
					traverseNode(item);	
				}
				else if ( type == FieldLocation.TABLE_OUTER_SUBFORM)
				{
					tableProcessor.StartAddingTableMarkup(item);
				} 
				else if( type == FieldLocation.INFO_BLOCK)
				{
					infoProcessor.StartAddingInfoMarkup(item);
				}
				// April 20,2008: add handlement with free text block
				else if ( type == FieldLocation.FREE_TEXT_BLOCK)
				{
					freeProcessor.StartAddingMarkup(item);
				}
				// 2008-08-18 add handlement with hidden subform for free text blocks
				else if ( type == FieldLocation.HIDDEN_SUBFORM)
				{
					hiddenSubformProcessor.StartAddingMarkup(item);
				}
				else if( type == FieldLocation.SUMMARY_BLOCK)
				{
					//summProcessor.StartAddingSummMarkup(item);
				}
				else  
				{
					traverseNode(item);
				}
			} 
			else if (item.getNodeName().equals("pageSet")) 
			{
				HandlePageSet(item);
			}
			// field not in the table
			else if (item.getNodeName().equals("field"))
			{
				//fieldLayoutAccCorrection(item);
			}
			else if (item.getNodeName().equals("draw"))
			{
				//drawCorrection(item);
				String fieldName = Tool.getAttributeValue("name",item);
				if( fieldName == null)
					continue;
				if( fieldName.equals(ConfigDom.getTitleNamingConvention()))
					titleProcessor.StartAddingMarkup(item);
			}
		}
	}
	
	private void HandlePageSet(Node PageSet)
	{
		NodeList masterChild = PageSet.getChildNodes();
		Node masterPageitem = null;
		int masterChildLength = masterChild.getLength();
		for (int j = 0; j < masterChildLength; j++) 
		{
			masterPageitem = masterChild.item(j);
			if (masterPageitem.getNodeName().equals("pageArea"))
			{
				HandlePageArea(masterPageitem);
			}
			else if ( masterPageitem.getNodeName().equals("pageSet"))
			{
				HandlePageSet(masterPageitem);
			}
		}
	}
	private void HandlePageArea(Node PageArea) 
	{
		NodeList child = PageArea.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				String SubformName = Tool.getAttributeValue("name",item);
				int type = FieldLocation.getSubformLocation(SubformName);
				if( type == FieldLocation.INFO_BLOCK)
				{
					// this function can handle with all the nodes into that subform
					infoProcessor.StartAddingInfoMarkup(item);	
				}
				else // summary block,free text block
				{
					traverseNode(item);
				}
			} 
			else if (item.getNodeName().equals("field")) 
			{
				//fieldLayoutAccCorrection(item);
			} 
			else if (item.getNodeName().equals("draw")) 
			{
				String fieldName = Tool.getAttributeValue("name",item);
				if( fieldName == null)
					continue;
				if( Tool.isFieldHidden(item))
					continue;
				if( fieldName.equals(ConfigDom.getTitleNamingConvention()))
					titleProcessor.StartAddingMarkup(item);
			}
		}
	}
}