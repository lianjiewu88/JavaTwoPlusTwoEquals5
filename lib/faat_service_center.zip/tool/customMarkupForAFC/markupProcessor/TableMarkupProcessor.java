package customMarkupForAFC.markupProcessor;
import configuration.*;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.Tool;




public class TableMarkupProcessor

{
	Node node = null;
	boolean isTableMarkupExist = false;

	public void AssignTask(Node task)
	{
		node = task;
		isTableMarkupExist = false;
	}
	public void AddCustomTableMarkuptoOuterSubform()
	{
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element tableNode = A1SDocument.createElement(CustomMarkupConfigDom.getTableSubformNodeName()); 
		A1SNode.appendChild(tableNode);
		
		// configurable attribute
		Attr config = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue("true");
		tableNode.setAttributeNode(config);
		
		// tableTargetWidth attribute
		Attr tableWidth = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getTableTargetWidthAttributeName());
		tableWidth.setNodeValue(CustomMarkupConfigDom.getTableDefaultWidth());
		tableNode.setAttributeNode(tableWidth);
		
		// title element
		Element title = A1SDocument.createElement(CustomMarkupConfigDom.getTitleNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		title.setAttributeNode(lang);
		title.setNodeValue(CustomMarkupConfigDom.getDefaultDescriptionValue());
		title.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		tableNode.appendChild(title);
	}
	public void StartAddingTableMarkup(Node task)
	{
		AssignTask(task);
		if( node == null)
		{
			System.out.println("Currently no task assigned to processor!");
			return;
		}
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		String itemName = null;
		String ElementName = null;
		if( Tool.isA1SNodeAlreadyExist(task) == false )
			AddCustomTableMarkuptoOuterSubform();
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			itemName = item.getNodeName();
			// Auguest 11st,2008: Now the table header can also have text fields:
			// so can only distinguish them by element name
			ElementName = Tool.getAttributeValue("name",item);
			if( ElementName == null)
				continue;
			if( ElementName.length() < 3)
				continue;
			ElementName = ElementName.substring(0,3);
			// distinguish by name now
			if( ElementName.equalsIgnoreCase(ConfigDom.getTableHeaderNamingConvention()))
				AddCustomTableMarkupToHeader(item);
			else if ( itemName.equals("field"))
				AddCustomTableMarkupToColumn(item);
			if( itemName.equalsIgnoreCase(CustomMarkupConfigDom.getCustomNodeName()))
			// custom markup already exist
			{
				isTableMarkupExist = true;
			}
			if( itemName.equalsIgnoreCase("subform") || itemName.equalsIgnoreCase("subformSet"))
			{
				// should recursively handle with subnode with subform type
				HandleWithSubNode(item);
			}	
		}
	}
	
	private void HandleWithSubNode(Node node)
	{
		NodeList child = node.getChildNodes();
		int number = child.getLength();
		Node item = null;
		String itemName = null;
		String ElementName = null;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( Tool.isFieldHidden(item) == true)
				continue;
			itemName = item.getNodeName();
			if( itemName.equals("subform") || itemName.equals("subformSet"))
			{
				System.out.println("Subform Name: " + Tool.getAttributeValue("name",item));
				String subformName = Tool.getAttributeValue("name",item);
				if( subformName == null )
					continue;
				if( subformName.length() < 9 )
					HandleWithSubNode(item);
				else
				{
					if( subformName.substring(0,9).equalsIgnoreCase(ConfigDom.getRemarkRowNamingConvention()))
						HandleWithRemarkRow(item);
					else
						HandleWithSubNode(item);
				}
			}
			else 
			{
				ElementName = Tool.getAttributeValue("name",item);
				if( ElementName == null)
					continue;
				if( ElementName.length() < 3)
					continue;
				ElementName = ElementName.substring(0,3);
				if( ElementName.equalsIgnoreCase(ConfigDom.getTableHeaderNamingConvention()) )
					/* Auguest 11st,2008 Now must distinguish by name */
					AddCustomTableMarkupToHeader(item);
				else if( itemName.equals("field"))
					AddCustomTableMarkupToColumn(item);
			}
		}
	}
	
	private void AddCustomRemarkRowSubform(Node node)
	{
		/* add 2008-09-05 : According to Thierry Hidden field must
		 * not be added with custom markup
		 */
		if( Tool.isFieldHidden(node))
			return;
		if( Tool.isA1SNodeAlreadyExist(node) )
			return;
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element RemarkSNode = A1SDocument.createElement(CustomMarkupConfigDom.getTableRemarkFieldName()); 
		A1SNode.appendChild(RemarkSNode);
		
		// configurable attribute
		Attr config = A1SDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue("true");
		RemarkSNode.setAttributeNode(config);
		
		Element description = A1SDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		description.setAttributeNode(lang);
		description.setNodeValue(CustomMarkupConfigDom.getDefaultDescriptionValue());
		description.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		RemarkSNode.appendChild(description);
	}
	private void HandleWithRemarkRow(Node node)
	{
		// 2008-08-25 should add custom markup for Remark row outer-most subform
		AddCustomRemarkRowSubform(node);
		// ignore all the subform in the remark row
		NodeList child = node.getChildNodes();
		int number = child.getLength();
		Node item = null;
		String itemName = null;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( Tool.isFieldHidden(item) == true)
				continue;
			itemName = item.getNodeName();
			if( itemName.equals("subform") || itemName.equals("subformSet"))
			{
				System.out.println("Subform Name: " + Tool.getAttributeValue("name",item));
				HandleWithSubNode(item);
				continue;
			}
			itemName = Tool.getAttributeValue("name",item);
			if( itemName == null)
				continue;
			if( itemName.length() < 3 )
				continue;
			if( itemName.substring(0,3).equalsIgnoreCase(ConfigDom.getTableColumnNamingConvention()))
				AddCustomRemarkMarkup(item);
		}
	}
	
	
	private void AddCustomRemarkMarkup(Node node)
	{
		// judge field presence and a1s existence has already been done
		// before function is called
		/* add 2008-09-05 : According to Thierry Hidden field must
		 * not be added with custom markup
		 */
		if( Tool.isFieldHidden(node))
			return;
		if( Tool.isA1SNodeAlreadyExist(node))
			return;
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element columnNode = A1SDocument.createElement(CustomMarkupConfigDom.getTableRemarkFieldName()); 
		A1SNode.appendChild(columnNode);
		
		// configurable attribute
		Attr config = A1SDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue("true");
		columnNode.setAttributeNode(config);
		
		Element description = A1SDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		description.setAttributeNode(lang);
		description.setNodeValue(CustomMarkupConfigDom.getDefaultDescriptionValue());
		description.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		columnNode.appendChild(description);
		System.out.println("Add custom markup for remark field successfully!");
	}

	// only those cells which are located in the remark row can be added 
	// with the custom markup
	private void AddCustomTableMarkupToColumn(Node node)
	{
		String name = node.getAttributes().getNamedItem("name").getNodeValue();
		String parentName = Tool.getAttributeValue("name",node.getParentNode());
		System.out.println("Operation on Node: " + name);
		if( Tool.isFieldHidden(node) == true)
			return;
		if( Tool.isA1SNodeAlreadyExist(node))
			return;
		if( parentName.toLowerCase().contains(ConfigDom.getRemarkRowNamingConvention()))
		{
			AddCustomRemarkMarkup(node);
			return;
		}
		/* April 23rd,2008:disable according to Thierry,only handle with Remark field
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element columnNode = A1SDocument.createElement(CustomMarkupConfigDom.getTableColumnNodeName()); 
		A1SNode.appendChild(columnNode);
		
		// minuWidth
		Attr width = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getTableminiumWidthNodeName());
		width.setNodeValue(CustomMarkupConfigDom.getTableDefaultMiniumWidth());
		columnNode.setAttributeNode(width);
		
		Element description = A1SDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		description.setAttributeNode(lang);
		description.setNodeValue(CustomMarkupConfigDom.getDefaultDescriptionValue());
		description.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		columnNode.appendChild(description);
		System.out.println("Add custom markup for table column successfully!");
		*/
	}
	
	private void AddCustomTableMarkupToHeader(Node node)
	{
		String name = node.getAttributes().getNamedItem("name").getNodeValue();
		System.out.println("Operation on Node: " + name);
		if( Tool.isFieldHidden(node) )
			return;
		if( Tool.isA1SNodeAlreadyExist(node))
			return;
		String Parentname = node.getParentNode().getAttributes().getNamedItem("name").getNodeValue();
		if( Parentname == null)
			return;
		if( name.length() <= 3)
			return;
		if( !name.substring(0,3).equalsIgnoreCase(ConfigDom.getTableHeaderNamingConvention()))
			return;
		// add 2008-06-04,only real table headers must be added with header markup
		if( !Parentname.toLowerCase().contains(ConfigDom.getTableHeaderNamingConvention()))
			return;
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element headerNode = A1SDocument.createElement(CustomMarkupConfigDom.getTableHeaderNodeName()); 
		A1SNode.appendChild(headerNode);
		
		// configurable attribute
		Attr config = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue("true");
		headerNode.setAttributeNode(config);
		
		// copyFromCustomFields attribute
		Attr copy = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getCopyAttributeName());
		copy.setNodeValue("false");
		headerNode.setAttributeNode(copy);
		
		// fixedWidth attribute
		Attr fixedWidth = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getfixedWidthAttributeName());
		fixedWidth.setNodeValue("false");
		headerNode.setAttributeNode(fixedWidth);
		
		// minuWidth
		Attr width = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getTableminiumWidthNodeName());
		width.setNodeValue(CustomMarkupConfigDom.getTableDefaultMiniumWidth());
		headerNode.setAttributeNode(width);
		
		Element description = A1SDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		description.setAttributeNode(lang);
		description.setNodeValue(CustomMarkupConfigDom.getDefaultDescriptionValue());
		description.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		headerNode.appendChild(description);
		System.out.println("Add custom markup for table header successfully!");
	}
	
}