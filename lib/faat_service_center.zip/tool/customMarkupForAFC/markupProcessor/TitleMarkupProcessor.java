package customMarkupForAFC.markupProcessor;
import configuration.*;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import customMarkupForAFC.markupProcessor.internalObject.FormTitle;
import utilities.Tool;

public class TitleMarkupProcessor

{
	Node node = null;
	boolean isMarkupExist = false;
	private void AssignTask(Node task)
	{
		node = task;
		isMarkupExist = false;
	}
	
	public void StartAddingMarkup(Node task)
	{
		AssignTask(task);
		if( node == null)
		{
			System.out.println("Currently no task assigned to processor!");
			return;
		}
		if( Tool.isA1SNodeAlreadyExist(node))
			return;
		AddCustomMarkup();
	}

	
	private void AddCustomMarkup()
	{
		// 2008-09-09 there is no check functionality for title because some form 
		// actually has no title at all! 
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element textblockNode = A1SDocument.createElement(CustomMarkupConfigDom.getFormTitleNodeName());
		Attr config = A1SDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		if( FormTitle.isStaticTitle(node))
			config.setNodeValue(CustomMarkupConfigDom.getDefaultAttrValue());
		else
			config.setNodeValue("false");
		textblockNode.setAttributeNode(config);
		A1SNode.appendChild(textblockNode);
	}
	
}