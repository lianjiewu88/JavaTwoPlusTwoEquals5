package customMarkupForAFC.markupProcessor;
import configuration.*;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import customMarkupForAFC.markupProcessor.internalObject.FormFieldCaption;
import utilities.Tool;


public class FreeTextProcessor

{
	private Node node = null;
	private boolean isFreeMarkupExist = false;
	private int IDIndex = 1;
	public void AssignTask(Node task)
	{
		node = task;
		isFreeMarkupExist = false;
	}
	
	public void StartAddingMarkup(Node task)
	{
		AssignTask(task);
		if( node == null)
		{
			System.out.println("Currently no task assigned to processor!");
			return;
		}
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		String itemName = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			itemName = item.getNodeName();
			System.out.println("Node name:" + itemName);
			if( itemName.equalsIgnoreCase("draw") || itemName.equalsIgnoreCase("field"))
				AddCustomFreeMarkupToSingleField(item);
			if( itemName.equalsIgnoreCase(CustomMarkupConfigDom.getCustomNodeName()))
			// custom markup already exist
			{
				isFreeMarkupExist = true;
			}
			if( itemName.equalsIgnoreCase("subform"))
			{
				// should recursively handle with subnode with subform type
				HandleWithSubNode(item);
			}
		}
		if( !isFreeMarkupExist)
		{
			AddCustomMarkup();
		}
	}

	/* 2008-08-18: must add this consideration,since in the hidden subform perhaps some fields'
	 * layout is still visible but they inherite the hidden from its parent
	 */
	private boolean isInHiddenSubform(Node node)
	{
		Node parent = node.getParentNode();
		if( parent == null)
			return false;
		String name = Tool.getAttributeValue("name",parent);
		if( name == null)
			return false;
		if( name.equalsIgnoreCase(CustomMarkupConfigDom.getHiddenSubformNamingConvention()))
			return true;
		return false;
	}
	
	private void HandleWithSubNode(Node node)
	{
		NodeList child = node.getChildNodes();
		int number = child.getLength();
		Node item = null;
		String itemName = null;
		boolean isCustomMarkupExist = false;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			/* 2008-08-18 hidden fields must be added with xml markup now
			 * since they are all regarded as possible fields.
			 */
			if( (Tool.isFieldHidden(item) == false) && ( isInHiddenSubform(item) == false))
				continue;
			itemName = item.getNodeName();
			if( itemName.equalsIgnoreCase(CustomMarkupConfigDom.getCustomNodeName()))
				isCustomMarkupExist = true;
			if( itemName.equalsIgnoreCase("subform"))
				HandleWithSubNode(item);
			else if( itemName.equalsIgnoreCase("draw") || itemName.equalsIgnoreCase("field"))
				HandleWithSingleField(item);
		}
		if( !isCustomMarkupExist)
			AddCustomMarkup(node);
	}
	
	private void AddCustomMarkup(Node node)
	{
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element textblockNode = A1SDocument.createElement(CustomMarkupConfigDom.getFreeTextBlockSubformNodeName());
		Attr config = A1SDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue(CustomMarkupConfigDom.getDefaultAttrValue());
		textblockNode.setAttributeNode(config);
		A1SNode.appendChild(textblockNode);
		
		Element title = A1SDocument.createElement(CustomMarkupConfigDom.getTitleNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		title.setAttributeNode(lang);
		title.setNodeValue(CustomMarkupConfigDom.getDefaultTitleValue());
		title.setTextContent(CustomMarkupConfigDom.getDefaultTitleValue());
		textblockNode.appendChild(title);
		System.out.println("Add custom free text block successfully!");
	}
	private void HandleWithSingleField(Node node)
	{
		NodeList child = node.getChildNodes();
		int number = child.getLength();
		boolean isFreeTagExist = false;
		Node item = null;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			System.out.println("Node Name in SingleField Function: " + item.getNodeName());
			if( item.getNodeName().equalsIgnoreCase(CustomMarkupConfigDom.getCustomNodeName()))
				isFreeTagExist = true;
		}
		if( !isFreeTagExist)
			AddCustomFreeMarkupToSingleField(node);
	}
	
	private void AddFieldID(Node node)
	{
		if( node.getNodeName().equals("draw"))
		{
			/* draw can not be used as possible field insertion,just ignore it
			 */
			return;
		}
		if( Tool.NodehasID(node))
		{
			// already have a ID,must not be a field in infoblock,no need to add ID!
			return;
		}
		String name = Tool.getAttributeValue("name",node);
		// 2008-10-10:add id index in order to avoid id conflict issue
		name += IDIndex++;
		if( name.equals("untitledField"))
		{
			Tool.ErrorReport("The Floating Field in Free Text Block Must have Name!");
			return;
		}
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Attr id = AssistNodeParentDocument.createAttribute("id");
		id.setNodeValue(name);
		Element field = (Element)node;
		field.setAttributeNode(id);
	}
	
	private void AddCustomFreeMarkupToSingleField(Node node)
	{
		/* 2008-08-18 hidden fields must be added with xml markup now
		 * since they are all regarded as possible fields.
		 */
		/* 2008-08-22 since all fields in the free text block must be configured, just
		 * comment out the following judging codes
		 */
		/*
		if( (Tool.isFieldHidden(node) == false) && ( isInHiddenSubform(node) == false))
			return;
		*/
		/* 2008-09-10:Only possible fields directly in the free text blocksubform
		 * can be available for field insertion,possible field must have id just as technical name
		 */
		AddFieldID(node);
		if( Tool.isA1SNodeAlreadyExist(node))
			return;
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);

		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element textblockItemNode = A1SDocument.createElement(CustomMarkupConfigDom.getFreeTextItem());
		A1SNode.appendChild(textblockItemNode);
		
		
		Attr configurable = AssistNodeParentDocument.createAttribute("configurable");
		configurable.setNodeValue("true");
		textblockItemNode.setAttributeNode(configurable);
		Element title = A1SDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		title.setAttributeNode(lang);
		// 2008-09-18 here default description is not enough, we must get right value from caption subnode
		String description = FormFieldCaption.getNodeFormattedCaption(node);
		if( description == null)
			description = CustomMarkupConfigDom.getDefaultDescriptionValue();
		title.setNodeValue(description);
		title.setTextContent(description);
		textblockItemNode.appendChild(title);
		System.out.println("Add custom free text block successfully!");
	}

	private void AddCustomMarkup()
	{
		// 2008-08-22 must ignore frmFloatfields
		// do not generate custom markup for hiddenFloatFields
		String name = Tool.getAttributeValue("name", node);
		if( name == null)
			return;
		if( name.equalsIgnoreCase(CustomMarkupConfigDom.getHiddenSubformNamingConvention()))
			return;
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element freetextblockNode = A1SDocument.createElement(CustomMarkupConfigDom.getFreeTextBlockSubformNodeName());
		Attr config = A1SDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue(CustomMarkupConfigDom.getDefaultAttrValue());
		freetextblockNode.setAttributeNode(config);
		A1SNode.appendChild(freetextblockNode);
		
		Element title = A1SDocument.createElement(CustomMarkupConfigDom.getTitleNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		title.setAttributeNode(lang);
		title.setNodeValue(CustomMarkupConfigDom.getDefaultFreeTitle());
		title.setTextContent(CustomMarkupConfigDom.getDefaultFreeTitle());
		freetextblockNode.appendChild(title);
		System.out.println("Add custom free text block successfully!");
	}
}