package customMarkupForAFC.markupProcessor;
import configuration.*;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.Tool;


public class InfoMarkupProcessor

{
	Node node = null;
	boolean isInfoMarkupExist = false;
	/* April 23,2008
	 * disable this since Thierry would not like to use template
	private InfoFieldtemplate infoTemplateProxy = null;
	*/
	/*public InfoMarkupProcessor (CustomMarkupConfigDom configDom)
	{
		markupConfigDom = configDom;
		//infoTemplateProxy = new InfoFieldtemplate();
	}*/
	public void AssignTask(Node task)
	{
		node = task;
		isInfoMarkupExist = false;
		// and the extensiblity template
		/* no need to add now
		Node hiddenTemplate = infoTemplateProxy.generate(node);
		node.insertBefore(hiddenTemplate,node.getFirstChild());
		*/
	}
	
	public void StartAddingInfoMarkup(Node task)
	{
		AssignTask(task);
		if( node == null)
		{
			System.out.println("Currently no task assigned to processor!");
			return;
		}
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		String itemName = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			itemName = item.getNodeName();
			System.out.println("Node name:" + itemName);
			if( itemName.equalsIgnoreCase("draw") || itemName.equalsIgnoreCase("field"))
				AddCustomInfoMarkupToSingleField(item);
			if( itemName.equalsIgnoreCase(CustomMarkupConfigDom.getCustomNodeName()))
			// custom markup already exist
			{
				isInfoMarkupExist = true;
			}
			if( itemName.equalsIgnoreCase("subform"))
			{
				// should recursively handle with subnode with subform type
				HandleWithSubNode(item);
			}
			
		}
		if( !isInfoMarkupExist)
		{
			AddCustomMarkup();
		}
	}

	
	private void HandleWithSubNode(Node node)
	{
		NodeList child = node.getChildNodes();
		int number = child.getLength();
		Node item = null;
		String itemName = null;
		//boolean isCustomMarkupExist = false;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( Tool.isFieldHidden(item) == true)
				continue;
			itemName = item.getNodeName();
			/*if( itemName.equalsIgnoreCase(markupConfigDom.getCustomNodeName()))
				isCustomMarkupExist = true;
			 */
			if( itemName.equalsIgnoreCase("subform"))
				HandleWithSubNode(item);
			else if( itemName.equalsIgnoreCase("draw") || itemName.equalsIgnoreCase("field"))
			{
				/* April 30,2008: Must not add custom markup in nested subforms
				HandleWithSingleField(item);
				*/
			}
		}
		/* the same reason above
		if( !isCustomMarkupExist)
			AddCustomMarkup(node);
		*/
	}
	
	/* add custom markup to info block subform
	private void AddCustomMarkup(Node node)
	{
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(markupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(markupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element infoblockNode = A1SDocument.createElement(markupConfigDom.getInfoBlockSubformNodeName());
		Attr config = A1SDocument.createAttribute(markupConfigDom.getConfigureAttrName());
		config.setNodeValue(markupConfigDom.getDefaultAttrValue());
		infoblockNode.setAttributeNode(config);
		A1SNode.appendChild(infoblockNode);
		
		Element title = A1SDocument.createElement(markupConfigDom.getTitleNodeName());
		Attr lang = A1SDocument.createAttribute(markupConfigDom.getLangAttrName());
		lang.setNodeValue(markupConfigDom.getLangDefaultValue());
		title.setAttributeNode(lang);
		title.setNodeValue(markupConfigDom.getDefaultTitleValue());
		title.setTextContent(markupConfigDom.getDefaultTitleValue());
		infoblockNode.appendChild(title);
		System.out.println("Add custom info block successfully!");
	}
	*/
	
	/*private void HandleWithSingleField(Node node)
	{
		NodeList child = node.getChildNodes();
		int number = child.getLength();
		boolean isInfoTagExist = false;
		Node item = null;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			System.out.println("Node Name in SingleField Function: " + item.getNodeName());
			if( item.getNodeName().equalsIgnoreCase(markupConfigDom.getCustomNodeName()))
				isInfoTagExist = true;
		}
		if( !isInfoTagExist)
			AddCustomInfoMarkupToSingleField(node);
	}*/
	

	private void AddCustomInfoMarkupToSingleField(Node node)
	{
		String name = node.getAttributes().getNamedItem("name").getNodeValue();
		System.out.println("Operation on Node: " + name);
		if( Tool.isFieldHidden(node) == true)
			return;
		if( Tool.isA1SNodeAlreadyExist(node))
			return;
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);

		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element infoblockNode = A1SDocument.createElement(CustomMarkupConfigDom.getInfoBlockItemNodeName());
		A1SNode.appendChild(infoblockNode);
		
		
		Attr configurable = AssistNodeParentDocument.createAttribute("configurable");
		configurable.setNodeValue("true");
		infoblockNode.setAttributeNode(configurable);
		
		/* add April 23,2008 according to Thierry's update document*/
		Attr copy = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getCopyAttributeName());
		copy.setNodeValue("false");
		infoblockNode.setAttributeNode(copy);
		
		Element title = A1SDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		title.setAttributeNode(lang);
		title.setNodeValue(CustomMarkupConfigDom.getDefaultDescriptionValue());
		title.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		infoblockNode.appendChild(title);
		System.out.println("Add custom info block successfully!");
	}

	private void AddCustomMarkup()
	{
		Document AssistNodeParentDocument = node.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);
		node.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Element infoblockNode = A1SDocument.createElement(CustomMarkupConfigDom.getInfoBlockSubformNodeName());
		Attr config = A1SDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue(CustomMarkupConfigDom.getDefaultAttrValue());
		infoblockNode.setAttributeNode(config);
		A1SNode.appendChild(infoblockNode);
		
		Element title = A1SDocument.createElement(CustomMarkupConfigDom.getTitleNodeName());
		Attr lang = A1SDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		title.setAttributeNode(lang);
		title.setNodeValue(CustomMarkupConfigDom.getDefaultTitleValue());
		title.setTextContent(CustomMarkupConfigDom.getDefaultTitleValue());
		infoblockNode.appendChild(title);
		System.out.println("Add custom info block successfully!");
	}
}