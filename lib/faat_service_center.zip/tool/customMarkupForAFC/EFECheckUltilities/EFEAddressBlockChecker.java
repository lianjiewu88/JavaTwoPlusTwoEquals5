package customMarkupForAFC.EFECheckUltilities;

import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JList;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.Tool;
import customMarkupForAFC.MarkupObject;
public class EFEAddressBlockChecker
{
	private Vector<Node> AddressSubformCol = null;
	private EFEErrorLocater errorLocater = null;
	public EFEAddressBlockChecker(Vector<Node> task,JList ListReference,ArrayList<MarkupObject> col)
	{
		AddressSubformCol = task; 
		errorLocater = new EFEErrorLocater(ListReference,col);
	}
	
	public boolean run()
	{
		if( AddressSubformCol.isEmpty())
		{
			// needn't check
			return true;
		}
		int size = AddressSubformCol.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachAddressBlock(AddressSubformCol.elementAt(i)))
				return false;
		}
		return true;
	}
	private boolean checkEachAddressBlock(Node node)
	{
		String error = null;
		String subformName = Tool.getAttributeValue("name", node);
		// 2008-09-11: Currently Address Block Subform is forbidden to have Markup
		if( Tool.getA1SNodeNumber(node) != 0 )
		{
			error = "Address Block: " + subformName + " Mustn't Have Any EFE Markup Currently!";
			Tool.ErrorReport(error);
			errorLocater.LocateErrorPosition(node);
			return false;
		}
		NodeList children = node.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals("subform"))
			{
				boolean ret = checkEachAddressBlock(item);
				if( !ret )
					return false;
			}
			else if( item.getNodeName().equals("field") || item.getNodeName().equals("draw"))
			{
				if ( Tool.getA1SNodeNumber(item) != 0)
				{
					String name = Tool.getAttributeValue("name", item);
					error = "Field: " + name + " in Address Block Mustn't Have Any EFE Markup Currently!";
					Tool.ErrorReport(error);
					errorLocater.LocateErrorPosition(node);
					return false;
				}
				if( !Tool.isFieldReadOnly(item, false))
					return false;
			}
		}
		return true;
	}
}