package customMarkupForAFC.EFECheckUltilities;

import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JList;
import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;
import customMarkupForAFC.MarkupObject;

public class EFETableChecker
{
	private Vector<Node> TableSubformCol = null;
	private Vector<Node> TableHeaderCol = null;
	private Vector<Node> TableRemarkRow = null;
	private EFEErrorLocater errorLocater = null;
	public EFETableChecker(Vector<Node> tableOuter,Vector<Node> TableHeader,Vector<Node> RemarkRow,JList ListReference,ArrayList<MarkupObject> col)
	{
		TableSubformCol = tableOuter;
		TableHeaderCol = TableHeader;
		TableRemarkRow = RemarkRow;
		errorLocater = new EFEErrorLocater(ListReference,col);
	}
	
	private boolean checkRemarkRow()
	{
		if( TableRemarkRow.isEmpty() )
			return true;
		int size = TableRemarkRow.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachRemarkRow(TableRemarkRow.elementAt(i)))
				return false;
		}
		return true;
	}
	
	//	 2008-08-26: do not check remark subform's description for the moment
	private boolean checkEachRemarkRow(Node subform)
	{
		if( !Tool.isSingleA1SNode(subform))
		{
			errorLocater.LocateErrorPosition(subform);
			return false;
		}
		NodeList children = subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( (!item.getNodeName().equals("draw")) && (!item.getNodeName().equals("field")))
				continue;
			/* add 2008-09-05:according to Thierry
			 * hidden field must not have sapa1s node!!
			 */
			if( Tool.isFieldHidden(item) && Tool.hasA1SNode(item))
			{
				Tool.ErrorReport("Hidden Field: " + Tool.getAttributeValue("name",item) + " Must Not Have EFE Markup!");
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isFieldHidden(item) && !Tool.hasA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isSingleA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isFieldReadOnly(item,false))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
		}
		return true;
	}
	
	private boolean checkTableHeader()
	{
		// add 2008-06-03 to support multiple table situations
		if( TableHeaderCol.isEmpty() )
			return true;
		int size = TableHeaderCol.size();
		Node item = null;
		for( int i = 0 ; i < size; i++)
		{
			item = TableHeaderCol.elementAt(i);
			if( !checkEachTableHeader(item))
				return false;
		}
		return true;
	}
	

	public boolean run()
	{
		if( !checkTableSubformDescription())
			return false;
		if( !checkTableHeader())
			return false;
		return checkRemarkRow();
	}
	private boolean checkEachTableSubformDescription(Node node)
	{
		Node a1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( a1s == null )
			return false;
		Node table = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableSubformNodeName(),a1s);
		if( table == null)
			return false;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),table);
		if( title == null)
			return false;
		String description = title.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0 )
			return false;
		if( !Tool.isSingleA1SNode(node))
		{
			errorLocater.LocateErrorPosition(node);
			return false;
		}
		return isDescriptionValidFormat(description);
	}
	
	private boolean isDescriptionValidFormat(String Description)
	{
		if( ConfigDom.DescriptionCheckOn == false)
			return true;
		if( Description.contains("#"))
			return false;
		String condensed = Tool.condense(Description);
		String defaultValue = CustomMarkupConfigDom.getTableDescriptionDefaultValue();
		int length = defaultValue.length();
		if( condensed.length() < length)
			return false;
		return condensed.substring(0,length).equals(defaultValue);
	}
	
	/* add 2008-08-21: check Table outer-most subform description now
	 * only outer-most subform need to check, ignore all those nested subforms
	 */
	private boolean checkTableSubformDescription()
	{
		if( TableSubformCol.isEmpty())
			return true;
		int size = TableSubformCol.size();
		Node item = null;
		String TableSubformName = null;
		for( int i = 0 ; i < size;i++)
		{
			item = TableSubformCol.elementAt(i);
			TableSubformName = Tool.getAttributeValue("name",item);
			if( TableSubformName == null)
				TableSubformName = ConfigDom.getDefaultSubformName();
			if( !checkEachTableSubformDescription(item))
			{
				String error = "Description for Table: <" + TableSubformName + "> must be maintained!";
				error += ( "\n" + "The description format must be like \"Table1\", \"Table2\"..."); 
				Tool.ErrorReport(error);
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !checkEachTableTargetWidthAttr(item))
			{
				Tool.ErrorReport("Table: " + TableSubformName + " TargetWidth Attribute Error!");
				errorLocater.LocateErrorPosition(item);
				return false;
			}
		}
		return true;
	}
	
	private boolean checkEachTableTargetWidthAttr(Node node)
	{
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( sapa1s == null)
			return false;
		Node table = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableSubformNodeName(),sapa1s);
		if( table == null)
			return false;
		String targetWidth = table.getAttributes().getNamedItem(CustomMarkupConfigDom.getTableTargetWidthAttributeName()).getNodeValue();
		if( targetWidth == null)
			return false;
		if( targetWidth.equals(CustomMarkupConfigDom.TableTargetWidthType1))
			return true;
		if( targetWidth.equals(CustomMarkupConfigDom.TableTargetWidthType2))
			return true;
		if( targetWidth.equals(CustomMarkupConfigDom.TableTargetWidthType3))
			return true;
		if( targetWidth.equals(CustomMarkupConfigDom.TableTargetWidthType4))
			return true;
		return false;
	}
	//	 input: the table header subform node
	private boolean checkEachTableHeader(Node node)
	{
		Node item = null;
		Node sapa1s = null;
		if( !Tool.isSingleA1SNode(node))
		{
			errorLocater.LocateErrorPosition(node);
			return false;
		}
		NodeList headers = node.getChildNodes();
		String attri = null;
		int TrueNumber = 0;
		int size = headers.getLength();
		for( int i = 0 ; i < size;i++)
		{
			item = headers.item(i);
			if( !item.getNodeName().equals("field") && !item.getNodeName().equals("draw"))
				continue;
			/*
			 * 2008-09-01 Do not check this, or else the table 
			 * caption will be displayed abnormally in some situation
			if( !checkCaptionSplit(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}*/
			if( !Tool.isFieldReadOnly(item,false))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isSingleA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			/* add 2008-09-05: According to Thierry hidden field must not have 
			 * EFE markup! Delete it!
			 */
			if( Tool.isFieldHidden(item) && ( Tool.hasA1SNode(item)))
			{
				Tool.ErrorReport("Hidden Field: " + Tool.getAttributeValue("name",item) + " Must Not Have sapa1s Node!You Must Delete it!");
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			// add 2008-09-05: visible fields have no sapa1s node, error happens!
			if( !Tool.isFieldHidden(item) && !Tool.hasA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			String itemName = Tool.getAttributeValue("name",item);
			String error = null;
			// add 2008-09-23: table header must use text fields now, or long description will be cut off!
			/* 2008-09-28
			 * Form Table Header currently can use draw for the momemnt, but will enable the check 
			 * in the future 
			 if( item.getNodeName().equals("draw"))
			{
				error = "Node: " + itemName + " Must Use TextField instead of Draw,or else Long Description Might be Truncated!"; 
				Tool.ErrorReport(error);
				errorLocater.LocateErrorPosition(item);
				return false;
			}*/
			
			if( item.getNodeName().equals("field"))
			{
				if( !LayoutTestReuseComponent.isFieldAllowMultipleLine(item))
				{
					error = "Node: " + itemName + " Must Allow Multiple Lines!";
					Tool.ErrorReport(error);
					errorLocater.LocateErrorPosition(item);
					return false;
				}
				if( !LayoutTestReuseComponent.isHeightExpandToFit(item,false))
				{
					error = "Node: " + itemName + " Height Must Expand to Fit!";
					Tool.ErrorReport(error);
					errorLocater.LocateErrorPosition(item);
					return false;
				}
			}
			// add 2008-09-23: add ACC check
			String acc = LayoutTestReuseComponent.getNodeAccessibilitySetting(item);
			if( !acc.equals(ConfigDom.getDefaultAccRightSetting()))
			{
				error = "Table Header Wrong Accessibility settings: " + acc;
				Tool.ErrorReport(error);
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),item);
			if( sapa1s == null)
				continue;
			Node header = Tool.getNodebyRoot(CustomMarkupConfigDom.getTableHeaderNodeName(),sapa1s);
			if( header == null)
				continue;
			attri = header.getAttributes().getNamedItem(CustomMarkupConfigDom.getCopyAttributeName()).getNodeValue();
			if( attri == null)
				continue;
			if( attri.equals("true"))
				TrueNumber++;
		}
		if( TrueNumber == 1)
			return true;
		Tool.ErrorReport("Table Header Can Only Have One \"CopyFromCustomFields\" be true");
		// needn't report table header subform location
		// errorLocater.LocateErrorPosition(node);
		return false;
	}
	
	/* 2008-08-26: Is there anythign in the spec about this?  
	 *This problem was also observed in many other forms.
	 * check if there is caption-split situation in infoblock
	 * in table header, both Field and Draw are possible to be used
	 */
	/* 2008-09-01: Arnold found one issue that if the table header split 
	 * is resolved, the table header will not be displayed so well, so
	 * in the table header this caption split check is not done any more
	 */
	/*private boolean checkCaptionSplit(Node node)
	{
		String name = Tool.getAttributeValue("name", node);
		if( name == null)
			name = "defaultFieldName";
		Node value = Tool.getNodebyRoot("value",node);
		if( value == null)
		// have caption but have no value, error happended!
		{
			Tool.ErrorReport("Field: " + name + " Does Not Have Value Node!");
			return false;
		}
		Node exData = Tool.getNodebyRoot("exData",value);
		if( exData != null)
		{
			Tool.ErrorReport("Field: " + name + " Has Splited Caption!Please Resolve it into Format: Value.Text!");
			return false;
		}
		return true;
	}*/
}