package customMarkupForAFC.EFECheckUltilities;

import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JList;

import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.FieldMappingChecker;
import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;
import customMarkupForAFC.MarkupObject;
import customMarkupForAFC.markupProcessor.internalObject.FormFieldCaption;

public class EFEFreeBlockChecker
{
	private Vector<Node> freeBlockSubformCol = null;
	private EFEErrorLocater errorLocater = null;
	private int DrawNumber = 0;
	public EFEFreeBlockChecker(Vector<Node> task,JList ListReference,ArrayList<MarkupObject> col)
	{
		freeBlockSubformCol = task; 
		errorLocater = new EFEErrorLocater(ListReference,col);
	}
	
	public boolean run()
	{
		if( freeBlockSubformCol.isEmpty() )
			return true;
		int size = freeBlockSubformCol.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachFreeBlock(freeBlockSubformCol.elementAt(i)))
				return false;
			// 2008-10-13: fixed one issue raised by Arnold
			DrawNumber = 0;
		}
		return true;
	}
	
	private boolean isDescriptionValidFormat(String Description)
	{
		if( ConfigDom.DescriptionCheckOn == false)
			return true;
		if( Description.contains("#"))
			return false;
		String condensed = Tool.condense(Description);
		String defaultValue = CustomMarkupConfigDom.getFreeTextBlockDescriptionDefaultValue();
		int length = defaultValue.length();
		if( condensed.length() < length)
			return false;
		return condensed.substring(0,length).equals(defaultValue);
	}
	
	private boolean checkEachFreeBlock(Node subform)
	{
		String error = null;
		String freeblockName = Tool.getAttributeValue("name",subform);
		if( checkFreeBlockDescription(subform) == false )
		{
			if( freeblockName == null)
				freeblockName = ConfigDom.getDefaultSubformName();
			error = "Description for Free Text Block: <" + freeblockName + "> must be maintained!";
			error += ( "\n" + "The description format must be like \"Free Text Block1\", \"Free Text Block2\"..."); 
			Tool.ErrorReport(error);
			errorLocater.LocateErrorPosition(subform);
			return false;
		}
		if( Tool.hasA1SNode(subform) == false)
			return false;
		if( !Tool.isSingleA1SNode(subform))
			return false;
		// supposed there is none nested subform in free text block
		NodeList children = subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals("draw"))
			{
				DrawNumber++;
				if( !Tool.isExDataExist(item))
				{
					error = "Draw: " +  Tool.getAttributeValue("name",item) + " in Free Text Block must have ExData SubNode!";
					Tool.ErrorReport(error);
					errorLocater.LocateErrorPosition(item);
					return false;
				}
				if( !LayoutTestReuseComponent.isHeightExpandToFit(item,true))
				{
					error = "Draw: " + Tool.getAttributeValue("name",item) + " Must Allow Height Expand to Fit!";
					Tool.ErrorReport(error);
					errorLocater.LocateErrorPosition(item);
					return false;
				}
			}
			/* 2008-11-04 Do not check nested free text block since now some block might be regarded 
			 * as free text block now.
			 * if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				error = "Nested Subform: " + Tool.getAttributeValue("name",item) + 
				" Must be Moved Outside Free Text Block: " + freeblockName;
				Tool.ErrorReport(error);
				errorLocater.LocateErrorPosition(item);
				return false;
			}*/
			if( (!item.getNodeName().equals("draw")) && (!item.getNodeName().equals("field")))
				continue;
			if( !checkMapping(item))
				return false;
			if( !Tool.NodehasID(item))
			{
				error = "Field: " + Tool.getAttributeValue("name",item) + " Does Not Have ID!\n";
				error += "You must Run the Tool to Add it!";
				Tool.ErrorReport(error);
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isSingleA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isFieldReadOnly(item,false))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			// all fields in the free text block( except draw ) must have EFE markup
			if( !Tool.DoesPossibleFieldsHaveA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !FormFieldCaption.checkPossibieFieldsDescriptionMaintained(item))
			{
				error = "Possible Field: " + Tool.getAttributeValue("name",item) + " Must Have Description Maintained!";
				error += "\n Description Mustn't be Default like Text Field,Decimal Field,Numeric Field and Date/Time Field";
				Tool.ErrorReport(error);
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			/* 2008-09-10 should only check: 
			 * if it does have sapa1s node, 
			 * then the type is correct. because sometimes the free text block item has wrong
			 * node type as info block item,this is not what we expected
			 */
			if( Tool.DoesPossibleFieldsHaveA1SNode(item) && Tool.getItemCustomMarkupType(item) != CustomMarkupConfigDom.FREEBLOCK_FIELD)
			{
				String itemName = Tool.getAttributeValue("name",item);
				error = "Node: " + itemName + " Must be a Free Text Item,now Wrong Type: " + CustomMarkupConfigDom.type2Name(Tool.getItemCustomMarkupType(item));
				Tool.ErrorReport(error);
				errorLocater.LocateErrorPosition(item);
				return false;
			}
		}
		if( DrawNumber != 1)
		{
			error = "Free Text Block: " + freeblockName + " Must Only have EXACTLY ONE draw";
			Tool.ErrorReport(error);
			errorLocater.LocateErrorPosition(subform);
			return false;
		}
		// need to check whether duplicate field id exist in the future!
		return true;
	}
	
	private boolean checkMapping(Node node)
	{
		FieldMappingChecker.init(node);
		int checkResult = FieldMappingChecker.check();
		String itemName = Tool.getAttributeValue("name", node);
		String error = null;
		if( checkResult == ConfigDom.NO_MAPPING)
		{
			error = "in Free Text Block,Every Possible Field: " + itemName + " Must Have Mapping!";
			Tool.ErrorReport(error);
			errorLocater.LocateErrorPosition(node);
			return false;
		}
		else if ( checkResult == ConfigDom.INVALID_RELATIVE_MAPPING)
		{
			error = "Possible Field: " + itemName + " Uses Relative Mapping,but its Parent Has No Mapping!";
			Tool.ErrorReport(error);
			errorLocater.LocateErrorPosition(node);
			return false;
		}
		return true;
	}
	
	/* 2008-08-21 now SM requires that the description for building blocks must be mandatory,
	 * so this description now must be input by developers manually by tool, and 
	 * tool must check whether it is null or not
	 */
	
	private boolean checkFreeBlockDescription( Node subform)
	{
		if( !Tool.isSingleA1SNode(subform))
			return false;
		Node a1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),subform);
		if( a1s == null )
			return false;
		Node freeblock = Tool.getNodebyRoot(CustomMarkupConfigDom.getFreeTextBlockSubformNodeName(),a1s);
		if( freeblock == null)
			return false;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),freeblock);
		if( title == null)
			return false;
		String description = title.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0 )
			return false;
		return isDescriptionValidFormat(description);
	}
}