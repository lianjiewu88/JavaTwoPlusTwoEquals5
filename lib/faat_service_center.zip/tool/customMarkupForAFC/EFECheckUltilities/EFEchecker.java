package customMarkupForAFC.EFECheckUltilities;

import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import org.w3c.dom.Node;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;
import customMarkupForAFC.MarkupObject;
import customMarkupForAFC.EFECorrection.SaveVerification;


public class EFEchecker
{
	private ArrayList<MarkupObject> markupCollection = null;
	private DefaultMutableTreeNode TreeRoot = null;
	private ArrayList<DefaultMutableTreeNode> hitTreeNodeCollection = null;
	private JTree jTree = null;
	private DefaultListModel jListMode = null;
	private JList jlist = null;
	private Node bodyPage = null;

	
	// 2008-06-05 this is just a workround to tell the difference between a lbl and a label field 
	// in the summaryblock
	//private int defaultNestedLevel = 5;
	
	public EFEchecker(ArrayList<MarkupObject> collection,DefaultMutableTreeNode Root,
			JTree treeControl,DefaultListModel ListMode,JList list)
	{
		markupCollection = collection;
		hitTreeNodeCollection = new ArrayList<DefaultMutableTreeNode>();
		TreeRoot = Root;
		jTree = treeControl;
		jListMode = ListMode;
		jlist = list;
	}
	
	private void highLightTree()
	{
		int size = hitTreeNodeCollection.size();
		DefaultMutableTreeNode item = null;
		TreePath[] newPath = new TreePath[size];
		for( int i = 0 ; i < size; i++)
		{
			item = hitTreeNodeCollection.get(i);
			TreeNode[] path = item.getPath();
			newPath[i] = new TreePath(path);
		}
		jTree.setSelectionPaths(newPath);
		repaintTree();
	}
	
	// 2008-06-05 just a workaround, if 
	private int isSummaryLabel(DefaultMutableTreeNode node)
	{
		TreeNode tree = node.getParent();
		String parentName = null;
		while ( tree != null )
		{
			parentName = tree.toString();
			if( parentName == null)
				return CustomMarkupConfigDom.INVALID_TYPE;
			if( parentName.length() < 7 )
			{
				tree = tree.getParent();
				continue;
			}
			if( parentName.substring(0,7).equalsIgnoreCase(ConfigDom.getSummaryBlockNamingConvention()))
				return CustomMarkupConfigDom.SUMM_SUBFORM;
			tree = tree.getParent();
		}
		return CustomMarkupConfigDom.INVALID_TYPE;
	}
	private int getNodeType(DefaultMutableTreeNode node)
	{
		TreeNode parent = node.getParent();
		if( parent == null)
			return CustomMarkupConfigDom.INVALID_TYPE;
		String name = node.toString();
		if( name.equals(ConfigDom.getTitleNamingConvention()))
			return CustomMarkupConfigDom.FORM_TITLE;
		String parentName = parent.toString();
		if( parentName == null)
			return CustomMarkupConfigDom.INVALID_TYPE;
		if( name.length() < 3)
			return CustomMarkupConfigDom.INVALID_TYPE;
		if( name.substring(0,3).equalsIgnoreCase(ConfigDom.getTableHeaderNamingConvention()))
		{
			// table header subform or table header cell 
			if( parentName.substring(0,3).equalsIgnoreCase(ConfigDom.getTableHeaderNamingConvention()))
				return CustomMarkupConfigDom.TABLE_HEADER_FIELD;
			else
				return CustomMarkupConfigDom.TABLE_HEADER_SUBFORM;
		}
		else if ( (name.substring(0,3).equalsIgnoreCase(ConfigDom.getTableNamingConvention())) && 
		(!name.contains(ConfigDom.getFooterPostfix())))
			return CustomMarkupConfigDom.TABLE_SUBFORM;
		else if ( name.substring(0,3).equalsIgnoreCase(ConfigDom.getSummaryLabelNamingConvention()))
			return isSummaryLabel(node);
		else if ( parentName.equalsIgnoreCase(CustomMarkupConfigDom.getHiddenSubformNamingConvention()))
			return CustomMarkupConfigDom.FREEBLOCK_FIELD;
		if ( node.getChildCount() > 0 )
		{
			// subform situation
			return getSubformType(name,true);
		}
		/* single field,the precondition that the code below work is 
		 * that since currently EFE can only support the field which are directly
		 * inside one subform,nested situation is forbidden
		 */
		return getSubformType(parentName,false);			
	}
	
	private int getSubformType(String name,boolean isSubform)
	{
		if( name.length() < 7 )
			return CustomMarkupConfigDom.INVALID_TYPE;
		if( name.substring(0,7).equalsIgnoreCase(ConfigDom.getInfoblockNamingConvention()))
			return (isSubform == true?CustomMarkupConfigDom.INFOBLOCK_SUBFORM:CustomMarkupConfigDom.INFOBLOCK_FIELD);
		if( name.substring(0,7).equalsIgnoreCase(ConfigDom.getFreeblockNamingConvention()))
			return (isSubform == true?CustomMarkupConfigDom.FREEBLOCK_SUBFORM:CustomMarkupConfigDom.FREEBLOCK_FIELD);
		if( name.substring(0,7).equalsIgnoreCase(ConfigDom.getSummaryBlockNamingConvention()))
			return CustomMarkupConfigDom.SUMM_SUBFORM;
		if( name.length() < 9 )
			return CustomMarkupConfigDom.INVALID_TYPE;
		if( name.substring(0,9).equalsIgnoreCase(ConfigDom.getRemarkRowNamingConvention()))
			return (isSubform == true?CustomMarkupConfigDom.REMARK_SUBFORM:CustomMarkupConfigDom.REMARK_FIELD);
		return CustomMarkupConfigDom.INVALID_TYPE;
	}

	private void repaintTree()
	{
		jTree.setCellRenderer(new DefaultTreeCellRenderer()
        {
             public Component getTreeCellRendererComponent(JTree pTree,
                 Object pValue, boolean pIsSelected, boolean pIsExpanded,
                 boolean pIsLeaf, int pRow, boolean pHasFocus)
             {
            	 DefaultMutableTreeNode node = (DefaultMutableTreeNode)pValue;
            	 super.getTreeCellRendererComponent(pTree, pValue, pIsSelected,
                     pIsExpanded, pIsLeaf, pRow, pHasFocus);

            		 int type = getNodeType(node);
            		 switch ( type )
            		 {
            		 	case CustomMarkupConfigDom.FORM_TITLE:
            		 		setForeground(Color.magenta);
            		 		break;
            		 	case CustomMarkupConfigDom.INFOBLOCK_SUBFORM:
            		 		setForeground(Color.red);
            		 		break;
            		 	case CustomMarkupConfigDom.INFOBLOCK_FIELD:
            		 		setForeground(Color.green);
            		 		break;
            		 	case CustomMarkupConfigDom.FREEBLOCK_SUBFORM:
            		 		setForeground(Color.orange);
            		 		break;
            		 	case CustomMarkupConfigDom.FREEBLOCK_FIELD:
            		 		setForeground(Color.blue);
            		 		break; 
            		 	case CustomMarkupConfigDom.TABLE_SUBFORM:
            		 		setForeground(Color.blue);
            		 		break;
            		 	case CustomMarkupConfigDom.TABLE_HEADER_SUBFORM:
            		 		setForeground(Color.orange);
            		 		break;
            		 	case CustomMarkupConfigDom.TABLE_HEADER_FIELD:
            		 		setForeground(Color.magenta);
            		 		break;
            		 	case CustomMarkupConfigDom.REMARK_FIELD:
            		 		setForeground(Color.cyan);
            		 		break;
            		 	case CustomMarkupConfigDom.REMARK_SUBFORM:
            		 		setForeground(Color.pink);
            		 		break;
            		 	case CustomMarkupConfigDom.SUMM_SUBFORM:
            		 		setForeground(Color.green);
            		 		break;
            		 	case CustomMarkupConfigDom.SUMM_LABEL:
            		 		setForeground(Color.magenta);
            		 		break;
            		 	default:
            	 		//System.out.println("Invalid type!");
            		 }
                 return (this);
             }
        });
		jTree.updateUI();
		jTree.repaint();
	}
	public void done()
	{
		if( FindHighLightTreeNode())
			highLightTree();
		printTotal();	
	}
	private void printTotal()
	{
		String data = null;
		int totalformtitle = 0;
		int totalInfoSubform = 0;
		int totalInfoField = 0;
		int totalFreeSubform = 0;
		int totalFreeField = 0;
		int totalTableSubform = 0;
		int totalTableHeaderLabel = 0;
		int totalRemarkCell = 0;
		int totalSummarySubform = 0;
		int totalSummaryField = 0;
		int totalError = 0;
		MarkupObject item = null;
		if( markupCollection.isEmpty() )
			return;
		int type = CustomMarkupConfigDom.INVALID_TYPE;
		int size = markupCollection.size();
		for( int i = 0 ; i < size; i++)
		{
			item = markupCollection.get(i);
			type = item.getType();
			switch ( type)
			{
				case CustomMarkupConfigDom.FORM_TITLE:
					totalformtitle++;
					break;
				case CustomMarkupConfigDom.INFOBLOCK_SUBFORM:
					totalInfoSubform++;
					break;
				case CustomMarkupConfigDom.INFOBLOCK_FIELD:
					totalInfoField++;
					break;
				case CustomMarkupConfigDom.FREEBLOCK_SUBFORM:
					totalFreeSubform++;
					break;
				case CustomMarkupConfigDom.FREEBLOCK_FIELD:
					totalFreeField++;
					break;
				case CustomMarkupConfigDom.TABLE_SUBFORM:
					totalTableSubform++;
					break;
				case CustomMarkupConfigDom.TABLE_HEADER_FIELD:
					totalTableHeaderLabel++;
					break;
				case CustomMarkupConfigDom.REMARK_FIELD:
					totalRemarkCell++;
					break;
				case CustomMarkupConfigDom.SUMM_SUBFORM:
					totalSummarySubform++;
					break;
				case CustomMarkupConfigDom.SUMM_LABEL:
					totalSummaryField++;
					break;
				case CustomMarkupConfigDom.TABLE_HEADER_SUBFORM:
					break;
				case CustomMarkupConfigDom.REMARK_SUBFORM:
					break;
				default:
					totalError++;
			}
		}
		data = "TOTAL FORM TITLE NUMBER for EFE: " + totalformtitle;
		jListMode.addElement(data);
		data = "TOTAL INFOBLOCK SUBFORM NUMBER for EFE: " + totalInfoSubform;
		jListMode.addElement(data);
		data = "TOTAL INFOBLOCK FIELD NUMBER for EFE: " + totalInfoField;
		jListMode.addElement(data);
		data = "TOTAL FREE TEXT BLOCK SUBFORM NUMBER for EFE: " + totalFreeSubform;
		jListMode.addElement(data);
		data = "TOTAL FREE TEXT BLOCK FIELD NUMBER for EFE: " + totalFreeField;
		jListMode.addElement(data);
		data = "TOTAL TABLE OUTERMOST SUBFORM NUMBER for EFE: " + totalTableSubform;
		jListMode.addElement(data);
		data = "TOTAL TABLE HEADER LABEL FIELD NUMBER for EFE: " + totalTableHeaderLabel;
		jListMode.addElement(data);
		data = "TOTAL TABLE REMARK FIELD NUMBER for EFE: " + totalRemarkCell;
		jListMode.addElement(data);
		data = "TOTAL SUMMARY BLOCK SUBFORM NUMBER for EFE: " + totalSummarySubform;
		jListMode.addElement(data);
		data = "TOTAL SUMMARY BLOCK FIELD NUMBER for EFE: " + totalSummaryField;
		jListMode.addElement(data);
		data = "TOTAL ERROR TYPE NUMBER for EFE: " + totalError;
		jListMode.addElement(data);
		if( (totalError == 0) && ( SaveVerification.QueryStatus(bodyPage)))
		{
			jListMode.addElement("\n");
			data = "NO ERROR FOUND";
			jListMode.addElement(data);
			data = "EFE CONVERSION IS DONE OK";
			jListMode.addElement(data);
		}
		jListMode.addElement("\n");
		data = "FINAL TEMPLATE MUST BE SAVED BY \"SAVE AS\" MENU";
		jListMode.addElement(data);
	}
	private boolean FindHighLightTreeNode()
	{
		if( markupCollection.isEmpty())
			return false;
		int size = markupCollection.size();
		MarkupObject obj = null;
		String name = null;
		DefaultMutableTreeNode found = null;
		int occurance = -1;
		for( int i = 0 ; i < size;i++)
		{
			obj = markupCollection.get(i);
			name = obj.getObjectName();
			if( name == null)
				continue;
			occurance = getOccurance(i);
			if( occurance == 1)
				found = getSingleNodeByName(name);
			else
			{
				int relative = convertAbsolute2RelativeIndex(i);
				found = getNodeByRelativeIndex(name,relative);
			}
			if( found != null)
				hitTreeNodeCollection.add(found);
		}
		return (!hitTreeNodeCollection.isEmpty());
	}
	
	// get the occurance of the name by index ( InList Box )
	private int getOccurance(int indexInListBox)
	{
		MarkupObject Obj = markupCollection.get(indexInListBox);
		if( Obj == null)
			return -1;
		if( Obj.getObjectName() == null)
			return -1;
		int occurance = 0;
		MarkupObject item = null;
		int size = markupCollection.size();
		for( int i = 0 ; i < size;i++)
		{
			item = markupCollection.get(i);
			if( item.getObjectName() == null )
				continue;
			if( item.getObjectName().equals(Obj.getObjectName()))
				occurance++; 
		}
		return occurance;
	}
	
	// get relative index of an object in the listbox by absoluteIndex
	private int convertAbsolute2RelativeIndex(int AbsoluteIndex)
	{
		String hitName = markupCollection.get(AbsoluteIndex).getObjectName();
		int size = markupCollection.size();
		String name = null;
		ArrayList<Integer> temp = new ArrayList<Integer>();
		for( int i = 0 ; i < size;i++)
		{
			name = markupCollection.get(i).getObjectName();
			if( name == null)
				continue;
			if( name.equals(hitName))
				temp.add(i);
		}
		// find relative index
		System.out.println("AbsoluteIndex: " + AbsoluteIndex);
		System.out.println("All found number: " + temp.size());
		for( int j = 0 ; j < temp.size();j++)
		{
			System.out.println("Index: " + temp.get(j).toString());
		}
		int match = temp.indexOf(AbsoluteIndex);
		System.out.println("RelativeIndex: " + match);
		match++;
		return match;
	}
	
	// get tree node by name
	private DefaultMutableTreeNode getSingleNodeByName(String ItemName)
	{
		DefaultMutableTreeNode root = TreeRoot;
		DefaultMutableTreeNode node = root.getNextNode();
		String Name = null;
		while( node != null)
		{
			Name = node.toString();
			if( Name.equals(ItemName))
				return node;
			node = node.getNextNode();
		}
		System.out.println("Node: " + ItemName + " Not find in Tree!");
		return null;
	}
	
	// find tree node by name and relative index
	private DefaultMutableTreeNode getNodeByRelativeIndex(String ItemName,int RelativeIndex)
    {
    	// can equal to 1: the first occurance
    	if( RelativeIndex < 1)
    	{
    		System.out.println("Error Relative Index: " + RelativeIndex);
    		//System.exit(0);
    		return null;
    	}
    	DefaultMutableTreeNode root = TreeRoot;
		DefaultMutableTreeNode node = root.getNextNode();
		String Name = null;
		while( node != null)
		{
			Name = node.toString();
			if( Name.equals(ItemName))
			{
				if( RelativeIndex == 1)
				{
					//repaintTree();
					return node;
				}
				else
				{
					// ignore this match
					RelativeIndex--;
				}
			}
			node = node.getNextNode();
		}
		System.out.println("Node: " + ItemName + " Not find in Tree!");
		return null;
    }
	
	private int getOccuranceInTree(DefaultMutableTreeNode selectedTreeNode)
	{
		DefaultMutableTreeNode node = TreeRoot.getNextNode();
		int occurance = 0;
		while( node != null)
		{
			if( node.equals(selectedTreeNode))
				occurance++;
			node = node.getNextNode();
		}
		return occurance;
	}
	private MarkupObject getMarkupObjectByName(String name)
	{
		if( markupCollection.isEmpty())
			return null;
		MarkupObject item = null;
		int size = markupCollection.size();
		for( int i = 0 ; i < size; i++)
		{
			item = markupCollection.get(i);
			if( item.getObjectName().equals(name))
				return item;
		}
		return null;
	}
	
	public void highLightListBox(DefaultMutableTreeNode selectedTreeNode)
	{
		jListMode.clear();
		MarkupObject item = null;
		int occurance = getOccuranceInTree(selectedTreeNode);
		if( occurance == 1 )
		{
			item = getMarkupObjectByName(selectedTreeNode.toString());
			DisplayDetail(item);
		}
	}

	private void DisplayDetail(MarkupObject obj)
	{
		if( obj == null)
			return;
		String data = null;
		data = "Adobe Designer Node Name: " + obj.getObjectName();
		jListMode.addElement(data);
		String description = obj.getDescription();
		if( description.length() == 0)
			description = "EMPTY ( DEFAULT VALUE )";
		data = "Current Description: " + description;
		jListMode.addElement(data);
		final int type = obj.getType();
		switch ( type )
		{
			case CustomMarkupConfigDom.INFOBLOCK_SUBFORM:
				data = "Info Block Subform,only description must be maintained";
				jListMode.addElement(data);
				jlist.setForeground(Color.red);
				break;
			case CustomMarkupConfigDom.INFOBLOCK_FIELD:
				data = "Info Block Field";
				jListMode.addElement(data);
				data = "CopyFromAttribute = " + obj.getCopyAttributeValue();
				jListMode.addElement(data);
				jlist.setForeground(Color.green);
				break;
			case CustomMarkupConfigDom.FREEBLOCK_SUBFORM:
				data = "Free Text Subform,only description must be maintained";
				jListMode.addElement(data);
				break;
			case CustomMarkupConfigDom.FREEBLOCK_FIELD:
				data = "Free Text Field,only description must be maintained";
				jListMode.addElement(data);
				break;
			case CustomMarkupConfigDom.TABLE_SUBFORM:
				data = "Table Outermost Subform";
				jListMode.addElement(data);
				data = "TargetWidth = " + obj.getTargetWidth() + "mm";
				jListMode.addElement(data);
				data = "In a nested table even there might be more than one subform";
				jListMode.addElement(data);
				data = "which start with tbl,but only the outermost one must be maintained for EFE";
				jListMode.addElement(data);
				jlist.setForeground(Color.blue);
				break;
			case CustomMarkupConfigDom.TABLE_HEADER_SUBFORM:
				data = "Table Header Subform";
				jListMode.addElement(data);
				data = "All table headers are wrapped into this subform";
				jListMode.addElement(data);
				data = "This node itself need not be maintained for EFE";
				jListMode.addElement(data);
				data = "but all of the header label fields within it need to be maitained";
				jListMode.addElement(data);
				jlist.setForeground(Color.orange);
				break;
			case CustomMarkupConfigDom.TABLE_HEADER_FIELD:
				data = "Table Header Field";
				jListMode.addElement(data);
				data = "miniumWidth = " + obj.getMiniumWidth() + "mm";
				jListMode.addElement(data);
				data = "fixWidth = " + obj.getFixWidthAttributeValue();
				jListMode.addElement(data);
				data = "copyFromCustomField = " + obj.getCopyAttributeValue();
				jListMode.addElement(data);
				jlist.setForeground(Color.magenta);
				break;
			case CustomMarkupConfigDom.REMARK_FIELD:
				data = "Remark Field";
				jListMode.addElement(data);
				jlist.setForeground(Color.cyan);
				break;
			case CustomMarkupConfigDom.REMARK_SUBFORM:
				data = "Remark Subform";
				jListMode.addElement(data);
				data = "This node itself need not be maintained for EFE";
				jListMode.addElement(data);
				data = "but all of the remark fields within it need to be maitained";
				jListMode.addElement(data);
				jlist.setForeground(Color.pink);
				break;
			case CustomMarkupConfigDom.SUMM_LABEL:
				data = "Summary Label Field";
				jListMode.addElement(data);
				jlist.setForeground(Color.green);
				break;
			case CustomMarkupConfigDom.SUMM_SUBFORM:
				data = "Summary Subform";
				jListMode.addElement(data);
				jlist.setForeground(Color.green);
				break;
			default:
		}
	}
}