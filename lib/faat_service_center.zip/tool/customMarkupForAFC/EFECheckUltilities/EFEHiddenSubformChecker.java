package customMarkupForAFC.EFECheckUltilities;

import java.util.ArrayList;

import javax.swing.JList;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import customMarkupForAFC.MarkupObject;
import utilities.Tool;

public class EFEHiddenSubformChecker
{
	private Node HiddenSubform = null;
	private EFEErrorLocater errorLocater = null;
	public EFEHiddenSubformChecker(Node task,JList ListReference,ArrayList<MarkupObject> col)
	{
		HiddenSubform = task; 
		errorLocater = new EFEErrorLocater(ListReference,col);
	}
	
	public boolean run()
	{
		return checkAllPossibleFields();
	}
	
	private boolean checkAllPossibleFields()
	{
		NodeList children = HiddenSubform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( (!item.getNodeName().equals("field")) && (!item.getNodeName().equals("draw")))
				continue;
			if( !Tool.isSingleA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( Tool.DoesPossibleFieldsHaveA1SNode(item) == false)
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			/* 2008-09-04 All possible fields needn't to be 
			 * hidden since they inherit the presence of their subform
			if( !Tool.isFieldHidden(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			*/
		}
		return true;
	}
}