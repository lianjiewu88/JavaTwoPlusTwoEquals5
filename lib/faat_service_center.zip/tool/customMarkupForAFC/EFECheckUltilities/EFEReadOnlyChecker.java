package customMarkupForAFC.EFECheckUltilities;

import java.util.Vector;
import org.w3c.dom.Node;
import configuration.ConfigDom;
import utilities.Tool;

public class EFEReadOnlyChecker
{
	private Vector<Node> allOtherFields = null;
	public EFEReadOnlyChecker(Vector<Node> task)
	{
		allOtherFields = task;
	}
	public boolean run()
	{
		if( allOtherFields.isEmpty() )
			return true;
		int size = allOtherFields.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachTextField(allOtherFields.elementAt(i)))
			{
				String name = Tool.getAttributeValue("name",allOtherFields.elementAt(i));
				Node parent = allOtherFields.elementAt(i).getParentNode();
				String parentName = Tool.getAttributeValue("name", parent);
				String error = "Field: " + name + " Must be Read Only!Parent Node: " + parentName;
				Tool.ErrorReport(error);
				return false;
			}
		}
		return true;
	}
	private boolean checkEachTextField(Node node)
	{
		if( !node.getNodeName().equals("field"))
			return true;
		if( Tool.isBarCode(node))
			return true;
		String name = Tool.getAttributeValue("name", node);
		if( name != null)
		{
			if( name.equals(ConfigDom.getFormFieldLogoName()))
				return true;
		}
		String readOnly = Tool.getAttributeValue("access", node);
		if( readOnly == null)
			return false;
		if( !readOnly.equals(ConfigDom.getFieldAccessReadOnly()))
			return false;
		return true;
	}
}