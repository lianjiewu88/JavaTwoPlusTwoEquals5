package customMarkupForAFC.EFECheckUltilities;

import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JList;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;
import customMarkupForAFC.MarkupObject;

public class EFEInfoblockChecker
{
	private Vector<Node> infoBlockSubformCol = null;
	private EFEErrorLocater errorLocater = null;
	public EFEInfoblockChecker(Vector<Node> task,JList ListReference,ArrayList<MarkupObject> col)
	{
		infoBlockSubformCol = task; 
		errorLocater = new EFEErrorLocater(ListReference,col);
	}
	public void traceMarkupObjCol()
	{
		errorLocater.displayCollection();
	}
	
	/*
	public void traceAllInfoBlockSubformCol()
	{
		if( infoBlockSubformCol.isEmpty())
			return;
		int size = infoBlockSubformCol.size();
		Node item = null;
		for( int i = 0 ; i < size;i++)
		{
			item = infoBlockSubformCol.elementAt(i);
			System.out.println("Subform Name: " + Tool.getAttributeValue("name", item));
			System.out.println("Parent Name: " + Tool.getAttributeValue("name", item.getParentNode()));
		}
	}
	*/
	public boolean run()
	{
		if( infoBlockSubformCol.isEmpty() )
			return true;
		int size = infoBlockSubformCol.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachInfoBlock(infoBlockSubformCol.elementAt(i)))
				return false;
		}
		return true;
	}
	

	/* 2008-08-21 now SM requires that the description for building blocks must be mandatory,
	 * so this description now must be input by developers manually by tool, and 
	 * tool must check whether it is null or not
	 */
	
	private boolean checkInfoBlockDescription( Node subform)
	{
		Node a1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),subform);
		if( a1s == null )
			return true;
		Node infoblock = Tool.getNodebyRoot(CustomMarkupConfigDom.getInfoBlockSubformNodeName(),a1s);
		if( infoblock == null)
			return false;
		Node title = Tool.getNodebyRoot(CustomMarkupConfigDom.getTitleNodeName(),infoblock);
		if( title == null)
			return false;
		String description = title.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0 )
			return false;
		/* 2008-08-22 should check whether description follows the format defined by Gia duong 
		 * Info Block1,2....
		 */
		if( !Tool.isSingleA1SNode(subform))
			return false;
		return isDescriptionValidFormat(description);
	}
	
	private boolean isDescriptionValidFormat(String Description)
	{
		if( ConfigDom.DescriptionCheckOn == false)
			return true;
		if( Description.contains("#"))
			return false;
		String condensed = Tool.condense(Description);
		String defaultValue = CustomMarkupConfigDom.getInfoBlockDescriptionDefaultValue();
		int length = defaultValue.length();
		if( condensed.length() < length)
			return false;
		return condensed.substring(0,length).equals(defaultValue);
	}
	
	// 2008-08-26: It is highly neccessary to enable the tool 
	// to check possible duplicate a1snode
	
	//	check each infoblock subform, the input is the root subform
	private boolean checkEachInfoBlock(Node subform)
	{
		Node item = null;
		Node sapa1s = null;
		Node info = null;
		NodeList infoChildren = null;
		String attri = null;
		String error = null;
		String InfoblockName = Tool.getAttributeValue("name",subform);
		if( InfoblockName == null)
			InfoblockName = ConfigDom.getDefaultSubformName();
		// add 2008-9-1;if the node has no A1SNode,it failes to be found in
		// markup object
		if( Tool.hasA1SNode(subform) == false )
			return false;
		if( checkInfoBlockDescription(subform) == false )
		{
			error = "Description for Infoblock: <" + InfoblockName + "> must be maintained!";
			error += ( "\n" + "The description format must be like \"Info Block1\", \"Info Block2\"...");
			error += ( "\n" + "Case Sensitive!!");
			Tool.ErrorReport(error);
			// add 2008-08-28 Error Location Detection
			errorLocater.LocateErrorPosition(subform);
			return false;
		}
		int TrueNumber = 0;
		infoChildren = subform.getChildNodes();
		int size = infoChildren.getLength();
		for( int i = 0; i < size; i++)
		{
			item = infoChildren.item(i);
			if( !item.getNodeName().equals("field") && !item.getNodeName().equals("draw"))
				continue;
			String name = Tool.getAttributeValue("name",item);
			/* add 2008-09-05: According to Thierry that hidde subform in infoblock must not be added with 
			 * xml markup
			 */
			if( !checkCaptionSplit(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( Tool.isFieldHidden(item) && Tool.hasA1SNode(item))
			{
				Tool.ErrorReport("Hidden Field: " + name + " Must Not Have sapa1s Node!You Must Delete it!");
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isFieldReadOnly(item,false))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( Tool.checkPageFieldExist(item))
			{
				Tool.ErrorReport("Field: " + name + " Must be Put Outside of InfoBlock!");
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isSingleA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			/* add 2008-09-05: according to Thierry's issue:137
			 * unhidden field must have xml markup mandatory!
			 */
			if( !Tool.isFieldHidden(item) && !Tool.hasA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			int type = Tool.getItemCustomMarkupType(item);
			if( type != CustomMarkupConfigDom.INFOBLOCK_FIELD && Tool.hasA1SNode(item))
			{
				error = "Field: " + name + " in Infoblock has Wrong Markup Type: " + CustomMarkupConfigDom.type2Name(type);
				Tool.ErrorReport(error);
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),item);
			if( sapa1s == null)
				continue;
			info = Tool.getNodebyRoot(CustomMarkupConfigDom.getInfoBlockItemNodeName(),sapa1s);
			if( info == null)
				continue;
			attri = info.getAttributes().getNamedItem(CustomMarkupConfigDom.getCopyAttributeName()).getNodeValue();
			if( attri == null)
				continue;
			if( attri.equals("true"))
				TrueNumber++;
		}
		if( TrueNumber == 1)
			return true;
		Tool.ErrorReport("Info Block: " +  InfoblockName + " Can Only Have One \"CopyFromCustomFields\" be true");
		errorLocater.LocateErrorPosition(subform);
		return false;
	}
	

	/* 2008-08-26: Is there anythign in the spec about this?  
	 *This problem was also observed in many other forms.
	 * check if there is caption-split situation in infoblock
	 * in infoblock, only Field can be used???
	 */
	private boolean checkCaptionSplit(Node node)
	{
		String name = Tool.getAttributeValue("name", node);
		if( name == null)
			name = "defaultFieldName";
		Node caption = Tool.getNodebyRoot("caption",node);
		if( caption == null)
		// no caption, such situation can not happen?
			return true;
		Node value = Tool.getNodebyRoot("value",caption);
		if( value == null)
		// have caption but have no value, error happended!
		// such situation does exist in DeliveryNote@Address block!
		{
			//Tool.ErrorReport("Field: " + name + " Does Not Have Value Node!");
			return true;
		}
		Node exData = Tool.getNodebyRoot("exData",value);
		if( exData != null)
		{
			Tool.ErrorReport("Field: " + name + " Has Splited Caption!Please Resolve it into Format: Value.Text!");
			return false;
		}
		return true;
	}
}