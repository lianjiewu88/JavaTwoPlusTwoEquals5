package customMarkupForAFC.EFECheckUltilities;

import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JList;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;
import customMarkupForAFC.MarkupObject;

// 2008-08-26 it is possible that Summary block has nested subform,
// must handle with such situation 
public class EFESummaryChecker
{
	private Vector<Node> summaryBlockSubformCol = null;
	private EFEErrorLocater errorLocater = null;
	public EFESummaryChecker(Vector<Node> task,JList ListReference,ArrayList<MarkupObject> col)
	{
		summaryBlockSubformCol = task; 
		errorLocater = new EFEErrorLocater(ListReference,col);
	}
	
	public boolean run()
	{
		if( summaryBlockSubformCol.isEmpty() )
			return true;
		int size = summaryBlockSubformCol.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachSummBlock(summaryBlockSubformCol.elementAt(i)))
				return false;
		}
		return true;
	}
	
	private boolean isDescriptionValidFormat(String Description)
	{
		if( ConfigDom.DescriptionCheckOn == false)
			return true;
		if( Description.contains("#"))
			return false;
		String condensed = Tool.condense(Description);
		String defaultValue = CustomMarkupConfigDom.getSummaryBlockDescriptionDefaultValue();
		int length = defaultValue.length();
		if( condensed.length() < length)
			return false;
		return condensed.substring(0,length).equals(defaultValue);
	}
	
	private boolean checkEachSummBlock(Node subform)
	{
		if( checkSummBlockDescription(subform) == false )
		{
			String summblockName = Tool.getAttributeValue("name",subform);
			if( summblockName == null)
				summblockName = ConfigDom.getDefaultSubformName();
			String error = "Description for Summary Block: <" + summblockName + "> must be maintained!";
			error += ( "\n" + "The description format must be like \"Summary Block1\", \"Summary Block2\"..."); 
			Tool.ErrorReport(error);
			errorLocater.LocateErrorPosition(subform);
			return false;
		}
		if( !Tool.hasA1SNode(subform))
			return false;
		return checkAllFields(subform);
	}
	
	// 2008-08-25 it is impossible the nested subform has certain sapa1s node,so just
	// ignore nested subform
	private boolean checkAllFields(Node subform)
	{
		if( !Tool.isSingleA1SNode(subform))
		{
			errorLocater.LocateErrorPosition(subform);
			return false;
		}
		NodeList children = subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			String name = Tool.getAttributeValue("name", item);
			System.out.println("Name: " + name);
			if( item.getNodeName().equals("subform"))
			{
				if( !checkAllFields(item))
					return false;
			}
			if( (!item.getNodeName().equals("draw")) && (!item.getNodeName().equals("field")))
				continue;
			if( Tool.isFieldHidden(item) && Tool.hasA1SNode(item))
			{
				Tool.ErrorReport("Hidden Field: " + Tool.getAttributeValue("name",item) + " Must Not Have EFE Markup!");
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isSingleA1SNode(item))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
			if( !Tool.isFieldReadOnly(item,false))
			{
				errorLocater.LocateErrorPosition(item);
				return false;
			}
		}
		return true;
	}
	/* 2008-08-25 now SM requires that the description for building blocks must be mandatory,
	 * so this description now must be input by developers manually by tool, and 
	 * tool must check whether it is null or not
	 */
	
	private boolean checkSummBlockDescription( Node subform)
	{
		Node a1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),subform);
		if( a1s == null )
			return false;
		Node summblock = Tool.getNodebyRoot(CustomMarkupConfigDom.getSummaryBlockSubformName(),a1s);
		if( summblock == null)
			return false;
		Node Desp = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),summblock);
		if( Desp == null)
			return false;
		String description = Desp.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0 )
			return false;
		return isDescriptionValidFormat(description);
	}
}