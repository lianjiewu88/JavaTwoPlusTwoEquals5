package customMarkupForAFC.EFECheckUltilities;

import java.util.Vector;
import org.w3c.dom.Node;
import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;

public class SummaryChecker
{
	private Vector<Node> summaryBlockSubformCol = null;
	public SummaryChecker(Vector<Node> task)
	{
		summaryBlockSubformCol = task; 
	}
	
	public boolean run()
	{
		if( summaryBlockSubformCol.isEmpty() )
			return true;
		int size = summaryBlockSubformCol.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachSummBlock(summaryBlockSubformCol.elementAt(i)))
				return false;
		}
		return true;
	}
	
	private boolean isDescriptionValidFormat(String Description)
	{
		String condensed = Tool.condense(Description);
		String defaultValue = CustomMarkupConfigDom.getSummaryBlockDescriptionDefaultValue();
		int length = defaultValue.length();
		if( condensed.length() < length)
			return false;
		return condensed.substring(0,length).equals(defaultValue);
	}
	
	private boolean checkEachSummBlock(Node subform)
	{
		if( checkSummBlockDescription(subform) == false )
		{
			String summblockName = Tool.getAttributeValue("name",subform);
			if( summblockName == null)
				summblockName = ConfigDom.getDefaultSubformName();
			String error = "Description for Summary Block: <" + summblockName + "> must be maintained!";
			error += ( "\n" + "The description format must be like \"Summary Block1\", \"Summary Block2\"..."); 
			Tool.ErrorReport(error);
			return false;
		}
		return true;
	}
	
	/* 2008-08-25 now SM requires that the description for building blocks must be mandatory,
	 * so this description now must be input by developers manually by tool, and 
	 * tool must check whether it is null or not
	 */
	
	private boolean checkSummBlockDescription( Node subform)
	{
		Node a1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),subform);
		if( a1s == null )
			return false;
		Node summblock = Tool.getNodebyRoot(CustomMarkupConfigDom.getSummaryBlockSubformName(),a1s);
		if( summblock == null)
			return false;
		Node Desp = Tool.getNodebyRoot(CustomMarkupConfigDom.getDescriptionNodeName(),summblock);
		if( Desp == null)
			return false;
		String description = Desp.getTextContent();
		if( description == null)
			return false;
		if( description.length() == 0 )
			return false;
		return isDescriptionValidFormat(description);
	}
}