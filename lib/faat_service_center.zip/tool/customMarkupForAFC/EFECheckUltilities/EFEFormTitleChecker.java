package customMarkupForAFC.EFECheckUltilities;

import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JList;
import org.w3c.dom.Node;
import utilities.Tool;
import customMarkupForAFC.MarkupObject;
import customMarkupForAFC.markupProcessor.internalObject.FormTitle;
public class EFEFormTitleChecker
{
	private Vector<Node> FormTitleCol = null;
	private EFEErrorLocater errorLocater = null;
	public EFEFormTitleChecker(Vector<Node> task,JList ListReference,ArrayList<MarkupObject> col)
	{
		FormTitleCol = task; 
		errorLocater = new EFEErrorLocater(ListReference,col);
	}
	
	public boolean run()
	{
		if( FormTitleCol.isEmpty())
		{
			String error = "No Form Title Found! Maybe You Use \"TextField\" as Form Title\n";
			error += "Please Use \"draw\" Instead, Or Else It'll Confuse EFE!";
			Tool.ErrorReport(error);
			return false;
		}
		int size = FormTitleCol.size();
		for( int i = 0 ; i < size;i++)
		{
			if( !checkEachFormTitle(FormTitleCol.elementAt(i)))
				return false;
		}
		return true;
	}
	private boolean checkEachFormTitle(Node node)
	{
		if( Tool.isFieldHidden(node))
		{
			// 2008-09-09 Form actually have no title, just put some hidden dummy table
			// do not check this!
			return true;
		}
		if( Tool.isSingleA1SNode(node) == false)
		{
			errorLocater.LocateErrorPosition(node);
			return false;
		}
		if( Tool.hasA1SNode(node) == false)
		{
			errorLocater.LocateErrorPosition(node);
			return false;
		}
		String config = FormTitle.getConfigurableAttr(node);
		if( config == null)
			return false;
		/* 2008-11-21 
		 * didn't check title configurable attribute now because EFE already support it
		if( config.equals("true"))
		{
			// must be static title
			if( !FormTitle.isStaticTitle(node))
			{
				Tool.ErrorReport("Form Title is Not a Static Title,Configurable Attribute Must Set to \"false\"!");
				errorLocater.LocateErrorPosition(node);
				return false;
			}
		}
		else if ( config.equals("false"))
		{
			if( FormTitle.isStaticTitle(node))
			{
				Tool.ErrorReport("Static Form Title Must Set Configurable Attribute to \"true\"!");
				errorLocater.LocateErrorPosition(node);
				return false;
			}
		}
		else
		{
			Tool.ErrorReport("Form Title Unknown Configurable Attribute: " + config);
			errorLocater.LocateErrorPosition(node);
			return false;
		}*/
		return true;
	}
}