package customMarkupForAFC.EFECheckUltilities;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JList;

import org.w3c.dom.Node;

import utilities.Tool;

import customMarkupForAFC.MarkupObject;

public class EFEErrorLocater
{
	private JList jList = null;
	private ArrayList<MarkupObject> ResultDescription = null;
	private String hint = null;
	public EFEErrorLocater(JList list,ArrayList<MarkupObject> col)
	{
		jList = list;
		ResultDescription = col;
		fillHint();
	}
	private void fillHint()
	{
		hint = "\nPossible Reasons:\n";
		hint += "(1)Field Does Not have any EFE Markup Currently;\n";
		hint += "(2)Field Has EFE Markup,but with Wrong Markup Type!";
	}
	// test function for issue 154
	public void displayCollection()
	{
		if( ResultDescription.isEmpty() )
			return;
		int size = ResultDescription.size();
		MarkupObject obj = null;
		for( int i = 0 ; i < size ;i++)
		{
			obj = ResultDescription.get(i);
			System.out.println("Description: " + obj.getDescription());
			System.out.println("Node name: " + obj.getObjectName());
			System.out.println("Parent Name: " + obj.getParentName());
		}
	}
	//	 subform node is the field in Adobe designer
	public void LocateErrorPosition(Node subform)
	{
		String name = Tool.getAttributeValue("name",subform);
		if( name == null)
			name = "untitledField";
		String parentName = null;
		Node parent = subform.getParentNode();
		if( parent != null)
			parentName = Tool.getAttributeValue("name",parent);
		int index = getMarkupObjIndex(subform);
		if( index == -1)
		{
			displayCollection();
			String error = "Can not Find Error Field: " + name + " Parent Name: " + parentName;
			error += hint;
			Tool.ErrorReport(error);
			return;
		}
		jList.setSelectedIndex(index);
		jList.setSelectionBackground(Color.red);
	    jList.updateUI();
	    jList.repaint();
	}
	
	private int getMarkupObjIndex(Node node)
	{
		if( ResultDescription.isEmpty())
			return -1;
		Node item = null;
		int size = ResultDescription.size();
		for( int i = 0 ; i < size; i++)
		{
			item = ResultDescription.get(i).getNode();
			if( item.equals(node))
				return i;
		}
		return -1;
	}
}