package customMarkupForAFC.templateForExtension;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import configuration.CustomMarkupConfigDom;


public class InfoFieldtemplate
{
	private final String TEMPLATE_NAME = "ext_template"; 
	private final String ACCESS = "readOnly";
	public Element generate(Node parent)
	{
		Document AssistNodeParentDocument = parent.getOwnerDocument();
		Element field = AssistNodeParentDocument.createElement("field");
		
		// name
		Attr name = AssistNodeParentDocument.createAttribute("name");
		name.setNodeValue(TEMPLATE_NAME);
		field.setAttributeNode(name);
		
		// width
		Attr width = AssistNodeParentDocument.createAttribute("width");
		width.setNodeValue("85mm");
		field.setAttributeNode(width);
		
		// minH
		Attr minH = AssistNodeParentDocument.createAttribute("minH");
		minH.setNodeValue("5mm");
		field.setAttributeNode(minH);
		
		// access
		Attr access = AssistNodeParentDocument.createAttribute("access");
		access.setNodeValue(ACCESS);
		field.setAttributeNode(access);
		
		// presence
		Attr presence = AssistNodeParentDocument.createAttribute("presence");
		presence.setNodeValue("hidden");
		field.setAttributeNode(presence);
		
		// ui node
		Element ui = AssistNodeParentDocument.createElement("ui");
		Element textEdit = AssistNodeParentDocument.createElement("textEdit");
		Attr multiLine = AssistNodeParentDocument.createAttribute("multiLine");
		multiLine.setNodeValue("1");
		textEdit.setAttributeNode(multiLine);
		ui.appendChild(textEdit);
		field.appendChild(ui);
		
		// font
		Element font = AssistNodeParentDocument.createElement("font");
		Attr baselineShift = AssistNodeParentDocument.createAttribute("baselineShift");
		baselineShift.setNodeValue("0pt");
		font.setAttributeNode(baselineShift);
		
		Attr typeface = AssistNodeParentDocument.createAttribute("typeface");
		typeface.setNodeValue("Arial");
		font.setAttributeNode(typeface);
		field.appendChild(font);
		
		// margin
		Element margin = AssistNodeParentDocument.createElement("margin");
		Attr bottomInset = AssistNodeParentDocument.createAttribute("bottomInset");
		bottomInset.setNodeValue("6.2mm");
		Attr leftInset = AssistNodeParentDocument.createAttribute("leftInset");
		leftInset.setNodeValue("0mm");
		Attr rightInset = AssistNodeParentDocument.createAttribute("rightInset");
		rightInset.setNodeValue("0mm");
		Attr topInset = AssistNodeParentDocument.createAttribute("topInset");
		topInset.setNodeValue("0mm");
		margin.setAttributeNode(bottomInset);
		margin.setAttributeNode(leftInset);
		margin.setAttributeNode(rightInset);
		margin.setAttributeNode(topInset);
		field.appendChild(margin);
		
		// caption
		Element caption = AssistNodeParentDocument.createElement("caption");
		Attr reserve = AssistNodeParentDocument.createAttribute("reserve");
		reserve.setNodeValue("38mm");
		caption.setAttributeNode(reserve);
		  // sub font
		Element subfont = AssistNodeParentDocument.createElement("font");
		Attr subtypeface = AssistNodeParentDocument.createAttribute("typeface");
		subtypeface.setNodeValue("Arial");
		subfont.setAttributeNode(subtypeface);
		caption.appendChild(subfont);
		
		Element para = AssistNodeParentDocument.createElement("para");
		Attr vAlign = AssistNodeParentDocument.createAttribute("vAlign");
		vAlign.setNodeValue("middle");
		para.setAttributeNode(vAlign);
		caption.appendChild(para);
		
		Element value = AssistNodeParentDocument.createElement("value");
		Element text = AssistNodeParentDocument.createElement("text");
		text.setTextContent("dummy caption");
		value.appendChild(text);
		caption.appendChild(value);
		field.appendChild(caption);
		
		// bind node
		Element bind = AssistNodeParentDocument.createElement("bind");
		Attr match = AssistNodeParentDocument.createAttribute("match");
		match.setNodeValue("none");
		bind.setAttributeNode(match);
		field.appendChild(bind);
		
		// assist node
		Element assist = AssistNodeParentDocument.createElement("assist");
		Element speak = AssistNodeParentDocument.createElement("speak");
		Attr priority = AssistNodeParentDocument.createAttribute("priority");
		priority.setNodeValue("caption");
		speak.setAttributeNode(priority);
		assist.appendChild(speak);
		field.appendChild(assist);
		
		// custom a1s node
		Element sapa1s = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr xmlns = AssistNodeParentDocument.createAttribute("xmlns");
		xmlns.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		sapa1s.setAttributeNode(xmlns);
		// InfoBlockItem
		Element InfoBlockItem = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getInfoBlockItemNodeName());
		Attr config = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getConfigureAttrName());
		config.setNodeValue("true");
		InfoBlockItem.setAttributeNode(config);
		  // description
		Element description = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getDescriptionNodeName());
		Attr lang = AssistNodeParentDocument.createAttribute(CustomMarkupConfigDom.getLangAttrName());
		lang.setNodeValue(CustomMarkupConfigDom.getLangDefaultValue());
		description.setAttributeNode(lang);
		description.setTextContent(CustomMarkupConfigDom.getDefaultDescriptionValue());
		
		InfoBlockItem.appendChild(description);
		sapa1s.appendChild(InfoBlockItem);
		field.appendChild(sapa1s);
		return field;
	}
}
