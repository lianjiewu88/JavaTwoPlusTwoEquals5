package customMarkupForAFC;

import java.util.HashMap;
import configuration.ConfigDom;
import utilities.Tool;
// format 2008-08-26T04:27:40Z --minus 8
public class TimeConvertor
{
	private String year = null;
	private String month = null;
	private String date = null;
	private String min = null;
	private String sec = null;
	private String time_zone = null;
	private int i_hour = -1;
	private int i_date = -1;
	private int i_month = -1;
	private int i_year = -1;
	private int time_zone_diff = 0;
	private String hour_min_sec = null;
	private HashMap<String,String> table = null;
	private HashMap<Integer,Integer> lastDayMap = null;
	public TimeConvertor()
	{
		table = new HashMap<String,String>();
		lastDayMap = new HashMap<Integer,Integer>();
		// 2008-08-27 very ugly code style :(
		table.put("Jan","01");
		table.put("Feb","02");
		table.put("Mar","03");
		table.put("Apr","04");
		table.put("May","05");
		table.put("Jun","06");
		table.put("Jul","07");
		table.put("Aug","08");
		table.put("Sep","09");
		table.put("Oct","10");
		table.put("Nov","11");
		table.put("Dec","12");
		
		lastDayMap.put(1,31);
		// 2008 has passed,only need to consider 2009-feb
		lastDayMap.put(2,28);
		lastDayMap.put(3,31);
		lastDayMap.put(4,30);
		lastDayMap.put(5,31);
		lastDayMap.put(6,30);
		lastDayMap.put(7,31);
		lastDayMap.put(8,31);
		lastDayMap.put(9,30);
		lastDayMap.put(10,31);
		lastDayMap.put(11,30);
		lastDayMap.put(12,31);
	}
	public String getCETTime()
	{
		String Date = Tool.getCurrentLocalTime();
		String[] col = Date.split(" ");
		if( col.length < 6 )
			return null;
		month = table.get(col[1]);
		date = col[2];
		hour_min_sec = col[3];
		time_zone = col[4];
		year = col[5];
		if( !setInteger() )
			return null;
		judgeTimeZoneDifference();
		return HandleDiff();
	}
	public String getTimeStamp()
	{
		String Date = Tool.getCurrentLocalTime();
		String[] col = Date.split(" ");
		if( col.length < 6 )
			return null;
		month = table.get(col[1]);
		date = col[2];
		hour_min_sec = col[3].replace(':','.');
		time_zone = col[4];
		year = col[5];
		String result = year + "." + month + "." + date + "." + hour_min_sec;
		return result;
	}

	private void judgeTimeZoneDifference()
	{
		if( time_zone.equals(ConfigDom.CHINA_TIME_ZONE) )
			time_zone_diff = ConfigDom.CHINE_TIME_DIFF;
		else if ( time_zone.equals(ConfigDom.CZECH_TIME_ZONE))
			time_zone_diff = ConfigDom.CZECH_TIME_DIFF;
	}
	private boolean setInteger()
	{
		String[] time = hour_min_sec.split(":");
		if( time.length < 3 )
			return false;
		i_hour = Integer.parseInt(time[0]);
		min = time[1];
		sec = time[2];
		i_date = Integer.parseInt(date);
		i_month = Integer.parseInt(month);
		i_year = Integer.parseInt(year);
		return true;
	}
	private String HandleDiff()
	{
		int realHour = i_hour - time_zone_diff;
		int realDate = i_date;
		int realMonth = i_month;
		int realYear = i_year;
		if( realHour < 0 )
		{
			// must revert to previous day
			realHour = i_hour + 24 - time_zone_diff;
			realDate = i_date - 1;
			if( realDate == 0)
			{
				// must revert to previous month
				realMonth = i_month -1;
				// must handle the realDate now, realDate equals to the last day 
				// according to month
				if( realMonth == 0)
				{
					// must revert to previous year
					realMonth = 12;
					realYear = i_year - 1;
				}
				realDate = lastDayMap.get(realMonth);
			}
		}
		String result = realYear + "-";
		if( realMonth < 10)
			result += ("0" + realMonth);
		else
			result += realMonth;
		if( realDate < 10)
			result += ("-0" + realDate + "T");
		else
			result += ( "-" + realDate + "T");
		if( realHour < 10 )
			result += ("0" + realHour);
		else
			result += realHour;
		result += (":" + min + ":" + sec + "Z");
		return result;
	}	
}