package customMarkupForAFC.EFECorrection;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utilities.Tool;

public class SplitCaptionCorrector
{
	private Node node = null;
	private Node value = null;
	private Node exData = null;
	private Node body = null;
	public SplitCaptionCorrector(Node task)
	{
		node = task;
	}
	
	/* 2008-08-27 assume that the default value will only
	 * exist in the field caption, never in the default value
	 */
	public boolean run()
	{
		if( node.getNodeName().equals("draw"))
			return fixDrawSplitNode();
		else if ( node.getNodeName().equals("field"))
			return fixFieldSplitNode();
		else 
		{
			Tool.ErrorReport("Unknown Node Type: " + node.getNodeName());
			Tool.stopApplication();
		}
		return true;
	}
	public String getTaskName()
	{
		return Tool.getAttributeValue("name", node);
	}
	/* 2008-08-27 if the function is called,it means that the draw does have a exData node,
	 * if in the internal function such node does not exist-- error happended!
	 */
	private boolean fixDrawSplitNode()
	{
		value = Tool.getNodebyRoot("value",node);
		if( value == null)
		{
			return false;
		}
		exData = Tool.getNodebyRoot("exData",value);
		if( exData == null)
			return false;
		body = Tool.getNodebyRoot("body",exData);
		String completeValue = getCompleteValue();
		return FormatTextNode(completeValue);
	}
	private boolean fixFieldSplitNode()
	{
		Node caption = Tool.getNodebyRoot("caption",node);
		if( caption == null)
			return false;
		value = Tool.getNodebyRoot("value",caption);
		if( value == null)
			return false;
		exData = Tool.getNodebyRoot("exData",value);
		if( exData == null)
			return false;
		body = Tool.getNodebyRoot("body",exData);
		String completeValue = getCompleteValue();
		return FormatTextNode(completeValue);
	}
	private  boolean FormatTextNode(String completevalue)
	{
		Document AssistNodeParentDocument = value.getOwnerDocument();
		Element Text = AssistNodeParentDocument.createElement("text");
		Text.setNodeValue(completevalue);
		Text.setTextContent(completevalue);
		//value.replaceChild(Text,exData);
		value.removeChild(exData);
		value.appendChild(Text);
		return true;
	}
	
	private String getCompleteValue()
	{
		NodeList children = body.getChildNodes();
		int length = children.getLength();
		Node item = null;
		String value = "";
		for( int i = 0 ; i < length; i++)
		{
			item = children.item(i);
			if( !item.getNodeName().equals("p"))
				continue;
			value += item.getTextContent();
		}
		return value;
	}
}