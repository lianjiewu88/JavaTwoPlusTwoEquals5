package customMarkupForAFC.EFECorrection;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import utilities.Tool;
import configuration.ConfigDom;
public class ReadOnlyCorrector
{
	static public boolean Correct(Node node)
	{
		Node task = node;
		// if already being read only, just return
		if( Tool.isFieldReadOnly(task,true))
			return true;
		if( task.getAttributes().getNamedItem(ConfigDom.getFieldAccessAtributeName()) != null )
		{
			task.getAttributes().getNamedItem(ConfigDom.getFieldAccessAtributeName()).setNodeValue(ConfigDom.getFieldAccessReadOnly());
			return true;
		}
		Document FieldDocument = task.getOwnerDocument();
		Attr Access = FieldDocument.createAttribute(ConfigDom.getFieldAccessAtributeName());
		Access.setNodeValue(ConfigDom.getFieldAccessReadOnly());
		Element temp = (Element)task;
		temp.setAttributeNode(Access);
		return true;
	}
}