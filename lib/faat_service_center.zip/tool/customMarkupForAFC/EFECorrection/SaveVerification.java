package customMarkupForAFC.EFECorrection;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import utilities.Tool;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;

public class SaveVerification
{
	private static int errorNum = 0;
	public static void AddErrorTimes()
	{
		errorNum++;
	}
	public static void reSet()
	{
		errorNum = 0;
	}
	public static boolean canSave()
	{
		return (errorNum >= ConfigDom.MAX_SAVE_FAIL_TIME)?true:false;
	}
	
	private static void createEFEAttributes(Node bodyPage,boolean status)
	{
		Node input = bodyPage;
		Document AssistNodeParentDocument = input.getOwnerDocument();
		Element A1SNode = AssistNodeParentDocument.createElement(CustomMarkupConfigDom.getCustomNodeName());
		Attr namespace = AssistNodeParentDocument.createAttribute("xmlns");
		namespace.setNodeValue(CustomMarkupConfigDom.getPreDefinedNamesapce());
		A1SNode.setAttributeNode(namespace);

		input.appendChild(A1SNode);
		
		Document A1SDocument = A1SNode.getOwnerDocument();
		Attr EFEPassedAttr = A1SDocument.createAttribute(CustomMarkupConfigDom.getEFEPPassedAttributeName());
		if( status )
			EFEPassedAttr.setNodeValue("true");
		else
			EFEPassedAttr.setNodeValue("false");
		A1SNode.setAttributeNode(EFEPassedAttr);
	}
	//	 2008-9-1:after adding save anyway,we need verify whether 
	// a template is saved by "save" or "save anyway" menu.
	public static void Verify(Node bodyPageNode,boolean status)
	{
		Node input = bodyPageNode;
		if( bodyPageNode == null)
			return;
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),input);
		if( sapa1s == null)
		{
			createEFEAttributes(input,status);
			return;
		}
		if( sapa1s.getAttributes().getNamedItem(CustomMarkupConfigDom.getEFEPPassedAttributeName()) == null)
		{
			// create a new one and set status
			createEFEAttributes(input,status);
			return;
		}
		if( status )
			sapa1s.getAttributes().getNamedItem(CustomMarkupConfigDom.getEFEPPassedAttributeName()).setNodeValue("true");
		else
			sapa1s.getAttributes().getNamedItem(CustomMarkupConfigDom.getEFEPPassedAttributeName()).setNodeValue("false");
	}
	public static boolean QueryStatus(Node bodyPage)
	{
		Node sapa1s = Tool.getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),bodyPage);
		if( sapa1s == null)
			return false;
		if( sapa1s.getAttributes().getNamedItem(CustomMarkupConfigDom.getEFEPPassedAttributeName()) == null)
			return false;
		String status = sapa1s.getAttributes().getNamedItem(CustomMarkupConfigDom.getEFEPPassedAttributeName()).getNodeValue();
		if( status.equals("true"))
			return true;
		return false;
	}
	
}