package customMarkupForAFC;

public class Input
{
	/* list all the input options here
	 * since the function MarkupDescriptionHandler::WriteNewDescription()
	 * does not handle with the needless attribute
	 */
	private String description = null;
	private String copyFromCustomFields = "false";
	private String fixedWidth = "false";
	private String targetWidth;
	private String miniumWidth;
	private MarkupObject markupObject = null; 
	public Input(MarkupObject markup,String desc,String copy,String fixWidth,String minium,String target)
	{
		markupObject = markup;
		description = desc;
		copyFromCustomFields = copy;
		fixedWidth = fixWidth ;
		miniumWidth = minium + "mm";
		targetWidth = target;
	}
	public String getDescription()
	{
		if( description == "")
			System.exit(0);
		return description;
	}
	// debug function
	public void display()
	{
		System.out.println("Node name: " + markupObject.getObjectName());
		System.out.println("New Description: " + description);
		System.out.println("copyFromCustomFields: " + copyFromCustomFields);
		System.out.println("fixedWidth: " + fixedWidth);
		System.out.println("miniumWidth: " + miniumWidth);
		System.out.println("targetWidth: " + targetWidth);
	}
	public String getCopyAttribute()
	{
		return copyFromCustomFields;
	}
	public String getFixWidthValue()
	{
		return fixedWidth;
	}
	public String gettargetWidth()
	{
		return targetWidth;
	}
	public String getminiumWidth()
	{
		return miniumWidth;
	}
}