package customMarkupForAFC;

import java.util.Vector;

import javax.swing.JTextArea;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import configuration.CustomMarkupConfigDom;
import customMarkupForAFC.markupProcessor.internalObject.FormTitle;
import utilities.Tool;
public class MarkupObject
{
	private Node node = null;
	private String currentDescription = null;
	private boolean isModified = false;
	private int Type = -1;
	private int internalIndex = -1;
	// optional attribute
	private String copyFromCustomField = "false";
	private String fixWidth = "false";
	private String TargetWidth = "176mm";
	private String miniumWidth = "15mm";
	private Vector<Node> DuplicateCol = null;
	
	public MarkupObject(Node n,String description,int type)
	{
		node = n;
		currentDescription = description;
		Type = type;
		DuplicateCol = new Vector<Node>();
	}
	public String getCopyAttributeValue()
	{
		return copyFromCustomField;
	}
	public void setInternalIndex(int index)
	{
		internalIndex = index;
	}
	public int getInternalIndex()
	{
		return internalIndex;
	}
	public boolean hasDuplicateSAPA1SNode()
	{
		System.out.println("In node: " + getObjectName());
		DuplicateCol.clear();
		NodeList children = node.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals(CustomMarkupConfigDom.getCustomNodeName()))
				DuplicateCol.add(item);
		}
		if( DuplicateCol.isEmpty())
			return false;
		int size = DuplicateCol.size();
		if( size == 1)
			return false;
		return true;
	}
	public boolean isFieldReadOnly()
	{
		return Tool.isFieldReadOnly(node,true);
	}
	public boolean DeleteHiddenFieldSAPA1SNode()
	{
		Vector<Node> temp = new Vector<Node>();
		NodeList children = node.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals(CustomMarkupConfigDom.getCustomNodeName()))
				temp.add(item);
		}
		if( temp.isEmpty())
			return false;
		int size = temp.size();
		for( int i = 0; i < size;i++)
			node.removeChild(temp.elementAt(i));
		return true;
	}
	public boolean DeleteDuplicateSAPA1SNode()
	{
		int size = DuplicateCol.size();
		for( int i = 0; i < size -1;i++)
			node.removeChild(DuplicateCol.elementAt(i));
		return true;
	}
	public void SetTargetWidth(String width)
	{
		TargetWidth = width;
	}
	// 2008-08-25 display needed information in the frame 
	// according to type
	public void SetText(JTextArea jTextField)
	{
		String data = "";
		switch ( Type )
		{
			case CustomMarkupConfigDom.INFOBLOCK_SUBFORM:
				data = "\n\tElement Name: " + getObjectName();
				data += "\n";
				data += "\tElement Type: Infoblock Subform";
				data += "\n";
				data += ("\tDescription: " + currentDescription);
				jTextField.setText(data);
				break;
			case CustomMarkupConfigDom.INFOBLOCK_FIELD:
				data = "\n\tElement Name: " + getObjectName();
				data += "\n";
				data += "\tElement Type: Info Block Field";
				data += "\n";
				data += "\tcopyForCustomFields: " + copyFromCustomField;
				data += "\n";
				data += ("\tDescription: " + currentDescription);
				jTextField.setText(data);
				break;
			case CustomMarkupConfigDom.FREEBLOCK_SUBFORM:
				data = "\n\tElement Name: " + getObjectName();
				data += "\n";
				data += "\tElement Type: Free Text Block Subform";
				data += "\n";
				data += ("\tDescription: " + currentDescription);
				jTextField.setText(data);
				break;
			case CustomMarkupConfigDom.FREEBLOCK_FIELD:
				data = "\n\tElement Name: " + getObjectName();
				data += "\n";
				data += "\tElement Type: Free Text Field";
				data += "\n";
				data += ("\tDescription: " + currentDescription);
				jTextField.setText(data);
				break;
			case CustomMarkupConfigDom.TABLE_SUBFORM:
				data = "\n\tElement Name: " + getObjectName();
				data += "\n";
				data += "\tElement Type: Table Outer-Most Subform";
				data += "\n";
				data += ("\tTotal Width: " + TargetWidth);
				data += "\n";
				data += ("\tDescription: " + currentDescription);
				jTextField.setText(data);
				break;
			case CustomMarkupConfigDom.TABLE_HEADER_FIELD:
				data = "\n\tElement Name: " + getObjectName();
				data += "\n";
				data += "\tElement Type: Table Header Label";
				data += "\n";
				data += "\tcopyForCustomFields: " + copyFromCustomField;
				data += "\n";
				data += ("\tfixWidth: " + fixWidth);
				data += "\n";
				data += ("\tminiumWidth: " + miniumWidth);
				data += "\n";
				data += ("\tDesciption: " +  currentDescription);
				jTextField.setText(data);
				break;
			case CustomMarkupConfigDom.REMARK_FIELD:
				data = "\n\tElement Name: " + getObjectName();
				data += "\n";
				data += "\tElement Type: Remark Row Field";
				data += "\n";
				data += ("\tDescription: " + currentDescription);
				jTextField.setText(data);
				break;
			case CustomMarkupConfigDom.SUMM_SUBFORM:
				data = "\n\tElement Name: " + getObjectName();
				data += "\n";
				data += "\tElement Type: Summary Block Subform";
				data += "\n";
				data += ("\tDescription: " + currentDescription);
				jTextField.setText(data);
				break;
			case CustomMarkupConfigDom.SUMM_LABEL:
				data = "\n\tElement Name: " + getObjectName();
				data += "\n";
				data += "\tElement Type: Summary Block Field";
				data += "\n";
				data += ("\tDescription: " + currentDescription);
				jTextField.setText(data);
				break;
			default:
				return;
		}
	}
	public String getParentName()
	{
		Node parent = node.getParentNode();
		if( parent == null )
			return null;
		return Tool.getAttributeValue("name",parent);
	}
	public boolean hasCopyFromAttribute()
	{
		if( (Type == CustomMarkupConfigDom.INFOBLOCK_FIELD ) || ( Type == CustomMarkupConfigDom.TABLE_HEADER_FIELD )) 
			return true;
		return false;
	}
	public boolean isTableOuterSubform()
	{
		return (Type == CustomMarkupConfigDom.TABLE_SUBFORM)?true:false;
	}
	
	// validate the input SET operation
	public String isValidNumber(String width)
	{
		if( width == null)
			return null;
		try
		{
			int i = Integer.parseInt(width);
			i++;
		}
		catch (java.lang.NumberFormatException d)
		{
			return null;
		}
		return width;
	}
	// used for GET operation
	public String getMiniumWidth()
	{
		// must remove unit of measure:"mm"
		return miniumWidth.substring(0,miniumWidth.length()-2);
	}
	public String getTargetWidth()
	{
		return TargetWidth.substring(0,TargetWidth.length()-2);
	}
	public void SetMiniumWidth(String width)
	{
		miniumWidth = width;
	}
	public boolean hasTargetWidth()
	{
		if ( Type == CustomMarkupConfigDom.TABLE_SUBFORM )
			return true;
		return false;
	}
	public boolean hasFixWidthAttribute()
	{
		if ( Type == CustomMarkupConfigDom.TABLE_HEADER_FIELD)
			return true;
		return false;
	}
	public boolean isTableHeader()
	{
		return hasFixWidthAttribute();
	}
	public void SetCopyAttribute(String status)
	{
		copyFromCustomField = status;
	}
	public void SetFixWidthAttribute(String fix)
	{
		fixWidth = fix;
	}
	public String getFixWidthAttributeValue()
	{
		return fixWidth;
	}
	public String FormatOutput()
	{
		String data = null;
		if( isModified )
			data = "Node: " + getObjectName() + " New Description Changed.";
		else
			data = "Node: " + getObjectName();
		switch ( Type )
		{
			case CustomMarkupConfigDom.INFOBLOCK_SUBFORM:
				data += " TYPE: Info block subform";
				break;
			case CustomMarkupConfigDom.INFOBLOCK_FIELD:
				data += " TYPE: Info block field CopyFromAttri: " + copyFromCustomField;
				break;
			case CustomMarkupConfigDom.FREEBLOCK_SUBFORM:
				data += " TYPE: Free Text block subform";
				break;
			case CustomMarkupConfigDom.FREEBLOCK_FIELD:
				data += " TYPE: Free Text block field";
				break;
			case CustomMarkupConfigDom.TABLE_SUBFORM:
				data += " TYPE: Table Outer Subform TargetWidth: " + TargetWidth;
				break;
			case CustomMarkupConfigDom.TABLE_HEADER_FIELD:
				data += " TYPE: Table Header, CopyFromAttri: " + copyFromCustomField + 
				" FixWidth: " + fixWidth + "  Minium Width: " + miniumWidth;
				break;
			case CustomMarkupConfigDom.REMARK_FIELD:
				data += " TYPE: Remark Field";
				break;
			case CustomMarkupConfigDom.SUMM_LABEL:
				data += " TYPE: Summary Label";
				break;
			case CustomMarkupConfigDom.SUMM_SUBFORM:
				data += " TYPE: Summary Subform";
				break;
			case CustomMarkupConfigDom.FORM_TITLE:
				data += " TYPE: Form Title";
				break;
			default:
				return data;
		}
		return data;
	}
	public boolean getStatus()
	{
		return isModified;
	}
	
	public boolean needFixSplitCaption()
	{
		if( node.getNodeName().equals("subform"))
			return false;
		if( node.getNodeName().equals("subformSet"))
			return false;
		if( Type == CustomMarkupConfigDom.REMARK_FIELD)
			return false;
		if( Type == CustomMarkupConfigDom.FREEBLOCK_FIELD)
			return false;
		if( Type == CustomMarkupConfigDom.FORM_TITLE)
			return false;
		// 2008-09-02 table caption needs not to be fixed with split caption
		// or else the table text will not be displayed correctly
		if( Type == CustomMarkupConfigDom.TABLE_HEADER_FIELD)
			return false;
		return hasSplitCaption();
	}
	
	private boolean hasSplitCaption()
	{
		String nodeType = node.getNodeName();
		if( nodeType.equals("draw"))
			return hasDrawSplitText();
		else 
			return hasFieldSplitText();
	}
	
	private boolean hasFieldSplitText()
	{
		Node caption = Tool.getNodebyRoot("caption",node);
		if( caption == null )
			return false;
		Node value = Tool.getNodebyRoot("value",caption);
		Node exData = Tool.getNodebyRoot("exData",value);
		if( exData == null)
			return false;
		return true;
	}
	private boolean hasDrawSplitText()
	{
		Node value = Tool.getNodebyRoot("value",node);
		if( value == null )
			return false;
		Node exData = Tool.getNodebyRoot("exData",value);
		if( exData == null)
			return false;
		return true;
	}
	public void setStatus(boolean status)
	{
		isModified = status;
	}
	/*public MarkupObject clone()
	{
		MarkupObject clone = new MarkupObject(node,currentDescription,Type);
		clone.setStatus(true);
		return clone;
	}*/
	public void SetNewDescription(String newDesp)
	{
		currentDescription = newDesp;
	}
	public MarkupObject(Node n,String description)
	{
		node = n;
		currentDescription = description;
	}
	public Node getNode()
	{
		return node;
	}
	public int getType()
	{
		return Type;
	}
	public String getDescription()
	{
		if( currentDescription == null)
			return "";
		return currentDescription;
	}

	public String getObjectName()
	{
		return Tool.getAttributeValue("name",node);
	}
	public boolean titleNeedToSetTrue()
	{
		String attr = FormTitle.getConfigurableAttr(node);
		if( FormTitle.isStaticTitle(node))
		{
			// if the attribute is set to false, then we must set it true!
			if( attr == null)
				return false;
			if( attr.equals("false"))
				return true;
		}
		return false;
	}
	public boolean titleNeedToSetFalse()
	{
		String attr = FormTitle.getConfigurableAttr(node);
		if( !FormTitle.isStaticTitle(node))
		{
			// if the attribute is set to false, then we must set it true!
			if( attr == null)
				return false;
			if( attr.equals("true"))
				return true;
		}
		return false;
	}
	public boolean HiddenFieldNeedDeleteXMLMarkup()
	{
		// 2008-09-18: free text block field markup mustn't be deleted in anytime!
		if( Type == CustomMarkupConfigDom.FREEBLOCK_SUBFORM || Type == CustomMarkupConfigDom.FREEBLOCK_FIELD)
			return false;
		if( (Tool.isFieldHidden(node)) && (Tool.hasA1SNode(node)) )
			return true;
		return false;
	}
}