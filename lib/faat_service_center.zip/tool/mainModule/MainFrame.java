package mainModule;

import layoutTest.TemplateDomTest;
import layoutTest.detailUI.*;
import PredefineField.PredefineFieldWrapper;
import customMarkupForAFC.*;
import pathExtraction.PathTransformerForExcel;
import excelFormat.excelHandler;
import layoutTest.internalStructure.*;
import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;
import layoutTest.correctionDetail.*;
import configuration.ConfigDom;
import formAutoBinding.*;
import defaultValue.TemplateDefaultValueHandler;
import utilities.*;
import customMarkupForAFC.markupProcessor.internalObject.FormTitle;
import versionControl.versionController;
import help.*;
import customMarkupForAFC.StoreFolder;
import customMarkupForAFC.EFECheckUltilities.EFEchecker;
import customMarkupForAFC.EFECorrection.*;
import customMarkupForAFC.EFEMassCheck.MassCheckerInitiator;
import customMarkupForAFC.markupProcessor.CustomMarkupProcessor;
import pathExtraction.*;
import mockupTool.*;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.JScrollPane;
import javax.swing.Timer;
import javax.swing.UIManager;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import javax.swing.JFileChooser;
import java.io.File;
import java.lang.String;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.SwingConstants;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Insets;
import javax.swing.BoxLayout;
import java.awt.Color;
import javax.swing.JTree;
import javax.swing.JSplitPane;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import org.w3c.dom.Node;
import javax.swing.JRadioButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;

public class MainFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JTextArea jTextField;
	public static TemplateDomTest DomTestOperation = null;  //  @jve:decl-index=0:
	public static CustomMarkupProcessor markupProcessor = null;
	private ExcelConfigurationLoader excelLoader = null;
	private EFEchecker checker = null;
	private TemplateDefaultValueHandler defaultValuehandler = null;
	private TemplateBindingPathExtractor pathExtractor = null;
	private FileDireManager folderManager = null;  //  @jve:decl-index=0:
	private TemplateBindingProcessor bindprocessor = null;
	private PredefineFieldWrapper extensionExtactor = null;
	private MarkupUI markupUI = null;  //  @jve:decl-index=0:
	private SchemaParser parser = null;
	private ExcelTransformer templateTransformer = null;
	private PathTransformerForExcel EngineerTransformer = null;
	private JList jList = null;
	private String ChosenNodeLocation = null;
	private MarkupObject currentSelectedObj = null;
	private JScrollPane jScrollPane = null;
	private JPanel jPanel = null;
	private JButton jOpenButton = null;
	private JFileChooser jFileChooser;
	private File[] fSelectedFiles;
	private JButton jCloseButton = null;
	private JButton jClearButton = null;
	private JButton jSaveButton = null;
	private int iCurrentlySelectedIndex = -1;
	private final int FORMAT_OK = 1;
	private final int NO_NEED_FORMAT = 2;
	private final int NO_BINDING_WORKSHEET = 3;
	private final int IDLE = 0;
	private final int LAYOUT_CHECK = 1;
	private final int MARKUP_ADD = 2;
	private final int MARKUP_CHECK = 3;
	private boolean isListBoxNeedUpdateDate = false;
	private boolean isInprogress = false;
	private boolean canContinue = false;
	private boolean canSort = true;
	private boolean canShowColumnDialog = true;
	private boolean canDeleteNode = true;
	private boolean canChangeCaption = true;
	private boolean canChangeFont = true;
	private boolean operationOnFile = false;
	private boolean operationOnFolder = false;
	private boolean isLayoutCheckingOn = false;
	private boolean isCustomMarkupOn = false;
	private excelHandler ExcelHandler = null;
	private JButton jSortButton = null;
	private JButton jFontButton = null;
	private JPanel jButtonPanel = null;
	private JPanel jStatusPanel = null;
	private JTextArea jStatusBar = null;
	private JButton jCorrectButton = null;
	private ArrayList<String> RecentFile = null;  //  @jve:decl-index=0:
	private Vector<String> HeaderNameList = null;  //  @jve:decl-index=0:
	private Timer myTimer;  //  @jve:decl-index=0:
	private JMenuItem deleteMenuItem = null;
	private JMenuItem exchangeMenuItem = null;
	private JMenuItem changeCaptionMenuItem = null;
	private JMenuItem fontMenuItem = null;
	private DefaultMutableTreeNode ChosenNode = null;
	
	private int ConstantStatusSize;
	private int progress;
	private int CurrentLeftMarkupTask;
	private int sizeOfCorrection;
	private int iTotalErrorNum = -1;
	private int EventXPosition = -1;
	private int EventYPosition = -1;
	private int workModel = -1;
	private JProgressBar jProgressBar = null;
	private JButton jRecent = null;
	private JMenuItem RecentMenuItem[];
	private JPopupMenu jRecentMenu = null;
	private JScrollPane jScrollPane1 = null;
	private JTree jTree = null;
	private JSplitPane jSplitPane = null;
	private ErrorTraceObject updateErrObj = null;
	private DefaultListModel ListMode = null;
	private JButton jFormatButton = null;
	private JRadioButton jRadioButton_File = null;
	private JPanel jMarkupPanel1 = null;
	private JLabel jFilleLabel = null;
	private JRadioButton jRadioButton_folder = null;
	private JLabel jFolderLabel = null;
	private JPanel jFilePanel1 = null;
	private JPanel jFolderPanel = null;
	private JPanel jCustomButtonPanel = null;
	private JPanel jRadioPanel = null;
	private JLabel jBlankLabel = null;
	private JButton jBindButton = null;
	private JMenuBar jJMenuBar = null;
	private JMenu jMenu = null;
	private JMenuItem jMenuItem = null;
	private JMenuItem jSaveAsMenuItem = null;
	private JMenu jBindMenu = null;
	private JMenuItem jAssignExcelMenuItem = null;
	private JMenuItem jTemplateBindMenuItem = null;
	private JMenuItem jSaveFormattedTemplateMenuItem = null;
	private JMenuItem jPreviewMenuItem = null;
	private JMenuItem jXDPPreviewMenuItem = null;
	private JMenuItem jLogFileMenuItem = null;
	private JMenu jTransformMenu = null;
	private JMenuItem jTransformMenuItem = null;
	private JMenu jExtactBindingMenu = null;
	private JMenuItem jExtractMenuItem = null;
	private JMenuItem jSaveAsTemplateExcelMenuItem = null;
	private JMenuItem jExcel2TemplateMenuItem = null;
	private JMenuItem jTransformWithXMLDataMenuItem = null;
	private JMenu jDefaultValueMenu = null;
	private JMenuItem jDeleteMenuItem = null;
	private JMenuItem jSaveMenuItem = null;
	private JMenuItem jEngineerSaveMenuItem = null;
	private JMenu jHelpMenu = null;
	private JMenuItem jExcelFormatMenuItem = null;
	private JMenuItem jGetPathMenuItem = null;
	private JMenuItem jSaveAsTextMenuItem = null;
	private JMenuItem jDetailViewMenuItem = null;
	private JMenu jMarkupMenu = null;
	private JMenuItem jAddMarkupMenuItem = null;
	private JMenuItem jSaveAsMarkupMenuItem = null;
	private JMenu FMT = null;
	private JMenuItem jMenuItem1 = null;
	private JMenuItem jCheckMenuItem = null;
	private JMenuItem jReturnMenuItem = null;
	private JMenuItem jSaveAsAnyway = null;
	private JMenuItem jMassCheckMenuItem = null;
	private JMenuItem jTimestamp = null;
	private JMenuItem jPredefineFieldMenuItem = null;
	private JTextArea getJTextField() 
	{
		if (jTextField == null) 
		{
			jTextField = new JTextArea();
			jTextField.setPreferredSize(new Dimension(275, 56));
			jTextField.setName("jTextField");
			jTextField.setMargin(new Insets(1, 0, 0, 0));
			jTextField.setBackground(Color.white);
			jTextField.setWrapStyleWord(true);
			jTextField.setEditable(false);
			jTextField.addMouseListener(new java.awt.event.MouseAdapter() 
			{
				public void mouseClicked(java.awt.event.MouseEvent e) 
				{
					if( e.getClickCount() == 2)
					{
						PopupCalculatorApplet it = new PopupCalculatorApplet();
						it.setVisible(true);
					}
				}
			});
		}
		return jTextField;
	}
 
	public TemplateDomTest getTestDom()
	{
		return DomTestOperation;
	}
	
	public void TraverseTree()
	{
		DomTestOperation.ModuleTree();
	}
	
	public void TraverseTreeForCustomMarkup()
	{
		markupUI.ModuleTree();
	}
	public void CreateOperationLogByUserInput(ErrorTraceObject obj,String input)
	{
		if( isListBoxNeedUpdateDate == false)
			return;
		OperationLog log = new OperationLog(obj,input,iCurrentlySelectedIndex);
		DomTestOperation.getOperationList().add(log);
	}
	public void CreateSortOperationLog()
	{
		OperationLog log = new OperationLog(null,"SORT",-1);
		DomTestOperation.getOperationList().add(log);
	}
	public void PrintTree() 
	{
		jTree.setModel(DomTestOperation.getTreeMode());
		jTree.setVisible(true);
	}
	
	public void PrintTreeforCustomMarkup() 
	{
		jTree.setModel(markupUI.getTreeMode());
		jTree.setVisible(true);
	}
	public void setTestDom(TemplateDomTest domTest)
	{
		DomTestOperation = domTest;
	}
	
	
	class MyTimerTask implements ActionListener
	{
		private void LayoutCheckProgressBarAction()
		{
			ArrayList notEmpty = DomTestOperation.GetJListData();
			int ErrorRecordSize = DomTestOperation.GetJListData().size();
			if( ErrorRecordSize != 0 )
			{
				ErrorTraceObject errObj = (ErrorTraceObject)notEmpty.get(notEmpty.size() - 1);
				// update the progress bar
				String Error = "Error: " + errObj.ErrorMessage + " HAS BEEN FIXED!";
				SetBold(jStatusBar);
				SetBold(jTextField);
				jStatusBar.setText(Error);
				jTextField.setText(Error);
				String ItemName = errObj.GetErrorNodeName();
				FindNodeByName(ItemName);
				ListMode.removeElementAt(ListMode.size()-1);
				notEmpty.remove(notEmpty.size()-1);
				iTotalErrorNum--;
				progress += 1;
				jProgressBar.setStringPainted(true);
				jProgressBar.setValue(progress);
				jProgressBar.updateUI();
			}
			else
			{
				myTimer.stop();
				String FinishMessage = iTotalErrorNum +" errors have been corrected";
				SetBold(jTextField);
				SetBold(jStatusBar);
				jTextField.setText(FinishMessage);
				jStatusBar.setText(FinishMessage);
				jProgressBar.setValue(0);
				jProgressBar.setEnabled(false);
				jProgressBar.setVisible(false);
				jProgressBar.updateUI();
				jCorrectButton.setText("Correct");
				isInprogress = false;
				canContinue = false;
				isLayoutCheckingOn = false;
				isCustomMarkupOn = false;
				jList.setEnabled(true);
				return;
			}
		}
		private void CustomMarkupProgressBarAction()
		{
			if( CurrentLeftMarkupTask != 0 )
			{
				jProgressBar.setStringPainted(true);
				jProgressBar.setValue(progress);
				jProgressBar.updateUI();
				CurrentLeftMarkupTask--;
				String result = "Template: " + markupProcessor.getFileCollection().elementAt(progress) + " Custom XML Markup Added OK!";
				ListMode.addElement(result);
				jProgressBar.setStringPainted(true);
				jProgressBar.setValue(progress);
				jProgressBar.updateUI();
				progress += 1;
			}
			else
			{
				myTimer.stop();
				jProgressBar.setValue(0);
				jProgressBar.setEnabled(false);
				jProgressBar.setVisible(false);
				jProgressBar.updateUI();
				isInprogress = false;
				canContinue = false;
				progress = 0;
		    	String result = "Totally " + markupProcessor.getFileCollection().size() + "  Template(s) Have been Modified!";
		    	ListMode.addElement(result);
		    	isLayoutCheckingOn = false;
				isCustomMarkupOn = false;
				return;
			}
		}
		public void actionPerformed(ActionEvent actionEvent) 
		{
			if( isLayoutCheckingOn)
				LayoutCheckProgressBarAction();
			else if( isCustomMarkupOn)
				CustomMarkupProgressBarAction();
			// 2008-09-08: Mass check mode
			else
			{
				MassCheckProgressBarAction();
			}
		}
	}
	private void MassCheckProgressBarAction()
	{
		if( CurrentLeftMarkupTask != 0 )
		{
			jProgressBar.setStringPainted(true);
			jProgressBar.setValue(progress);
			jProgressBar.updateUI();
			CurrentLeftMarkupTask--;
			progress += 1;
		}
		else
		{
			myTimer.stop();
			jProgressBar.setValue(0);
			jProgressBar.setEnabled(false);
			jProgressBar.setVisible(false);
			jProgressBar.updateUI();
			isInprogress = false;
			canContinue = false;
			progress = 0;
	    	isLayoutCheckingOn = false;
			isCustomMarkupOn = false;
			return;
		}
	}
	public static void ChangeAppearance()
	{
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch( Exception e)
		{
			throw new RuntimeException(e);
		}
	}
	
	public void setSizeOfCorrection(int size)
	{
		this.sizeOfCorrection = size;	
	}
	public int getSizeOfCorrection()
	{
		return this.sizeOfCorrection;
	}
	
	private void SetBold(JTextArea textfield)
	{
		JTextArea input = textfield;
		Font oldFont = textfield.getFont();
		Font newFont = new Font(oldFont.getFontName(),oldFont.getStyle() | Font.BOLD,14);
		input.setFont(newFont);
	}
	
	public String MarkupObjectDispatch(MarkupObject obj)
	{
		InputDescriptionUI inputUI = new InputDescriptionUI(null,obj,jTextField);
		inputUI.setVisible(true);
		isListBoxNeedUpdateDate = inputUI.getChangeStatus();
		return inputUI.getNewDescription();
	}
	public void ErrorEventDispatch(ErrorTraceObject errorObj)
	{
		String input = null;
		System.out.println("Error Type: " + errorObj.ErrorType + " Message: " + errorObj.ErrorMessage);
		switch( errorObj.ErrorType)
		{
			case LayoutErrorType.ACC_SETTING:
				AccCorrector Acc = new AccCorrector(errorObj);
				Acc.getUserInputData();
				isListBoxNeedUpdateDate = Acc.Correction();
				CreateOperationLogByUserInput(errorObj,Acc.getInput());
				break;
				
			case LayoutErrorType.MARGIN_SETTING : 
				InputMarginDialog inputDialog = new InputMarginDialog(null, errorObj);
				inputDialog.setVisible(true);
				isListBoxNeedUpdateDate = inputDialog.isCorrectRealDone;
				CreateOperationLogByUserInput(errorObj,inputDialog.getInput());
				break;
				
			case LayoutErrorType.SEPERATOR_HEIGHT_SETTING:
				SeperatorHeightCorrection height = new SeperatorHeightCorrection(errorObj);
				input = height.getUserInputData();
				isListBoxNeedUpdateDate = height.Correction();
				CreateOperationLogByUserInput(errorObj,input);
				break;
			
			case LayoutErrorType.FORM_LOGO_WIDTH:
				LogoWidthCorrector logowidth = new LogoWidthCorrector(errorObj);
				input = logowidth.getUserInputData();
				isListBoxNeedUpdateDate = logowidth.Correction();
				CreateOperationLogByUserInput(errorObj,input);
				break;
				
			case LayoutErrorType.FORM_LOGO_HEIGHT:
				LogoHeightCorrector logoheight = new LogoHeightCorrector(errorObj);
				input = logoheight.getUserInputData();
				isListBoxNeedUpdateDate = logoheight.Correction();
				CreateOperationLogByUserInput(errorObj,input);
				break;
			case LayoutErrorType.FONT_SIZE_SETTING :
				FontSizeDialog fontsizedialog = new FontSizeDialog(errorObj);
				fontsizedialog.getUserInputData();
				isListBoxNeedUpdateDate = fontsizedialog.Correction();
				CreateOperationLogByUserInput(errorObj,fontsizedialog.getFontSize());
				break;
				
			case LayoutErrorType.FORM_TITLE_WIDTH_SETTING:
				FormTitleWidth FormTitleWidthDialog = new FormTitleWidth(errorObj);
				FormTitleWidthDialog.getUserInputData();
				isListBoxNeedUpdateDate = FormTitleWidthDialog.Correction();
				CreateOperationLogByUserInput(errorObj,FormTitleWidthDialog.getWidth());
				break;
				
			case LayoutErrorType.TABLE_CELL_AUTOFIT :
				HeightAutofitDialog heightDialog = new HeightAutofitDialog(errorObj);
				heightDialog.getUserInputData();
				isListBoxNeedUpdateDate = heightDialog.Correction();
				CreateOperationLogByUserInput(errorObj,heightDialog.getAutoFitSetting());
				break;
			
			case LayoutErrorType.VALUE_TYPE_SETTING :
				FieldValueDialog valueDialog = new FieldValueDialog(errorObj);
				valueDialog.getUserInputData();
				isListBoxNeedUpdateDate = valueDialog.Correction();
				CreateOperationLogByUserInput(errorObj,valueDialog.getAccessMode());
				break;
				
			case LayoutErrorType.SUBFORM_NORMAL_BINDING :
				SubformNormalBindingDialog subformbindDialog = new SubformNormalBindingDialog(errorObj);
				subformbindDialog.getUserInputData();
				isListBoxNeedUpdateDate = subformbindDialog.Correction();
				CreateOperationLogByUserInput(errorObj,subformbindDialog.getBindingSetting());
				break;
			
			case LayoutErrorType.XSD_LINK_EXIST:
				XSDLink link = new XSDLink(errorObj.getNode());
				isListBoxNeedUpdateDate  = link.correct();
				break;
			
			case LayoutErrorType.NO_DATA_VIEW:
				Tool.ErrorReport("You Must Add DataView,or else PDF can not be Rendered!");
				break;
				
			case LayoutErrorType.DATA_FILE_LINK_EXIST:
				DataFileLink fileLink = new DataFileLink(errorObj.getNode());
				isListBoxNeedUpdateDate = fileLink.correct();
				break;
				
			case LayoutErrorType.SUBFORM_FLOW_SETTING :
				SubformLayoutDialog subformDialog = new SubformLayoutDialog(errorObj);
				subformDialog.getUserInputData();
				isListBoxNeedUpdateDate = subformDialog.Correction();
				CreateOperationLogByUserInput(errorObj,subformDialog.getLayoutSetting());
				break;
				
			case LayoutErrorType.FIELD_BOLD_OR_REGULAR :
				FontTypeDialog FontTypedialog = new FontTypeDialog(errorObj);
				FontTypedialog.getUserInputData();
				isListBoxNeedUpdateDate = FontTypedialog.Correction();
				CreateOperationLogByUserInput(errorObj,FontTypedialog.getFontType());
				break;
				
			case LayoutErrorType.FORM_LOGO_ACC_SETTING :
				LogoAccCorrector LogoAccDialog = new LogoAccCorrector(errorObj);
				LogoAccDialog.getUserInputData();
				isListBoxNeedUpdateDate = LogoAccDialog.Correction();
				CreateOperationLogByUserInput(errorObj,LogoAccDialog.getLogoAcc());
				break;
				
			case LayoutErrorType.FORM_TITLE_COLOR_SETTING:
				ColorChooser colorChooser = new ColorChooser(errorObj);
				isListBoxNeedUpdateDate = colorChooser.Correction();
				CreateOperationLogByUserInput(errorObj,colorChooser.GetColor());
				break;
				
			case LayoutErrorType.SEPERATOR_FILL_COLOR_SETTING:
				/*ColorChooser SeparatorcolorChooser = new ColorChooser(errorObj);
				isListBoxNeedUpdateDate = SeparatorcolorChooser.Correction();
				CreateOperationLogByUserInput(errorObj,SeparatorcolorChooser.GetColor());
				break;*/
				Tool.ErrorReport("Correction not Implemented yet!You must Correct it Manually!");
				break;
				
			case LayoutErrorType.TABLE_HEADER_DRAW:
				Tool.ErrorReport("Correction not Implemented yet!You must Correct it Manually!");
				break;
			
			case LayoutErrorType.NESTED_SUBFORM_IN_FREE:
				Tool.ErrorReport("Please move nested Subform outside Free Text Block!");
				break;
				
			case LayoutErrorType.SEPERATOR_LINE_COLOR_SETTING:
				/*ColorChooser lineChooser = new ColorChooser(errorObj);
				isListBoxNeedUpdateDate = lineChooser.Correction();
				CreateOperationLogByUserInput(errorObj,lineChooser.GetColor());
				break;*/
				Tool.ErrorReport("Correction not Implemented yet!You must Correct it Manually!");
				break;
				
			case LayoutErrorType.FONT_TYPE_SETTING:
				/*FontDialog FontType = new FontDialog(null,errorObj.getNode());
				  FontType.setVisible(true);*/
				/*FontType.getUserInputData();
				isListBoxNeedUpdateDate = FontType.Correction();
				CreateOperationLogByUserInput(errorObj,FontType.getFontType());*/
				Tool.ErrorReport("Correction not Implemented yet!You must Correct it Manually!");
				break;
			
			case LayoutErrorType.TABLE_SUBFORM_FILL_COLOR:
				Tool.ErrorReport("Correction not Implemented yet!You must Correct it Manually!");
				break;
				
			case LayoutErrorType.FORM_TITLE_AUTO_HEIGHT_FIT:
				FormTitleHeightExpand heightExpandDialog = new FormTitleHeightExpand(errorObj);
				heightExpandDialog.getUserInputData();
				isListBoxNeedUpdateDate = heightExpandDialog.Correction();
				CreateOperationLogByUserInput(errorObj,heightExpandDialog.getExpandSetting());
				break;
				
			case LayoutErrorType.FORM_TITLE_HEIGHT_SETTING:
				FormTitleHeight titleHeight = new FormTitleHeight(errorObj);
				input = titleHeight.getUserInputData();
				isListBoxNeedUpdateDate = titleHeight.Correction();
				CreateOperationLogByUserInput(errorObj,input);
				break;
				
			case LayoutErrorType.FORM_TITLE_AUTO_WIDTH_FIT:
				FormTitleWidthExpand WidthExpandDialog = new FormTitleWidthExpand(errorObj);
				WidthExpandDialog.getUserInputData();
				isListBoxNeedUpdateDate = WidthExpandDialog.Correction();
				CreateOperationLogByUserInput(errorObj,WidthExpandDialog.getWidthExpandSetting());
				break;
				
			case LayoutErrorType.PAGE_WIDTH_EXPAND:
				FormTitleWidthExpand WidthDialog = new FormTitleWidthExpand(errorObj);
				WidthDialog.getUserInputData();
				isListBoxNeedUpdateDate = WidthDialog.Correction();
				CreateOperationLogByUserInput(errorObj,WidthDialog.getWidthExpandSetting());
				break;
				
			case LayoutErrorType.TABLE_CELL_MULTILINES:
				MultiLinesDialog multiDialog = new MultiLinesDialog(errorObj);
				multiDialog.getUserInputData();
				isListBoxNeedUpdateDate = multiDialog.Correction();
				CreateOperationLogByUserInput(errorObj,multiDialog.getLineSetting());
				break;
			
			case LayoutErrorType.H_ALIGN_SETTING:
				HAlignDialog hDialog = new HAlignDialog(errorObj);
				hDialog.getUserInputData();
				isListBoxNeedUpdateDate = hDialog.Correction();
				CreateOperationLogByUserInput(errorObj,hDialog.getHAlignSetting());
				break;
			
			case LayoutErrorType.V_ALIGN_SETTING:
				VAlignDialog vDialog = new VAlignDialog(errorObj);
				vDialog.getUserInputData();
				isListBoxNeedUpdateDate = vDialog.Correction();
				CreateOperationLogByUserInput(errorObj,vDialog.getVAlignSetting());
				break;
			
			case LayoutErrorType.PAGE_HEIGHT_EXPAND:
				FormTitleHeightExpand pageDialog = new FormTitleHeightExpand(errorObj);
				pageDialog.getUserInputData();
				isListBoxNeedUpdateDate = pageDialog.Correction();
				CreateOperationLogByUserInput(errorObj,pageDialog.getExpandSetting());
				break;
			
			default:
				System.out.println("Wrong Type Error: " + errorObj.ErrorType);
		}
	}
	
	private void ErrorMessageDispath(int errorType,String Location)
	{
		String ErrorDetail = null;
		String ErrorLocation = Location;
		switch(errorType)
		{
			case LayoutErrorType.ACC_SETTING :
				ErrorDetail = "Accessibility Setting Wrong in " + Location;
				break;
			
			case LayoutErrorType.MARGIN_SETTING:
				if( ErrorLocation.equals("infoblock"))
					ErrorDetail = "Margin Setting Wrong,Correct Settings: 0mm,0mm,0mm,1.2mm";
				else if( ErrorLocation.contains("table"))
					ErrorDetail = "Margin Setting Wrong,Correct Settings: 1mm,1mm,1mm,1mm";
				else if( ErrorLocation.equals("summaryblock"))
					ErrorDetail = "Margin Setting Wrong,Correct Settings: 0.1mm,0.1mm,0.1mm,0.1mm";
				else 
					ErrorDetail = "Unknown Error Location";
				break;
			
			case LayoutErrorType.FONT_SIZE_SETTING:
				ErrorDetail = "Field in " + ErrorLocation + " Font Size Setting Wrong";
				break;
			
			case LayoutErrorType.FORM_TITLE_WIDTH_SETTING:
				ErrorDetail = "Form Title Width should be 86mm";
				break;
			
			case LayoutErrorType.TABLE_CELL_AUTOFIT:
				ErrorDetail = "Table Cell should allow Mutiple Lines and Allow Height Expand To Fit";
				break;
			
			case LayoutErrorType.VALUE_TYPE_SETTING :
				ErrorDetail = "Field in the " + ErrorLocation + " Should Set to ReadOnly";
				break;
			
			case LayoutErrorType.SUBFORM_NORMAL_BINDING :
				ErrorDetail = "Subform Should NOT have normal binding";
				break;
			
			case LayoutErrorType.SUBFORM_FLOW_SETTING :
				ErrorDetail = "Subform Should NOT be Positioned";
				break;
			
			case LayoutErrorType.SEPERATOR_HEIGHT_SETTING:
				ErrorDetail = "Graph Separator Height should be 2.5mm";
				break;
			
			case LayoutErrorType.FIELD_BOLD_OR_REGULAR :
				ErrorDetail = "Field in the " + ErrorLocation + "Regular/Bold Setting wrong";
			break;
			
			case LayoutErrorType.FORM_LOGO_ACC_SETTING :
				ErrorDetail = "Form Logo Accessibility Setting should be TOOLTIP";
			break;
			
			case LayoutErrorType.FORM_TITLE_COLOR_SETTING:
				ErrorDetail = "Form Title Color Should be 128,128,128";
				break;
			
			case LayoutErrorType.FORM_LOGO_WIDTH:
				ErrorDetail = "Form Logo Width should be 40mm";
				break;
			
			case LayoutErrorType.FORM_LOGO_HEIGHT:
				ErrorDetail = "Form Logo Height should be 20mm";
				break;
			
			case LayoutErrorType.FORM_TITLE_AUTO_HEIGHT_FIT:
				ErrorDetail = "Form Title should NOT Allow Expand to fit";
				break;
			
			case LayoutErrorType.FORM_TITLE_AUTO_WIDTH_FIT:
				ErrorDetail = "Form Title should NOT Allow Expand to fit";
				break;
			
			case LayoutErrorType.FONT_TYPE_SETTING :
				ErrorDetail = "Form Font Should be Arial";
				break;
			
			case LayoutErrorType.MASTER_PAGE_SETTING:
				ErrorDetail =  "Master Page should be Set to A4";
				break;
				
			case LayoutErrorType.H_ALIGN_SETTING:
				ErrorDetail = "For Numeric field,the horizontal alignment should be RIGHT,otherwise LEFT";
				break;
				
			case LayoutErrorType.V_ALIGN_SETTING:
				ErrorDetail = "All the fields should be Top-Aligned";
				break;
				
			default:
				System.out.println("Wrong Error Type: " + errorType);
		}
		jTextField.setText(ErrorDetail);
	}
	
	private void CorrectionAssistant()
	{
		if( DomTestOperation == null )
			return;
		if( markupProcessor != null )
			return;
		int index = jList.getSelectedIndex();
		if( index == -1 )
			return;
		ErrorTraceObject SelectedObj = (ErrorTraceObject)DomTestOperation.GetJListData().get(index);
		ErrorMessageDispath(SelectedObj.ErrorType,SelectedObj.Location);
	}
	public void HandleChosedListItem()
	{
		if( DomTestOperation == null || markupProcessor != null)
			return;
		iCurrentlySelectedIndex = jList.getSelectedIndex();
		if( iCurrentlySelectedIndex == -1)
			return;
		ErrorTraceObject errObj = (ErrorTraceObject)DomTestOperation.GetJListData().get(iCurrentlySelectedIndex);
		String ItemName = errObj.GetErrorNodeName();
		FindNodeByName(ItemName);
	}
	
	public void HandleChosedListForCustomMarkup()
	{
		if( markupUI == null)
			return;
		iCurrentlySelectedIndex = jList.getSelectedIndex();
		if( iCurrentlySelectedIndex == -1)
			return;
		if( markupUI.getDescription().isEmpty())
			return;
		MarkupObject Obj = (MarkupObject)markupUI.getDescription().get(iCurrentlySelectedIndex);
		String ItemName = Obj.getObjectName();
		Obj.SetText(jTextField);
		int occurance = markupUI.getOccurance(iCurrentlySelectedIndex);
		if( occurance == 1)
			FindNodeByName(ItemName);
		else
		{
			int RelativeIndex = markupUI.convertAbsolute2RelativeIndex(iCurrentlySelectedIndex);
			FindNodeByRelativeIndex(ItemName,RelativeIndex);
		}
	}
	
	private void repaintTree()
	{
		jTree.setCellRenderer(new DefaultTreeCellRenderer()
        {
             public Component getTreeCellRendererComponent(JTree pTree,
                 Object pValue, boolean pIsSelected, boolean pIsExpanded,
                 boolean pIsLeaf, int pRow, boolean pHasFocus)
             {
            	 DefaultMutableTreeNode node = (DefaultMutableTreeNode)pValue;
            	 super.getTreeCellRendererComponent(pTree, pValue, pIsSelected,
                     pIsExpanded, pIsLeaf, pRow, pHasFocus);
                 if (node.isRoot())
                	 setBackgroundSelectionColor(Color.red);
                 else if (node.getChildCount() > 0)
                	 setBackgroundSelectionColor(Color.yellow);
                 else if (pIsLeaf)
                	 setBackgroundSelectionColor(Color.green);
                 return (this);
             }
        });
		jTree.updateUI();
		jTree.repaint();
	}
    private void FindNodeByRelativeIndex(String ItemName,int RelativeIndex)
    {
    	// can equal to 1: the first occurance
    	if( RelativeIndex < 1)
    	{
    		System.out.println("Error Relative Index: " + RelativeIndex);
    		System.exit(0);
    	}
    	DefaultMutableTreeNode root = null;
		if( workModel == LAYOUT_CHECK )
			root = DomTestOperation.GetRootNode();
		else if( workModel == MARKUP_ADD )
			root = markupUI.GetRootNode();
		DefaultMutableTreeNode node = root.getNextNode();
		String Name = null;
		while( node != null)
		{
			Name = node.toString();
			System.out.println("Name: " + Name);
			if( Name.equals(ItemName))
			{
				if( RelativeIndex == 1)
				{
					TreeNode[] path = node.getPath();
					TreePath newPath = new TreePath(path);
					jTree.expandPath(newPath);
					jTree.scrollPathToVisible(newPath);
					jTree.setSelectionPath(newPath);
					repaintTree();
					return;
				}
				else
				{
					// ignore this match
					RelativeIndex--;
				}
			}
			node = node.getNextNode();
		}
		System.out.println("Node: " + ItemName + " Not find in Tree!");
		System.exit(0);
    }
	private void FindNodeByName(String ItemName)
	{
		DefaultMutableTreeNode root = null;
		if( workModel == LAYOUT_CHECK )
			root = DomTestOperation.GetRootNode();
		else
			root = markupUI.GetRootNode();
		DefaultMutableTreeNode node = root.getNextNode();
		String Name = null;
		while( node != null)
		{
			Name = node.toString();
			if( Name.equals(ItemName))
			{
				TreeNode[] path = node.getPath();
				TreePath newPath = new TreePath(path);
				jTree.expandPath(newPath);
				jTree.scrollPathToVisible(newPath);
				jTree.setSelectionPath(newPath);
				repaintTree();
				return;
			}
			node = node.getNextNode();
		}
		System.out.println("Node: " + ItemName + " Not find in Tree!");
		System.exit(0);
	}
	
	public void UpdateStatusBar()
	{
		iTotalErrorNum--;
    	String CurrentErrorStatus = null;
    	int LeftErrorNumber = DomTestOperation.GetJListData().size();
    	if( LeftErrorNumber == 0 )
    		CurrentErrorStatus = "All Errors have been fixed!";
    	else
    		CurrentErrorStatus = "Current " + LeftErrorNumber + " Errors Left!";
    	SetBold(jStatusBar);
    	jStatusBar.setText(CurrentErrorStatus);
	}
	
	private JList getJList() 
	{
		if (jList == null) 
		{
			jList = new JList();
			ListMode = new DefaultListModel();
			jList.setModel(ListMode);
			jList.setSize(new Dimension(589, 253));
			jList.addMouseListener(new java.awt.event.MouseAdapter() 
			{
				public void mouseClicked(java.awt.event.MouseEvent e) 
				{
					if( DomTestOperation == null && markupUI == null)
						return;
					if( workModel == MARKUP_CHECK )
						return;
					if( workModel == MARKUP_ADD)
					{
						// currently in markup process mode
						// System.out.println("currently in markup process mode");
						HandleChosedListForCustomMarkup();
						JPopupMenu jMarkupmenu = new JPopupMenu();
						JMenuItem menuItemChange = new JMenuItem();
						JMenuItem menuItemDupA1SNode = new JMenuItem();
						JMenuItem menuItemReadOnly = new JMenuItem();
						JMenuItem menuItemSetTrue = new JMenuItem();
						JMenuItem menuItemSetFalse = new JMenuItem();
						JMenuItem menuItemDeleteHidden = new JMenuItem();
						menuItemReadOnly.addActionListener(new java.awt.event.ActionListener()
						{
							public void actionPerformed(ActionEvent e) 
						    {
								if( currentSelectedObj == null)
									return;
								if( ReadOnlyCorrector.Correct(currentSelectedObj.getNode()))
									Tool.InfoReport("Field: " + currentSelectedObj.getObjectName() + " Set to \"ReadOnly\" Successfully!");
						    	jList.updateUI();
						    	jList.repaint();
						    }
						});
						menuItemDupA1SNode.addActionListener(new java.awt.event.ActionListener() 
						{
							public void actionPerformed(ActionEvent e) 
						    {
								if( currentSelectedObj == null)
									return;
								if( currentSelectedObj.DeleteDuplicateSAPA1SNode())
									Tool.InfoReport("Node: " + currentSelectedObj.getObjectName() + " Duplicate sapa1s Node Delete Successfully!");
						    	jList.updateUI();
						    	jList.repaint();
						    }
						});
						menuItemChange.addActionListener(new java.awt.event.ActionListener() 
						{ 
							// change description
							public void actionPerformed(ActionEvent e) 
						    {
								if( currentSelectedObj == null)
									return;
								SplitCaptionCorrector CaptionCorrector = new SplitCaptionCorrector(currentSelectedObj.getNode());
								if( CaptionCorrector.run())
									Tool.InfoReport("Split Caption Removed for Node: " + CaptionCorrector.getTaskName() + " Successfully!");
								else
									Tool.ErrorReport("Split Caption Removed for Node: " + CaptionCorrector.getTaskName() + " Failed!");
						    	jList.updateUI();
						    	jList.repaint();
						    }
						});
						menuItemSetTrue.addActionListener(new java.awt.event.ActionListener() 
						{ 
							public void actionPerformed(ActionEvent e) 
						    {
								if( FormTitle.setConfigurableAttribute(currentSelectedObj.getNode(),"true") )
									Tool.InfoReport("Form Title Set Configurable to \"True\" Sucessfully!");
								else
									Tool.ErrorReport("Form Title Set Configurable to \"True\" Failed!");
						    	jList.updateUI();
						    	jList.repaint();
						    }
						});
						menuItemSetFalse.addActionListener(new java.awt.event.ActionListener() 
						{ 
							public void actionPerformed(ActionEvent e) 
						    {
								if( FormTitle.setConfigurableAttribute(currentSelectedObj.getNode(),"false") )
									Tool.InfoReport("Form Title Set Configurable to \"False\" Sucessfully!");
								else
									Tool.ErrorReport("Form Title Set Configurable to \"False\" Failed!");
						    	jList.updateUI();
						    	jList.repaint();
						    }
						});
						menuItemDeleteHidden.addActionListener(new java.awt.event.ActionListener() 
						{ 
							public void actionPerformed(ActionEvent e) 
						    {
								if( currentSelectedObj.DeleteHiddenFieldSAPA1SNode())
									Tool.InfoReport("Hidden Field: " +  currentSelectedObj.getObjectName() + " Delete EFE Markup Sucessfully!");
								else
									Tool.ErrorReport("Hidden Field: " +  currentSelectedObj.getObjectName() + " Delete EFE Markup Failed!");
						    	jList.updateUI();
						    	jList.repaint();
						    }
						});
						menuItemChange.setText("Remove Split Caption");
						menuItemDupA1SNode.setText("Remove Duplicate sapa1s Node");
						menuItemReadOnly.setText("Set Read Only");
						menuItemSetTrue.setText("Set Configurable to \"True\"");
						menuItemSetFalse.setText("Set Configurable to \"False\"");
						menuItemDeleteHidden.setText("Delete Hidden Field's XML Markup");
						// disalbe on Aug,25 2008: it is better to 
						// allow user to change directly by double clicking
						if( markupUI == null)
							return;
						iCurrentlySelectedIndex = jList.getSelectedIndex();
				    	if( iCurrentlySelectedIndex == -1)
				    		return;
				    	if( markupUI.getDescription().isEmpty())
				    		return;
				    	currentSelectedObj = (MarkupObject)markupUI.getDescription().get(iCurrentlySelectedIndex);
				    	if( currentSelectedObj == null)
				    		return;
				    	if( currentSelectedObj.needFixSplitCaption())
				    		jMarkupmenu.add(menuItemChange);
				    	if( currentSelectedObj.hasDuplicateSAPA1SNode())
				    		jMarkupmenu.add(menuItemDupA1SNode);
				    	if( !currentSelectedObj.isFieldReadOnly())
				    		jMarkupmenu.add(menuItemReadOnly);
				    	if( currentSelectedObj.titleNeedToSetFalse())
				    		jMarkupmenu.add(menuItemSetFalse);
				    	if( currentSelectedObj.titleNeedToSetTrue())
				    		jMarkupmenu.add(menuItemSetTrue);
				    	if( currentSelectedObj.HiddenFieldNeedDeleteXMLMarkup())
				    		jMarkupmenu.add(menuItemDeleteHidden);
						int mods=e.getModifiers();
						if((mods & java.awt.event.MouseEvent.BUTTON3_MASK )!=0)
						{
							jMarkupmenu.setVisible(true);
							jMarkupmenu.show(jList,e.getX(),e.getY());	
						}
						if( e.getClickCount() == 2)
						{
							if( markupUI == null)
								return;
							iCurrentlySelectedIndex = jList.getSelectedIndex();
					    	if( iCurrentlySelectedIndex == -1)
					    		return;
					    	currentSelectedObj = (MarkupObject)markupUI.getDescription().get(iCurrentlySelectedIndex);
					    	if( currentSelectedObj == null)
					    		return;
					    	String newDescription = MarkupObjectDispatch(currentSelectedObj);
					    	UpdateListBoxforMarkup(newDescription);
					    	jList.updateUI();
					    	jList.repaint();
						}
						return;
					}
					else if ( workModel == LAYOUT_CHECK )
					{
						CorrectionAssistant();
						HandleChosedListItem();
						JPopupMenu jmenu = new JPopupMenu();
						JMenuItem menuItem1 = new JMenuItem();
						JMenuItem menuItem2 = new JMenuItem();
						menuItem1.addActionListener(new java.awt.event.ActionListener() 
						{ 
							// delete
							public void actionPerformed(ActionEvent e) 
							{
								if( DomTestOperation == null || markupProcessor != null)
									return;
								iCurrentlySelectedIndex = jList.getSelectedIndex();
								if( iCurrentlySelectedIndex == -1)
									return;
								ErrorTraceObject DeletedErrorObj = (ErrorTraceObject)DomTestOperation.GetJListData().get(iCurrentlySelectedIndex);
								ListMode.removeElementAt(iCurrentlySelectedIndex);
								DomTestOperation.DeleteElementat(iCurrentlySelectedIndex);
								// add the operation to loglist
								OperationLog log = new OperationLog(DeletedErrorObj,"Delete",iCurrentlySelectedIndex);
								DomTestOperation.getOperationList().add(log);
								jList.updateUI();
								jList.repaint();
								// Set the status bar
								UpdateStatusBar();
							}
						});
						menuItem2.addActionListener(new java.awt.event.ActionListener() 
						{ 
							public void actionPerformed(ActionEvent e) 
							{
								if( DomTestOperation == null || markupProcessor != null)
									return;
								iCurrentlySelectedIndex = jList.getSelectedIndex();	 
								if( iCurrentlySelectedIndex == -1 )
									return;
								ErrorTraceObject errorObj = (ErrorTraceObject) DomTestOperation.GetJListData().get(iCurrentlySelectedIndex);
								ErrorEventDispatch(errorObj);
								UpdateListBox();
								UpdateStatusBar();
							}
						});
						menuItem1.setText("Delete");
						menuItem2.setText("Correct");
						jmenu.add(menuItem1);
						jmenu.add(menuItem2);				    
						int mods=e.getModifiers();
						if((mods & java.awt.event.MouseEvent.BUTTON3_MASK )!=0)
						{
							if( markupProcessor != null)
								return;
							jmenu.setVisible(true);
							jmenu.show(jList,e.getX(),e.getY());	
						}
					}
				}
				});	
		}
		
		return jList;
	}
	
	public void UpdateListBoxforMarkup(String newDescription)
	{
		if( isListBoxNeedUpdateDate == false)
			return;
		if( newDescription == null )
			return;
		markupUI.UpdateDescriptionCollection(iCurrentlySelectedIndex, newDescription);
		ListMode.clear();
		MarkupObject obj = null;
    	String input = null;
    	int ListDataSize = markupUI.getDescription().size();
    	for( int i = 0; i < ListDataSize;i++)
    	{
    		obj = (MarkupObject)markupUI.getDescription().get(i);
    		input = obj.FormatOutput();
    		ListMode.addElement(input);
    	}
	}
	public void UpdateListBox()
	{
		if( isListBoxNeedUpdateDate == false)
			return;
		ListMode.clear();
    	ErrorTraceObject TempObj = null;
    	String input = null;
    	int ListDataSize = DomTestOperation.GetJListData().size();
    	for( int i = 0; i < ListDataSize;i++)
    	{
    		TempObj = (ErrorTraceObject) DomTestOperation.GetJListData().get(i);
    		input = TempObj.ErrorMessage;
    		ListMode.addElement(input);
    	}
    	SetCurrentCorrectionMessage();
    	ListMode.removeElementAt(iCurrentlySelectedIndex);
    	DomTestOperation.DeleteElementat(iCurrentlySelectedIndex);
    	jList.updateUI();
    	jList.repaint();
    	iTotalErrorNum--;
    	isListBoxNeedUpdateDate = false;
	}
	
	private void SetCurrentCorrectionMessage()
	{
		ErrorTraceObject errorObj = (ErrorTraceObject)DomTestOperation.GetJListData().get(iCurrentlySelectedIndex);
		String ErrorMessage = "The error : " + errorObj.ErrorMessage + "  has been successfully resloved!";
		jTextField.setText(ErrorMessage);
	}

	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setViewportView(getJList());
		}
		return jScrollPane;
	}


	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setLayout(new BoxLayout(getJPanel(), BoxLayout.X_AXIS));
			jPanel.setPreferredSize(new Dimension(560, 140));
			jPanel.add(getJTextField(), null);
			jPanel.add(getJButtonPanel(), null);
		}
		return jPanel;
	}
	
	private void UpdateRecentHistory(String NewFile)
	{
		if( RecentFile.size() < 5)
		{
			RecentFile.add(NewFile);
		}
		else
		{
			RecentFile.remove(0);
			RecentFile.add(NewFile);
		}
	}

	public void DoLayoutChecking(String FileName)
	{
		DomTestOperation = new TemplateDomTest();
		workModel = LAYOUT_CHECK;
		ArrayList<ErrorTraceObject> resultData = DomTestOperation.DoActions(FileName);
		ListMode.clear();
		if( resultData == null)
		{
			 String data = "You should select a template file ended with .xdp";
			 ListMode.addElement(data);
			 return;
		}
		jList.setCellRenderer(new ColorRenderer()); 
		jList.setEnabled(true);
		ErrorTraceObject errorObj = null;
		int ListDataSize = resultData.size();
		for(int k = 0 ; k < ListDataSize; k ++ )
		{
			 errorObj = (ErrorTraceObject) resultData.get(k);
			 ListMode.addElement(errorObj.ErrorMessage);
		}
		jList.updateUI();
		SetBold(jStatusBar);
		SetBold(jTextField);
		String ErrorStatistic = "Total  " + ListDataSize + " Errors on the Template have been found!";
		iTotalErrorNum = ListDataSize;
		jStatusBar.setText(ErrorStatistic);
		jTextField.setText(ErrorStatistic);
	}
	
	public void AddCustomMarkbyDeveloper(String FileName)
	{
		markupUI = new MarkupUI(ListMode,jList,jTextField);
		workModel = MARKUP_ADD;
		if ( markupUI.getAllDescriptions(FileName) == false )
		{
			 String data = "You should select a template file ended with .xdp";
			 ListMode.addElement(data);
			 return;
		}
		markupUI.display();
		SetBold(jStatusBar);
		SetBold(jTextField);
		
	}
	private JButton getJOpenButton() {
		if (jOpenButton == null) {
			jOpenButton = new JButton();
			jOpenButton.setText("Open");
			jOpenButton.setHorizontalAlignment(SwingConstants.CENTER);
			jOpenButton.setFont(new Font("Dialog", Font.BOLD, 12));
			jOpenButton.setMnemonic(KeyEvent.VK_UNDEFINED);
			jOpenButton.setName("jButton");
			jOpenButton.setToolTipText("Open the template file to be tested.");
			jOpenButton.setPreferredSize(new Dimension(77, 23));
			jOpenButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					jFileChooser = new JFileChooser();
					jFileChooser.setMultiSelectionEnabled(true);
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						jFileChooser.setCurrentDirectory(curr);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
					jFileChooser.addChoosableFileFilter(filter);
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on Template File: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	fSelectedFiles = jFileChooser.getSelectedFiles();
						UpdateRecentHistory(fSelectedFiles[0].getAbsolutePath());
						DoLayoutChecking(fSelectedFiles[0].getAbsolutePath());
						folderManager.setLastOpenPath(fSelectedFiles[0].getParent());
						TraverseTree();
						PrintTree();
				    }
				    else 
				    {
				    	jTextField.setText("You canceled.");
				    } 
				}
			});
		}
		return jOpenButton;
	}


	private JButton getJCloseButton() {
		if (jCloseButton == null) {
			jCloseButton = new JButton();
			jCloseButton.setName("Close");
			jCloseButton.setPreferredSize(new Dimension(77, 23));
			jCloseButton.setToolTipText("Exit the tool.");
			jCloseButton.setText("Close");
			jCloseButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					System.exit(0);
				}
			});
		}
		return jCloseButton;
	}

	private void ResetProgressBar()
	{
		jProgressBar.setMinimum(0);
		jProgressBar.setMaximum(0);
		jProgressBar.setVisible(false);
		isInprogress = false;
		canContinue = false;
		jCorrectButton.setText("Correct");
	}
	
	private JButton getJClearButton() 
	{
		if (jClearButton == null) 
		{
			jClearButton = new JButton();
			jClearButton.setPreferredSize(new Dimension(77, 23));
			jClearButton.setToolTipText("Clear all the records displayed on the list box.");
			jClearButton.setText("Clear");
			jClearButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					ListMode.clear();
					if( DomTestOperation == null && markupUI == null && parser == null)
					{
						String ErrorMessage = "You have not open any Template File";
						SetBold(jTextField);
						jTextField.setText(ErrorMessage);
						return;
					}
					DoMainFrameClear();
					workModel = IDLE;
					jSaveAsMarkupMenuItem.setEnabled(false);
					jReturnMenuItem.setEnabled(false);
					jCheckMenuItem.setEnabled(false);
					canSort = true;
				}
			});
			
		}
		return jClearButton;
	}
	
	private void DoMainFrameClear()
	{
		if( DomTestOperation != null)
			DomTestOperation.GetJListData().clear();
		if( markupUI != null)
			markupUI.getDescription().clear();
		jList.updateUI();
		jList.repaint();
		jTextField.setText(null);
		jStatusBar.setText(null);
		jTree.clearSelection();
		jTree.removeAll();
		jTree.setVisible(false);
		DefaultTreeModel nullMode = new DefaultTreeModel(null);
		jTree.setModel(nullMode);
		jTree.repaint();
		jTree.updateUI();
		jTree.invalidate();
		ResetProgressBar();
	}
	public boolean CheckFileExistence(String name)
	{
		File fileChecking = new File(name);
		return fileChecking.exists();
	}


	private JButton getJSaveButton() {
		if (jSaveButton == null) {
			jSaveButton = new JButton();
			jSaveButton.setPreferredSize(new Dimension(77, 23));
			jSaveButton.setToolTipText("Save the modified template file.");
			jSaveButton.setText("Save");
			jSaveButton.addActionListener(new java.awt.event.ActionListener() 
			{
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					if( DomTestOperation == null)
					{
						String ErrorMessage = "You have not open any Template File";
						SetBold(jTextField);
						jTextField.setText(ErrorMessage);
						return;
					}
					JFileChooser Savechooser = new JFileChooser();
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
					Savechooser.addChoosableFileFilter(filter);
					Savechooser.setApproveButtonText("Save");
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						Savechooser.setCurrentDirectory(curr);
					int option = Savechooser.showOpenDialog(null);
					String path = null;
					if (option == JFileChooser.APPROVE_OPTION) 
					{
						path = Savechooser.getSelectedFile().toString();
						path += ".xdp";
						if( CheckFileExistence(path) == true )
						{
							Tool.ErrorReport("The file: " + path + " already exists!");
							return ;
						}
						// Write the file back to disk
						 try
						 {   
				              TransformerFactory tff = TransformerFactory.newInstance();   
				              Transformer tf = tff.newTransformer();   
				              DOMSource source = new DOMSource(DomTestOperation.getDocument());
				              File newXDPFile = new File(path);
				              StreamResult rs = new StreamResult(newXDPFile);
				              tf.transform(source,rs);  
				              tf.reset();
				          }
						 catch(Exception   e1)
						 {   
				              e1.printStackTrace();   
				         }  
						 String SaveMessage = "Save File: " + path + " OK";
						 SetBold(jTextField);
						 jTextField.setText(SaveMessage);
						 folderManager.setLastOpenPath(Savechooser.getSelectedFile().getParent());
						 Tool.InfoReport(SaveMessage);
					}
		 
				}
			});
		}
		return jSaveButton;
	}


	private JButton getJSortButton() {
		if (jSortButton == null) {
			jSortButton = new JButton();
			jSortButton.setPreferredSize(new Dimension(77, 23));
			jSortButton.setToolTipText("Sort the error records according to their error types.");
			jSortButton.setText("Sort");
			jSortButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					if( !canSort)
						return;
					if( DomTestOperation == null)
					{
						String ErrorMessage = "You have not open any Template File";
						SetBold(jTextField);
						jTextField.setText(ErrorMessage);
						return;
					}
					ListMode.clear();
					jList.setModel(ListMode);
					ArrayList<ErrorTraceObject> TempVec = null;
					DomTestOperation.BackupDataBeforeSort();
					ArrayList<ErrorTraceObject> DataVec = DomTestOperation.GetJListData();  
					TempVec = (ArrayList<ErrorTraceObject>)DataVec.clone();
					DataVec.clear();
					ErrorTraceObject errorObj = null;
					for( int i = 1 ; i <= LayoutErrorType.FORM_MAX_ERROR_TYPE; i++)
					{
						int ListDataSize = TempVec.size();
						for( int j = 0 ; j < ListDataSize; j++)
						{
							errorObj = (ErrorTraceObject)TempVec.get(j);
							if( errorObj.ErrorType == i )
							{
								ListMode.addElement(errorObj.ErrorMessage);
								DataVec.add(errorObj);
							}
						}
					}
					jList.setCellRenderer(new ColorRenderer()); 
					jList.updateUI();
					SetBold(jTextField);
					jTextField.setText("Sort the Errors by their Error Type OK");
					CreateSortOperationLog();
					canSort = false;
				}
			});
		}
		return jSortButton;
	}

	/**
	 * This method initializes jFontButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJFontButton() {
		if (jFontButton == null) {
			jFontButton = new JButton();
			jFontButton.setText("Font");
			jFontButton.setToolTipText("Change the list font size.");
			jFontButton.setPreferredSize(new Dimension(77, 23));
			jFontButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					if(( DomTestOperation == null) && ( markupProcessor == null) && ( excelLoader == null)
							&& ( ExcelHandler == null) && ( templateTransformer == null) && ( markupUI == null))
					{
						String ErrorMessage = "You have not open any Template File or custom xml markup task";
						SetBold(jTextField);
						jTextField.setText(ErrorMessage);
						return;
					}
					String[] ValueOption = new String[] { "Default","10","11","12","13","14","15","16","17","18","19","20","21","22" }; 
				    String FontSize  = (String) JOptionPane.showInputDialog(
				        new JFrame(),
				        "Please select the right font size",
				        "JListBox Font Size Correction", JOptionPane.INFORMATION_MESSAGE,
				        new ImageIcon("java2sLogo.GIF"), ValueOption, "86mm");
				    if( FontSize == null)
				    	return;
				    int NewSize = -1;
					Font oldFont = jList.getFont();
					if( FontSize.equals("Default"))
						NewSize = 12;
					else 
						NewSize = Integer.parseInt(FontSize);
					Font newFont = new Font(oldFont.getName(),oldFont.getStyle(),NewSize);
					String FontMessage = "Change Font Size from " + oldFont.getSize() + " PT to " + NewSize + " PT";
					SetBold(jTextField);
					jTextField.setText(FontMessage);
					jList.setFont(newFont);
				}
			});
		}
		return jFontButton;
	}

	/**
	 * This method initializes jButtonPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJButtonPanel() {
		if (jButtonPanel == null) {
			jFolderLabel = new JLabel();
			jFolderLabel.setText("Folder");
			jFolderLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			jFilleLabel = new JLabel();
			jFilleLabel.setText("File");
			jFilleLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			jButtonPanel = new JPanel();
			jButtonPanel.setLayout(new FlowLayout());
			jButtonPanel.setPreferredSize(new Dimension(300, 120));
			jButtonPanel.add(getJOpenButton(), null);
			jButtonPanel.add(getJSaveButton(), null);
			jButtonPanel.add(getJCloseButton(), null);
			jButtonPanel.add(getJClearButton(), null);
			jButtonPanel.add(getJFontButton(), null);
			jButtonPanel.add(getJSortButton(), null);
			jButtonPanel.add(getJCorrectButton(), null);
			jButtonPanel.add(getJRecent(), null);
			jButtonPanel.add(getJBindButton(), null);
			jButtonPanel.add(getJMarkupPanel1(), null);
		}
		return jButtonPanel;
	}

	/**
	 * This method initializes jStatusPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJStatusPanel() {
		if (jStatusPanel == null) {
			jStatusPanel = new JPanel();
			jStatusPanel.setLayout(new BoxLayout(getJStatusPanel(), BoxLayout.Y_AXIS));
			jStatusPanel.setPreferredSize(new Dimension(560, 40));
			jStatusPanel.add(getJProgressBar(), null);
			jStatusPanel.add(getJStatusBar(), null);
		}
		return jStatusPanel;
	}

	/**
	 * This method initializes jStatusBar	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextArea getJStatusBar() {
		if (jStatusBar == null) {
			jStatusBar = new JTextArea();
			jStatusBar.setBorder(null);
			jStatusBar.setEditable(false);
			jStatusBar.setName("jStatusBar");
			jStatusBar.setBackground(Color.lightGray);
		}
		return jStatusBar;
	}

	/**
	 * This method initializes jCorrectButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJCorrectButton() {
		if (jCorrectButton == null) {
			jCorrectButton = new JButton();
			jCorrectButton.setPreferredSize(new Dimension(77, 23));
			jCorrectButton.setToolTipText("Automatically Correct All Errors about the Template");
			jCorrectButton.setText("Correct");
			jCorrectButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					TemplateDomTest domTest = getTestDom();
					if( domTest == null)
					{
						Tool.ErrorReport("You have not selected a template file");
						SetBold(jStatusBar);
						jStatusBar.setText("You have not selected a template file");
						return;
					}
					if( domTest.GetJListData().size() == 0 )
					{
						Tool.ErrorReport("You have not selected a template file");
						SetBold(jStatusBar);
						jStatusBar.setText("You have not selected a template file");
						return;
					}
					if( isInprogress == false)
					{
						if( canContinue == true) // a aborted correction restart
						{
							jCorrectButton.setText("Cancel");
							setSizeOfCorrection(domTest.GetJListData().size());
							jProgressBar.setMaximum(ConstantStatusSize);
							jStatusPanel.add(jProgressBar);
							jProgressBar.setValue(progress);
							jProgressBar.setStringPainted(true);
							jProgressBar.updateUI();
							canContinue = false;
							isInprogress = true;
							jList.setEnabled(false);
							myTimer.start();
							System.out.println("Restart!");
						}
						else // a completely new correction
						{
							// Start new correction
							jCorrectButton.setText("Cancel");
							jList.setEnabled(false);
							setSizeOfCorrection(domTest.GetJListData().size());
							jProgressBar.setMinimum(0);
							ConstantStatusSize = getSizeOfCorrection();
							jProgressBar.setMaximum(ConstantStatusSize);
							System.out.println("A new Bar Created: " + getSizeOfCorrection());
							jStatusPanel.add(jProgressBar);
							jProgressBar.setValue(0);
							jProgressBar.setStringPainted(true);
							jProgressBar.setVisible(true);
							jProgressBar.updateUI();
							progress = 0;
							if(myTimer == null)
							{
								myTimer = new Timer(400, new MyTimerTask());
							}
							isLayoutCheckingOn = true;
							isCustomMarkupOn = false;
							isInprogress = true;
							myTimer.start();
						
						}
					}
					else if( isInprogress == true)
					// correction in process,click this to abort correction
					{
						jCorrectButton.setText("Continue");
						jList.setEnabled(true);
						SetBold(jStatusBar);
						SetBold(jTextField);
						jStatusBar.setText("Correction Canceled");
						jTextField.setText("Correction Canceled");
						canContinue = true;
						isInprogress = false;
						System.out.println("User cancel the correction,In process: " + isInprogress + " CanContinue: " + canContinue);
						myTimer.stop();
					}
				}
			});
		}
		return jCorrectButton;
	}

	/**
	 * This method initializes jProgressBar	
	 * 	
	 * @return javax.swing.JProgressBar	
	 */
	private JProgressBar getJProgressBar() {
		if (jProgressBar == null) {
			jProgressBar = new JProgressBar();
			jProgressBar.setPreferredSize(new Dimension(580, 40));
			jProgressBar.setName("jProgressBar");
		}
		return jProgressBar;
	}

	private void InitializeRecentMenu()
	{
		int RecentLogSize = RecentFile.size();
		if( RecentLogSize == 0)
			return;
		jRecentMenu = new JPopupMenu();
		RecentMenuItem = new JMenuItem[10];
		int iCurrentMenuItem = 0;
		for(; iCurrentMenuItem < RecentLogSize; iCurrentMenuItem++)
		{
			RecentMenuItem[iCurrentMenuItem] = new JMenuItem();
			RecentMenuItem[iCurrentMenuItem].setText(RecentFile.get(iCurrentMenuItem).toString());
			jRecentMenu.add(RecentMenuItem[iCurrentMenuItem]);
			RecentMenuItem[iCurrentMenuItem].addActionListener(new java.awt.event.ActionListener() 
			{ 
				public void actionPerformed(ActionEvent e) 
				{
					String Text = e.getSource().toString();
					int index = Text.indexOf("text=");
					if( index == -1)
						return;
					String Path = Text.substring(index);
					Path = Path.substring(5,Path.length() - 1);
					DoLayoutChecking(Path);
					TraverseTree();
					PrintTree();
				}
			});
		}
		
	}
	
	private JButton getJRecent() {
		if (jRecent == null) {
			jRecent = new JButton();
			jRecent.setPreferredSize(new Dimension(77, 23));
			jRecent.setToolTipText("Recent tested Template file");
			jRecent.setText("Recent");
			jRecent.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) 
				{
					if( RecentFile.isEmpty())
						return;
					InitializeRecentMenu();
					jList.setEnabled(true);
					jRecentMenu.show(jRecent, e.getX(), e.getY());
				}
			});
		}
		return jRecent;
	}

	/**
	 * This method initializes jScrollPane1	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setViewportView(getJTree());
		}
		return jScrollPane1;
	}

	private void HandleChosenNodeLocation()
	{
		// System.out.println("Chosen: " + ChosenNode.toString());
		ChosenNodeLocation = ConfigDom.getNodeLocation(ChosenNode);
		if( ChosenNodeLocation == null)
			return;
		// System.out.println("Want to search node: " + ChosenNode.toString());
	}
	private void HandleChosenNode()
	{
		HandleChosenNodeLocation();
		ArrayList ListBoxDataVec = getTestDom().GetJListData();
		String NodeName = ChosenNode.toString();
		int ListBoxSize = ListBoxDataVec.size();
		String searchName = null;
		for(int i = 0;i< ListBoxSize;i++)
		{
			updateErrObj = (ErrorTraceObject)ListBoxDataVec.get(i);
			searchName = updateErrObj.GetErrorNodeName();
			if( searchName == null)
				continue;
			if( NodeName.equals(searchName))
			{
				// System.out.println("Found Data in list box: " + searchName);
				// update jlist here
				updatelistbox();
				return;
			}
		}
	}
	
	private void updatelistbox()
	{
    	jList.setSelectedValue(updateErrObj.ErrorMessage, true);
    	jList.setSelectionBackground(Color.gray);
    	jList.updateUI();
    	jList.repaint();
	}
	private void AddPopMeanuForTree()
	{
		jTree.addMouseListener(new   MouseAdapter()   
		{   
			public   void   mousePressed(MouseEvent   event)   
            {   
				if( workModel != LAYOUT_CHECK )
					return;
				if(((event.getModifiers()   &   InputEvent.BUTTON3_MASK)!=0)   &&   (jTree.getSelectionCount()>0))   
                { 
					EventXPosition = event.getX();
					EventYPosition = event.getY();
					JPopupMenu jmenu = new JPopupMenu();
					deleteMenuItem.addActionListener(new java.awt.event.ActionListener() 
					{ 
						// delete
						public void actionPerformed(ActionEvent e) 
					    {
							showNodeDeleteMenu(EventXPosition,EventYPosition);
							canDeleteNode = false;
					    }
					});
					
					exchangeMenuItem.addActionListener(new java.awt.event.ActionListener() 
					{ 
						public void actionPerformed(ActionEvent e) 
					    {
							//System.out.println("Chosen Node: " + ChosenNode.toString());
							showColumnExchangeMenu(EventXPosition,EventYPosition);
							exchangeMenuItem.setEnabled(false);
							canShowColumnDialog = false;
					    }
					});
					changeCaptionMenuItem.addActionListener(new java.awt.event.ActionListener() 
					{ 
						public void actionPerformed(ActionEvent e) 
					    {
							// System.out.println("Caption Chosen Node: " + ChosenNode.toString());
							showCaptionChangeMenu(EventXPosition,EventYPosition);
							changeCaptionMenuItem.setEnabled(false);
							canChangeCaption = false;
					    }
					});
					fontMenuItem.addActionListener(new java.awt.event.ActionListener() 
					{
						public void actionPerformed(ActionEvent e)
						{
							// System.out.println("Operationg on Node:" + ChosenNode.toString());
							showFontChangeMenu(EventXPosition,EventYPosition);
							canChangeFont = false;
						}
					});
					jDetailViewMenuItem.addActionListener(new java.awt.event.ActionListener() 
					{
						public void actionPerformed(ActionEvent e)
						{
							Node node = DomTestOperation.SearchNode(ChosenNode);
							DrawdetailUI drawUI = new DrawdetailUI(null,node);
							drawUI.setVisible(true);
							drawUI.setEnabled(true);
						}
					});
					deleteMenuItem.setText("Delete This Node");
					exchangeMenuItem.setText("Table Column Exchange");
					changeCaptionMenuItem.setText("Change Text");
					fontMenuItem.setText("Change Font Setting");
					jDetailViewMenuItem.setText("View Detail");
					jmenu.add(deleteMenuItem);
					jmenu.add(exchangeMenuItem);
					jmenu.add(changeCaptionMenuItem);
					jmenu.add(fontMenuItem);
					jmenu.add(jDetailViewMenuItem);
					deleteMenuItem.setEnabled(false);
					exchangeMenuItem.setEnabled(false);
					changeCaptionMenuItem.setEnabled(false);
					fontMenuItem.setEnabled(false);
					jDetailViewMenuItem.setEnabled(true);
					if(isColumnExchangedNeed())
					{
						canShowColumnDialog = true;
						exchangeMenuItem.setEnabled(true);
					}
					if( isNodeCanDelete())
					{
						canDeleteNode = true;
						deleteMenuItem.setEnabled(true);
					}
					if( isCaptionCanChange())
					{
						canChangeCaption = true;
						changeCaptionMenuItem.setEnabled(true);
					}
					if( isFontCanChange())
					{
						canChangeFont = true;
						fontMenuItem.setEnabled(true);
					}
					jmenu.setVisible(true);
					jmenu.show(jTree,event.getX(),event.getY());	
                }   
            }   
		});   
	}   
	private boolean isFontCanChange()
	{
		if( !ChosenNode.isLeaf())
			return false;
		String name = ChosenNode.toString();
		return checkFieldCanChangeFont(name);
	}
	private boolean checkFieldCanChangeFont(String name)
	{
		if( name.length() < 3 )
			return false;
		String subThree = name.substring(0,3);
		if( subThree.equalsIgnoreCase(ConfigDom.getTextFieldNamingConvention()))
			return true;
		if( subThree.equalsIgnoreCase(ConfigDom.getStaticTextNamingConvention()))
			return true;
		if( subThree.equalsIgnoreCase(ConfigDom.getTableHeaderNamingConvention()))
			return true;
		if( subThree.equalsIgnoreCase(ConfigDom.getNumericNamingConvention()))
			return true;
		if( subThree.equalsIgnoreCase(ConfigDom.getDecimalNamingConvention()))
			return true;
		return false;
	}
	
	
	private boolean isCaptionCanChange()
	{
		// subform has no caption definition
		if( ChosenNodeLocation == null)
			return false;
		if( !ChosenNode.isLeaf())
			return false;
		Node node = DomTestOperation.SearchNode(ChosenNode);
		if( node == null)
			return false;
		String name = node.getAttributes().getNamedItem("name").getNodeValue();
		if( name == null)
			return false;
		String subThree = name.substring(0,3);
		if( (!subThree.equals(ConfigDom.getTextFieldNamingConvention()) &&
				(!subThree.equals(ConfigDom.getTableHeaderNamingConvention()) &&
				(!subThree.equals(ConfigDom.getStaticTextNamingConvention())))))
			return false;
		return true;
		
	}
	private boolean isNodeCanDelete()
	{
		if( ChosenNodeLocation == null )
			return false;
		if( ChosenNodeLocation.equalsIgnoreCase(ConfigDom.getTableLocation()) || 
				ChosenNodeLocation.equalsIgnoreCase(ConfigDom.getHeaderLocation()) || 
				ChosenNodeLocation.equalsIgnoreCase(ConfigDom.getRowLocation()))
			return false;
		return true;
	}
	private boolean isColumnExchangedNeed()
	{
		if( ChosenNodeLocation == null )
			return false;
		if( ChosenNodeLocation.equalsIgnoreCase(ConfigDom.getTableLocation()) || 
				ChosenNodeLocation.equalsIgnoreCase(ConfigDom.getHeaderLocation()) || 
				ChosenNodeLocation.equalsIgnoreCase(ConfigDom.getRowLocation()))
			return true;
		return false;
	}
	private Node getTableRootNode()
	{
		HeaderNameList.clear();
		TreeNode[] path = ChosenNode.getPath();
		int length = path.length;
		TreeNode item = null;
		Node tableRoot = null;
		for(int i = 0; i < length;i++)
		{
			item = path[i];
			String subThree = item.toString().substring(0,3);
			if( !subThree.equals(ConfigDom.getTableNamingConvention()))
				continue;
			tableRoot = DomTestOperation.SearchNode((DefaultMutableTreeNode)item);
			int childNumber = item.getChildAt(0).getChildCount();
			for(int j = 0; j < childNumber;j++)
			{
				Node headerNode = DomTestOperation.SearchNode((DefaultMutableTreeNode)item.getChildAt(0).getChildAt(j));
				HeaderNameList.add(LayoutTestReuseComponent.GetHeaderNameFromDrawNode(headerNode));
			}
			return tableRoot;
		}
		return null;
	}
	protected   void   showColumnExchangeMenu(int   x,int   y)   
	{   
			if( !canShowColumnDialog)
				return;
			Node tableRoot = getTableRootNode();
			// get the table root node here first
			ColumnDialog cDialog = new ColumnDialog(null,tableRoot,
					HeaderNameList);
			cDialog.setModal(true);
			cDialog.setTitle("Table Column Exchange");
			cDialog.setLocation(x, y);
			cDialog.setVisible(true);
			canShowColumnDialog = cDialog.IsExchangeOK();
			// do the main change work here
			if( cDialog.needRefreshTree())
				RefreshTree();
			exchangeMenuItem.setEnabled(false);
	}
	private void showFontChangeMenu(int x,int y)
	{
		if( !canChangeFont )
			return;
		Node node = DomTestOperation.SearchNode(ChosenNode);
		FontDialog fontDialog = new FontDialog(null,node);
		fontDialog.setLocation(x,y);
		fontDialog.setModal(true);
		fontDialog.setVisible(true);
		canChangeFont = fontDialog.isFontChangeOK();
	}
	private void showCaptionChangeMenu(int x,int y)
	{
		if( !canChangeCaption)
			return;
		Node node = DomTestOperation.SearchNode(ChosenNode);
		CaptionDialog captionDialog = new CaptionDialog(null,node);
		captionDialog.setLocation(x,y);
		captionDialog.setModal(true);
		captionDialog.setVisible(true);
	}
	protected void showNodeDeleteMenu(int x,int y)   
	{   
			if( !canDeleteNode)
				return;
			DeleteDialog deleteDialog = new DeleteDialog(null,ChosenNode);
			deleteDialog.setModal(true);
			deleteDialog.setLocation(x, y);
			deleteDialog.setVisible(true);
			System.out.println("Delete OK? " + deleteDialog.IsDeleteOK());
			canDeleteNode = deleteDialog.IsDeleteOK();
			// do the main change work here
			if( deleteDialog.NeedRefreshTree())
			{
				//Delete the corresponding node in the Dom
				Node selectedNode = DomTestOperation.SearchNode(ChosenNode);
				if( selectedNode == null)
				{
					System.out.println("Corresponding node in the Dom does not exist!");
					return;
				}
				System.out.println("Deleting node: " + ChosenNode.toString());
				selectedNode.getParentNode().removeChild(selectedNode);
				RefreshTree();
				System.out.println("Delete node: " + ChosenNode.toString() + " OK!");
			}
	}
	private void RefreshTree()
	{
		DomTestOperation.StartNewTraverseWithoutCheck();
		DomTestOperation.ModuleTree();
		jTree.removeAll();
		DefaultTreeModel nullModel = new DefaultTreeModel(null);
		jTree.setModel(nullModel);
		jTree.repaint();
		jTree.updateUI();
		jTree.setModel(DomTestOperation.getTreeMode());
		jTree.setVisible(true);
	}
	private JTree getJTree() 
	{
		if (jTree == null) 
		{
			jTree = new JTree();
			jTree.setVisible(false);
			jTree.addMouseListener(new java.awt.event.MouseAdapter() 
			{
				public void mouseClicked(java.awt.event.MouseEvent e) 
				{
					if( workModel == LAYOUT_CHECK)
					{
						ChosenNode = (DefaultMutableTreeNode)jTree.getLastSelectedPathComponent();
						if( ChosenNode == null)
							return;
						HandleChosenNode();
					}
					else if ( workModel == MARKUP_CHECK )
					{
						if( checker == null)
							return;
						System.out.println("Click: " + jTree.getLastSelectedPathComponent().toString());
						checker.highLightListBox((DefaultMutableTreeNode)jTree.getLastSelectedPathComponent());
					}
				}
			});
		}
		AddPopMeanuForTree();
		return jTree;
	}

	/**
	 * This method initializes jSplitPane	
	 * 	
	 * @return javax.swing.JSplitPane	
	 */
	private JSplitPane getJSplitPane() {
		if (jSplitPane == null) {
			jSplitPane = new JSplitPane();
			jSplitPane.setLeftComponent(getJScrollPane1());
			jSplitPane.setRightComponent(getJScrollPane());
		}
		return jSplitPane;
	}

	private void UndoSortOperation()
	{
    	String input = null;
    	jList.setModel(ListMode);
    	ListMode.removeAllElements();
    	ErrorTraceObject errObj = null;
    	DomTestOperation.RestoreDataAfterSort();
    	int size = DomTestOperation.GetJListData().size();
    	for( int i = 0; i < size;i++)
    	{
    		errObj= (ErrorTraceObject) DomTestOperation.GetJListData().get(i);
    		input = errObj.ErrorMessage;
    		ListMode.addElement(input);
    	}
    	jList.updateUI();
    	jList.repaint();
    	canSort = true;
	}
	private void ReDoupdatelistbox(OperationLog log)
	{
    	String input = null;
    	ErrorTraceObject errObj = null;
    	int ListDataSize = DomTestOperation.GetJListData().size();
    	ListMode.clear();
    	for( int i = 0; i < ListDataSize;i++)
    	{
    		errObj= (ErrorTraceObject) DomTestOperation.GetJListData().get(i);
    		input = errObj.ErrorMessage;
    		ListMode.addElement(input);
    	}
    	DomTestOperation.GetJListData().add(log.iIndexinListbox, log.errObj);
    	ListMode.add(log.iIndexinListbox, log.errObj.ErrorMessage);
    	int size = DomTestOperation.getOperationList().size();
    	DomTestOperation.getOperationList().remove(size-1);
    	String CurrentError = "Currently " + ++iTotalErrorNum  + " Errors left!";
    	SetBold(jTextField);
    	jTextField.setText(CurrentError);
    	SetBold(jStatusBar);
    	jStatusBar.setText(CurrentError);
    	jList.updateUI();
    	jList.repaint();
	}

	private boolean SetFileChooserProperty()
	{
		System.out.println("File?" + operationOnFile);
		System.out.println("Folder:" + operationOnFolder);
		if(( operationOnFile == false) && ( operationOnFolder == false))
			return false;
		if( operationOnFile )
		{
			jFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			jFileChooser.setMultiSelectionEnabled(true);
			ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
			jFileChooser.addChoosableFileFilter(filter);
		}
		else if( operationOnFolder)
		{
			jFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		}
		return true;
	}
	
	private JButton getJFormatButton() {
		if (jFormatButton == null) {
			jFormatButton = new JButton();
			jFormatButton.setPreferredSize(new Dimension(241, 23));
			jFormatButton.setText("Custom Markup Format");
			jFormatButton.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e)
				{
					StoreFolder store = new StoreFolder(null,e.getXOnScreen() ,e.getYOnScreen());
					store.setVisible(true);
					String storePath = store.getStoreFolderPath();
					if( storePath == null || !store.IsStoreOK())
						return;
					jList.setCellRenderer(new ColorRenderer()); 
					// should assign a folder to store modified file
					ListMode.clear();
					ListMode.addElement("All the Templates Have Been Put Into Folder:  " + storePath);
					jFileChooser = new JFileChooser();
					// 2008-06-10 add file manager logic
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						jFileChooser.setCurrentDirectory(curr);
					// should set the corresponding configuration of file choose 
					// here according to the selection in the previous radio button 
					SetFileChooserProperty();
					//jFileChooser.setMultiSelectionEnabled(true);
					//jFileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
					
					
					 int option = jFileChooser.showOpenDialog(null);
				     if (option == JFileChooser.APPROVE_OPTION) 
				     {
				    	 SetBold(jTextField);
				    	 jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	 jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	 String StatusMessage = "Currently Operationed on Template File: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	 SetBold(jStatusBar);
				    	 jStatusBar.setText(StatusMessage);
				    	 if( operationOnFile )
				    	 {
				    		 fSelectedFiles = jFileChooser.getSelectedFiles();
				    		 // 2008-06-10 add file manager logic
				    		 folderManager.setLastOpenPath(fSelectedFiles[0].getParent());
				    	 }
				    	 else
				    	 {
				    		 fSelectedFiles = new File[1];
				    		 fSelectedFiles[0]= jFileChooser.getSelectedFile();
				    	 }
						 //UpdateRecentHistory(fSelectedFiles[0].getAbsolutePath());
						 //DoLayoutChecking(fSelectedFiles[0].getAbsolutePath());
						 //TraverseTree();
						 //PrintTree();
				    	 markupProcessor = new CustomMarkupProcessor(storePath);
				    	 int TaskNumber = markupProcessor.AssginTaskArrayList(fSelectedFiles);
				    	 InitializeProgressBarWithCustomMarkupOperation(TaskNumber);
				    	 markupProcessor.DoActions(fSelectedFiles);
				     }
				     else 
				     {
				    	 jTextField.setText("You canceled.");
				     }
				}
			});
		}
		return jFormatButton;
	}
	private void InitializeProgressBarWithCustomMarkupOperation(int taskNumber)
	{
		jProgressBar.setMinimum(0);
		jProgressBar.setMaximum(taskNumber);
		System.out.println("A new Bar Created: " + taskNumber);
		jStatusPanel.add(jProgressBar);
		jProgressBar.setValue(0);
		jProgressBar.setStringPainted(true);
		jProgressBar.setVisible(true);
		jProgressBar.updateUI();
		progress = 0;
		CurrentLeftMarkupTask = taskNumber;
		if(myTimer == null)
		{
			myTimer = new Timer(40, new MyTimerTask());
		}
		isLayoutCheckingOn = false;
		isCustomMarkupOn = true;
		myTimer.start();
	}
	private void InitializeProgressBarWithEFEMassCheckOperation(int taskNumber)
	{
		jProgressBar.setMinimum(0);
		jProgressBar.setMaximum(taskNumber);
		jStatusPanel.add(jProgressBar);
		jProgressBar.setValue(0);
		jProgressBar.setStringPainted(true);
		jProgressBar.setVisible(true);
		jProgressBar.updateUI();
		progress = 0;
		CurrentLeftMarkupTask = taskNumber;
		if(myTimer == null)
		{
			myTimer = new Timer(30, new MyTimerTask());
		}
		myTimer.start();
	}
	/**
	 * This method initializes jRadioButton_File	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getJRadioButton_File() {
		if (jRadioButton_File == null) {
			jRadioButton_File = new JRadioButton();
			jRadioButton_File.setSelected(true);
			operationOnFile = true;
			jRadioButton_File.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					jRadioButton_folder.setSelected(false);
					jRadioButton_File.setSelected(true);
					operationOnFolder = false;
					operationOnFile = true;
				}
			});
		}
		return jRadioButton_File;
	}

	/**
	 * This method initializes jMarkupPanel1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJMarkupPanel1() {
		if (jMarkupPanel1 == null) {
			jMarkupPanel1 = new JPanel();
			jMarkupPanel1.setLayout(new BoxLayout(getJMarkupPanel1(), BoxLayout.Y_AXIS));
			jMarkupPanel1.add(getJCustomButtonPanel(), null);
			jMarkupPanel1.add(getJRadioPanel(), null);
		}
		return jMarkupPanel1;
	}

	/**
	 * This method initializes jRadioButton_folder	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getJRadioButton_folder() {
		if (jRadioButton_folder == null) {
			jRadioButton_folder = new JRadioButton();
			jRadioButton_folder.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					jRadioButton_File.setSelected(false);
					jRadioButton_folder.setSelected(true);
					operationOnFile = false;
					operationOnFolder = true;
				}
			});
		}
		return jRadioButton_folder;
	}

	/**
	 * This method initializes jFilePanel1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJFilePanel1() {
		if (jFilePanel1 == null) {
			jFilePanel1 = new JPanel();
			jFilePanel1.setLayout(new BoxLayout(getJFilePanel1(), BoxLayout.X_AXIS));
			jFilePanel1.add(getJRadioButton_File(), null);
			jFilePanel1.add(jFilleLabel, null);
		}
		return jFilePanel1;
	}

	/**
	 * This method initializes jFolderPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJFolderPanel() {
		if (jFolderPanel == null) {
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.gridx = 2;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.gridx = 1;
			gridBagConstraints.gridy = 0;
			jFolderPanel = new JPanel();
			jFolderPanel.setLayout(new GridBagLayout());
			jFolderPanel.add(getJRadioButton_folder(), new GridBagConstraints());
			jFolderPanel.add(jFolderLabel, gridBagConstraints1);
			jFolderPanel.add(jBlankLabel, gridBagConstraints);
		}
		return jFolderPanel;
	}

	/**
	 * This method initializes jCustomButtonPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJCustomButtonPanel() {
		if (jCustomButtonPanel == null) {
			jCustomButtonPanel = new JPanel();
			jCustomButtonPanel.setLayout(new GridBagLayout());
			jCustomButtonPanel.add(getJFormatButton(), new GridBagConstraints());
		}
		return jCustomButtonPanel;
	}

	/**
	 * This method initializes jRadioPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJRadioPanel() {
		if (jRadioPanel == null) {
			jBlankLabel = new JLabel();
			jBlankLabel.setText("");
			jRadioPanel = new JPanel();
			jRadioPanel.setLayout(new BoxLayout(getJRadioPanel(), BoxLayout.X_AXIS));
			jRadioPanel.add(getJFilePanel1(), null);
			jRadioPanel.add(getJFolderPanel(), null);
		}
		return jRadioPanel;
	}

	/**
	 * This method initializes jBindButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJBindButton() {
		if (jBindButton == null) {
			jBindButton = new JButton();
			jBindButton.setPreferredSize(new Dimension(77, 23));
			jBindButton.setText("Undo");
			jBindButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					if( DomTestOperation == null)
						return;
					int LogSize = DomTestOperation.getOperationList().size();
					if( LogSize == 0 )
						return;
					ArrayList LogList = DomTestOperation.getOperationList();
					System.out.println("Log List Size: " + LogList.size());
					OperationLog log = (OperationLog)LogList.get(LogSize -1);
					if( log.UserInput == null)
						return;
					if( log.UserInput.equals("SORT"))
					{
						UndoSortOperation();
						return;
					}
					ReDoupdatelistbox(log);
				}
			});
		}
		return jBindButton;
	}

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.setPreferredSize(new Dimension(10, 20));
			jJMenuBar.add(getJMenu());
			jJMenuBar.add(getJBindMenu());
			jJMenuBar.add(getJTransformMenu());
			jJMenuBar.add(getJExtactBindingMenu());
			jJMenuBar.add(getJDefaultValueMenu());
			jJMenuBar.add(getJMarkupMenu());
			jJMenuBar.add(getFMT());
			jJMenuBar.add(getJHelpMenu());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenu() {
		if (jMenu == null) {
			jMenu = new JMenu();
			jMenu.setText("Excel");
			jMenu.add(getJMenuItem());
			jMenu.add(getJSaveAsMenuItem());
			jMenu.add(getJPreviewMenuItem());
		}
		return jMenu;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem() {
		if (jMenuItem == null) {
			jMenuItem = new JMenuItem();
			jMenuItem.setText("Excel Format");
			jMenuItem.setToolTipText("Format a un-formatted excel template.");
			jMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser ExcelFileChooser = new JFileChooser();
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						ExcelFileChooser.setCurrentDirectory(curr);
					ExcelFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xml", "Form Data Binding Specification File");
					ExcelFileChooser.addChoosableFileFilter(filter);
					int option = ExcelFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((ExcelFileChooser.getSelectedFile()!=null)?
				    	ExcelFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	folderManager.setLastOpenPath(ExcelFileChooser.getSelectedFile().getParent());
				    	String StatusMessage = "Currently Operationed on Data Binding Specification File: " + ExcelFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	ExcelHandler = new excelHandler();
				    	ExcelHandler.SetDisplayMode(jList,ListMode);
				    	int ret = ExcelHandler.FormatExcel(ExcelFileChooser.getSelectedFile().getAbsolutePath());
				    	if( ret == FORMAT_OK)
				    	{
				    		Tool.InfoReport("Excel Specification Formatted Successfully!");
				    		jSaveAsMenuItem.setEnabled(true);
				    	}
				    	else if ( ret == NO_NEED_FORMAT)
				    		Tool.InfoReport("This specification has already been well formatted,no need format any more!");
				    	else if ( ret == NO_BINDING_WORKSHEET)
				    		Tool.ErrorReport("Can not find one workSheet named 'Binding' ");
				    	else 
				    		Tool.ErrorReport("This Excel file has wrong format,unable to be formatted!");
				    	
				    }
				    else 
				    {
				    	jTextField.setText("You canceled.");
				    }
				    
				}
			});
		}
		return jMenuItem;
	}

	/**
	 * This method initializes jSaveAsMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJSaveAsMenuItem() {
		if (jSaveAsMenuItem == null) {
			jSaveAsMenuItem = new JMenuItem();
			jSaveAsMenuItem.setEnabled(false);
			jSaveAsMenuItem.setToolTipText("Save the formatted excel template into another file.");
			jSaveAsMenuItem.setText("Save As");
			jSaveAsMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					Tool.InfoReport("Choose the location you want to save");
					jFileChooser = new JFileChooser();
					jFileChooser.setMultiSelectionEnabled(true);
					ExampleFileFilter filter = new ExampleFileFilter("xml", "Form Data Binding Specification File");
					jFileChooser.addChoosableFileFilter(filter);
					jFileChooser.setApproveButtonText("Save");
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on Template File: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	String savedPath = ExcelHandler.WriteBacktoDisk(jFileChooser.getSelectedFile().getAbsolutePath());
				    	if( savedPath != null )
				    	{
				    		ExcelHandler = null;
				    		jSaveAsMenuItem.setEnabled(false);
				    		Tool.InfoReport("File Saved into Folder: " + savedPath + " Successfully!");
				    	}
				    	else
				    	{
				    		Tool.ErrorReport(jFileChooser.getSelectedFile().getAbsolutePath() + " Already existed! Please choose a new file!" );
				    	}
				    	
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jSaveAsMenuItem;
	}

	/**
	 * This method initializes jBindMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJBindMenu() {
		if (jBindMenu == null) {
			jBindMenu = new JMenu();
			jBindMenu.setPreferredSize(new Dimension(63, 21));
			jBindMenu.setText("Auto Bind");
			jBindMenu.setSize(new Dimension(45, 18));
			jBindMenu.add(getJAssignExcelMenuItem());
			jBindMenu.add(getJTemplateBindMenuItem());
			jBindMenu.add(getJSaveFormattedTemplateMenuItem());
			jBindMenu.add(getJXDPPreviewMenuItem());
			jBindMenu.add(getJLogFileMenuItem());
		}
		return jBindMenu;
	}

	/**
	 * This method initializes jAssignExcelMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJAssignExcelMenuItem() {
		if (jAssignExcelMenuItem == null) {
			jAssignExcelMenuItem = new JMenuItem();
			jAssignExcelMenuItem.setText("Assign a Excel Spec");
			jAssignExcelMenuItem.setToolTipText("Only after you choose an formatted excel template can you do automatic data-binding on a template.");
			jAssignExcelMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser ExcelFileChooser = new JFileChooser();
					ExcelFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xml", "Form Data Binding Specification File");
					ExcelFileChooser.addChoosableFileFilter(filter);
					int option = ExcelFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((ExcelFileChooser.getSelectedFile()!=null)?
				    	ExcelFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on Data Binding Specification File: " + ExcelFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	excelLoader = new ExcelConfigurationLoader();
				    	if( excelLoader.FillCollection(ExcelFileChooser.getSelectedFile().getAbsolutePath()) == -1 )
				    	{
				    		Tool.InfoReport("This excel has not been formatted,you must first format it!");
				    		excelLoader = null;
				    		return;
				    	}
				    	excelLoader.printPathCollection(ListMode,jList);
				    	Tool.InfoReport("Excel Specification Loaded Successfully!");
				    	jTemplateBindMenuItem.setEnabled(true);
				    	jSaveFormattedTemplateMenuItem.setEnabled(false);
				    	jLogFileMenuItem.setEnabled(false);
				    }
				    else 
				    {
				    	jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jAssignExcelMenuItem;
	}

	/**
	 * This method initializes jTemplateBindMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJTemplateBindMenuItem() {
		if (jTemplateBindMenuItem == null) {
			jTemplateBindMenuItem = new JMenuItem();
			jTemplateBindMenuItem.setEnabled(false);
			jTemplateBindMenuItem.setText("Auto Bind a Template");
			jTemplateBindMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					jFileChooser = new JFileChooser();
					jFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
					jFileChooser.addChoosableFileFilter(filter);
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on Template File: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	bindprocessor = new TemplateBindingProcessor(excelLoader.getBindingPathCollection());
				    	bindprocessor.StartTemplateBinding(jFileChooser.getSelectedFile().getAbsolutePath());
				    	bindprocessor.PrintBindingStatistics(jList,ListMode);
				    	jSaveFormattedTemplateMenuItem.setEnabled(true);
				    	jLogFileMenuItem.setEnabled(true);
				    	Tool.InfoReport("Template Data Binding Done!");
			
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jTemplateBindMenuItem;
	}

	/**
	 * This method initializes jSaveFormattedTemplateMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJSaveFormattedTemplateMenuItem() {
		if (jSaveFormattedTemplateMenuItem == null) {
			jSaveFormattedTemplateMenuItem = new JMenuItem();
			jSaveFormattedTemplateMenuItem.setEnabled(false);
			jSaveFormattedTemplateMenuItem.setText("Save As");
			jSaveFormattedTemplateMenuItem
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) 
						{
							Tool.InfoReport("Choose the location you want to save the modified template file");
							jFileChooser = new JFileChooser();
							jFileChooser.setMultiSelectionEnabled(false);
							ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Template File");
							jFileChooser.addChoosableFileFilter(filter);
							jFileChooser.setApproveButtonText("Save");
							int option = jFileChooser.showOpenDialog(null);
						    if (option == JFileChooser.APPROVE_OPTION) 
						    {
						    	SetBold(jTextField);
						    	jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
						    	jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
						    	String StatusMessage = "Currently Operationed on Template File: " + jFileChooser.getSelectedFile().getAbsolutePath();
						    	SetBold(jStatusBar);
						    	jStatusBar.setText(StatusMessage);
						    	String savedPath = bindprocessor.SaveAs(jFileChooser.getSelectedFile().getAbsolutePath());
						    	if( savedPath != null )
						    	{
						    		bindprocessor = null;
						    		jSaveFormattedTemplateMenuItem.setEnabled(false);
						    		jTemplateBindMenuItem.setEnabled(false);
						    		Tool.InfoReport("Template Saved into Folder: " + savedPath + " Successfully!");
						    	}
						    	else
						    	{
						    		Tool.ErrorReport(jFileChooser.getSelectedFile().getAbsolutePath() + " Already existed! Please choose a new file!" );
						    	}
						    	
						    }
						    else 
						    {
						    	 jTextField.setText("You canceled.");
						    }
						}
					});
		}
		return jSaveFormattedTemplateMenuItem;
	}

	/**
	 * This method initializes jPreviewMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJPreviewMenuItem() {
		if (jPreviewMenuItem == null) {
			jPreviewMenuItem = new JMenuItem();
			jPreviewMenuItem.setText("Preview Excel");
			jPreviewMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser excelFileChooser = new JFileChooser();
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						excelFileChooser.setCurrentDirectory(curr);
					excelFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xml", "A1S Excel Template");
					excelFileChooser.addChoosableFileFilter(filter);
					int option = excelFileChooser.showOpenDialog(null);
					if (option == JFileChooser.APPROVE_OPTION) 
					{
				    	 SetBold(jTextField);
				    	 jTextField.setText("" + ((excelFileChooser.getSelectedFile()!=null)?
				    	 excelFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	 String StatusMessage = "Currently Operationed on Template File: " + excelFileChooser.getSelectedFile().getAbsolutePath();
				    	 SetBold(jStatusBar);
				    	 jStatusBar.setText(StatusMessage);
				    	 folderManager.setLastOpenPath(excelFileChooser.getSelectedFile().getParent());
				    	 try                                      //try statement
				         {
				    		 Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + excelFileChooser.getSelectedFile().getAbsolutePath());   //open the excel
				         } 
				    	 catch (Exception e1)                    //catch any exceptions here
				         {
				    		 System.out.println("Error:" + e1 );  //print the error
				         }

				     }
				     else 
				     {
				    	 jTextField.setText("You canceled.");
				     }
				}
			});
		}
		return jPreviewMenuItem;
	}

	/**
	 * This method initializes jXDPPreviewMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJXDPPreviewMenuItem() {
		if (jXDPPreviewMenuItem == null) {
			jXDPPreviewMenuItem = new JMenuItem();
			jXDPPreviewMenuItem.setText("Preview Template");
			jXDPPreviewMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser xdpFileChooser = new JFileChooser();
					xdpFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
					xdpFileChooser.addChoosableFileFilter(filter);
					int option = xdpFileChooser.showOpenDialog(null);
					if (option == JFileChooser.APPROVE_OPTION) 
					{
				    	 SetBold(jTextField);
				    	 jTextField.setText("" + ((xdpFileChooser.getSelectedFile()!=null)?
				    	 xdpFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	 String StatusMessage = "Currently Operationed on Template File: " + xdpFileChooser.getSelectedFile().getAbsolutePath();
				    	 SetBold(jStatusBar);
				    	 jStatusBar.setText(StatusMessage);
				    	 try                                      //try statement
				         {
				    		 Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + xdpFileChooser.getSelectedFile().getAbsolutePath());   //open the excel
				         } 
				    	 catch (Exception e1)                    //catch any exceptions here
				         {
				    		 System.out.println("Error:" + e1 );  //print the error
				         }

				     }
				     else 
				     {
				    	 jTextField.setText("You canceled.");
				     }
				}
			});
		}
		return jXDPPreviewMenuItem;
	}

	/**
	 * This method initializes jLogFileMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJLogFileMenuItem() {
		if (jLogFileMenuItem == null) {
			jLogFileMenuItem = new JMenuItem();
			jLogFileMenuItem.setEnabled(false);
			jLogFileMenuItem.setText("Save Bind LogFile");
			jLogFileMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					Tool.InfoReport("Choose the location you want to save the log file");
					jFileChooser = new JFileChooser();
					jFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("html", "Binding Log File");
					jFileChooser.addChoosableFileFilter(filter);
					jFileChooser.setApproveButtonText("Save");
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on Template File: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	String savedPath = bindprocessor.SaveLogFile(jFileChooser.getSelectedFile().getAbsolutePath());
				    	Tool.InfoReport("Log File: " + savedPath + " Saved OK!");
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				    jFileChooser = null;
				}
			});
		}
		return jLogFileMenuItem;
	}

	/**
	 * This method initializes jTransformMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJTransformMenu() {
		if (jTransformMenu == null) {
			jTransformMenu = new JMenu();
			jTransformMenu.setText("Transform");
			jTransformMenu.add(getJTransformMenuItem());
			jTransformMenu.add(getJTransformWithXMLDataMenuItem());
			jTransformMenu.add(getJSaveAsTemplateExcelMenuItem());
			jTransformMenu.add(getJExcel2TemplateMenuItem());
		}
		return jTransformMenu;
	}

	/**
	 * This method initializes jTransformMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJTransformMenuItem() {
		if (jTransformMenuItem == null) {
			jTransformMenuItem = new JMenuItem();
			jTransformMenuItem.setText("Transform template");
			jTransformMenuItem.setToolTipText("Transform standard form template without xml data file.");
			jTransformMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser jTemplateChooser = new JFileChooser();
					jTemplateChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
					jTemplateChooser.addChoosableFileFilter(filter);
					int option = jTemplateChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((jTemplateChooser.getSelectedFile()!=null)?
				    	jTemplateChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on Template File: " + jTemplateChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	TemplateTransformer transformer = new TemplateTransformer();
				    	transformer.Transform(jTemplateChooser.getSelectedFile().getAbsolutePath());
				    	// tempory solution
				    	templateTransformer = new ExcelTransformer(transformer.getTemplateCellCollection(),
				    			transformer.getPositionInfo());
				    	templateTransformer.getListHandler(jList, ListMode);
				    	// 1.xml as the raw excel template for output an excel from template
				    	templateTransformer.FormatRawExcel("./1.xml",jTemplateChooser.getSelectedFile().getAbsolutePath());
				    	jSaveAsTemplateExcelMenuItem.setEnabled(true);
				    	Tool.InfoReport("Template: " + jTemplateChooser.getSelectedFile().getAbsolutePath() + " Transformed to Excel Successfully!");
				    	
				     }
				     else 
				     {
				    	 jTextField.setText("You canceled.");
				     }
				}
			});
		}
		return jTransformMenuItem;
	}

	/**
	 * This method initializes jExtactBindingMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJExtactBindingMenu() {
		if (jExtactBindingMenu == null) {
			jExtactBindingMenu = new JMenu();
			jExtactBindingMenu.setText("Extract Binding");
			jExtactBindingMenu.add(getJExtractMenuItem());
			jExtactBindingMenu.add(getJEngineerSaveMenuItem());
			jExtactBindingMenu.add(getJGetPathMenuItem());
			jExtactBindingMenu.add(getJSaveAsTextMenuItem());
		}
		return jExtactBindingMenu;
	}

	/**
	 * This method initializes jExtractMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJExtractMenuItem() {
		if (jExtractMenuItem == null) {
			jExtractMenuItem = new JMenuItem();
			jExtractMenuItem.setText("Extract Binding Path");
			jExtractMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					Tool.InfoReport("Chooser A Template Whose Binding Path You Want to Extract!");
					jFileChooser = new JFileChooser();
					jFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
					jFileChooser.addChoosableFileFilter(filter);
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						jFileChooser.setCurrentDirectory(curr);
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on Template File: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	folderManager.setLastOpenPath(jFileChooser.getSelectedFile().getParent());
				    	fSelectedFiles = jFileChooser.getSelectedFiles();
				    	pathExtractor = new TemplateBindingPathExtractor(jList,ListMode);
				    	pathExtractor.StartExtracting(jFileChooser.getSelectedFile().getAbsolutePath());
				    	Tool.InfoReport("Choose An Engineer Spec into which the Extracted Path will be Written!");
				    	ExampleFileFilter excelfilter = new ExampleFileFilter("xml", "A1S Form Engineer Specification File");
						jFileChooser.addChoosableFileFilter(excelfilter);
						option = jFileChooser.showOpenDialog(null);
						if( option != JFileChooser.APPROVE_OPTION)
							return;
						EngineerTransformer  = new PathTransformerForExcel(pathExtractor.getPathCollection(),
				    			pathExtractor.getRootPath());
						EngineerTransformer.setMessageTypeRoot(pathExtractor.getMessageTypeRoot());
						EngineerTransformer.LoadExcelSpec(jFileChooser.getSelectedFile().getAbsolutePath());
						if( !EngineerTransformer.TransformPath() )
						{
							Tool.InfoReport("Check the Message Type you Imported to Excel Template!");
							return;
						}
						jEngineerSaveMenuItem.setEnabled(true);
						Tool.InfoReport("All Binding Path Written into Excel Engineer Specification: " + 
								jFileChooser.getSelectedFile().getAbsolutePath() + "Successfully!");
				    }
				    else 
				    {
				    	jTextField.setText("You canceled.");
				    }
					
				}
			});
		}
		return jExtractMenuItem;
	}

	/**
	 * This method initializes jSaveAsTemplateExcelMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJSaveAsTemplateExcelMenuItem() {
		if (jSaveAsTemplateExcelMenuItem == null) {
			jSaveAsTemplateExcelMenuItem = new JMenuItem();
			jSaveAsTemplateExcelMenuItem.setEnabled(false);
			jSaveAsTemplateExcelMenuItem.setText("Save As");
			jSaveAsTemplateExcelMenuItem
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) 
						{
							JFileChooser jTemplateChooser = new JFileChooser();
							jTemplateChooser.setMultiSelectionEnabled(false);
							ExampleFileFilter filter = new ExampleFileFilter("xml", "Excel File");
							jTemplateChooser.addChoosableFileFilter(filter);
							int option = jTemplateChooser.showOpenDialog(null);
						    if (option == JFileChooser.APPROVE_OPTION) 
						    {
						    	String savePath = templateTransformer.SaveAs(jTemplateChooser.getSelectedFile().getAbsolutePath());
						    	if( savePath == null)
						    	{
						    		Tool.ErrorReport(jTemplateChooser.getSelectedFile().getAbsolutePath() + " Already existed! Please choose a new file!" );
						    		return;
						    	}
						    	jSaveAsTemplateExcelMenuItem.setEnabled(true);
						    	String StatusMessage = "Currently Saved Excel File in: " + savePath;
						    	SetBold(jStatusBar);
						    	jStatusBar.setText(StatusMessage);
						    	SetBold(jTextField);
						    	jTextField.setText(StatusMessage);
						    	Tool.InfoReport("Excel File Saved into Folder: " + savePath + " Successfully!");
						    	
						    	
						    }
						    else 
						    {
						    	 jTextField.setText("You canceled.");
						    }
						}
					});
		}
		return jSaveAsTemplateExcelMenuItem;
	}

	/**
	 * This method initializes jExcel2TemplateMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJExcel2TemplateMenuItem() {
		if (jExcel2TemplateMenuItem == null) {
			jExcel2TemplateMenuItem = new JMenuItem();
			jExcel2TemplateMenuItem.setText("Excel to Template");
			jExcel2TemplateMenuItem.setToolTipText("Transform the modified excel file back into a new template file.");
			jExcel2TemplateMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					Tool.InfoReport("Choose Your Mockup Excel File to be Transformed!");
					JFileChooser ExcelFileChooser = new JFileChooser();
					ExcelFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xml", "A1S Form Mockup File");
					ExcelFileChooser.addChoosableFileFilter(filter);
					int option = ExcelFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((ExcelFileChooser.getSelectedFile()!=null)?
				    	ExcelFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on A1S Form Mockup File: " + ExcelFileChooser.getSelectedFile().getAbsolutePath();
				    	String excelPath = ExcelFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	ExampleFileFilter xdpfilter = new ExampleFileFilter("xdp", "A1S Form Template File");
				    	ExcelFileChooser.removeChoosableFileFilter(filter);
				    	ExcelFileChooser.addChoosableFileFilter(xdpfilter);
				    	Tool.InfoReport("Please Choose a Location to Store Your Transformed Form Template");
				    	option = ExcelFileChooser.showOpenDialog(null);
				    	if( option != JFileChooser.APPROVE_OPTION)
				    		return;
				    	String xdpPath = ExcelFileChooser.getSelectedFile().getAbsolutePath();
				    	if( !xdpPath.contains("xdp") && !xdpPath.contains("XDP"))
				    		xdpPath += ".xdp";
				    	File newFile = new File(xdpPath);
						if( newFile.exists())
						{
							Tool.ErrorReport("You Selected File: " + xdpPath + " Alreadt Exist!Please Reselect a New File");
							return;
						}
						int highLightOption = Tool.Chooser("Would You Like to HighLight Your Newly Added Fields?");
				    	Excel2Template transformer = new Excel2Template(excelPath);
				    	transformer.setHighLightOption(highLightOption);
				    	transformer.setSavedTemplatePath(xdpPath);
				    	transformer.SetJlistMode(jList,ListMode);
				    	transformer.Transform2Template();
				    	Tool.InfoReport("Template File: " + xdpPath + " Transformed from Excel Successfully!");
				    }
				    else
				    {
				    	jTextField.setText("You canceled.");
				    }
				    
				}
			});
		}
		return jExcel2TemplateMenuItem;
	}

	/**
	 * This method initializes jTransformWithXMLDataMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJTransformWithXMLDataMenuItem() {
		if (jTransformWithXMLDataMenuItem == null) {
			jTransformWithXMLDataMenuItem = new JMenuItem();
			jTransformWithXMLDataMenuItem.setText("Transform template with XML data file");
			jTransformWithXMLDataMenuItem.setToolTipText("Transform standard form template together with xml data file for it.");
			jTransformWithXMLDataMenuItem
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) 
						{
							Tool.InfoReport("Choose a Template File You Want to Transform into Excel Format");
							JFileChooser jTemplateChooser = new JFileChooser();
							jTemplateChooser.setMultiSelectionEnabled(false);
							ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
							jTemplateChooser.addChoosableFileFilter(filter);
							int option = jTemplateChooser.showOpenDialog(null);
						    if (option == JFileChooser.APPROVE_OPTION) 
						    {
						    	SetBold(jTextField);
						    	jTextField.setText("" + ((jTemplateChooser.getSelectedFile()!=null)?
						    	jTemplateChooser.getSelectedFile().getAbsolutePath():"Nothing"));
						    	String templatePath = jTemplateChooser.getSelectedFile().getAbsolutePath();
						    	String StatusMessage = "Currently Operationed on Template File: " + templatePath;
						    	SetBold(jStatusBar);
						    	jStatusBar.setText(StatusMessage);
						    	// choose a xml data file
						    	Tool.InfoReport("Choose a XML Data File You Want to Import into Excel File");
						    	ExampleFileFilter XMLfilter = new ExampleFileFilter("xml", "A1S Form Template XML Data File");
						    	jTemplateChooser.removeChoosableFileFilter(filter);
						    	jTemplateChooser.addChoosableFileFilter(XMLfilter);
						    	option = jTemplateChooser.showOpenDialog(null);
						    	if( option != JFileChooser.APPROVE_OPTION)
						    		return;
						    	TemplateTransformer transformer = new TemplateTransformer();
						    	transformer.SetXMLDataFileFlag(jTemplateChooser.getSelectedFile().getAbsolutePath());
						    	transformer.Transform(templatePath);
						    	// tempory solution
						    	templateTransformer = new ExcelTransformer(transformer.getTemplateCellCollection(),
						    			transformer.getPositionInfo());
						    	templateTransformer.getListHandler(jList, ListMode);
						    	templateTransformer.TraceFileInfo(templatePath,jTemplateChooser.getSelectedFile().getAbsolutePath());
						    	// 1.xml as the raw excel template for output an excel from template
						    	templateTransformer.FormatRawExcel("./1.xml",templatePath);
						    	jSaveAsTemplateExcelMenuItem.setEnabled(true);
						    	Tool.InfoReport("Template: " + templatePath + " Transformed to Excel Successfully!");
						    	
						     }
						     else 
						     {
						    	 jTextField.setText("You canceled.");
						     }
						}
					});
		}
		return jTransformWithXMLDataMenuItem;
	}

	/**
	 * This method initializes jDefaultValueMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJDefaultValueMenu() {
		if (jDefaultValueMenu == null) {
			jDefaultValueMenu = new JMenu();
			jDefaultValueMenu.setText("Default Value");
			jDefaultValueMenu.add(getJDeleteMenuItem());
			jDefaultValueMenu.add(getJSaveMenuItem());
		}
		return jDefaultValueMenu;
	}

	/**
	 * This method initializes jDeleteMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJDeleteMenuItem() {
		if (jDeleteMenuItem == null) {
			jDeleteMenuItem = new JMenuItem();
			jDeleteMenuItem.setText("Delete Default Value");
			jDeleteMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser XDPFileChooser = new JFileChooser();
					XDPFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template File");
					XDPFileChooser.addChoosableFileFilter(filter);
					int option = XDPFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((XDPFileChooser.getSelectedFile()!=null)?
				    	XDPFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on Data Binding Specification File: " + XDPFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	defaultValuehandler = new TemplateDefaultValueHandler(XDPFileChooser.getSelectedFile().getAbsolutePath());
				    	defaultValuehandler.SetJlistMode(jList,ListMode);
				    	defaultValuehandler.StartDeleting();
				    	jSaveMenuItem.setEnabled(true);
				    }
				    else 
				    {
				    	jTextField.setText("You canceled.");
				    }
				    
				}
			});
		}
		return jDeleteMenuItem;
	}

	/**
	 * This method initializes jSaveMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJSaveMenuItem() {
		if (jSaveMenuItem == null) {
			jSaveMenuItem = new JMenuItem();
			jSaveMenuItem.setText("SaveAs");
			jSaveMenuItem.setEnabled(false);
			jSaveMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser jTemplateChooser = new JFileChooser();
					jTemplateChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template File");
					jTemplateChooser.addChoosableFileFilter(filter);
					int option = jTemplateChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	String savePath = defaultValuehandler.SaveAs(jTemplateChooser.getSelectedFile().getAbsolutePath());
				    	if( savePath == null)
				    	{
				    		Tool.ErrorReport(jTemplateChooser.getSelectedFile().getAbsolutePath() + " Already existed! Please choose a new file!" );
				    		return;
				    	}
				    	String StatusMessage = "Currently Saved New Template File in: " + savePath;
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	SetBold(jTextField);
				    	jTextField.setText(StatusMessage);
				    	Tool.InfoReport("New Template Saved into Folder: " + savePath + " Successfully!");
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jSaveMenuItem;
	}

	/**
	 * This method initializes jEngineerSaveMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJEngineerSaveMenuItem() {
		if (jEngineerSaveMenuItem == null) {
			jEngineerSaveMenuItem = new JMenuItem();
			jEngineerSaveMenuItem.setEnabled(false);
			jEngineerSaveMenuItem.setText("Save As");
			jEngineerSaveMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser jEngineerChooser = new JFileChooser();
					jEngineerChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xml", "A1S Form Engineer Specification File");
					jEngineerChooser.addChoosableFileFilter(filter);
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						jEngineerChooser.setCurrentDirectory(curr);
					int option = jEngineerChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	folderManager.setLastOpenPath(jEngineerChooser.getSelectedFile().getParent());
				    	String savePath = EngineerTransformer.SaveAs(jEngineerChooser.getSelectedFile().getAbsolutePath());
				    	if( savePath == null)
				    	{
				    		Tool.ErrorReport(jEngineerChooser.getSelectedFile().getAbsolutePath() + " Already existed! Please choose a new file!" );
				    		return;
				    	}
				    	String StatusMessage = "Currently Saved Engineer Specification File in: " + savePath;
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	SetBold(jTextField);
				    	jTextField.setText(StatusMessage);
				    	Tool.InfoReport("Excel File Saved into Folder: " + savePath + " Successfully!");    	
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jEngineerSaveMenuItem;
	}

	/**
	 * This method initializes jHelpMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJHelpMenu() {
		if (jHelpMenu == null) {
			jHelpMenu = new JMenu("jefae");
			jHelpMenu.setText("Help");
			jHelpMenu.add(getJExcelFormatMenuItem());
		}
		return jHelpMenu;
	}

	/**
	 * This method initializes jExcelFormatMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJExcelFormatMenuItem() {
		if (jExcelFormatMenuItem == null) {
			jExcelFormatMenuItem = new JMenuItem();
			jExcelFormatMenuItem.setText("About me");
			jExcelFormatMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					Tool.InfoReport("Please Contact I042416");
				}
			});
		}
		return jExcelFormatMenuItem;
	}

	/**
	 * This method initializes jGetPathMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJGetPathMenuItem() {
		if (jGetPathMenuItem == null) {
			jGetPathMenuItem = new JMenuItem();
			jGetPathMenuItem.setText("Get Binding Path");
			jGetPathMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					Tool.InfoReport("Chooser A Template Whose Binding Path You Want to Extract!");
					jFileChooser = new JFileChooser();
					jFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
					jFileChooser.addChoosableFileFilter(filter);
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	String StatusMessage = "Currently Operationed on Template File: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	fSelectedFiles = jFileChooser.getSelectedFiles();
				    	pathExtractor = new TemplateBindingPathExtractor(jList,ListMode);
				    	pathExtractor.StartExtracting(jFileChooser.getSelectedFile().getAbsolutePath());
				    	jSaveAsTextMenuItem.setEnabled(true);
				    }
				    else 
				    {
				    	jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jGetPathMenuItem;
	}

	/**
	 * This method initializes jSaveAsTextMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJSaveAsTextMenuItem() {
		if (jSaveAsTextMenuItem == null) {
			jSaveAsTextMenuItem = new JMenuItem();
			jSaveAsTextMenuItem.setEnabled(false);
			jSaveAsTextMenuItem.setText("Save As Text File");
			jSaveAsTextMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser jEngineerChooser = new JFileChooser();
					jEngineerChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("txt", "Text File");
					jEngineerChooser.addChoosableFileFilter(filter);
					int option = jEngineerChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	System.out.println("Save Path:" + jEngineerChooser.getSelectedFile().getAbsolutePath());
				    	// add vincent's requirement here
				    	String SavedPath = pathExtractor.SaveAsText(jEngineerChooser.getSelectedFile().getAbsolutePath());
				    	Tool.InfoReport("Save As Text File: " + SavedPath + " OK!");
				    }
				    else 
				    {
				    	jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jSaveAsTextMenuItem;
	}

	/**
	 * This method initializes jMarkupMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMarkupMenu() {
		if (jMarkupMenu == null) {
			jMarkupMenu = new JMenu();
			jMarkupMenu.setText("Markup");
			jMarkupMenu.add(getJAddMarkupMenuItem());
			jMarkupMenu.add(getJSaveAsMarkupMenuItem());
			jMarkupMenu.add(getJSaveAsAnyway());
			jMarkupMenu.add(getJCheckMenuItem());
			jMarkupMenu.add(getJReturnMenuItem());
			jMarkupMenu.add(getJMassCheckMenuItem());
			jMarkupMenu.add(getJTimestamp());
			jMarkupMenu.add(getJPredefineFieldMenuItem());
		}
		return jMarkupMenu;
	}

	/**
	 * This method initializes jAddMarkupMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJAddMarkupMenuItem() {
		if (jAddMarkupMenuItem == null) {
			jAddMarkupMenuItem = new JMenuItem();
			jAddMarkupMenuItem.setText("Add");
			jAddMarkupMenuItem.setToolTipText("Select a template which is generated automatically by tool");
			jAddMarkupMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					jFileChooser = new JFileChooser();
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						jFileChooser.setCurrentDirectory(curr);
					jFileChooser.setMultiSelectionEnabled(true);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template");
					jFileChooser.addChoosableFileFilter(filter);
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	 SetBold(jTextField);
				    	 jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	 jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	 String StatusMessage = "Currently Operationed on Template File: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	 SetBold(jStatusBar);
				    	 jStatusBar.setText(StatusMessage);
				    	 fSelectedFiles = jFileChooser.getSelectedFiles();
				    	 folderManager.setLastOpenPath(fSelectedFiles[0].getParent());
				    	 jList.setCellRenderer(new ColorRenderer()); 
				    	 // 2008-06-10:reset font setting 
				    	 Font oldFont = jList.getFont();
				    	 Font newFont = new Font(oldFont.getName(),oldFont.getStyle(),12);
						 jList.setFont(newFont);
						 jList.setForeground(Color.black);
				    	 AddCustomMarkbyDeveloper(fSelectedFiles[0].getAbsolutePath());
				    	 TraverseTreeForCustomMarkup();
				    	 PrintTreeforCustomMarkup();
				    	 jSaveAsMarkupMenuItem.setEnabled(true);
				    	 jCheckMenuItem.setEnabled(true);
				    	 jReturnMenuItem.setEnabled(false);
				    	 jSaveAsAnyway.setEnabled(false);
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jAddMarkupMenuItem;
	}

	/**
	 * This method initializes jSaveAsMarkupMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJSaveAsMarkupMenuItem() {
		if (jSaveAsMarkupMenuItem == null) {
			jSaveAsMarkupMenuItem = new JMenuItem();
			jSaveAsMarkupMenuItem.setText("Save As");
			jSaveAsMarkupMenuItem.setEnabled(false);
			jSaveAsMarkupMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser jTemplateChooser = new JFileChooser();
					jTemplateChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template File");
					jTemplateChooser.addChoosableFileFilter(filter);
					int option = jTemplateChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	String savePath = markupUI.SaveAs(jTemplateChooser.getSelectedFile().getAbsolutePath());
				    	System.out.println("save: " + savePath);
				    	if( savePath == null)
				    	{
				    		Tool.ErrorReport(jTemplateChooser.getSelectedFile().getAbsolutePath() + " Already existed! Please choose a new file!" );
				    		return;
				    	}
				    	else if ( savePath.equals(markupUI.getInvalidCopyFlag()))
				    	{
				    		SaveVerification.AddErrorTimes();
				    		if( SaveVerification.canSave())
				    		{
				    			// enable save as anyaway now
				    			jSaveAsAnyway.setEnabled(true);
				    			SaveVerification.reSet();
				    		}
				    		return;
				    	}
				    	String StatusMessage = "Currently Saved New Template File in: " + savePath;
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	SetBold(jTextField);
				    	jTextField.setText(StatusMessage);
				    	Tool.InfoReport("New Template Saved into Folder: " + savePath + " Successfully!");
				    	SaveVerification.reSet();
				    	jSaveAsMarkupMenuItem.setEnabled(false);
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jSaveAsMarkupMenuItem;
	}

	/**
	 * This method initializes FMT	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getFMT() {
		if (FMT == null) {
			FMT = new JMenu();
			FMT.setText("FMT");
			FMT.add(getJMenuItem1());
		}
		return FMT;
	}

	/**
	 * This method initializes jMenuItem1	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem1() {
		if (jMenuItem1 == null) {
			jMenuItem1 = new JMenuItem();
			jMenuItem1.setText("View Message Type Structure");
			jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser XSDFileChooser = new JFileChooser();
					XSDFileChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xsd", "Form Message Type Schema File");
					XSDFileChooser.addChoosableFileFilter(filter);
					int option =XSDFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	SetBold(jTextField);
				    	jTextField.setText("" + ((XSDFileChooser.getSelectedFile()!=null)?
				    	XSDFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	folderManager.setLastOpenPath(XSDFileChooser.getSelectedFile().getParent());
				    	String StatusMessage = "Currently Operationed on Form Message Type Schema File: " + XSDFileChooser.getSelectedFile().getAbsolutePath();
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	parser = new SchemaParser();
						if ( !parser.StartParse(XSDFileChooser.getSelectedFile().getAbsolutePath()) )
						{
							Tool.ErrorReport("Can not Display Message Type Structure! Error Message: " + parser.getErrorMessage());
							return;
						}
						jTree.setModel(parser.getModel());
						jTree.setVisible(true);
				    }
				    else 
				    {
				    	jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jMenuItem1;
	}

	/**
	 * This method initializes jCheckMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJCheckMenuItem() {
		if (jCheckMenuItem == null) {
			jCheckMenuItem = new JMenuItem();
			jCheckMenuItem.setText("Overview");
			jCheckMenuItem.setToolTipText("Display Mode: Check whether all the EFE nodes are maintained correctly");
			jCheckMenuItem.setEnabled(false);
			jCheckMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					workModel = MARKUP_CHECK;
					ListMode.clear();
					checker = new EFEchecker(markupUI.getDescription(),
							markupUI.GetRootNode(),jTree,ListMode,jList);
					checker.done();
					Font oldFont = jList.getFont();
					Font newFont = new Font(oldFont.getName(),oldFont.getStyle(),22);
					jList.setFont(newFont);
					jReturnMenuItem.setEnabled(true);
					jSaveAsMarkupMenuItem.setEnabled(true);
				}
			});
		}
		return jCheckMenuItem;
	}

	/**
	 * This method initializes jReturnMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJReturnMenuItem() {
		if (jReturnMenuItem == null) {
			jReturnMenuItem = new JMenuItem();
			jReturnMenuItem.setText("Return");
			jReturnMenuItem.setToolTipText("Return to Edit Mode");
			jReturnMenuItem.setEnabled(false);
			jReturnMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					workModel = MARKUP_ADD;
					// revert to old font
					Font oldFont = jList.getFont();
					Font newFont = new Font(oldFont.getName(),oldFont.getStyle(),12);
					jList.setFont(newFont);
					markupUI.display();
					// add 2008-08-21 Resolve the issue in tracking list 152
					jSaveAsMarkupMenuItem.setEnabled(true);
				}
			});
		}
		return jReturnMenuItem;
	}

	/**
	 * This method initializes jSaveAsAnyway	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJSaveAsAnyway() {
		if (jSaveAsAnyway == null) {
			jSaveAsAnyway = new JMenuItem();
			jSaveAsAnyway.setText("Save Anyway");
			jSaveAsAnyway.setEnabled(false);
			jSaveAsAnyway.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JFileChooser jTemplateChooser = new JFileChooser();
					jTemplateChooser.setMultiSelectionEnabled(false);
					ExampleFileFilter filter = new ExampleFileFilter("xdp", "A1S Form Template File");
					jTemplateChooser.addChoosableFileFilter(filter);
					int option = jTemplateChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	String savePath = markupUI.SaveAsAnyway(jTemplateChooser.getSelectedFile().getAbsolutePath());
				    	System.out.println("save: " + savePath);
				    	if( savePath == null)
				    	{
				    		Tool.ErrorReport(jTemplateChooser.getSelectedFile().getAbsolutePath() + " Already existed! Please choose a new file!" );
				    		return;
				    	}
				    	else if ( savePath.equals(markupUI.getInvalidCopyFlag()))
				    	{
				    		return;
				    	}
				    	String StatusMessage = "Currently Saved New Template File in: " + savePath;
				    	SetBold(jStatusBar);
				    	jStatusBar.setText(StatusMessage);
				    	SetBold(jTextField);
				    	jTextField.setText(StatusMessage);
				    	Tool.InfoReport("New Template Saved into Folder: " + savePath + " Successfully!");
				    	SaveVerification.reSet();
				    	jSaveAsMarkupMenuItem.setEnabled(false);
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jSaveAsAnyway;
	}

	/**
	 * This method initializes jMassCheckMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMassCheckMenuItem() {
		if (jMassCheckMenuItem == null) {
			jMassCheckMenuItem = new JMenuItem();
			jMassCheckMenuItem.setText("Mass Check");
			jMassCheckMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					jFileChooser = new JFileChooser();
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						jFileChooser.setCurrentDirectory(curr);
					jFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	 SetBold(jTextField);
				    	 jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	 jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	 String StatusMessage = "Mass Check on Folder: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	 SetBold(jStatusBar);
				    	 jStatusBar.setText(StatusMessage);
				    	 fSelectedFiles = new File[1];
			    		 fSelectedFiles[0]= jFileChooser.getSelectedFile();
				    	 /*Font oldFont = jList.getFont();
				    	 Font newFont = new Font(oldFont.getName(),oldFont.getStyle(),12);
						 jList.setFont(newFont);*/
			    		 // add 2008-09-11: must clear the tree before mass check
			    		 DoMainFrameClear();
						 Tool.createLog(fSelectedFiles[0].getAbsolutePath());
						 MassCheckerInitiator massCheckerInitiator = new MassCheckerInitiator(ListMode,jList);
						 massCheckerInitiator.AssginTask(fSelectedFiles);
						 InitializeProgressBarWithEFEMassCheckOperation(30);
						 massCheckerInitiator.run();
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jMassCheckMenuItem;
	}

	/**
	 * This method initializes jTimestamp	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJTimestamp() {
		if (jTimestamp == null) {
			jTimestamp = new JMenuItem();
			jTimestamp.setText("Get Time Stamp");
			jTimestamp.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					jFileChooser = new JFileChooser();
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						jFileChooser.setCurrentDirectory(curr);
					jFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	 SetBold(jTextField);
				    	 jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	 jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	 String StatusMessage = "Mass Check on Folder: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	 SetBold(jStatusBar);
				    	 jStatusBar.setText(StatusMessage);
				    	 fSelectedFiles = new File[1];
			    		 fSelectedFiles[0]= jFileChooser.getSelectedFile();
				    	 /*Font oldFont = jList.getFont();
				    	 Font newFont = new Font(oldFont.getName(),oldFont.getStyle(),12);
						 jList.setFont(newFont);*/
			    		 // add 2008-09-11: must clear the tree before mass check
			    		 DoMainFrameClear();
						 //Tool.createLog(fSelectedFiles[0].getAbsolutePath());
						 MassCheckerInitiator massCheckerInitiator = new MassCheckerInitiator(ListMode,jList);
						 massCheckerInitiator.AssginTask(fSelectedFiles);
						 massCheckerInitiator.fetchTimeStamp();
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
				}
			});
		}
		return jTimestamp;
	}

	/**
	 * This method initializes jPredefineFieldMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJPredefineFieldMenuItem() {
		if (jPredefineFieldMenuItem == null) {
			jPredefineFieldMenuItem = new JMenuItem();
			jPredefineFieldMenuItem.setText("Extract Predefine Field");
			jPredefineFieldMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					jFileChooser = new JFileChooser();
					File curr = folderManager.getCurrentFolder();
					if( curr != null)
						jFileChooser.setCurrentDirectory(curr);
					jFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					int option = jFileChooser.showOpenDialog(null);
				    if (option == JFileChooser.APPROVE_OPTION) 
				    {
				    	 SetBold(jTextField);
				    	 jTextField.setText("" + ((jFileChooser.getSelectedFile()!=null)?
				    	 jFileChooser.getSelectedFile().getAbsolutePath():"Nothing"));
				    	 String StatusMessage = "PredefineExtension Field Search on Folder: " + jFileChooser.getSelectedFile().getAbsolutePath();
				    	 SetBold(jStatusBar);
				    	 jStatusBar.setText(StatusMessage);
				    	 fSelectedFiles = new File[1];
			    		 fSelectedFiles[0]= jFileChooser.getSelectedFile();
			    		 extensionExtactor = new PredefineFieldWrapper(fSelectedFiles,jList,ListMode);
			    		 extensionExtactor.StartExtract();
						 
				    }
				    else 
				    {
				    	 jTextField.setText("You canceled.");
				    }
					
				}
			});
		}
		return jPredefineFieldMenuItem;
	}

	public static void main(String[] args) 
	{
		SwingUtilities.invokeLater(new Runnable() {
			public void run() 
			{
				//ChangeAppearance();
				MainFrame thisClass = new MainFrame();	
				thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				thisClass.setVisible(true);
		        //PopupFactory.setSharedInstance(new ScrollablePopupFactory(true, true));
			}
		});
	}

	/**
	 * This is the default constructor
	 */
	public MainFrame() 
	{
		super();

		initialize();
		/*String currentVersion = versionController.getCurrentVersion(this.getTitle());
		if( !versionController.checkVersion(currentVersion))
			Tool.stopApplication();*/
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(850, 489);
		this.setTitle("Form Automatic Adaptation Tool (Beta Version 2.4O)");
		this.setJMenuBar(getJJMenuBar());
		this.setMinimumSize(new Dimension(469, 166));
		this.setPreferredSize(new Dimension(800, 600));
		this.setContentPane(getJContentPane());
		RecentFile = new ArrayList<String>();
		HeaderNameList = new Vector<String>();
		deleteMenuItem = new JMenuItem();
		exchangeMenuItem = new JMenuItem();
		changeCaptionMenuItem = new JMenuItem();
		fontMenuItem = new JMenuItem();
		jDetailViewMenuItem = new JMenuItem();
		folderManager = new FileDireManager();
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.setPreferredSize(new Dimension(600, 180));
			jContentPane.add(getJPanel(), BorderLayout.NORTH);
			jContentPane.add(getJStatusPanel(), BorderLayout.SOUTH);
			jContentPane.add(getJSplitPane(), BorderLayout.CENTER);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="7,7"
