package utilities;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import configuration.ConfigDom;
import configuration.CustomMarkupConfigDom;
import customMarkupForAFC.EFEMassCheck.MassCheckLog;

public class Tool
{
	static private boolean SilentMode = false;
	
	static public void ErrorReport(String Message)
	{
		if( SilentMode)
			return;
		JOptionPane.showMessageDialog(new JFrame(), Message, "ERROR",
		        JOptionPane.ERROR_MESSAGE);
	}
	static public void ResetSwitch()
	{
		SilentMode = false;
	}
	
	static public void TurnOnSilentMode()
	{
		SilentMode = true;
	}
	static public boolean isBarCode(Node node)
	{
		Node ui = getNodebyRoot("ui",node);
		if( ui == null)
			return false;
		Node barcode = getNodebyRoot("barcode",ui);
		if( barcode == null)
			return false;
		return true;
	}
	static public String getAttributeValue(String AttrName,Node node)
	{
		if( node.getAttributes() == null)
			return null;
		if( node.getAttributes().getNamedItem(AttrName) == null)
			return null;
		return node.getAttributes().getNamedItem(AttrName).getNodeValue();
	}
	static public float getFloatingValue(String heightValue)
	{
		int index = heightValue.indexOf('m');
		if( index == -1)
		{
			index = heightValue.indexOf('i');
			if( index == -1)
				return index;
			String FloatValue = heightValue.substring(0,index);
			return (float) (Float.parseFloat(FloatValue) * 25.4);
		}
		String Height = heightValue.substring(0,index);
		return Float.parseFloat(Height);
	}
	
	static public Element createSeperatorElement(Node parent)
	{
		Document doc = parent.getOwnerDocument();
		Element p = doc.createElement("p");
		Attr style = doc.createAttribute("style");
		style.setNodeValue("text-decoration:none");
		p.setAttributeNode(style);
		
		Element span = doc.createElement("span");
		Attr spanStyle = doc.createAttribute("style");
		spanStyle.setNodeValue("xfa-spacerun:yes");
		span.setAttributeNode(spanStyle);
		span.setTextContent(" ");
		p.appendChild(span);
		p.setTextContent(" ");
		return p;
	}
	static public Element createInputElement(Node parent)
	{
		Document doc = parent.getOwnerDocument();
		Element p = doc.createElement("p");
		Attr style = doc.createAttribute("style");
		style.setNodeValue("text-decoration:none");
		p.setAttributeNode(style);
		p.setTextContent(" ");
		return p;
	}
	static public int getItemCustomMarkupType(Node node)
	{
		int invalid = CustomMarkupConfigDom.INVALID_TYPE;
		Node sapa1s = getNodebyRoot(CustomMarkupConfigDom.getCustomNodeName(),node);
		if( sapa1s == null)
			return invalid;
		Node sub = getNodebyRoot(CustomMarkupConfigDom.getInfoBlockItemNodeName(),sapa1s);
		if( sub != null)
			return CustomMarkupConfigDom.INFOBLOCK_FIELD;
		sub = getNodebyRoot(CustomMarkupConfigDom.getFreeTextItem(),sapa1s);
		if( sub != null)
			return CustomMarkupConfigDom.FREEBLOCK_FIELD;
		sub = getNodebyRoot(CustomMarkupConfigDom.getTableHeaderNodeName(),sapa1s);
		if( sub != null)
			return CustomMarkupConfigDom.TABLE_HEADER_FIELD;
		sub = getNodebyRoot(CustomMarkupConfigDom.getTableRemarkFieldName(),sapa1s);
		if( sub != null)
			return CustomMarkupConfigDom.REMARK_FIELD;
		sub = getNodebyRoot(CustomMarkupConfigDom.getSummaryLabelName(),sapa1s);
		if( sub != null)
			return CustomMarkupConfigDom.SUMM_LABEL;
		return invalid;
	}
	// just for debug
	static public void stopApplication()
	{
		System.exit(0);
	}
	static public boolean CheckInputXDPFileExistence(String filename)
	{
		File ForChecking = new File(filename);
		return ForChecking.exists();
	}
	
	static public Node getNodebyRoot(String subNodeName,Node root)
	{
		if( root == null)
			return root;
		NodeList child = root.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals(subNodeName))
				return item;
		}
		return null;
	}
	static public void writeLog(String error,int errorType )
	{
		try {
			MassCheckLog.WriteToLogFile(error,errorType);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	static public String getHierarchy(Node node)
	{
		Node anchor = node.getParentNode();
		String temp = getAttributeValue("name",node);
		String name = null;
		while ( anchor != null )
		{
			name = getAttributeValue("name", anchor);
			if( name == "null" || name == null )
				return temp;
			temp = name	+ "." + temp;
			anchor = anchor.getParentNode();
		}
		return temp;
	}
	// 2008-10-10 raised by Bille: Decimal,numeric and Date field needn't set 
	// allow multiple lines
	static public boolean isDateField(Node node)
	{
		Node ui = Tool.getNodebyRoot("ui",node);
		if( ui == null)
			return false;
		Node dateTimeEdit = Tool.getNodebyRoot("dateTimeEdit", ui);
		if( dateTimeEdit == null)
			return false;
		return true;
	}
	static public boolean isNumericField(Node node)
	{
		Node ui = Tool.getNodebyRoot("ui",node);
		if( ui == null)
			return false;
		Node numericEdit = Tool.getNodebyRoot("numericEdit", ui);
		if( numericEdit == null)
			return false;
		return true;
	}
	static public void TurnOnCountMode()
	{
		MassCheckLog.TurnOnCountMode();
	}
	static public void TurnOffCountMode()
	{
		MassCheckLog.TurnOffCountMode();
	}
	static public void newLine()
	{
		String line = "____________________________________________________________________________";
		MassCheckLog.TurnOffCountMode();
		writeLog(line,999);
		MassCheckLog.TurnOnCountMode();
	}
	static public void createLog(String path)
	{
		try {
			MassCheckLog.createLog(path);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	static public void closeLog()
	{
		MassCheckLog.CloseFile();
	}
	static public String getCurrentLocalTime()
	{
		Calendar cal = Calendar.getInstance(); 
		return cal.getTime().toString();
	}
	static public boolean NodehasID(Node node)
	{
		// 2008-09-18 For draw, we don't think it must have an ID, so directly return
		if( node.getNodeName().equals("draw"))
			return true;
		if( node.getAttributes() == null)
			return false;
		if( node.getAttributes().getNamedItem("id") == null)
			return false;
		if( node.getAttributes().getNamedItem("id").getNodeValue() == null)
			return false;
		return true;
	}

	static public boolean hasDuplicateID(Vector<String> input)
	{
		if( input.isEmpty())
			return false;
		int size = input.size();
		if( size == 1)
			return false;
		String left = null;
		String right = null;
		for( int i = 0 ; i < size;i++)
		{
			for( int j = i + 1 ; j < size;j++)
			{
				left = input.elementAt(i);
				right = input.elementAt(j);
				if( left.equals(right))
					return true;
			}
		}
		return false;
	}
	
	/* add 2008-10-10 to align with Sai, currently only draw with exData
	 * is accepted for free text block
	 */
	static public boolean isExDataExist(Node node)
	{
		if( !node.getNodeName().equals("draw"))
			// do not check other type than draw
			return true;
		Node value = getNodebyRoot("value",node);
		if( value == null)
			return false;
		Node exData = getNodebyRoot("exData",value);
		if( exData == null)
			return false;
		return true;
	}
	static public String condense(String description)
	{
		String n = description.trim();
		n = n.replace(' ','#');
		String[] col = n.split("#");
		String result = "";
		for ( int i = 0 ; i < col.length; i++)
		{
			if( col[i].length() != 0)
				result += col[i];
		}
		return result;
	}
	static public boolean isFieldHidden(Node node)
	{
		if( node.getAttributes() == null )
			return false;
		if( node.getAttributes().getNamedItem("presence") == null)
			return false;
		if( node.getAttributes().getNamedItem("presence").getNodeValue().equals("hidden"))
			return true;
		return false;
	}

	static public boolean isFieldReadOnly(Node node,boolean silentMode)
	{
		// in case that wrong type of node has called this method!
		if( node.getNodeName().equals("field") == false)
			return true;
		String name = getAttributeValue("name",node);
		if( name == null)
			name = "unTitledField";
		if( node.getAttributes().getNamedItem(ConfigDom.getFieldAccessAtributeName()) == null)
		{
			if( !silentMode)
				Tool.ErrorReport("Field: " + name + " Must Be Set to \"ReadOnly\"");
			return false;
		}
		String setting = node.getAttributes().getNamedItem(ConfigDom.getFieldAccessAtributeName()).getNodeValue();
		if( setting == null)
		{
			if( !silentMode)
				Tool.ErrorReport("Field: " + name + " Must Be Set to \"ReadOnly\"");
			return false;
		}
		if( !setting.equals(ConfigDom.getFieldAccessReadOnly()))
		{
			if( !silentMode)
				Tool.ErrorReport("Field: " + name + " Must Be Set to \"ReadOnly\"");
			return false;
		}
		return true;
	}
	static public void PrintErrorMessage(String Message)
	{
		System.out.println("Error:" + Message);
		System.exit(0);
	}
	
	static public void InfoReport(String Message)
	{
	    JOptionPane.showMessageDialog(new JFrame(), Message, "INFO MESSAGE",
	        JOptionPane.INFORMATION_MESSAGE);
	}
	
	static public int Chooser(String Message)
	{
	    return JOptionPane.showConfirmDialog(new JFrame(), Message, "INFO MESSAGE", JOptionPane.YES_NO_OPTION);
	}
	static public boolean isSingleA1SNode(Node node)
	{
		String name = getAttributeValue("name",node);
		if( name == null)
			name = "DefaultNodeName";
		if( CustomMarkupConfigDom.checkDuplicateA1SNode == false)
			return true;
		int totalA1SNodeNum = getA1SNodeNumber(node);
		if( totalA1SNodeNum > 1)
		{
			ErrorReport("The Node: " + name + " Has Duplicate sapa1s Node,Total Number: " + totalA1SNodeNum);
			return false;
		}
		return true;
	}
	static public boolean DoesPossibleFieldsHaveA1SNode(Node node)
	{
		if( node.getNodeName().equals("draw"))
			return true;
		String name = getAttributeValue("name",node);
		if( name == null)
			name = "DefaultNodeName";
		int totalA1SNodeNum = getA1SNodeNumber(node);
		if( totalA1SNodeNum == 0)
		{
			String error = "The Node: " + name + " Has No A1SNode !\n";
			error += "You Need to Run Convertion Tool Once Again to Add it!";
			ErrorReport(error);
			return false;
		}
		return true;
	}
	static public boolean isValidTemplate(String inputXDPName)
	{
		int index = inputXDPName.lastIndexOf('.');
		String extName = inputXDPName.substring(++index, inputXDPName.length());
		//System.out.println("Ext Name: " + extName);
		if( extName.equalsIgnoreCase("xdp"))
			return true;
		return false;
	}
	static public boolean hasA1SNode(Node node)
	{
		String name = getAttributeValue("name",node);
		if( name == null)
			name = "DefaultNodeName";
		int totalA1SNodeNum = getA1SNodeNumber(node);
		if( totalA1SNodeNum == 0)
		{
			if( isFieldHidden(node))
				return false;
			String error = "The Node: " + name + " Has No A1SNode !\n";
			error += "You Need to Run Convertion Tool Once Again to Add it!";
			ErrorReport(error);
			return false;
		}
		return true;
	}
	static public int getA1SNodeNumber(Node node)
	{
		String name = getAttributeValue("name",node);
		if( name == null)
			name = "DefaultNodeName";
		int totalA1SNodeNum = 0;
		NodeList children = node.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals(CustomMarkupConfigDom.getCustomNodeName()))
				totalA1SNodeNum++;
		}
		return totalA1SNodeNum;
	}
	
	static public boolean isA1SNodeAlreadyExist(Node node)
	{
		/* change on 2008-9-3: resue method of Tool ultilities
		 * 
		 */
		int number = getA1SNodeNumber(node);
		return (number > 0)?true:false;
	}

	// 2008-08-29 add check for page fields according to Bille
	static public boolean checkPageFieldExist(Node node)
	{
		String name = getAttributeValue("name", node);
		if( name == null)
			return false;
		name = name.toLowerCase();
		if( name.contains("page"))
			return true;
		Node value = getNodebyRoot("value",node);
		if( value == null)
			return false;
		Node text = getNodebyRoot("text",value);
		if( text != null)
		{
			String textvalue = text.getTextContent();
			if( textvalue == null)
				return false;
			textvalue = textvalue.toLowerCase();
			if( textvalue.contains("page"))
				return true;
			return false;
		}
		Node exData = getNodebyRoot("exData",value);
		if( exData == null)
			return false;
		Node body = getNodebyRoot("body",exData);
		if( body == null)
			return false;
		String bodyvalue = getCompleteValue(body);
		bodyvalue = bodyvalue.toLowerCase();
		if( bodyvalue.contains("page"))
			return true;
		return false;
	}
	static private String getCompleteValue(Node body)
	{
		if( body == null)
			return null;
		NodeList children = body.getChildNodes();
		int length = children.getLength();
		Node item = null;
		String value = "";
		for( int i = 0 ; i < length; i++)
		{
			item = children.item(i);
			if( !item.getNodeName().equals("p"))
				continue;
			value += item.getTextContent();
		}
		return value;
	}
    //	 Add 2009-01-19 suggested by Arnold
	static public String getTableCaptionasDescription(Node node)
	{
		Node value = null;
		Node text = null;
		Node exData = null;
		Node body = null;
		if( node.getNodeName().equals("field"))
		{
			value = Tool.getNodebyRoot("value",node);
			if( value == null)
				return null;
			text = Tool.getNodebyRoot("text", value);
			if( text == null)
				return null;
			return text.getTextContent();
		}
		else if ( node.getNodeName().equals("draw"))
		{
			value = Tool.getNodebyRoot("value",node);
			if( value == null)
				return null;
			text = Tool.getNodebyRoot("text", value);
			if( text == null)
			{
				exData = Tool.getNodebyRoot("exData", text);
				if ( exData == null)
					return null;
				body = Tool.getNodebyRoot("body", exData);
				return Tool.getCompleteValue(body);
			}
			return text.getTextContent();
		}
		return null;
	}
}