package utilities;

import java.io.*;

public class FileLogFactory 
{
	private String FileName;
	BufferedWriter bw;
	public FileLogFactory(String xdpFileName) throws IOException 
	{
		int pointindex = xdpFileName.lastIndexOf('.');
		if( pointindex == -1)
		{
			Tool.ErrorReport("You should input a file whose name ends up with .XDP");
		}
		else
		{
			String LogOutput = xdpFileName.substring(0,pointindex);
			LogOutput += ".html";
			FileName = LogOutput;
			bw = new BufferedWriter(new FileWriter(FileName));
			System.out.println("Log file: " + FileName);
		}
	}
	
	public  void WriteToLogFile(String data) throws IOException
	{  
		data = "<p>" + data + "</p>";
	    bw.write(data);
	    bw.flush();
	    //System.out.println("Want to write to log:" + data);
	}
	
	public void CloseFile()
	{
		try {
			bw.flush();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}