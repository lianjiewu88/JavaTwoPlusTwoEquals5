package utilities;

import java.io.File;

public class FileDireManager
{
	private String currentPath = null;
	public File getCurrentFolder()
	{
		if( currentPath == null)
			return null;
		return new File(currentPath);
	}
	public void setLastOpenPath(String path)
	{
		currentPath = path;
	}
}