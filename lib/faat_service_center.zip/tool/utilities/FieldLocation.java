package utilities;

import configuration.ConfigDom;

public class FieldLocation
{
	static public final int DEFAULT_SUBFORM = 0;
	static public final int HIDDEN_SUBFORM = 1;
	static public final int INFO_BLOCK = 2;
	static public final int FREE_TEXT_BLOCK = 3;
	static public final int SUMMARY_BLOCK = 4;
	static public final int REMARK_ROW = 5;
	static public final int TABLE_OUTER_SUBFORM = 6;
	static public final int TABLE_HEADER_SUBFORM = 7;
	static public final int TABLE_CONTENT_SUBFORM = 8;
	static public final int BODY_PAGE = 9;
	static public final int ADDRESS_BLOCK = 10;
	static public final int MASTER_PAGE = 11;
	static public final int FORM_TITLE = 12;
	static public final int FORM_LOGO = 13;
	static public final int FORM_SEPERATOR = 14;
	static public final int SENDER_ADDRESS_PLACE_HOLDER = 15;
	static public final int FOOTER_BLOCK = 16;
	static public final int PAGE_INDEX = 17;
	static public final int CONNECTION_SET = 18;
	static public final int TEMPLATE_DOM = 19;
	static public String getLocationDescription(int type)
	{
		String location = null;
		switch ( type)
		{
			case DEFAULT_SUBFORM:
				location = "DEFAULT SUBFORM";
				break;
			case INFO_BLOCK:
				location = "INFO BLOCK";
				break;
			case FREE_TEXT_BLOCK:
				location = "FREE TEXT BLOCK";
				break;
			case SUMMARY_BLOCK:
				location = "SUMMARY BLOCK";
				break;
			case REMARK_ROW:
				location = "REMARK ROW";
				break;
			case TABLE_OUTER_SUBFORM:
				location = "TABLE OUTER SUBFORM";
				break;
			case TABLE_HEADER_SUBFORM:
				location = "TABLE HEADER SUBFORM";
				break;
			case TABLE_CONTENT_SUBFORM:
				location = "TABLE CONTENT SUBFORM";
				break;
			case BODY_PAGE:
				location = "BODY PAGE";
				break;
			case ADDRESS_BLOCK:
				location = "ADDRESS_BLOCK";
				break;
			case MASTER_PAGE:
				location = "MASTER PAGE";
				break;
			case FORM_TITLE:
				location = "FORM TITLE";
				break;
			case FORM_LOGO:
				location = "FORM LOGO";
				break;
			case FORM_SEPERATOR:
				location = "FORM SEPERATOR";
				break;
			case SENDER_ADDRESS_PLACE_HOLDER:
				location = "SENDER ADDRESS PLACE HOLDER";
				break;
			case FOOTER_BLOCK:
				location = "FOOTER BLOCK";
				break;
			case PAGE_INDEX:
				location = "PAGE INDEX";
				break;
			case CONNECTION_SET:
				location = "CONNECTION SET";
				break;
			case TEMPLATE_DOM:
				location = "TEMPLATE DOM";
				break;
			default:
				location = "UNKNOWN LOCATION";
		}
		return location;
	}
	static private int getSubformType(String subformName)
	{
		if( subformName.length() < 7 )
		{
			//Tool.ErrorReport("The Subform: " + subformName + " should have at least 7 CHARS");
			return DEFAULT_SUBFORM;
		}
		// 2008-08-18 add handlement with frmfloatfields
		if( subformName.equalsIgnoreCase(ConfigDom.getHiddenSubformNamingConvention()))
		{
			return HIDDEN_SUBFORM;
		}
		String StartString = subformName.substring(0, 7);
		if (StartString.equalsIgnoreCase(ConfigDom.getInfoblockNamingConvention())) 
		{
			return INFO_BLOCK;
		} 
		else if ( StartString.equalsIgnoreCase(ConfigDom.getAddressblockNamingConvention()))
		{
			return ADDRESS_BLOCK;
		}
		else if (StartString.equalsIgnoreCase(ConfigDom.getFreeblockNamingConvention())) 
		{
			return FREE_TEXT_BLOCK;
		} 
		else if (StartString.equalsIgnoreCase(ConfigDom.getSummaryBlockNamingConvention()))
		{
			return SUMMARY_BLOCK;
		} 
		else if ( subformName.toLowerCase().contains(ConfigDom.getRemarkRowNamingConvention()))
		{
			return REMARK_ROW;
		}
		return DEFAULT_SUBFORM;
	}
	static public int getSubformLocation(String SubformName) 
	{
		if( SubformName == null)
			return DEFAULT_SUBFORM;
		if( SubformName.length() < 3)
			return DEFAULT_SUBFORM;
		// 2008-09-12: must deal with the situation that SubformName is null or less than 3 char
		String StartingString = SubformName.substring(0, 3);
		if (StartingString.equalsIgnoreCase(ConfigDom.getSubformNamingConvention()))
		// should catalog furtherly
			return getSubformType(SubformName);
		else if (StartingString.equalsIgnoreCase(ConfigDom.getTableNamingConvention())) 
		{
			if( SubformName.contains("A1SFC_FooterBlock"))
				return FOOTER_BLOCK;
			else
				return TABLE_OUTER_SUBFORM;
		} 
		else if (StartingString.equalsIgnoreCase(ConfigDom.getTableHeaderNamingConvention())) 
		{
			return TABLE_HEADER_SUBFORM;
		} 
		else if (StartingString.equalsIgnoreCase(ConfigDom.getTableRowNamingConvention())) 
		{
			return TABLE_CONTENT_SUBFORM;
		} 
		else if ( StartingString.equalsIgnoreCase(ConfigDom.getBodyPageNamingConvention()))
		{
			return BODY_PAGE;
		}
		return DEFAULT_SUBFORM;
	}
}