package utilities;

import org.w3c.dom.Node;
import configuration.ConfigDom;
public class FieldMappingChecker
{
	static private Node node = null;
	static public void init(Node task)
	{
		node = task;
	}
	static public int check()
	{
		if( !node.getNodeName().equals("field"))
			return ConfigDom.MAPPING_OK;
		Node bind = Tool.getNodebyRoot("bind", node);
		if( bind == null)
			return ConfigDom.NO_MAPPING;
		String ref = Tool.getAttributeValue("ref",bind);
		if( ref == null)
			return ConfigDom.NO_MAPPING;
		return checkRelativeMap(ref);
	}
	static private int check(Node subform)
	{
		Node bind = Tool.getNodebyRoot("bind", subform);
		if( bind == null)
			return ConfigDom.NO_MAPPING;
		String ref = Tool.getAttributeValue("ref",bind);
		if( ref == null)
			return ConfigDom.NO_MAPPING;
		return ConfigDom.MAPPING_OK;
	}
	static private boolean isRelativeMap(String ref)
	{
		if ( !ref.contains("$record"))
			return true;
		return false;
	}
	static private int checkRelativeMap(String ref)
	{
		if( isRelativeMap(ref) == false)
			return ConfigDom.MAPPING_OK;
		Node parent = node.getParentNode();
		/* only if parent subform has mapping can this relative mapping is valid */
		if( check(parent) == ConfigDom.MAPPING_OK)
			return ConfigDom.MAPPING_OK;
		// parent does not have mapping,so child mustn't use relative mapping!
		return ConfigDom.INVALID_RELATIVE_MAPPING;
	}
}