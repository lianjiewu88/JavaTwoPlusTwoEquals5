package utilities;

import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JList;

public class DisplayTool
{
	static private DefaultListModel ListMode = null;
	static private JList jList = null;
	static private int count = 1;
	static private boolean count_mode = false;
	
	static public void init(DefaultListModel mode,JList list)
	{
		ListMode = mode;
		jList = list;
		ListMode.clear();
		jList.setModel(ListMode);
	}
	static public void display(String item)
	{
		String data = null;
		if( count_mode )
			data = "(" + count++ + ") " + item;
		else
		{
			count = 1;
			data = item;
		}
		ListMode.addElement(data);
	}
	static public void TurnOnCountMode()
	{
		count_mode = true;
	}
	static public void TurnOffCountMode()
	{
		count_mode = false;
	}
	static public void newLine()
	{
		String line = "____________________________________________________________________________";
		ListMode.addElement(line);
	}
	static public void setFont(int size) 
	{
		Font oldFont = jList.getFont();
		Font newFont = new Font(oldFont.getName(),oldFont.getStyle(),size);
		jList.setFont(newFont);
	}
}