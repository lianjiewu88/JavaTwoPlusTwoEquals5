package utilities;

import layoutTest.internalStructure.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import configuration.ConfigDom;
 



public class ColorChooser extends JFrame
{
	private Node mNode;
	private String ColorSetting;
	private int errorType = -1;
	public String GetColor()
	{
		return ColorSetting;
	}
	
	public ColorChooser (ErrorTraceObject errObj)
	{
		super("ColorChooser");
		System.out.println("ColorChooser()");
		mNode = errObj.getNode();
		errorType = errObj.ErrorType;
	    setSize(300, 200);
	    final Container contentPane = getContentPane();
	    final JButton go = new JButton("Choose the right color here");
	    setVisible(true);
	    contentPane.add(go, BorderLayout.SOUTH);
	    go.addActionListener(new ActionListener() 
	    {
	      public void actionPerformed(ActionEvent e) 
	      {
	        Color c = JColorChooser.showDialog(((Component) e.getSource())
	            .getParent(), "Demo", Color.blue);
	        contentPane.setBackground(c);
	        if( c == null)
	        	return;
	        System.out.println("Red: " + c.getRed() + " Green: " + c.getGreen() + 
	        		" Blue: " + c.getBlue());
	        ColorSetting = c.getRed() + "," + c.getGreen() + "," + c.getBlue();
	      }
	    });
	    
	    final JButton closeButton = new JButton("Close the Color Chooser");
	    closeButton.addActionListener(new ActionListener()
	    {
	    	public void actionPerformed(ActionEvent e)
	    	{
	    		setVisible(false);
	    	}
	    });
	    contentPane.add(closeButton,BorderLayout.NORTH);
	    setContentPane(contentPane);
	    //setDefaultCloseOperation(EXIT_ON_CLOSE);
	  }
	
	
	public boolean Correction()
	{
		NodeList Child = mNode.getChildNodes();
		int childLength = Child.getLength();
		Node item = null;
		for (int i = 0; i < childLength; i++) 
		{
			item = Child.item(i);
			if (item.getNodeName().equals("fill")) 
			{
				NodeList colorList = item.getChildNodes();
				Node colorItem = null;
				int colorListLength = colorList.getLength();
				for (int j = 0; j < colorListLength; j++) 
				{
					colorItem = colorList.item(j);
					if (colorItem.getNodeName().equals("color")) 
					{
						if( errorType == LayoutErrorType.FORM_TITLE_COLOR_SETTING)
							colorItem.getAttributes().getNamedItem("value").setNodeValue(ConfigDom.getFormDefaultFontColor());
					}
				}
			}
		}
		return true;
	}
}