package utilities;

import java.awt.Color;
import java.awt.Component;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;

public class ColorRenderer extends DefaultListCellRenderer
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Component getListCellRendererComponent(
			JList list,
			Object value,
			int index,
			boolean isSelected,
			boolean cellHasFocus)
	{
		super.getListCellRendererComponent(list,value,index,isSelected,cellHasFocus);;
		/*if(!isSelected)
		{
			if(index%2 == 0)
			{
				this.setBackground(Color.white);
				this.setForeground(Color.red);
			}
			else
			{	
				this.setBackground(Color.cyan);
				this.setForeground(Color.black);
			}
		}*/

		System.out.println("Desp: " + value);
		if( value == null)
			return this;
		String highLight = value.toString();
		if(highLight.contains("Acc:") || highLight.contains("Acc Setting"))
			this.setForeground(Color.orange);
		else if( highLight.contains("Access") || highLight.contains("ReadOnly") || highLight.contains("Markup Added"))
			this.setForeground(Color.green);
		else if ( highLight.contains("New Description"))
			this.setBackground(Color.green);
		else if ( highLight.contains("margin") || highLight.contains("Margin")) 
			this.setForeground(Color.red);
		else if(highLight.contains("normal binding"))
			this.setForeground(Color.magenta);
		else if ( highLight.contains("Autofit"))
			this.setForeground(Color.blue);
		else if ( highLight.contains("FLOW"))
			this.setForeground(Color.cyan);
		else if (highLight.contains("Font"))
			this.setForeground(Color.pink);
		else if (highLight.contains("Align"))
			this.setForeground(Color.darkGray);
		return this;
	}

	/*private String String(Object value) {
		// TODO Auto-generated method stub
		return null;
	}*/
}