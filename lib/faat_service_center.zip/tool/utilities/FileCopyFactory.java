package utilities;

import java.io.*;

public class FileCopyFactory 
{
	String readed = "";
	BufferedReader br;
	BufferedWriter bw;
	public void DeleteUnusedXML(String UnusedXML)
	{
		File unusedXML = new File(UnusedXML);
		unusedXML.delete();
	}
	
	public boolean CheckifXDPFile(String inputXDPFile)
	{
		int length = inputXDPFile.length();
		String ext = inputXDPFile.substring(length-3,length);
		if( !ext.equalsIgnoreCase("xdp"))
			return false;
		return true;
	}
	
	public String getFileNameExcludingExt(String wholeName)
	{
		int length = wholeName.length();
		String RegularName = wholeName.substring(0,length-4);
		//System.out.println("RegularName: " + RegularName);
		return RegularName;
		
	}
	public  String copyFile(String inputXDPFile) throws IOException
	// Absolute path,should check if it is really a xdp file
	{
		if( CheckifXDPFile(inputXDPFile) == false )
			return null;
		String XMLOutput = getFileNameExcludingExt(inputXDPFile);
		XMLOutput += ".xml";
		br = new BufferedReader(new FileReader(inputXDPFile));   
	    bw = new BufferedWriter(new FileWriter(XMLOutput));  
	    System.out.println("Begin to Copy File");  
	    File XML = new File(inputXDPFile);
	    int length = (int)XML.length();
	    char[] inputdata = new char [length];
	    br.read(inputdata,0,length);
	    String input = new String(inputdata);
	    int indexlocale = input.indexOf("<localeSet");
	    if( indexlocale == -1)
	    {
	    	// the template has no localeSet node!
	    	bw.write(inputdata);
	    	br.close();
	    	bw.close();
	    	return XMLOutput;
	    }
	    String before = input.substring(0,indexlocale);
	    int postindex = input.indexOf("</localeSet>");
	    String locale = "</localeSet>";
	    String post = input.substring(postindex + locale.length());
	    String finalString = before.concat(post);
	    System.out.println("***************************************");
	    //System.out.println(finalString);
	    bw.write(finalString);
	    br.close();
	    bw.close();   
	    System.out.println("End read File!");
	    return XMLOutput;
	}
}