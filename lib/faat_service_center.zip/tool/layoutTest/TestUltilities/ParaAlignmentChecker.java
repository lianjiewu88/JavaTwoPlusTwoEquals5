package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;

import org.w3c.dom.Node;

import utilities.FieldLocation;
import configuration.ConfigDom;

public class ParaAlignmentChecker
{
	private Node node = null;
	private String nodeName = null;
	private int type = -1;
	private ArrayList<ErrorTraceObject> reference = null;
	
	// input node: para
	public ParaAlignmentChecker(Node input,ArrayList<ErrorTraceObject> data,String Name,int Type)
	{
		node = input;
		reference = data;
		type = Type;
		nodeName = Name;
	}
	private boolean isHAlignShouldbeRight(String Name)
	{
		if( Name.length() < 3)
			return false;
		if( Name.substring(0,3).equals(ConfigDom.getDecimalNamingConvention()) || Name.substring(0,3).equals(ConfigDom.getNumericNamingConvention()))
			return true;
		return false;
	}
	public void check()
	{
		String hAlignSetting = null;
		String hAlignErr = null;
		String Location = FieldLocation.getLocationDescription(type);
		if(isHAlignShouldbeRight(nodeName))	// dec or num field,should be right!
		{
			if( node.getAttributes().getNamedItem("hAlign") != null)
			{
				hAlignSetting = node.getAttributes().getNamedItem("hAlign").getNodeValue();
				System.out.println("Right-Align setting: " + hAlignSetting);
				if( hAlignSetting.contains("right") == false)
				{
					hAlignErr = "Field:" + nodeName
					+ ".Horizontal Align Wrong: " + hAlignSetting + " Correct should be Right-Aligned";
					ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.H_ALIGN_SETTING,node,Location);
					errorObj.SetErrorMessage(hAlignErr,hAlignSetting);
					reference.add(errorObj);
				}
			}
			else // this situation is left-aligned
			{
				hAlignErr = "Field:" + nodeName
				+ ".Horizontal Align Wrong: Left-Aligned,Correct should be Right-Aligned";
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.H_ALIGN_SETTING,node,Location);
				errorObj.SetErrorMessage(hAlignErr,ConfigDom.getDefaultHorizonAlignStyle());
				reference.add(errorObj);
			}
		}
		else	// not a dec or a num
		{
			if( node.getAttributes().getNamedItem("hAlign") != null)
			{
				hAlignSetting = node.getAttributes().getNamedItem("hAlign").getNodeValue();
				hAlignErr = "Field:" + nodeName
				+ ".Horizontal Align Wrong: " + hAlignSetting + " Correct should be Left-Aligned";
				ErrorTraceObject HerrorObj = new ErrorTraceObject(LayoutErrorType.H_ALIGN_SETTING,node,Location);
				HerrorObj.SetErrorMessage(hAlignErr,hAlignErr);
				reference.add(HerrorObj);
			}
		}
		if( type != FieldLocation.TABLE_HEADER_SUBFORM && type != FieldLocation.TABLE_CONTENT_SUBFORM)
			return;
		if( node.getAttributes().getNamedItem("vAlign") != null)
		{
			String vAlignSetting = node.getAttributes().getNamedItem("vAlign").getNodeValue();
			String vAlignErr = "Field:" + nodeName
			+ ".Vertical Align Wrong: " + vAlignSetting + " Correct should be Top-Aligned";
			ErrorTraceObject VerrorObj = new ErrorTraceObject(LayoutErrorType.V_ALIGN_SETTING,node,Location);
			VerrorObj.SetErrorMessage(vAlignErr,vAlignErr);
			reference.add(VerrorObj);
		}
	}
}