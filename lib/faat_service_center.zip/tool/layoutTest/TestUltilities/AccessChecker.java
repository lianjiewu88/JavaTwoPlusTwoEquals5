package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;
import org.w3c.dom.Node;
import configuration.ConfigDom;
import utilities.FieldLocation;
import utilities.Tool;
public class AccessChecker
{
	private Node node = null;
	private String nodeName = null;
	private ArrayList<ErrorTraceObject> reference = null;
	private int fieldType;
	public AccessChecker(Node input,ArrayList<ErrorTraceObject> data,String name,int type)
	{
		node = input;
		reference = data;
		nodeName = name;
		fieldType = type;
	}
	public void check()
	{
		// 2008-09-27 regard draw as readOnly always
		String Location = FieldLocation.getLocationDescription(fieldType);
		if( node.getNodeName().equals("draw"))
		{
			if( fieldType != FieldLocation.TABLE_HEADER_SUBFORM)
				return;
			String error = "Field:" + nodeName + ".Should Use TextField Instead Of Draw,Location: " + Location;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.TABLE_HEADER_DRAW,node,Location);
			errorObj.SetErrorMessage(error,ConfigDom.getDefaultAccessMode());
			reference.add(errorObj);
			return;
		}
		String access = Tool.getAttributeValue("access",node);
		if( access != null)
		{
			if( access.equals(ConfigDom.getFieldAccessReadOnly()))
				return;
		}
		if( nodeName.equals(ConfigDom.getFormFieldLogoName()))
			return;
		if( nodeName.equals(ConfigDom.getLogoNamingConvention()))
			return;
		String Access = "Field:" + nodeName + ".Should be ReadOnly,Location: " + Location;
		ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.VALUE_TYPE_SETTING,node,Location);
		errorObj.SetErrorMessage(Access,ConfigDom.getDefaultAccessMode());
		reference.add(errorObj);
	}
}