package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utilities.FieldLocation;
import configuration.ConfigDom;
import utilities.Tool;

public class TitleChecker
{
	private Node title = null;
	private ArrayList<ErrorTraceObject> reference = null;
	public TitleChecker(Node node,ArrayList<ErrorTraceObject> resultReference)
	{
		title = node;
		reference = resultReference;
	}
	private void checkFormWidthandHeight() 
	{
		String height = null;
		String width = null;
		String Location = FieldLocation.getLocationDescription(FieldLocation.FORM_TITLE);
		String Name = title.getAttributes().getNamedItem("name").getNodeValue();
		height = Tool.getAttributeValue("h",title);
		width = Tool.getAttributeValue("w",title);
		if (height == null) 
		{
			String heightErr = "Field:" + Name + ".Form Title should not allow height auto fit";
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FORM_TITLE_AUTO_HEIGHT_FIT,title,Location);
			errorObj.SetErrorMessage(heightErr,ConfigDom.getDefaultHeightSetting());
			reference.add(errorObj);
			return;
		}
		if (width == null) 
		{
			String widthErr = "Field:" + Name + ".Form Title should not allow width auto fit";
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FORM_TITLE_AUTO_WIDTH_FIT,title,Location);
			errorObj.SetErrorMessage(widthErr,ConfigDom.getDefaultWidthSetting());
			reference.add(errorObj);
			return;
		}
		float fWidth = Tool.getFloatingValue(width);
		if ((fWidth < ConfigDom.getStandardFormTitleWidth() - 0.1 ) || (fWidth > ConfigDom.getStandardFormTitleWidth() + 0.1)) 
		{
			String widthError = "Field:" + Name + ".Form Title Width should be: " + ConfigDom.getStandardFormTitleWidth() + "mm,current Wrong Width: "
					+ fWidth;
			ErrorTraceObject errObj = new ErrorTraceObject(LayoutErrorType.FORM_TITLE_WIDTH_SETTING,title,Location);
			errObj.SetErrorMessage(widthError,null);
			reference.add(errObj);
		}
		float fHeight = Tool.getFloatingValue(height);
		if ((fHeight < ConfigDom.getStandardFormTitleHeight() - 0.1 ) || (fHeight > ConfigDom.getStandardFormTitleHeight() + 0.1)) 
		{
			String widthError = "Field:" + Name + ".Form Title Height should be: " + ConfigDom.getStandardFormTitleHeight() + "mm,current Wrong Height: "
					+ fHeight;
			ErrorTraceObject errObj = new ErrorTraceObject(LayoutErrorType.FORM_TITLE_HEIGHT_SETTING,title,Location);
			errObj.SetErrorMessage(widthError,null);
			reference.add(errObj);
		}
	}
	
	private void CheckFormTitleAcc()
	{
		String acc = LayoutTestReuseComponent.getNodeAccessibilitySetting(title);
		if ( !acc.equals(ConfigDom.getDefaultAccRightSetting())) 
		{
			String TitleAcc = "Form Title Acc Should be None,Wrong Acc: "+ acc;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.ACC_SETTING,title,FieldLocation.getLocationDescription(FieldLocation.FORM_TITLE));
			errorObj.SetErrorMessage(TitleAcc,TitleAcc);
			reference.add(errorObj);
		}
	}

	private void CheckFormPara()
	{
		// vAlign="bottom"/>
		String error = null;
		String name = Tool.getAttributeValue("name",title);
		String Location = FieldLocation.getLocationDescription(FieldLocation.FORM_TITLE);
		Node para = Tool.getNodebyRoot("para",title);
		if( para == null)
			return;
		String vAlign = Tool.getAttributeValue("vAlign",para);
		String hAlign = Tool.getAttributeValue("hAlign",para);
		if( hAlign != null)
		{
			error = "Field:" + name + ".Form Title Must be Left-Aligned in Horizon!";
			ErrorTraceObject errObj = new ErrorTraceObject(LayoutErrorType.FORM_TITLE_HEIGHT_SETTING,para,Location);
			errObj.SetErrorMessage(error,null);
			reference.add(errObj);
		}
		if( vAlign == null)
		{
			error = "Field:" + name + ".Form Title Must be Bottom-Aligned Vertically!";
			ErrorTraceObject errObj = new ErrorTraceObject(LayoutErrorType.FORM_TITLE_HEIGHT_SETTING,para,Location);
			errObj.SetErrorMessage(error,null);
			reference.add(errObj);
		}
		else if ( !vAlign.equals("bottom"))
		{
			error = "Field:" + name + ".Form Title Must be Bottom-Aligned Vertically!";
			ErrorTraceObject errObj = new ErrorTraceObject(LayoutErrorType.FORM_TITLE_HEIGHT_SETTING,para,Location);
			errObj.SetErrorMessage(error,null);
			reference.add(errObj);
		}
	}
	
	public void CheckFormTitle() 
	{
		checkFormWidthandHeight();
		CheckFormTitleAcc();
		CheckFormPara();
		NodeList child = title.getChildNodes();
		Node item = null;
		String Name = title.getAttributes().getNamedItem("name").getNodeValue();
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if (item.getNodeName().equals("font")) 
			{
				checkFormFontSetting(item,Name);
			}
		}
	}
	private void checkFormFontSetting(Node node,String FormTitle) 
	{
		String boldSetting = "regular";
		String ColorSetting = "Wrong";
		String Location = FieldLocation.getLocationDescription(FieldLocation.FORM_TITLE);
		String fontType = node.getAttributes().getNamedItem("typeface").getNodeValue();
		boolean isError = false;
		if (node.getAttributes().getNamedItem("weight") != null )
			boldSetting = node.getAttributes().getNamedItem("weight")
					.getNodeValue();
		NodeList Child = node.getChildNodes();
		Node item = null;
		int childLength = Child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = Child.item(i);
			if (item.getNodeName().equals("fill")) 
			{
				NodeList colorList = item.getChildNodes();
				Node colorItem = null;
				int colorListLength = colorList.getLength();
				for (int j = 0; j < colorListLength; j++) {
					colorItem = colorList.item(j);
					if (colorItem.getNodeName().equals("color")) 
					{
						ColorSetting = colorItem.getAttributes().getNamedItem(
								"value").getNodeValue();
					}
				}
			}
		}
		if (ColorSetting.equals(ConfigDom.getFormDefaultFontColor()) == false) 
		{
			String FontErr = "Field:" + FormTitle + ".Form Title Font should be 128,128,128,Current wrong Setting: "
					+ ColorSetting;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FORM_TITLE_COLOR_SETTING,node,Location);
			errorObj.SetErrorMessage(FontErr,ColorSetting);
			reference.add(errorObj);
		}
		if (boldSetting.equals("regular") == false) 
		{
			String FontBold = "Field:" + FormTitle + ".Font Title Font should be regular,current wrong Setting: "
					+ boldSetting;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_TYPE_SETTING,node,Location);
			errorObj.SetErrorMessage(FontBold,boldSetting);
			reference.add(errorObj);
		}
		if (fontType.equals(ConfigDom.getDefaultFontFamily()) == false) 
		{
			String FontFamily = "Field:" + FormTitle + ".Font Title Font Type should be Arial,current wrong Setting: "
					+ fontType;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_TYPE_SETTING ,node,Location);
			errorObj.SetErrorMessage(FontFamily,fontType);
			reference.add(errorObj);
		}
		String size = Tool.getAttributeValue("size", node);
		if( size == null)
			isError = true;
		else if (size.equals(ConfigDom.getFormTitleDefaultFontSize()) == false)
			isError = true;
		if( isError)
		{
			String SizeErr = "Field:" + FormTitle + ".Font Title Font Size should be 18PT!";
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_SIZE_SETTING,node,Location);
			errorObj.SetErrorMessage(SizeErr,size);
			reference.add(errorObj);
		}
	}
}