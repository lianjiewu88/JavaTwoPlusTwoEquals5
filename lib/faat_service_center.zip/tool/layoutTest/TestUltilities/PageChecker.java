package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;
import org.w3c.dom.Node;
import utilities.FieldLocation;
import utilities.Tool;

public class PageChecker
{
	private Node node = null;
	private ArrayList<ErrorTraceObject> reference = null;
	public PageChecker(Node input,ArrayList<ErrorTraceObject> resultReference)
	{
		node = input;
		reference = resultReference;
	}
	public void check()
	{
		String minH = Tool.getAttributeValue("minH", node);
		String error = null;
		String Location = FieldLocation.getLocationDescription(FieldLocation.PAGE_INDEX);
		String name = Tool.getAttributeValue("name", node);
		if( minH != null)
		{
			error = "Field:" + name + ".Page Index should not allow height expand to fit";
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.PAGE_HEIGHT_EXPAND,node,Location);
			errorObj.SetErrorMessage(error,"Height NO Expand to Fit");
			reference.add(errorObj);
		}
		String minW = Tool.getAttributeValue("minW", node);
		if( minW != null)
		{
			error = "Field:" + name + ".Page Index should not allow width expand to fit";
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.PAGE_WIDTH_EXPAND,node,Location);
			errorObj.SetErrorMessage(error,"Width NO Expand to Fit");
			reference.add(errorObj);
		}
	}
}