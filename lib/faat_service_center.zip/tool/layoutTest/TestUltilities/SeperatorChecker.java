package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.FieldLocation;
import utilities.Tool;
import configuration.ConfigDom;

public class SeperatorChecker
{
	private Node node = null;
	private ArrayList<ErrorTraceObject> reference = null;
	public SeperatorChecker(Node task,ArrayList<ErrorTraceObject> data)
	{
		node = task;
		reference = data;
	}
	public void CheckFormSeperator() 
	{
		String Location = FieldLocation.getLocationDescription(FieldLocation.FORM_SEPERATOR);
		String height = node.getAttributes().getNamedItem("h").getNodeValue();
		String Name = node.getAttributes().getNamedItem("name").getNodeValue();
		float actualHeight = Tool.getFloatingValue(height);
		if ((actualHeight < ConfigDom.getSepatatorDefaultHeight() - 0.01) || ( actualHeight > ConfigDom.getSepatatorDefaultHeight() + 0.01))
		{
			String HeightErr = "Field:" + Name + ".Separator Height should be 2.5mm,current Wrong Height: "
					+ height;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.SEPERATOR_HEIGHT_SETTING,node,Location);
			errorObj.SetErrorMessage(HeightErr,height);
			reference.add(errorObj);
		}
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if (item.getNodeName().equals("value"))
				HandleSeparatorValue(item,Name);
		}
	}
	private void HandleSeparatorValue(Node node,String Name) 
	{
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) {
			item = child.item(i);
			if (item.getNodeName().equals("rectangle"))
				HandleSeparatorRectangle(item,Name);
		}
	}
	private void HandleSeparatorRectangle(Node node,String Name) {

		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) {
			item = child.item(i);
			if (item.getNodeName().equals("edge"))
				HandleSeparatorEdge(item,Name);
			if (item.getNodeName().equals("fill"))
				HandleSeparatorFill(item,Name);
		}
	}
	
	private void HandleSeparatorFill(Node node,String Name) 
	{
		String Location = FieldLocation.getLocationDescription(FieldLocation.FORM_SEPERATOR);
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) {
			item = child.item(i);
			if (item.getNodeName().equals("color")) {
				String color = item.getAttributes().getNamedItem("value")
						.getNodeValue();
				if (color.equals(ConfigDom.getSeparatorDefaultFillColor()) == false) 
				{
					String colorErr = "Field:" + Name + ".Separator line color should be:" + ConfigDom.getSeparatorDefaultFillColor() + " current wrong color: "
							+ color;
					ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.SEPERATOR_FILL_COLOR_SETTING,node,Location);
					errorObj.SetErrorMessage(colorErr,color);
					reference.add(errorObj);
				}
			}
		}
	}
	private void HandleSeparatorEdge(Node node,String Name) 
	{
		String Location = FieldLocation.getLocationDescription(FieldLocation.FORM_SEPERATOR);
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if (item.getNodeName().equals("color")) 
			{
				String color = item.getAttributes().getNamedItem("value")
						.getNodeValue();
				if (color.equals(ConfigDom.getSeparatorDefaultLineColor()) == false) 
				{
					String colorErr = "Field:" + Name + ".Separator line color should be: " + ConfigDom.getSeparatorDefaultLineColor() + " current wrong color: "
							+ color;
					ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.SEPERATOR_LINE_COLOR_SETTING,node,Location);
					errorObj.SetErrorMessage(colorErr,color);
					reference.add(errorObj);
				}
			}
		}
	}
	
}