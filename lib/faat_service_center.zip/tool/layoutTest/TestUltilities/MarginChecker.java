package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;
import org.w3c.dom.Node;
import utilities.FieldLocation;
import configuration.ConfigDom;

public class MarginChecker
{
	private Node node = null; // input: margin node
	private ArrayList<ErrorTraceObject> reference = null;
	private String fieldName = null;
	private int nodeType = -1;
	private String topInset = null;
	private String bottomInset = null;
	private String leftInset = null;
	private String rightInset = null;

	public MarginChecker(Node input,ArrayList<ErrorTraceObject> data,String Name,int Type)
	{
		node = input;
		reference = data;
		nodeType = Type;
		fieldName = Name;
	}
	private void fillTableDrawMargin()
	{
		topInset = ConfigDom.getDefaultDrawMargin();
		bottomInset = ConfigDom.getDefaultDrawMargin();
		leftInset = ConfigDom.getDefaultDrawMargin();
		rightInset = ConfigDom.getDefaultDrawMargin();
	}
	private void getMargin()
	{
		if( node == null)
		{
			fillTableDrawMargin();
			return;
		}
		if ( node.getAttributes() == null)
		{
			// 2008-09-28: reported by Yoyo:Production Order SP0,
			// draw does not have margin subnode,but in fact margin in 
			// Designer is 1,1,1,1mm
			fillTableDrawMargin();
			return;
		}
		int length = node.getAttributes().getLength();
		if (length == 4) 
		{
			topInset = node.getAttributes().getNamedItem("topInset")
					.getNodeValue();
			bottomInset = node.getAttributes()
					.getNamedItem("bottomInset").getNodeValue();
			leftInset = node.getAttributes().getNamedItem("leftInset")
					.getNodeValue();
			rightInset = node.getAttributes().getNamedItem("rightInset")
					.getNodeValue();
		} 
		else 
		// 2008-09-27: barcode has only one margin: bottom margin.
		{
			bottomInset = node.getAttributes().item(0).getNodeValue();
			topInset = ConfigDom.getDefaultBarcodeMargin();
			leftInset = ConfigDom.getDefaultBarcodeMargin();
			rightInset = ConfigDom.getDefaultBarcodeMargin();
		}
	}
	private boolean isMarginOfTableCellCorrect(String name) 
	{
		if (topInset.equals(ConfigDom.getTableCellTopMargin()) && bottomInset.equals(ConfigDom.getTableCellBottomMargin())
				&& leftInset.equals(ConfigDom.getTableCellLeftMargin()) && rightInset.equals(ConfigDom.getTableCellRightMargin()))
			return true;
		return false;
	}

	public void check()
	{
		getMargin();
		// 2008-09-28 needn't this since node is actually margin node:
		//if( Tool.isFieldHidden(node))
		//	return;
		String MarginErr = null;
		String Location = FieldLocation.getLocationDescription(nodeType);
		System.out.println("Location: " + Location + " FieldName: " + fieldName);
		if ( nodeType == FieldLocation.INFO_BLOCK) 
		// 0,0,0,1.2mm
		{			 
			if (!topInset.equals(ConfigDom.getInfoblockTopMargin()) || !leftInset.equals(ConfigDom.getInfoblockLeftMargin())
					|| !rightInset.equals(ConfigDom.getInfoblockRightMargin())) 
			{
				MarginErr = "Field:" + fieldName
						+ ".in the infoblock margin wrong: top:" + topInset + " bottom: " + bottomInset 
						+ " left: " + leftInset + " right: " + rightInset;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.MARGIN_SETTING,node.getParentNode(),Location);
				String WrongMargin = topInset + "." + bottomInset 
				+ "." + leftInset + "." + rightInset;
				errorObj.SetErrorMessage(MarginErr,WrongMargin);
				reference.add(errorObj);
			}
			if (bottomInset.equals(ConfigDom.getInfoblockBottomMargin()) || bottomInset.equals(ConfigDom.getInfoblockBottomMarginwithBlankRow()))
				return;
		}
		// summary block
		if( nodeType == FieldLocation.SUMMARY_BLOCK)
		{
			if (!topInset.equals(ConfigDom.getSummaryblockTopMargin()) || !bottomInset.equals(ConfigDom.getSummaryblockBottomMargin()) || 
				!leftInset.equals(ConfigDom.getSummaryblockLeftMargin()) ||!rightInset.equals(ConfigDom.getSummaryblockRightMargin()))
			{		
				String SummaryMarginErr = "Field: " + fieldName
			+ ".in the summary block margin wrong: top:" + topInset
			+ " left: " + leftInset + " right: " + rightInset;
				String WrongMargin = topInset
				+ "." + bottomInset + "." + leftInset + "." + rightInset;
				ErrorTraceObject SummaryerrorObj = new ErrorTraceObject(LayoutErrorType.MARGIN_SETTING,node,Location);
				SummaryerrorObj.SetErrorMessage(SummaryMarginErr,WrongMargin);
				reference.add(SummaryerrorObj);
			}
		}
		if( nodeType == FieldLocation.TABLE_HEADER_SUBFORM || nodeType == FieldLocation.TABLE_CONTENT_SUBFORM)
		{
			if (isMarginOfTableCellCorrect(fieldName) == false) 
			{
				String drawErrorMargin = "Field:" + fieldName + ".in table header Margin error->Top: "
				+ topInset + " bottom: " + bottomInset + " left: " + leftInset + " right: " + rightInset;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.MARGIN_SETTING,node.getParentNode(),FieldLocation.getLocationDescription(FieldLocation.TABLE_HEADER_SUBFORM));
				String ErrorMargin = topInset + "." + bottomInset + "." + leftInset + "." + rightInset;
				errorObj.SetErrorMessage(drawErrorMargin,ErrorMargin);
				reference.add(errorObj);
			}
		}
	}
}