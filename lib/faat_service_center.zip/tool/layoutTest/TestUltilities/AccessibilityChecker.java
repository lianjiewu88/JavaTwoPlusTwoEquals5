package layoutTest.TestUltilities;

import java.util.ArrayList;

import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;

import org.w3c.dom.Node;

import configuration.ConfigDom;

import utilities.FieldLocation;
import utilities.Tool;

public class AccessibilityChecker
{
	private Node node = null;
	private int type = -1;
	private ArrayList<ErrorTraceObject> reference = null;
	public AccessibilityChecker(Node input,ArrayList<ErrorTraceObject> data,int Type)
	{
		node = input;
		reference = data;
		type = Type;
	}
	private boolean hasSubCaption()
	{
		Node caption = Tool.getNodebyRoot("caption",node);
		if( caption == null)
			return false;
		Node value = Tool.getNodebyRoot("value",caption);
		if( value == null)
			return false;
		Node text = Tool.getNodebyRoot("text",value);
		if( text == null)
			return false;
		if( text.getTextContent() == null)
			return false;
		String result = text.getTextContent().trim();
		if( result.length() == 0)
			return false;
		return true;
	}
	public void check()
	{
		String acc = LayoutTestReuseComponent.getNodeAccessibilitySetting(node);
		String name = Tool.getAttributeValue("name", node);
		if( name.equals(ConfigDom.getFormFieldLogoName()))
			// because the form logo will be checked separately in function call later
			return;
		String Location = FieldLocation.getLocationDescription(type);
		// All draws must have "none" as ACC settings
		if( node.getNodeName().equals("draw"))
		{
			if( !acc.equals(ConfigDom.getDefaultAccRightSetting()))
			{
				String FieldAccWrongMessage = "Field:" + name + ".Wrong Acc:"
				+ acc + " Location: " + Location + " Correct Acc: " + ConfigDom.getDefaultAccRightSetting();
				ErrorTraceObject FielderrorObj = new ErrorTraceObject(LayoutErrorType.ACC_SETTING,node,Location);
				FielderrorObj.SetErrorMessage(FieldAccWrongMessage,acc);
				reference.add(FielderrorObj);
			}
			return;
		}
		if( Tool.isBarCode(node))
		{
			if( !acc.equals(ConfigDom.getFieldAccessToolTip()))
			{
				String Wrong = "Field:" + name + ".Wrong Acc:"
				+ acc + " Location: " + Location + " Correct Acc: " + ConfigDom.getFieldAccessToolTip();
				ErrorTraceObject FielderrorObj = new ErrorTraceObject(LayoutErrorType.ACC_SETTING,node,Location);
				FielderrorObj.SetErrorMessage(Wrong,acc);
				reference.add(FielderrorObj);
			}
			return;
		}
		if( Tool.isFieldHidden(node))
			return;
		Node parent = node.getParentNode();
		if( parent != null)
		{
			if( Tool.isFieldHidden(parent))
				return;
		}
		// must check if there is subcaption
		if( hasSubCaption()) // caption
		{
			if( !acc.equalsIgnoreCase(ConfigDom.getDefaultCaptionAccSetting()))
			{
					String FieldAccWrongMessage = "Field:" + name + ".Wrong Acc:"
					+ acc + " Location: " + Location + " Correct Acc: " + ConfigDom.getDefaultCaptionAccSetting();
					ErrorTraceObject FielderrorObj = new ErrorTraceObject(LayoutErrorType.ACC_SETTING,node,Location);
					FielderrorObj.SetErrorMessage(FieldAccWrongMessage,acc);
					reference.add(FielderrorObj);
			}
			return;
		}
		// no subcaption
		if( !acc.equals(ConfigDom.getDefaultAccRightSetting()))
		{
				String FieldAccWrongMessage = "Field:" + name + ".Wrong Acc:"
				+ acc + " Location: " + Location + " Correct Acc: " + ConfigDom.getDefaultAccRightSetting();
				ErrorTraceObject FielderrorObj = new ErrorTraceObject(LayoutErrorType.ACC_SETTING,node,Location);
				FielderrorObj.SetErrorMessage(FieldAccWrongMessage,acc);
				reference.add(FielderrorObj);
				return;
		}
	}
}