package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;
import org.w3c.dom.Node;
import utilities.FieldLocation;
import utilities.Tool;

public class SenderAddressChecker
{
	private Node address = null;
	private ArrayList<ErrorTraceObject> reference = null;
	public SenderAddressChecker(Node node,ArrayList<ErrorTraceObject> data)
	{
		address = node;
		reference = data;
	}
	private void checkSenderAcc()
	{
		String Location = FieldLocation.getLocationDescription(FieldLocation.SENDER_ADDRESS_PLACE_HOLDER);
		String acc = LayoutTestReuseComponent.getNodeAccessibilitySetting(address);
		String Name = Tool.getAttributeValue("name", address);
		if( !acc.equals("toolTip"))
		{
			String LogoAcc = "Field:" + Name + ".Form SenderAddress Should be toolTip,Wrong Acc: "
			+ acc;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.ACC_SETTING,address,Location);
			errorObj.SetErrorMessage(LogoAcc,acc);
			reference.add(errorObj);
		}
	}
	private void checkFont()
	{
		FontChecker fontChecker = new FontChecker(Tool.getNodebyRoot("font",address),reference,Tool.getAttributeValue("name",address),FieldLocation.SENDER_ADDRESS_PLACE_HOLDER);
		fontChecker.checkValueFontSetting();
	}
	public void CheckSenderAddress()
	{
		checkSenderAcc();
		checkFont();
	}
	
}