package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;

import org.w3c.dom.Node;

import utilities.FieldLocation;
import utilities.Tool;
import configuration.ConfigDom;

public class HeaderFillColorChecker
{
	private Node node = null;
	private String nodeName = null;
	private ArrayList<ErrorTraceObject> reference = null;
	private int fieldType;
	public HeaderFillColorChecker(Node input,ArrayList<ErrorTraceObject> data,String name,int type)
	{
		node = input;
		reference = data;
		nodeName = name;
		fieldType = type;
	}
	public void check()
	{
		Node border = Tool.getNodebyRoot("border",node);
		if( border == null)
			return;
		Node fill = Tool.getNodebyRoot("fill",border);
		if( fill == null)
			return;
		Node color = Tool.getNodebyRoot("color",fill);
		if( color == null)
			return;
		String value = Tool.getAttributeValue("value",color);
		if( value == null)
			return;
		if( !value.equals(ConfigDom.getTableHeaderFillColor()))
		{
			String Location = FieldLocation.getLocationDescription(fieldType);
			String Access = "Table Header: " + nodeName + ".Fill Color Wrong: " + value + " Correct Color Must be: " + 
			ConfigDom.getTableHeaderFillColor();
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.TABLE_SUBFORM_FILL_COLOR,node,Location);
			errorObj.SetErrorMessage(Access,ConfigDom.getTableHeaderFillColor());
			reference.add(errorObj);
		}
	}
}