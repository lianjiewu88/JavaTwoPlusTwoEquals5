package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;
import layoutTest.internalStructure.LayoutErrorType;
import layoutTest.internalStructure.ErrorTraceObject;
import org.w3c.dom.Node;
import utilities.FieldLocation;
import utilities.Tool;
import configuration.ConfigDom;

public class LogoChecker
{
	private Node logo = null;
	private ArrayList<ErrorTraceObject> reference = null;
	public LogoChecker(Node node,ArrayList<ErrorTraceObject> data)
	{
		logo = node;
		reference = data;
	}
	private void CheckLogoAcc()
	{
		String acc = LayoutTestReuseComponent.getNodeAccessibilitySetting(logo);
		String Location = FieldLocation.getLocationDescription(FieldLocation.FORM_LOGO);
		if( !acc.equals(ConfigDom.getFieldAccessToolTip()))
		{
			String LogoAcc = "Field:" + Tool.getAttributeValue("name",logo)+ ".Acc Should be toolTip,Wrong Acc: "
			+ acc;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FORM_LOGO_ACC_SETTING,logo,Location);
			errorObj.SetErrorMessage(LogoAcc,acc);
			reference.add(errorObj);
		}
	}
	public void CheckFormLogo() 
	{
		CheckLogoAcc();
		String Location = FieldLocation.getLocationDescription(FieldLocation.FORM_LOGO);
		String LogoName = logo.getAttributes().getNamedItem("name").getNodeValue();
		String h = null;
		String w = null;
		h = logo.getAttributes().getNamedItem("h").getNodeValue();
		w = logo.getAttributes().getNamedItem("w").getNodeValue();
		if (h.equals(ConfigDom.getLogoHeight()) == false) 
		{
			String HeightErr = "Field:" + LogoName+ ".Form logo Height should be 40mm,current Height: "
					+ h;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FORM_LOGO_HEIGHT,logo,Location);
			errorObj.SetErrorMessage(HeightErr,h);
			reference.add(errorObj);
		}
		if (w.equals(ConfigDom.getLogoWidth()) == false) 
		{
			String WidthErr = "Field:" + LogoName + ".Form logo Weight should be 20mm,current Width: "
					+ w;
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FORM_LOGO_WIDTH,logo,Location);
			errorObj.SetErrorMessage(WidthErr,w);
			reference.add(errorObj);
		}
	}
}