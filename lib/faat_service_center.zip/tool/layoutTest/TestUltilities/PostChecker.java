package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import configuration.ConfigDom;

import utilities.FieldLocation;
import utilities.Tool;
public class PostChecker
{
	private Node connection = null;
	private Node template = null;
	private ArrayList<ErrorTraceObject> reference = null;
	public PostChecker(Node input,Node Template,ArrayList<ErrorTraceObject> data)
	{
		connection = input;
		reference = data;
		template = Template;
	}
	private void checkDataFile()
	{
		NodeList child = template.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName() != null)
			{
				if( item.getTextContent() != null)
				{
					if( item.getTextContent().contains(ConfigDom.getDataFileLinkNodeName()))
					{
						String Location = FieldLocation.getLocationDescription(FieldLocation.TEMPLATE_DOM);
						String error = "Field:" + ConfigDom.getDefaultTreeNodeName() + ".Data file link existing,Must be deleted!";
						ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.DATA_FILE_LINK_EXIST,template,Location);
						errorObj.SetErrorMessage(error,ConfigDom.getDefaultAccessMode());
						reference.add(errorObj);
						return;
					}
				}
			}
		}
	}
	public void check()
	{
		checkDataFile();
		checkXSD();
	}
	
	private void checkXSD()
	{
		Node xsdConnection = Tool.getNodebyRoot("xsdConnection",connection);
		String error = null;
		String Location = FieldLocation.getLocationDescription(FieldLocation.CONNECTION_SET);
		if( xsdConnection == null)
		{
			error = "Field:" + ConfigDom.getDefaultTreeNodeName() + ".Form Data View Has Been Wrongly Deleted!";
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.NO_DATA_VIEW,connection,Location);
			errorObj.SetErrorMessage(error,ConfigDom.getDefaultAccessMode());
			reference.add(errorObj);
			return;
		}
		Node uri = Tool.getNodebyRoot("uri",xsdConnection);
		if( uri == null)
			return;
		String XSD = uri.getTextContent();
		if( XSD == null)
			return;
		if( XSD.length() == 0)
			return;
		error = "Field:" + ConfigDom.getDefaultTreeNodeName() + ".XSD Link Existing! Must be deleted!";
		ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.XSD_LINK_EXIST,connection,Location);
		errorObj.SetErrorMessage(error,ConfigDom.getDefaultAccessMode());
		reference.add(errorObj);
		return;
	}
}