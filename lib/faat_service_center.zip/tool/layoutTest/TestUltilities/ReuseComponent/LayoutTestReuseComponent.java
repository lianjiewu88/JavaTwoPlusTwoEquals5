package layoutTest.TestUltilities.ReuseComponent;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utilities.FieldLocation;
import utilities.Tool;
import configuration.ConfigDom;

public class LayoutTestReuseComponent
{
	static private ArrayList<ErrorTraceObject> ResultData = null;
	static public void initialize(ArrayList<ErrorTraceObject> input)
	{
		ResultData = input;
	}
	static public String getNodeAccessibilitySetting(Node node) 
	{
		// 2008-09-14: pay attention that acc is assigned with DEFAULT ACC,not CORRECT ACC.
		String acc = ConfigDom.getDefaultAccSetting();
		Node assist = Tool.getNodebyRoot("assist",node);
		if( assist == null)
			return acc;
		Node speak = Tool.getNodebyRoot("speak",assist);
		if( speak == null)
			return acc;
		String disable = Tool.getAttributeValue("disable",speak);
		if( disable != null)
			return ConfigDom.getDefaultAccRightSetting();
		String priority = Tool.getAttributeValue("priority",speak);
		if( priority == null)
			return acc;
		return priority;
	}
	
	static public boolean isHeightExpandToFit(Node node,boolean isInFreeTextBlock)
	{
		if( node.getNodeName().equals("draw") && ( isInFreeTextBlock == false ))
			return true; // avoid duplicate error reporting!
		if( Tool.getAttributeValue("minH", node) != null)
			return true;
		return false;
	}
	static public boolean isFieldAllowMultipleLine(Node node)
	{
		if( node.getNodeName().equals("draw"))
			return true; // avoid duplicate error reporting!
		Node ui = Tool.getNodebyRoot("ui",node);
		if( ui == null)
			return false;
		Node textEdit = Tool.getNodebyRoot("textEdit",ui);
		if( textEdit == null)
			return false;
		String multiLine = Tool.getAttributeValue("multiLine",textEdit);
		if( multiLine == null)
			return false;
		return true;
	}
	//	 hidden subform should be ignored
	static public void checkIfSubformFlowed(Node node,int type) 
	{
		String Location = FieldLocation.getLocationDescription(type);
		if( node.getAttributes().getNamedItem("presence") != null)
		{
			if( node.getAttributes().getNamedItem("presence").equals("hidden"))
				return;
		}
		String SubformName = "";
		if (node.getAttributes().getNamedItem("name") != null) {
			SubformName = node.getAttributes().getNamedItem("name")
					.getNodeValue();
		}
		if (node.getAttributes().getNamedItem("layout") == null) 
		{
			String flowMessage = "Subform:" + SubformName
					+ ".does not set layout to FLOW";
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.SUBFORM_FLOW_SETTING,node,Location);
			errorObj.SetErrorMessage(flowMessage,ConfigDom.getPositionedStyle());
			ResultData.add(errorObj);
		} 
		else 
		{
			String layoutPattern = node.getAttributes().getNamedItem("layout")
					.getNodeValue();
			if ((layoutPattern.equals(ConfigDom.getTopToBottomSetting()) == true)
					|| (layoutPattern.equals(ConfigDom.getWestenTextSetting()) == true) || ( layoutPattern.equals(ConfigDom.getRowLayoutSetting())))
			// Table row need not set to flow
				return;
			String flowMessage = "Subform:  " + SubformName
					+ "  does not set layout to FLOW";
	 
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.SUBFORM_FLOW_SETTING,node,Location);
			errorObj.SetErrorMessage(flowMessage,ConfigDom.getPositionedStyle());
			ResultData.add(errorObj);
		}
	}
	static public String getHeaderNamebyBody(Node node) // input body node
	{
		String content = "";
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i=0;i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("p"))
			{
				content = content + "\\" + item.getTextContent(); 
			}
		}
		return content;
	}
	static public String GetHeaderNameFromDrawNode(Node node) // input: draw node
	{
		Node ValueNode = Tool.getNodebyRoot("value",node);
		if( ValueNode == null)
			return null;
		Node TextNode = Tool.getNodebyRoot("text",ValueNode);
		if( TextNode != null)
			return TextNode.getTextContent();
		Node exData = Tool.getNodebyRoot("exData",ValueNode);
		if( exData == null)
			return null;
		Node bodyNode = Tool.getNodebyRoot("body",exData);
		if( bodyNode == null)
			return null;
		return getHeaderNamebyBody(bodyNode);
	}
}