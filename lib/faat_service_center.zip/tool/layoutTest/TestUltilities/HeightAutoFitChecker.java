package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utilities.FieldLocation;
import utilities.Tool;
import configuration.ConfigDom;

public class HeightAutoFitChecker
{
	private Node node = null;
	private String nodeName = null;
	private int type = -1;
	private ArrayList<ErrorTraceObject> reference = null;
	public HeightAutoFitChecker(Node input,ArrayList<ErrorTraceObject> data,String name,int Type)
	{
		node = input;
		reference = data;
		type = Type;
		nodeName = name;
	}
	public void check() 
	{
		NodeList grandson = node.getChildNodes();
		Node drawgrandson = null;
		String Location = FieldLocation.getLocationDescription(type);
		boolean isExpandtoFit = false;
		boolean isAllowMutiLine = false;
		if (node.getAttributes().getNamedItem("h") != null) 
		{
			String Height = node.getAttributes().getNamedItem("h")
					.getNodeValue();
			// dummy
			Height.hashCode();
		} 
		else
			isExpandtoFit = true;
		if (isExpandtoFit == false) 
		{
		    String HeightMessage = "Field:" + nodeName + " should allow Height Expand To Fit";
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.TABLE_CELL_AUTOFIT,node,Location);
			errorObj.SetErrorMessage(HeightMessage,ConfigDom.getDefaultHeightSetting());
			reference.add(errorObj);
		}
		int grandsonLength = grandson.getLength();
		for (int k = 0; k < grandsonLength; k++) 
		{
			drawgrandson = grandson.item(k);
			if (drawgrandson.getNodeName().equals("ui")) 
			{ 
				NodeList UISubnode = drawgrandson.getChildNodes();
				int UISubnodeLength = UISubnode.getLength();
				for (int j = 0; j < UISubnodeLength; j++) 
				{
					Node TextEditNode = UISubnode.item(j);
					if (TextEditNode.getNodeName().equals("textEdit")) 
					{
						if (TextEditNode.getAttributes().getNamedItem("multiLine") == null)
							continue;
						String multiline = TextEditNode.getAttributes().getNamedItem("multiLine").getNodeValue();
						if (multiline.equals("1")) 
						{
							isAllowMutiLine = true;
						}
					}
				}
			}	
		}
		if((isAllowMutiLine == false) && (isAllowMultipleReallyNeeded(node)))
		{
			String HeightMessage = "Field:" + nodeName + " in table row Should select Allow Multilines!";
			ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.TABLE_CELL_MULTILINES,node,Location);
			errorObj.SetErrorMessage(HeightMessage,ConfigDom.getDefaultLineSetting());
			reference.add(errorObj);
		}
	}

	private boolean isAllowMultipleReallyNeeded(Node node)
	{
		if( Tool.isBarCode(node))
			return false;
		if( Tool.isDateField(node))
			return false;
		if( Tool.isNumericField(node))
			return false;
		return true;
	}
}