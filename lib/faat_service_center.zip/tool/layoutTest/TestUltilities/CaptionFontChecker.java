package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.FieldLocation;
import configuration.ConfigDom;

// 2008-09-23: Attention: input node is Caption subNode!!!!
public class CaptionFontChecker
{
	private Node caption = null;
	private String nodeName = null;
	private int type = -1;
	private ArrayList<ErrorTraceObject> reference = null;
	public CaptionFontChecker(Node input,ArrayList<ErrorTraceObject> data,String name,int Type)
	{
		caption = input;
		reference = data;
		type = Type;
		nodeName = name;
	}
	public void check()
	{
		String BoldSetting = "";
		String size = null;
		String fontType = "";
		String Location = FieldLocation.getLocationDescription(type);
		NodeList child = caption.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if (item.getNodeName().equals("font")) {
				if (item.getAttributes().getNamedItem("weight") != null)
					BoldSetting = item.getAttributes().getNamedItem("weight")
							.getNodeValue();
				if (item.getAttributes().getNamedItem("size") != null)
					size = item.getAttributes().getNamedItem("size")
							.getNodeValue();
				fontType = item.getAttributes().getNamedItem("typeface")
						.getNodeValue();
			}
		}
		if ( type == FieldLocation.INFO_BLOCK)
		{
			if (!BoldSetting.equals("bold")) 
			{
				String ValueFontErr = "Field:"
						+ nodeName
						+ ".Caption Font Setting in infoblock should be BOLD,current Regular "
						+ BoldSetting;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FIELD_BOLD_OR_REGULAR,caption,Location);
				errorObj.SetErrorMessage(ValueFontErr,BoldSetting);
				reference.add(errorObj);
			}
			if (( size != null) && (!size.equals(ConfigDom.getDefaultFontSize()))) 
			{
				String ValueFontSizeErr = "Field:"
						+ nodeName
						+ ".Caption Font Size in infoblock should be 10PT,current: "
						+ size;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_SIZE_SETTING,caption,Location);
				errorObj.SetErrorMessage(ValueFontSizeErr,size);
				reference.add(errorObj);
			}
			if (!fontType.equals(ConfigDom.getDefaultFontFamily())) 
			{
				String ValueFontTypeErr = "Field:"
						+ nodeName
						+ ".Caption Font Type in infoblock should be Arial,current: "
						+ fontType;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_TYPE_SETTING,caption,Location);
				errorObj.SetErrorMessage(ValueFontTypeErr,fontType);
				reference.add(errorObj);
			}
		}
	}
}