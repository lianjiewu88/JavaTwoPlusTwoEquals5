package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.FieldLocation;
import configuration.ConfigDom;

// node: sub caption code!
public class CaptionParaChecker
{
	private Node node = null;
	private String nodeName = null;
	private int type = -1;
	private ArrayList<ErrorTraceObject> reference = null;
	public CaptionParaChecker(Node input,ArrayList<ErrorTraceObject> data,String name,int Type)
	{
		node = input;
		reference = data;
		type = Type;
		nodeName = name;
	}
	public void check()
	{
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for(int i = 0;i<length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("para"))
			{
				checkSubCaptionParaSetting(item,nodeName,type);
				return;
			}
		}
		HandleCaptionParaNode(node,nodeName,type);
	}
	private void checkSubCaptionParaSetting(Node node,String Name,int type)
	{
		String hAlignSetting = null;
		String hAlignErr = null;
		String Location = FieldLocation.getLocationDescription(type);
		if(isHAlignShouldbeRight(Name))	// dec or num field,should be right!
		{
			if( node.getAttributes().getNamedItem("hAlign") != null)
			{
				hAlignSetting = node.getAttributes().getNamedItem("hAlign").getNodeValue();
				System.out.println("Right-Align setting: " + hAlignSetting);
				if( hAlignSetting.contains("right") == false)
				{
					hAlignErr = "Field:" + Name
					+ ".Caption Horizontal Align Wrong: " + hAlignSetting + " Correct should be Right-Aligned";
					ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.H_ALIGN_SETTING,node,Location);
					errorObj.SetErrorMessage(hAlignErr,hAlignSetting);
					reference.add(errorObj);
				}
			}
			else // this situation is left-aligned
			{
				hAlignErr = "Field:" + Name
				+ ".Caption Horizontal Align Wrong: Left-Aligned,Correct should be Right-Aligned";
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.H_ALIGN_SETTING,node,Location);
				errorObj.SetErrorMessage(hAlignErr,ConfigDom.getDefaultHorizonAlignStyle());
				reference.add(errorObj);
			}
		}
		else	// not a dec or a num
		{
			if( node.getAttributes().getNamedItem("hAlign") != null)
			{
				hAlignSetting = node.getAttributes().getNamedItem("hAlign").getNodeValue();
				hAlignErr = "Field:" + Name
				+ ".Caption Horizontal Align Wrong: " + hAlignSetting + " Correct should be Left-Aligned";
				ErrorTraceObject HerrorObj = new ErrorTraceObject(LayoutErrorType.H_ALIGN_SETTING,node,Location);
				HerrorObj.SetErrorMessage(hAlignErr,hAlignErr);
				reference.add(HerrorObj);
			}
		}
		/* Style guide 1.7 does not have requirement about vertical alignment
		 * if( node.getAttributes().getNamedItem("vAlign") != null)
		{
			String vAlignSetting = node.getAttributes().getNamedItem("vAlign").getNodeValue();
			String vAlignErr = "Field:" + Name
			+ ".Caption Vertical Align Wrong: " + vAlignSetting + " Correct should be Top-Aligned";
			ErrorTraceObject VerrorObj = new ErrorTraceObject(LayoutErrorType.V_ALIGN_SETTING,node,Location);
			VerrorObj.SetErrorMessage(vAlignErr,vAlignErr);
			reference.add(VerrorObj);
		}*/
	}
	private boolean isHAlignShouldbeRight(String Name)
	{
		if( Name.substring(0,3).equals(ConfigDom.getDecimalNamingConvention()) || Name.substring(0,3).equals(ConfigDom.getNumericNamingConvention()))
		{
			System.out.println(Name + " should be Right-Aligned!");
			return true;
		}
		return false;
	}
	private void  HandleCaptionParaNode(Node node,String name,int type)
	{
		String Location = FieldLocation.getLocationDescription(type);
		if( isHAlignShouldbeRight(name) == false)
			return;
		String hAlignErr = "Field:" + name
			+ ".Caption Horizontal Align Wrong: Left-Aligned,Correct should be Right-Aligned";
		ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.H_ALIGN_SETTING,node,Location);
		errorObj.SetErrorMessage(hAlignErr,ConfigDom.getDefaultHorizonAlignStyle());
		reference.add(errorObj);
	}
}