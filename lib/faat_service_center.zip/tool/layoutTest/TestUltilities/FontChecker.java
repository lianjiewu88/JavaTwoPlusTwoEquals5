package layoutTest.TestUltilities;

import java.util.ArrayList;
import layoutTest.internalStructure.ErrorTraceObject;
import org.w3c.dom.Node;
import layoutTest.internalStructure.LayoutErrorType;
import utilities.FieldLocation;
import utilities.Tool;
import configuration.ConfigDom;

public class FontChecker
{
	private Node node = null;
	private String nodeName = null;
	private int type = -1;
	private ArrayList<ErrorTraceObject> reference = null;
	public FontChecker(Node input,ArrayList<ErrorTraceObject> data,String name,int Type)
	{
		node = input;
		reference = data;
		type = Type;
		nodeName = name;
	}

	public void checkValueFontSetting() 
	{
		String BoldSetting = "regular";
		if (node.getAttributes().getNamedItem("weight") != null)
			BoldSetting = node.getAttributes().getNamedItem("weight")
					.getNodeValue();
		String size = null; // default font size in Form Designer is 10pt
		if (node.getAttributes().getNamedItem("size") != null)
			size = node.getAttributes().getNamedItem("size").getNodeValue();
		String fontType = node.getAttributes().getNamedItem("typeface")
				.getNodeValue();
		String Location = FieldLocation.getLocationDescription(type);
		if ( type == FieldLocation.INFO_BLOCK)
		{
			if (!BoldSetting.equals("regular")) 
			{
				String ValueFontErr = "Field: "+ nodeName + ".Value Font Setting in infoblock should be REGULAR,current: "
						+ BoldSetting;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FIELD_BOLD_OR_REGULAR,node,Location);
				errorObj.SetErrorMessage(ValueFontErr,BoldSetting);
				reference.add(errorObj);
			}
			else if (( size != null ) && (!size.equals(ConfigDom.getDefaultFontSize()) )) 
			{
				String ValueFontSizeErr = "Field:"
						+ nodeName
						+ ".Value Font Size in infoblock should be 10PT,current: "
						+ size;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_SIZE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontSizeErr,size);
				reference.add(errorObj);
			}
			if( Tool.isBarCode(node.getParentNode()))
				return;
			if (!fontType.equals(ConfigDom.getDefaultFontFamily())) 
			{
				String ValueFontTypeErr = "Field:"
						+ nodeName
						+ ".Value Font Type in infoblock should be Arial,current: "
						+ fontType;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_TYPE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontTypeErr,fontType);
				reference.add(errorObj);
			}
		}
		else if ( type == FieldLocation.SENDER_ADDRESS_PLACE_HOLDER)
		{
			// 8 pt, Arial, Regular
			if (!BoldSetting.equals("regular")) 
			{
				String ValueFontErr = "Field: "+ nodeName + ".Value Font Setting SenderAddress should be REGULAR,current: "
						+ BoldSetting;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FIELD_BOLD_OR_REGULAR,node,Location);
				errorObj.SetErrorMessage(ValueFontErr,BoldSetting);
				reference.add(errorObj);
			}
			if( size == null ) // 10 pt
			{
				String ValueFontSizeErr = "Field:"
					+ nodeName + ".Value Font Size in SenderAddress shouldn't be 10PT,correct Size: " + ConfigDom.getdefaultSenderAddressFont();
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_SIZE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontSizeErr,size);
				reference.add(errorObj);
			}
			else if ( !size.equals(ConfigDom.getdefaultSenderAddressFont()))
			{
				String ValueFontSizeErr = "Field:"
					+ nodeName + ".Value Font Size in SenderAddress shouldn't be: " + size + " correct Size: " + ConfigDom.getdefaultSenderAddressFont();
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_SIZE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontSizeErr,size);
				reference.add(errorObj);
			}
			if (!fontType.equals(ConfigDom.getDefaultFontFamily())) 
			{
				String ValueFontTypeErr = "Field:"
						+ nodeName
						+ ".Value Font Type in SenderAddress should be Arial,current: "
						+ fontType;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_TYPE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontTypeErr,fontType);
				reference.add(errorObj);
			}
		}
		else if ( type == FieldLocation.TABLE_HEADER_SUBFORM)
		{
			// Arial, 9pt, bold
			if (!BoldSetting.equals("bold")) 
			{
				String ValueFontErr = "Field: "+ nodeName + ".Font in Table Header should be BOLD,current: "
						+ BoldSetting;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FIELD_BOLD_OR_REGULAR,node,Location);
				errorObj.SetErrorMessage(ValueFontErr,BoldSetting);
				reference.add(errorObj);
			}
			if( size == null ) // 10 pt
			{
				String ValueFontSizeErr = "Field:"
					+ nodeName + ".Value Font Size in Table Header shouldn't be 10PT,correct Size: " + ConfigDom.getdefaultTableFont();
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_SIZE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontSizeErr,size);
				reference.add(errorObj);
			}
			else if ( !size.equals(ConfigDom.getdefaultTableFont()))
			{
				String ValueFontSizeErr = "Field:"
					+ nodeName + ".Font Size in Table Header shouldn't be: " + size + " correct Size: " + ConfigDom.getdefaultTableFont();
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_SIZE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontSizeErr,size);
				reference.add(errorObj);
			}
			if (!fontType.equals(ConfigDom.getDefaultFontFamily())) 
			{
				String ValueFontTypeErr = "Field:"
						+ nodeName
						+ ".Font Type in Table Header should be Arial,current: "
						+ fontType;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_TYPE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontTypeErr,fontType);
				reference.add(errorObj);
			}
		}
		else if ( type == FieldLocation.TABLE_CONTENT_SUBFORM)
		{
			//Arial, 9 pt, Regular
			if (!BoldSetting.equals("regular")) 
			{
				String ValueFontErr = "Field: "+ nodeName + ".Font in Table Content Row should be Regular,current: "
						+ BoldSetting;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FIELD_BOLD_OR_REGULAR,node,Location);
				errorObj.SetErrorMessage(ValueFontErr,BoldSetting);
				reference.add(errorObj);
			}
			if( size == null ) // 10 pt
			{
				String ValueFontSizeErr = "Field:"
					+ nodeName + ".Font Size in Table Content Row shouldn't be 10PT,correct Size: " + ConfigDom.getdefaultTableFont();
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_SIZE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontSizeErr,size);
				reference.add(errorObj);
			}
			else if ( !size.equals(ConfigDom.getdefaultTableFont()))
			{
				String ValueFontSizeErr = "Field:"
					+ nodeName + ".Font Size in Table Content Row shouldn't be: " + size + " correct Size: " + ConfigDom.getdefaultTableFont();
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_SIZE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontSizeErr,size);
				reference.add(errorObj);
			}
			if (!fontType.equals(ConfigDom.getDefaultFontFamily())) 
			{
				String ValueFontTypeErr = "Field:"
						+ nodeName
						+ ".Font Type in Table Content Row should be Arial,current: "
						+ fontType;
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.FONT_TYPE_SETTING,node,Location);
				errorObj.SetErrorMessage(ValueFontTypeErr,fontType);
				reference.add(errorObj);
			}
		}
	}
}