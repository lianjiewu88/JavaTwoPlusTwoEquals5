package layoutTest;
import utilities.FieldLocation;
import utilities.FileLogFactory;
import utilities.FileCopyFactory;
import utilities.Tool;
import layoutTest.TestUltilities.AccessChecker;
import layoutTest.TestUltilities.AccessibilityChecker;
import layoutTest.TestUltilities.CaptionFontChecker;
import layoutTest.TestUltilities.CaptionParaChecker;
import layoutTest.TestUltilities.FontChecker;
import layoutTest.TestUltilities.HeaderFillColorChecker;
import layoutTest.TestUltilities.HeightAutoFitChecker;
import layoutTest.TestUltilities.LogoChecker;
import layoutTest.TestUltilities.MarginChecker;
import layoutTest.TestUltilities.PageChecker;
import layoutTest.TestUltilities.PostChecker;
import layoutTest.TestUltilities.SenderAddressChecker;
import layoutTest.TestUltilities.SeperatorChecker;
import layoutTest.TestUltilities.TitleChecker;
import layoutTest.TestUltilities.ReuseComponent.LayoutTestReuseComponent;
import layoutTest.internalStructure.ErrorTraceObject;
import layoutTest.internalStructure.LayoutErrorType;
import layoutTest.internalStructure.OperationLog;
import configuration.ConfigDom;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class TemplateDomTest 
{
	private FileLogFactory logfile;
	
	private DocumentBuilderFactory domfac;

	private DocumentBuilder dombuilder;

	private FileCopyFactory filecopy;

	private ArrayList<ErrorTraceObject> ResultData;

	private Document doc;
	
	private int NodeIndex = 0;
	
	private boolean isRootNode = true;
	
	private ArrayList<ErrorTraceObject> PriorSortBackUp = null;
	
	private HashMap<DefaultMutableTreeNode,String> hashMap = null;
	
	private ArrayList<OperationLog> OperationLogList = null;
	
	private ArrayList<Node> NodeList = null;			// used for search backup node
	
	private ArrayList<DefaultMutableTreeNode> ModuleTreeBackUpList = null;
   
	private DefaultTreeModel TreeMode;
	
	private DefaultMutableTreeNode root;
	
	private DefaultMutableTreeNode parentNode;
	
	public TemplateDomTest() 
	{  
		ResultData = new ArrayList<ErrorTraceObject>();
		OperationLogList = new ArrayList<OperationLog>();
		hashMap = new HashMap<DefaultMutableTreeNode,String>();
		NodeList = new ArrayList<Node>();
		ModuleTreeBackUpList = new ArrayList<DefaultMutableTreeNode>();
		domfac = DocumentBuilderFactory.newInstance();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			
			e.printStackTrace();
		}
	}

	public Document getDocument()
	{
		return doc;
	}

	public void BackupDataBeforeSort()
	{
		PriorSortBackUp = (ArrayList<ErrorTraceObject>)ResultData.clone();
	}
	
	public void RestoreDataAfterSort()
	{
		ResultData = (ArrayList)PriorSortBackUp.clone();
	}
	
	public DefaultMutableTreeNode GetRootNode()
	{
		return root;
	}
	
	public ArrayList<OperationLog> getOperationList()
	{
		return OperationLogList;
	}

	public ArrayList<ErrorTraceObject> GetJListData()
	{
		return ResultData;
	}
	
	public void DeleteElementat(int index)
	{
		ResultData.remove(index);
	}
	
	private boolean CheckInputXDPFileExistence(String filename)
	{
		File ForChecking = new File(filename);
		return ForChecking.exists();
	}
	
	private void CreateLogFile(String filename)
	{
		try 
		{
			logfile = new FileLogFactory(filename);
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Calendar c=Calendar.getInstance(); 
		String Date = c.getTime().toString();
		try 
		{
			logfile.WriteToLogFile(Date);
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void WriteResultToFile()
	{
		int number = ResultData.size();
		ErrorTraceObject obj = null;
		for( int i = 0 ; i < number;i++)
		{
			obj = ResultData.get(i);
			try 
			{
				logfile.WriteToLogFile(obj.ErrorMessage);
			} 
			catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public ArrayList<ErrorTraceObject> DoActions(String inputXDPName) 
	{
		try 
		{
			filecopy = new FileCopyFactory();
			if( CheckInputXDPFileExistence(inputXDPName) == false)
			{
				Tool.ErrorReport("You select a file which does not exist!");
				return null;
			}
			String OutputXMLFile = filecopy.copyFile(inputXDPName);
			CreateLogFile(inputXDPName);
			if (OutputXMLFile == null)
				return null;
			InputStream inputXML = new FileInputStream(OutputXMLFile);
			doc = dombuilder.parse(inputXML);
			Element root = doc.getDocumentElement();
			
			filecopy.DeleteUnusedXML(OutputXMLFile);
			Node template = Tool.getNodebyRoot("template",root);
			if( template == null)
				return null;
			Node connection = Tool.getNodebyRoot("connectionSet", root);
			CreateRootNodeForTree(template);
			LayoutTestReuseComponent.initialize(ResultData);
			traverseNode(template);
			PostChecker postChecker = new PostChecker(connection,template,ResultData);
			postChecker.check();
			
			WriteResultToFile();
			logfile.CloseFile();
		}
		catch (FileNotFoundException d) {
			d.printStackTrace();
		} catch (SAXException d) {
			d.printStackTrace();
			System.exit(0);
		} catch (IOException d) {
			d.printStackTrace();
		}
		return ResultData;
	}

	public void drawTableHeaderFieldCorrection(Node node) 
	{
		SetParent(node);
		HeaderFillColorChecker headerFillChecker = new HeaderFillColorChecker(node,ResultData,Tool.getAttributeValue("name", node),
				FieldLocation.TABLE_HEADER_SUBFORM);
		headerFillChecker.check();
		NodeList childs = node.getChildNodes();
		Node child_node = null;
		int childLength = childs.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			child_node = childs.item(i);
			// the subnode in the table header
			if (child_node.getNodeName().equals("draw") || child_node.getNodeName().equals("field")) 
			{
				insertLeaf(child_node);
				String drawname = child_node.getAttributes().getNamedItem("name").getNodeValue();
				checkElementAccSetting(child_node,FieldLocation.TABLE_HEADER_SUBFORM);
				Node margin = Tool.getNodebyRoot("margin",child_node);
				MarginChecker marginChecker = new MarginChecker(margin,ResultData,drawname,FieldLocation.TABLE_HEADER_SUBFORM);
				marginChecker.check();
				
				// check font
				Node font = Tool.getNodebyRoot("font",child_node);
				FontChecker fontChecker = new FontChecker(font,ResultData,drawname,FieldLocation.TABLE_HEADER_SUBFORM);
				fontChecker.checkValueFontSetting();
				
				// check para
				Node para = Tool.getNodebyRoot("para",child_node);
				if( para == null)
				{
					// top left
					continue;
				}
				/* 2008-09-27 Does not check Table Header Alignment setting now
				 * ParaAlignmentChecker paraChecker = new ParaAlignmentChecker(para,ResultData,drawname,FieldLocation.TABLE_HEADER_SUBFORM);
				paraChecker.check();
				*/
				HeaderFillColorChecker headerFillchecker = new HeaderFillColorChecker(child_node,ResultData,drawname,
						FieldLocation.TABLE_HEADER_SUBFORM);
				headerFillchecker.check();
				
				checkFieldAccessMode(child_node,FieldLocation.TABLE_HEADER_SUBFORM);
			}
		}
		BackTrace();
	}

	public void TableContentRowCorrection(Node node) 
	{
		NodeList child = node.getChildNodes();
		Node item = null;
		SetParent(node);
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				// nested table
				String SubformName = Tool.getAttributeValue("name",item);
				if( SubformName == null)
					continue;
				System.out.println("Subform: " + SubformName);
				/* hidden accessibility should be considered now
				 *
				if( isFieldHidden(item) == true)
					continue;
					*/
				insertSubform(item);
				CheckSubformSetWithinTableNamingConvention(item,SubformName);
				int type = FieldLocation.getSubformLocation(SubformName);
				if( type == FieldLocation.TABLE_OUTER_SUBFORM)
					CheckTableAttribute(item);
				else
				{
					TableContentRowCorrection(item);
				}
			}
			// field type
			else if (item.getNodeName().equals("field")) 
			{
				insertLeaf(item);
				ContentRowTextfieldCorrection(item,Tool.isFieldHidden(node));
			} 
			else if (item.getNodeName().equals("draw")) 
			{
				insertLeaf(item);
				ContentRowDrawCorrection(item);
			}
		}
		BackTrace();
	}

	private void ContentRowDrawCorrection(Node node) 
	{
		checkElementAccSetting(node,FieldLocation.TABLE_CONTENT_SUBFORM);
		String name = node.getAttributes().getNamedItem("name").getNodeValue();
		
		Node margin = Tool.getNodebyRoot("margin",node);
		MarginChecker marginChecker = new MarginChecker(margin,ResultData,name,FieldLocation.TABLE_CONTENT_SUBFORM);
		marginChecker.check();
		
		Node font = Tool.getNodebyRoot("font",node);
		FontChecker fontChecker = new FontChecker(font,ResultData,name,FieldLocation.TABLE_CONTENT_SUBFORM);
		fontChecker.checkValueFontSetting();
		
		Node para = Tool.getNodebyRoot("para",node);
		if( para == null)
			return;
		/* 2008-09-27 Does Not check Table Content element alignment Setting now
		ParaAlignmentChecker paraChecker = new ParaAlignmentChecker(para,ResultData,name,FieldLocation.TABLE_HEADER_SUBFORM);
		paraChecker.check();
		*/
	} 

	private void ContentRowTextfieldCorrection(Node node,boolean isHidden) 
	{	
		checkFieldAccessMode(node,FieldLocation.TABLE_CONTENT_SUBFORM);
		checkElementAccSetting(node,FieldLocation.TABLE_CONTENT_SUBFORM);
		String name = node.getAttributes().getNamedItem("name").getNodeValue();
		if( !isHidden)
		{
			HeightAutoFitChecker heightChecker = new HeightAutoFitChecker(node,ResultData,name,FieldLocation.TABLE_CONTENT_SUBFORM);
			heightChecker.check();
			
			Node margin = Tool.getNodebyRoot("margin",node);
			MarginChecker marginChecker = new MarginChecker(margin,ResultData,name,FieldLocation.TABLE_CONTENT_SUBFORM);
			marginChecker.check();
			
			Node font = Tool.getNodebyRoot("font",node);
			FontChecker fontChecker = new FontChecker(font,ResultData,name,FieldLocation.TABLE_CONTENT_SUBFORM);
			fontChecker.checkValueFontSetting();
			
			Node para = Tool.getNodebyRoot("para",node);
			if( para == null)
				return;
			/* 2008-09-27 Does Not check Table Content element alignment Setting now
			ParaAlignmentChecker paraChecker = new ParaAlignmentChecker(para,ResultData,name,FieldLocation.TABLE_HEADER_SUBFORM);
			paraChecker.check();
			*/
		}
	} 

	private void CheckSubformSetWithinTableNamingConvention(Node node,String name)
	{
		if( !node.getNodeName().equals("subformSet"))
			return;
		if( !name.substring(0,3).equalsIgnoreCase(ConfigDom.getTableRowNamingConvention()))
		{
			String error = "SubformSet: " + name + " within the table should begin with ROW,not " + name.substring(0,3);
			Tool.ErrorReport(error);
		}
	}
	
	private void CheckTableAttribute(Node parent) 
	{
		NodeList child = parent.getChildNodes();
		Node item = null;
		SetParent(parent);
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) {
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				// Should check if the subform is info block or table or root
				// node
				String SubformName = Tool.getAttributeValue("name", item);
				if( SubformName.equals("rowOperationItem"))
					System.out.println("here");
				CheckSubformSetWithinTableNamingConvention(item,SubformName);
				/* hidden accessibility should be considered now
				if( isFieldHidden(item) == true)
					continue;
					*/
				insertSubform(item);
				int type = FieldLocation.getSubformLocation(SubformName);
				if( type == FieldLocation.TABLE_HEADER_SUBFORM)
					drawTableHeaderFieldCorrection(item);
				if( type == FieldLocation.TABLE_CONTENT_SUBFORM)
					TableContentRowCorrection(item);
				if( type == FieldLocation.TABLE_OUTER_SUBFORM)
					CheckTableAttribute(item);
			}
		}
		BackTrace();
	}

	private void checkIfSubformNormalBinding(Node node,int type) 
	{
		if( isRootNode == true)
		{
			isRootNode = false;
			return;					// ignore the root node
		}
		String SubformName = Tool.getAttributeValue("name", node);
		String Location = FieldLocation.getLocationDescription(type);
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if (item.getNodeName().equals("bind") == true) 
			{

				String bindingPath = item.getAttributes().getNamedItem("match")
						.getNodeValue();
				bindingPath.hashCode();
				// Directly return
				return;
			}
		}
		// executing here means has normal binding
		String NormalBindingMessage = "Subform: " + SubformName
				+ " has normal binding";
		ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.SUBFORM_NORMAL_BINDING,node,Location);
		errorObj.SetErrorMessage(NormalBindingMessage,ConfigDom.getNormalBinding());
		ResultData.add(errorObj);
		
	}

	private void traverseNode(Node parent) 
	{
		NodeList child = parent.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		SetParent(parent);
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				// 2008-10-09 : in some form like payment advice,the free text blocl
				// option are hidden as design
				if( item.getAttributes().getNamedItem("name") == null)
				{
					Tool.ErrorReport("Subform should have a name attribute!");
					continue;
				}
				String SubformName = Tool.getAttributeValue("name",item);
				int type = FieldLocation.getSubformLocation(SubformName);
				if( Tool.isFieldHidden(item) && type == FieldLocation.DEFAULT_SUBFORM)
					continue;
				insertSubform(item);
				if( type == FieldLocation.BODY_PAGE)
					traverseNode(item);	
				else if ( type == FieldLocation.TABLE_OUTER_SUBFORM)
					CheckTableAttribute(item);
				else if( type == FieldLocation.INFO_BLOCK)
					HandleWithInfoBlock(item);	
				else if( type == FieldLocation.SUMMARY_BLOCK)
					HandleWithSummaryBlock(item);
				else if( type == FieldLocation.FREE_TEXT_BLOCK)
					HandleWithFreeTextBlock(item);
				else  
				{
					// Shoud check if the subform is flowed
					LayoutTestReuseComponent.checkIfSubformFlowed(item,type);
					checkIfSubformNormalBinding(item,type);
					traverseNode(item);
				}
			} 
			else if (item.getNodeName().equals("pageSet")) 
			{
				SetParent(item);
				insertSubform(item);
				NodeList masterChild = item.getChildNodes();
				Node masterPageitem = null;
				int masterChildLength = masterChild.getLength();
				for (int j = 0; j < masterChildLength; j++) 
				{
					masterPageitem = masterChild.item(j);
					if (masterPageitem.getNodeName().equals("pageArea"))
					{
						checkIfPageAreaSetting(masterPageitem);
						HandlePageArea(masterPageitem);
					}
				}
				BackTrace();
			}
			// field not in the table
			else if (item.getNodeName().equals("field"))
			{
				insertLeaf(item);
				fieldLayoutAccCorrection(item,FieldLocation.DEFAULT_SUBFORM);
			}
			else if (item.getNodeName().equals("draw"))
			{
				insertLeaf(item);
				drawCorrection(item,FieldLocation.DEFAULT_SUBFORM);
			}
		}
		BackTrace();
	}
	
	private void HandleWithFreeTextBlock(Node node)
	{
		// 2008-10-09: only one draw is allowed in free text block,
		// no nested subform allowed in free text block
		SetParent(node);
		String location = FieldLocation.getLocationDescription(FieldLocation.FREE_TEXT_BLOCK);
		checkIfSubformNormalBinding(node,FieldLocation.FREE_TEXT_BLOCK);
		LayoutTestReuseComponent.checkIfSubformFlowed(node,FieldLocation.FREE_TEXT_BLOCK);
		NodeList children = node.getChildNodes();
		int length = children.getLength();
		String error = null;
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals("subform"))
			{
				// no nested subform allowed
				error = "Field:" + Tool.getAttributeValue("name", node) + ".No Nested Subform Allowed in Free Text Block!";
				ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.NESTED_SUBFORM_IN_FREE,node,location);
				errorObj.SetErrorMessage(error,"Nested Subform Not Allowed!");
				ResultData.add(errorObj);
				continue;
			}
			if( item.getNodeName().equals("field"))
			{
				insertLeaf(item);
				fieldLayoutAccCorrection(item,FieldLocation.FREE_TEXT_BLOCK);
			}
			else if ( item.getNodeName().equals("draw"))
			{
				insertLeaf(item);
				drawCorrection(item,FieldLocation.FREE_TEXT_BLOCK);
			}
		}
		BackTrace();
	}
	public Node SearchNode(DefaultMutableTreeNode node)
	{
		String index = (String)hashMap.get(node);
		System.out.println("Chosen node: " + index);
		if( index == null)
		{
			System.out.println("Attention! " + node.toString() + " not exist in Dom!");
			return SearchBackupNode(node);
		}
		int realIndex = Integer.parseInt(index);
		Node searchedNode = (Node)NodeList.get(realIndex);
		return searchedNode;
	}
	
	
	private Node SearchBackupNode(DefaultMutableTreeNode node)
	{
		int length = ModuleTreeBackUpList.size();
		DefaultMutableTreeNode item = null;
		for( int i = 0; i < length;i++)
		{
			item = (DefaultMutableTreeNode)ModuleTreeBackUpList.get(i);
			if( item.toString().equals(node.toString()) == false)
				continue;
			String index = (String)hashMap.get(item);
			if( index == null)
				continue;
			int realIndex = Integer.parseInt(index);
			Node searchedNode = (Node)NodeList.get(realIndex);
			System.out.println("Seached Node in Backup List: " + realIndex);
			return searchedNode;
		}
		return null;
	}
	private void HandleWithSummaryBlock(Node node)
	{
		NodeList child = node.getChildNodes();
		Node item = null;
		LayoutTestReuseComponent.checkIfSubformFlowed(node,FieldLocation.SUMMARY_BLOCK);
		checkIfSubformNormalBinding(node,FieldLocation.SUMMARY_BLOCK);
		int childLength = child.getLength();
		SetParent(node);
		for(int i = 0; i < childLength;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				if(Tool.isFieldHidden(item))
					continue;
				insertSubform(item);
				HandleWithSummaryBlock(item);
			}
			else if (item.getNodeName().equals("field"))
			{
				insertLeaf(item);
				fieldLayoutAccCorrection(item,FieldLocation.SUMMARY_BLOCK);
			}
			else if (item.getNodeName().equals("draw"))
			{
				insertLeaf(item);
				drawCorrection(item,FieldLocation.SUMMARY_BLOCK);
			}
		}
		BackTrace();
	}

	private void HandleWithInfoBlock(Node node)
	{
		if( Tool.isFieldHidden(node) == true)
		// do not handle with the hidden subform
			return;					
		NodeList child = node.getChildNodes();
		Node item = null;
		LayoutTestReuseComponent.checkIfSubformFlowed(node,FieldLocation.INFO_BLOCK);
		checkIfSubformNormalBinding(node,FieldLocation.INFO_BLOCK);
		SetParent(node);
		int childLength = child.getLength();
		for(int i = 0; i < childLength;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				insertSubform(item);
				HandleWithInfoBlock(item);
			}
			else if (item.getNodeName().equals("field"))
			{
				insertLeaf(item);
				fieldLayoutAccCorrection(item,FieldLocation.INFO_BLOCK);
			}
			else if (item.getNodeName().equals("draw"))
			{
				insertLeaf(item);
				drawCorrection(item,FieldLocation.INFO_BLOCK);
			}
		}
		BackTrace();
	}
	
	private void HandleFooterBlock(Node node)
	{
		LayoutTestReuseComponent.checkIfSubformFlowed(node,FieldLocation.FREE_TEXT_BLOCK);
		checkIfSubformNormalBinding(node,FieldLocation.FREE_TEXT_BLOCK);
		NodeList child = node.getChildNodes();
		SetParent(node);
		Node item = null;
		int childLength = child.getLength();
		for( int i = 0; i < childLength;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform"))
			{
				insertSubform(item);
				HandleFooterBlock(item);
			}
			else if ( item.getNodeName().equals("draw"))
			{
				// should handle footer field
				insertLeaf(item);
			}
		}
		BackTrace();
	}
	
	
	private void HandlePageArea(Node PageArea) 
	{
		NodeList child = PageArea.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		SetParent(PageArea);
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				String SubformName = Tool.getAttributeValue("name",item);
				if( SubformName.equals(ConfigDom.getFooterBlockNamingConvention()))
				{
					insertSubform(item);
					HandleFooterBlock(item);
					continue;
				}
				int type = FieldLocation.getSubformLocation(SubformName);
				if( type == FieldLocation.INFO_BLOCK)
				{
					// this function can handle with all the nodes into that subform
					insertSubform(item);
					HandleWithInfoBlock(item);	
				}
				else // summary block,free text block
				{
					insertSubform(item);
					traverseNode(item);
				}
			} 
			else if (item.getNodeName().equals("field")) 
			{
				insertLeaf(item);
				fieldLayoutAccCorrection(item,FieldLocation.MASTER_PAGE);
			} 
			else if (item.getNodeName().equals("draw")) 
			{
				insertLeaf(item);
				drawCorrection(item,FieldLocation.MASTER_PAGE);
			}
		}
		BackTrace();

	}

	private void checkIfPageAreaSetting(Node node) {
		String SubformName = "";
		if (node.getAttributes().getNamedItem("name") != null) {
			SubformName = node.getAttributes().getNamedItem("name")
					.getNodeValue();
		}
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if (item.getNodeName().equals("medium") == true) {
 
				String stockType = item.getAttributes().getNamedItem("stock")
						.getNodeValue();
				
				if (stockType.equals(ConfigDom.getMasterPageDefaultSetting()) == false) 
				{
					String StockMessage = "Master Page:" + SubformName
							+ " Wrong Page Setting: " + stockType;
					 
					ErrorTraceObject errorObj = new ErrorTraceObject(LayoutErrorType.MASTER_PAGE_SETTING,node,FieldLocation.getLocationDescription(FieldLocation.MASTER_PAGE));
					errorObj.SetErrorMessage(StockMessage,stockType);
					ResultData.add(errorObj);
					return;
				}
			}
		}
	}
	
	private void checkFieldAccessMode(Node node,int type)
	{
		AccessChecker accessChecker = new AccessChecker(node,ResultData,Tool.getAttributeValue("name", node),type);
		accessChecker.check();
	}
	
	private void checkElementAccSetting(Node node,int type)
	{
		AccessibilityChecker accChecker = new AccessibilityChecker(node,ResultData,type);
		accChecker.check();
	}
	private void fieldLayoutAccCorrection(Node node,int type) 
	{
		if( Tool.isFieldHidden(node))
			return;
		String Location = FieldLocation.getLocationDescription(type);
		checkFieldAccessMode(node,type);
		checkElementAccSetting(node,type);
		if( node.getAttributes().getNamedItem("name") == null)
		{
			Tool.ErrorReport("Field in " + Location + "Should have a name!");
			return;
		}
		String name = node.getAttributes().getNamedItem("name").getNodeValue(); 
		if( name.equals(ConfigDom.getFormFieldLogoName()))
		{
			LogoChecker logoChecker = new LogoChecker(node,ResultData);
			logoChecker.CheckFormLogo();
			return;
		}
		NodeList childs = node.getChildNodes();
		Node child_node = null;
		int childLength = childs.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			child_node = childs.item(i);
			// get margin,bind info,acc setting
			if (child_node.getNodeName().equals("margin"))
			{
				MarginChecker marginChecker = new MarginChecker(child_node,ResultData,name,type);
				marginChecker.check();
			}
			// ShouldConsider build-in caption situation
			if (child_node.getNodeName().equals("font"))
			{
				// field value font
				if( Tool.isFieldHidden(node) == false)
				{
					FontChecker fontChecker = new FontChecker(child_node,ResultData,name,type);
					fontChecker.checkValueFontSetting();
				}
			}
			if (child_node.getNodeName().equals("caption"))
			{
				if( Tool.isFieldHidden(node) == false)
				{
					CaptionFontChecker captionChecker = new CaptionFontChecker(child_node,ResultData,name,type);
					captionChecker.check();
					CaptionParaChecker captionParaChecker = new CaptionParaChecker(child_node,ResultData,name,type);
					captionParaChecker.check();
				}
			}
		} // end for 
	}
	
	public void drawCorrection(Node node,int type) 
	{
		if( Tool.isFieldHidden(node))
			return;
		if( Tool.checkPageFieldExist(node))
		{
			PageChecker checker = new PageChecker(node,ResultData);
			checker.check();
		}
		String name = Tool.getAttributeValue("name", node);
		if (name.equals(ConfigDom.getTitleNamingConvention())) 
		{
			TitleChecker titleChecker = new TitleChecker(node,ResultData);
			titleChecker.CheckFormTitle();
			return;
		} 
		else if (name.equals(ConfigDom.getLogoNamingConvention())) 
		{
			LogoChecker logoChecker = new LogoChecker(node,ResultData);
			logoChecker.CheckFormLogo();
			return;
		} 
		else if( name.equals(ConfigDom.getSenderAddressNamingConvention()))
		{
			SenderAddressChecker senderChecker = new SenderAddressChecker(node,ResultData);
			senderChecker.CheckSenderAddress();
			return;
		}
		else if (name.contains(ConfigDom.getSeparatorNamingConvention())) 
		{
			SeperatorChecker sepeChecker = new SeperatorChecker(node,ResultData);
			sepeChecker.CheckFormSeperator();
			return;
		}
		if (node.getNodeType() == Node.ELEMENT_NODE) 
		{
			checkElementAccSetting(node,type);
			NodeList childs = node.getChildNodes();
			Node child_node = null;
			int childLength = childs.getLength();
			for (int i = 0; i < childLength; i++) 
			{
				child_node = childs.item(i);
				if (child_node.getNodeType() == Node.ELEMENT_NODE) 
				{
					if (child_node.getNodeName().equals("margin"))
					{
						MarginChecker marginChecker = new MarginChecker(child_node,ResultData,name,type);
						marginChecker.check();
					}
				}
			}
		}
	}

	public void ModuleTree()
	{
		DefaultMutableTreeNode a = root.getNextNode();
		DefaultMutableTreeNode b = a.getNextNode();
		while(( a != null) && ( b != null))
		{
			if( a.toString().equals(b.toString()))
			{
				if( a.isLeaf())
				{
					// remove a:
					TreeMode.removeNodeFromParent(a);
					ModuleTreeBackUpList.add(a);
					a = b;
					b = b.getNextNode();
				}
				else if( b.isLeaf())
				{
					a = b.getNextNode();
					TreeMode.removeNodeFromParent(b);
					ModuleTreeBackUpList.add(b);
					b = a.getNextNode();
				}
			}
			else
			{
				a = b;
				b = b.getNextNode();
			}
		}
	}
	
	private String GetNodeName(Node node)
	{
		if( node == null)
		{
			System.out.println("Nill!");
			System.exit(0);
		}
		if( node.getAttributes().getNamedItem("name") == null)
			return ConfigDom.getDefaultTreeNodeName();
		return node.getAttributes().getNamedItem("name").getNodeValue();
	}
	
	private void SetParent(Node parent)
	{
		DefaultMutableTreeNode oldParent =  parentNode;
		int childNumber = oldParent.getChildCount();
		if(true )
		{
			parentNode = new DefaultMutableTreeNode(GetNodeName(parent));
			TreeMode.insertNodeInto(parentNode, oldParent,childNumber);
		}
	}
	
	private void BackTrace()
	{
		parentNode = (DefaultMutableTreeNode)parentNode.getParent();	
	}
	
	private void CreateRootNodeForTree(Node Template)
	{
		NodeList child = Template.getChildNodes();
		int Length = child.getLength();
		Node item = null;
		for( int i = 0; i < Length; i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform"))
			{
				root = new DefaultMutableTreeNode(item.getAttributes().getNamedItem("name").getNodeValue());
				TreeMode = new DefaultTreeModel(root);
			}
		}
		parentNode = root;
	}
	private void ResetTreeModel(Node Template)
	{
		TreeMode = null;
		parentNode = null;
		root = null;
		NodeList child = Template.getChildNodes();
		int Length = child.getLength();
		Node item = null;
		for( int i = 0; i < Length; i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform"))
			{
				root = new DefaultMutableTreeNode(item.getAttributes().getNamedItem("name").getNodeValue());
				TreeMode = new DefaultTreeModel(root);
			}
		}
		parentNode = root;
	}
	
	public void StartNewTraverseWithoutCheck()
	{
		Element root = doc.getDocumentElement();
		NodeList doms = root.getChildNodes();
		int length = doms.getLength();
		Node template = null;
		ModuleTreeBackUpList.clear();
		System.out.println("Start a New Traverse");
		NodeIndex = 0;
		NodeList.clear();
		hashMap.clear();
		for (int i = 0; i < length; i++)
		{
			if (doms.item(i).getNodeName().equals("template")) 
			{
				template = doms.item(i);
				ResetTreeModel(template);
				TraverseNodeWithoutCheck(template);
			}
		}
	}
	

	private void TraverseNodeWithoutCheck(Node node)
	{
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		SetParent(node);
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				if( Tool.isFieldHidden(item) == true)
					continue;
				insertSubform(item);
				if( item.getAttributes().getNamedItem("name") == null)
				{
					Tool.ErrorReport("Subform should have a name attribute!");
					continue;
				}
				TraverseNodeWithoutCheck(item);
			} 
			else if (item.getNodeName().equals("pageSet")) 
			{
				NodeList masterChild = item.getChildNodes();
				Node masterPageitem = null;
				SetParent(item);
				insertSubform(item);
				int masterChildLength = masterChild.getLength();
				for (int j = 0; j < masterChildLength; j++) 
				{
					masterPageitem = masterChild.item(j);
					if (masterPageitem.getNodeName().equals("pageArea"))
					{
						TraverseMasterPage(masterPageitem);
					}
				}
				BackTrace();
			}
			// field not in the table
			else if (item.getNodeName().equals("field"))
			{
				insertLeaf(item);
			}
			else if (item.getNodeName().equals("draw"))
			{
				insertLeaf(item);
			}
		}
		BackTrace();
	}
	private void TraverseMasterPage(Node PageArea) 
	{
		NodeList child = PageArea.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		SetParent(PageArea);
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				insertSubform(item);
				TraverseMasterPage(item);
			} 
			else if (item.getNodeName().equals("field")) 
			{
				insertLeaf(item);
			} 
			else if (item.getNodeName().equals("draw")) 
			{
				insertLeaf(item);
			}
		}
		BackTrace();
	}
	public DefaultTreeModel getTreeMode()
	{
		return TreeMode;
	}
	
	// add the subform to its parent
	private void insertSubformbyName(String subformName,Node node)
	{
		DefaultMutableTreeNode child = new DefaultMutableTreeNode(subformName);
		int index = parentNode.getChildCount();
		TreeMode.insertNodeInto(child, parentNode, index);
		NodeList.add(node);
		String nodeindex = ""+ NodeIndex++;
		hashMap.put(child,nodeindex);
	}
	
	private void insertSubform(Node subform)
	{
		insertSubformbyName(GetNodeName(subform),subform);
	}
	
	private void insertLeaf(Node field)
	{
		String name = GetNodeName(field);
		DefaultMutableTreeNode child = new DefaultMutableTreeNode(name);
		parentNode.add(child);
		NodeList.add(field);
		String nodeindex = ""+ NodeIndex++;
		hashMap.put(child,nodeindex);
	}
}
