package layoutTest.internalStructure;



public class OperationLog
{
	public  ErrorTraceObject errObj;
	public 	String UserInput;
	public  int iIndexinListbox;
	
	public OperationLog(ErrorTraceObject obj,String input,int index)
	{
		errObj = obj;
		UserInput = input;
		iIndexinListbox = index;
	}
}