package layoutTest.internalStructure;

import org.w3c.dom.Node;



public class ErrorTraceObject
{
	public  String ErrorMessage;
	public  int ErrorType = -1;
	public 	Node NodeTobeModified;
	public  String Location;
	public  int index = -1;				// internal use
	public  String ErrorDetail;

	public Node getNode()
	{
		return NodeTobeModified;
	}
	
	public ErrorTraceObject(String message,int type,Node node,String loc)
	{
		ErrorMessage = message;
		ErrorType = type;
		NodeTobeModified = node;
		Location = loc;
	}
	
	public ErrorTraceObject(int type,Node node,String loc)
	{
		ErrorMessage = null;
		ErrorType = type;
		NodeTobeModified = node;
		Location = loc;
	}
	
	private String FetchNamefromErrorMessage()
	{
		int index = ErrorMessage.indexOf('.');
		System.out.println("Error: " + ErrorMessage);
		if( index == -1)
		{
			System.out.println("There must be a space between Name and Description");
			return null;
		}
		if( ErrorMessage.contains("Field:"))
		{
			String name = ErrorMessage.substring(6,index);
			System.out.println("Name:" + name);
			name = name.trim();
			return name;
		}
		else if( ErrorMessage.contains("Draw:"))
		{
			String name = ErrorMessage.substring(5,index);
			System.out.println("Name:" + name);
			name = name.trim();
			return name;
		}
		else if( ErrorMessage.contains("Subform:"))
		{
			String name = ErrorMessage.substring(8,index);
			System.out.println("Name:" + name);
			name = name.trim();
			return name;
		}
		return null;
	}
	
	public void SetErrorMessage ( String mess,String wrong)
	{
		ErrorMessage = mess;
		ErrorDetail = wrong;
		//System.out.println("ErrorMessage: " + ErrorMessage);
	}
	public void SetErrorMessage(String mess)
	{
		ErrorMessage = mess;
	}
	
	public String GetErrorNodeName()
	{
		if( NodeTobeModified == null)
			return FetchNamefromErrorMessage();
		if( NodeTobeModified.getAttributes() == null)
			return FetchNamefromErrorMessage();
		if( NodeTobeModified.getAttributes().getNamedItem("name") == null)
			return FetchNamefromErrorMessage();
		return NodeTobeModified.getAttributes().getNamedItem("name").getNodeValue();
	}
}