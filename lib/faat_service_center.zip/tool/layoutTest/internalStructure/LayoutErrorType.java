package layoutTest.internalStructure;

public class LayoutErrorType
{
	static public final int ACC_SETTING = 1;
	
	static public final int MARGIN_SETTING = 2;
	
	static public final int FONT_SIZE_SETTING = 3;
	
	static public final int FORM_TITLE_WIDTH_SETTING = 4;
	
	static public final int TABLE_CELL_AUTOFIT = 5;
	
	static public final int VALUE_TYPE_SETTING = 6;
	
	static public final int SUBFORM_NORMAL_BINDING = 7;
	
	static public final int SUBFORM_FLOW_SETTING = 8;
	
	static public final int MASTER_PAGE_SETTING = 9;
	
	static public final int FIELD_BOLD_OR_REGULAR = 10;
	
	static public final int FONT_TYPE_SETTING = 11;
	
	static public final int FORM_LOGO_ACC_SETTING = 12;
	
	static public final int SEPERATOR_HEIGHT_SETTING = 13;
	
	static public final int FORM_LOGO_WIDTH = 14;
	
	static public final int FORM_LOGO_HEIGHT = 15;
	
	static public final int FORM_TITLE_AUTO_WIDTH_FIT = 16;
	
	static public final int FORM_TITLE_AUTO_HEIGHT_FIT = 17;
	
	static public final int FORM_TITLE_COLOR_SETTING = 18;
	
	static public final int SEPERATOR_LINE_COLOR_SETTING = 21;
	
	static public final int SEPERATOR_FILL_COLOR_SETTING = 22;
	
	static public final int TABLE_CELL_MULTILINES = 24;
	
	static public final int H_ALIGN_SETTING = 25;
	
	static public final int V_ALIGN_SETTING = 26;
	
	static public final int FORM_TITLE_HEIGHT_SETTING = 27;
	
	static public final int TABLE_SUBFORM_FILL_COLOR = 28;
	
	static public final int PAGE_HEIGHT_EXPAND = 29;
	
	static public final int PAGE_WIDTH_EXPAND = 30;
	
	static public final int TABLE_HEADER_DRAW = 31;
	
	static public final int NO_DATA_VIEW = 32;
	
	static public final int XSD_LINK_EXIST = 33;
	
	static public final int DATA_FILE_LINK_EXIST = 34;
	
	static public final int NESTED_SUBFORM_IN_FREE = 35;
	
	static public final int FORM_MAX_ERROR_TYPE = 36;
}