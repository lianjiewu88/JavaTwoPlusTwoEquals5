package layoutTest.correctionDetail;


import java.util.Vector;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.Tool;




public class TableColumnAdjustor
{
	private Node rootNode = null;
	private String newColumnWidth = " ";
	public TableColumnAdjustor(Node node)
	{
		rootNode = node;
	}
	public void StartAdjustment(int left,int right)
	{
		ChangeColumn(left,right,rootNode);
		ReCaculateColumnWidth();
	}
	
	private void ReCaculateColumnWidth()
	{
		if( true)
			return;
		NodeList child = rootNode.getChildNodes();
		System.out.println("root: " + rootNode.getAttributes().getNamedItem("name").getNodeValue());
		int length = child.getLength();
		Node item = null;
		for( int i = 0; i<length; i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("subform"))
				continue;
			String Name = item.getAttributes().getNamedItem("name").getNodeValue();
			if(Name.substring(0,3).equals("hdr"))
				getNewColumnWidth(item);
		}
		System.out.println("New Column Width: " + newColumnWidth);
	}
	
	private void getNewColumnWidth(Node node)
	{
		System.out.println("In getNewColumnWidth()");
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0; i < length;i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("draw"))
				continue;
			System.out.println("Widht: " + item.getAttributes().getNamedItem("w").getNodeValue()); 
		}
	}
	
	private String getSubformName(Node node)
	{
		if( node.getAttributes().getNamedItem("name") == null)
			return "UnNamed Subform";
		return node.getAttributes().getNamedItem("name").getNodeValue();
	}
	
	private void ChangeColumn(int left,int right,Node root)
	{
		// traverse the whole table
		NodeList tablenodes = root.getChildNodes();
		int Length = tablenodes.getLength();
		Node item = null;
		for(int i = 0;i < Length;i++)
		{
			item = tablenodes.item(i);
			if( item.getNodeName().equals("subform") == false)
				continue;
			if( Tool.isFieldHidden(item) == true)
				continue;
			System.out.println("Subform name: " + item.getAttributes().getNamedItem("name").getNodeValue());
			NodeList SubNode = item.getChildNodes();
			Node leftNode = null;
			Node rightNode = null;
			Node Cellitem = null;
			Vector<Node> temp = new Vector<Node>();
			int length = SubNode.getLength();
			
			for(int j = 0; j < length; j++)
			{
				Cellitem = SubNode.item(j);
				if(( Cellitem.getNodeName().equals("draw")) || ( Cellitem.getNodeName().equals("field")) )
				{
					temp.add(Cellitem);
				}
				else if( Cellitem.getNodeName().equals("subform") || ( Cellitem.getNodeName().equals("subformSet")))
				{
					if( Tool.isFieldHidden(Cellitem) == true)
						continue;
					System.out.println("begin into Subform: " + getSubformName(Cellitem));
					ChangeColumn(left,right,Cellitem);
				}
			}
			System.out.println("Vector size: " + temp.size() + " Subform: " + getSubformName(item));
			if( temp.size() == 0)
				continue;
			leftNode = (Node)temp.elementAt(left);
			rightNode = (Node)temp.elementAt(right);
			Node postfixRight = null;
			System.out.println("LeftNode: " + leftNode.getAttributes().getNamedItem("name").getNodeValue());
			System.out.println("RightNode: " + rightNode.getAttributes().getNamedItem("name").getNodeValue());
			if( right - left == 1)
			{
				Node newright = rightNode.cloneNode(true);
				item.removeChild(rightNode);
				item.insertBefore(newright, leftNode);
				ChangeColumn(left,right,item);
			}
			else
			{
				if( right + 1 == temp.size())
					postfixRight = null;
				else
					postfixRight = (Node)temp.elementAt(right+1);
				Node postfixLeft = (Node)temp.elementAt(left+1);
				// put left before the postfix right node
				// put right before the postfix left node
				Node newLeft = leftNode.cloneNode(true);
				item.removeChild(leftNode);
				if( postfixRight == null)
					item.appendChild(newLeft);
				else
					item.insertBefore(newLeft, postfixRight);
				Node newRight = rightNode.cloneNode(true);
				item.removeChild(rightNode);
				item.insertBefore(newRight, postfixLeft);
				
				//ChangeColumn(left,right,item);
			}
		}// end for loop
	}
}
