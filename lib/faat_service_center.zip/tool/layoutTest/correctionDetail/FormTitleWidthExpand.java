package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import utilities.Tool;

import configuration.ConfigDom;

public class FormTitleWidthExpand

{
	private Node mNode;
	private String Width; // dummy
	private int errorType = -1;
	public FormTitleWidthExpand (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
		errorType = errObj.ErrorType;
	}
	
	public String getWidthExpandSetting()
	{
		return Width;
	}
	public String getUserInputData()
	{
		String desp = null;
		String title = null;
		if( errorType == LayoutErrorType.FORM_TITLE_AUTO_WIDTH_FIT)
		{
			desp = "Form Title Width Do not Expand to fit";
			title = "Form Title Width Correction";
		}
		else if ( errorType == LayoutErrorType.PAGE_WIDTH_EXPAND)
		{
			desp = "Page Index Width Do not Expand to fit";
			title = "Page Index Width Correction";
		}
	    String[] ValueOption = new String[] { "Width DO NOT Expand to fit" };
	    Width = (String) JOptionPane.showInputDialog(
	        new JFrame(),desp,title, JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), ValueOption, "Width DO NOT Expand to fit");
	    return Width;
	 }
	
	public boolean Correction()
	{
		if( Width == null)
			return false;
		String correctWidth = Tool.getAttributeValue("minW",mNode);
		mNode.getAttributes().removeNamedItem("minW");
		Document HDocument = mNode.getOwnerDocument();
		Attr HAttr = HDocument.createAttribute("w");
		if( errorType == LayoutErrorType.FORM_TITLE_AUTO_WIDTH_FIT)
			correctWidth = ConfigDom.getStandardFormTitleWidth() + "mm";
		HAttr.setNodeValue(correctWidth);
		Element HElment = (Element)mNode;
		HElment.setAttributeNode(HAttr);
		return true;
	}
}