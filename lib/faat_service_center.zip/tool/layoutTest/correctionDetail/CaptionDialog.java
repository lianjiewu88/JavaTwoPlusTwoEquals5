package layoutTest.correctionDetail;

import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.Tool;

import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.util.Vector;

public class CaptionDialog extends JDialog {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JTextField jNewCaption1 = null;

	private JPanel jButtonPanel = null;

	private JButton jOKButton = null;

	private JButton jCancelButton = null;

	private JLabel jOldLabel = null;

	private JLabel jNewLabel = null;
	
	private Node changeNode = null;
	
	private String oldCaption = null;  //  @jve:decl-index=0:

	private JLabel jOldCaptionLabel = null;
	
	private boolean isChangeOK = false;

	private JTextField jNewCaption2 = null;

	private JTextField jNewCaption3 = null;

	private JTextField jNewCaption4 = null;

	/**
	 * This method initializes jNewCaption1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJNewCaption1() {
		if (jNewCaption1 == null) {
			jNewCaption1 = new JTextField();
			jNewCaption1.setBounds(new Rectangle(0, 90, 416, 20));
		}
		return jNewCaption1;
	}
	private void CloseDialog()
	{
		this.dispose();
	}
	public boolean isStatusChangeOK()
	{
		return isChangeOK;
	}
	
	/**
	 * This method initializes jButtonPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJButtonPanel() {
		if (jButtonPanel == null) {
			jButtonPanel = new JPanel();
			jButtonPanel.setLayout(new FlowLayout());
			jButtonPanel.setBounds(new Rectangle(0, 177, 414, 33));
			jButtonPanel.add(getJOKButton(), null);
			jButtonPanel.add(getJCancelButton(), null);
		}
		return jButtonPanel;
	}

	/**
	 * This method initializes jOKButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private Vector getNewCaptionInput()
	{
		Vector<String> newInput = new Vector<String>();
		JTextField[] array = {jNewCaption1,jNewCaption2,jNewCaption3,jNewCaption4};
		for(int i = 0 ; i < 4; i++)
		{
			String content = array[i].getText();
			if( content != null)
				newInput.add(content);
		}
		return newInput;
	}
	private JButton getJOKButton() {
		if (jOKButton == null) {
			jOKButton = new JButton();
			jOKButton.setPreferredSize(new Dimension(75, 23));
			jOKButton.setText("OK");
			jOKButton.addActionListener(new java.awt.event.ActionListener() {   
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{    
					Vector newInput = getNewCaptionInput();
					CaptionAdjustor cAdjustor = new CaptionAdjustor(changeNode,newInput);
					isChangeOK = cAdjustor.StartCaptionAdjust();
					CloseDialog();
				}
			
			});
		}
		return jOKButton;
	}

	/**
	 * This method initializes jCancelButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJCancelButton() {
		if (jCancelButton == null) {
			jCancelButton = new JButton();
			jCancelButton.setPreferredSize(new Dimension(75, 23));
			jCancelButton.setText("Cancel");
			jCancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					CloseDialog();
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jCancelButton;
	}

	/**
	 * @param owner
	 */
	public CaptionDialog(Frame owner,Node node) 
	{
		super(owner);
		changeNode = node;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(423, 243);
		this.setContentPane(getJContentPane());
		this.setTitle("Change Text Dialog");
		GetOldCaption();
		if( oldCaption != null)
			jOldCaptionLabel.setText(oldCaption);
		//jNewCaption1.setText(oldCaption);
			
	}
	private void ShowNewInputField(Vector multiText)
	{
		if( multiText.isEmpty())
			return;
		int size = multiText.size();
		System.out.println("Text Number: " + size);
		String content = null;
		JTextField[] array = {jNewCaption1,jNewCaption2,jNewCaption3,jNewCaption4};
		//for( int i = 0; i < size;i++)
		// currently we can only modify 4 text due to limit of window
		for( int i = 0 ; i < 4;i++)
		{
			content = (String)multiText.elementAt(i);
			array[i].setText(content);
		}
		for( int j = size; j < 4;j++)
			array[j].setVisible(false);
	}
	
	private boolean isSpaceRunNode(Node node)
	{
		if( node.getAttributes() == null)
			return false;
		if( node.getAttributes().getNamedItem("style") == null)
			return false;
		if( node.getAttributes().getNamedItem("style").getNodeValue().equals("xfa-spacerun:yes"))
			return true;
		return false;
	}
	
	// input node : p node
	private void getTextValue(Node Pnode,Vector<String> TextList)
	{
		Vector<String> temp = TextList;
		NodeList child = Pnode.getChildNodes();
		int length = child.getLength();
		Node item = null;
		String Value = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("#text"))
			{
				Value = item.getNodeValue();
				if( Value == null)
					continue;
				String formatedValue = Value.trim();
				if( formatedValue.equals("") || ( formatedValue.equals(" ")))
					continue;
				temp.add(item.getNodeValue());
				System.out.println("Adding......."  + i + ":  " + item.getNodeValue());
			}
			else if ( item.getNodeName().equals("span"))
			{
				if( isSpaceRunNode(item))
					continue;
				NodeList spanChild = item.getChildNodes();
				int spanLength = spanChild.getLength();
				Node subItem = null;
				for( int j = 0; j < spanLength;j++)
				{
					subItem = spanChild.item(j);
					if( !subItem.getNodeName().equals("#text"))
						continue;
					Value = subItem.getNodeValue();
					if( Value == null)
						continue;
					temp.add(Value);
				}
			}
		}
	}
	private void GetDrawCaption()
	{
		Node ValueNode = Tool.getNodebyRoot("value",changeNode);
		Node textNode = Tool.getNodebyRoot("text",ValueNode);
		if(textNode == null)
		{
			Node exDataNode = Tool.getNodebyRoot("exData",ValueNode);
			Node bodyNode = Tool.getNodebyRoot("body",exDataNode);
			NodeList child = bodyNode.getChildNodes();
			int length = child.getLength();
			Node item = null;
			Vector<String> multiText = new Vector<String>();
			for(int i = 0; i < length;i++)
			{
				item = child.item(i);
				if( item.getNodeName().equals("p"))
				{
					String content = item.getTextContent();
					getTextValue(item,multiText);
					oldCaption = " " + content;
				}
			}
			ShowNewInputField(multiText);
		}
		else
		{
			oldCaption = " " + textNode.getTextContent();
			jNewCaption1.setText(oldCaption);
			jNewCaption2.setVisible(false);
			jNewCaption3.setVisible(false);
			jNewCaption4.setVisible(false);
			
		}
	}
	private void GetOldCaption()
	{
		if( changeNode.getNodeName().equals("draw"))
			GetDrawCaption();
		else if( changeNode.getNodeName().equals("field"))
			GetFieldCaption();
	}
	private void GetFieldCaption()
	{
		Node captionNode = Tool.getNodebyRoot("caption",changeNode);
		Node valueNode = Tool.getNodebyRoot("value",captionNode);
		oldCaption = " " + Tool.getNodebyRoot("text",valueNode).getTextContent();
		jNewCaption1.setText(oldCaption);
		jNewCaption2.setVisible(false);
		jNewCaption3.setVisible(false);
		jNewCaption4.setVisible(false);
	}
	
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jOldCaptionLabel = new JLabel();
			jOldCaptionLabel.setBounds(new Rectangle(0, 19, 416, 40));
			jOldCaptionLabel.setText("");
			jNewLabel = new JLabel();
			jNewLabel.setBounds(new Rectangle(0, 58, 155, 19));
			jNewLabel.setText("  Input New Caption Name:");
			jOldLabel = new JLabel();
			jOldLabel.setBounds(new Rectangle(-1, 0, 122, 20));
			jOldLabel.setText("  Old Caption Name:");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJNewCaption1(), null);
			jContentPane.add(getJButtonPanel(), null);
			jContentPane.add(jOldLabel, null);
			jContentPane.add(jNewLabel, null);
			jContentPane.add(jOldCaptionLabel, null);
			jContentPane.add(getJNewCaption2(), null);
			jContentPane.add(getJNewCaption3(), null);
			jContentPane.add(getJNewCaption4(), null);
		}
		return jContentPane;
	}
	/**
	 * This method initializes jNewCaption2	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJNewCaption2() {
		if (jNewCaption2 == null) {
			jNewCaption2 = new JTextField();
			jNewCaption2.setBounds(new Rectangle(0, 110, 416, 20));
		}
		return jNewCaption2;
	}
	/**
	 * This method initializes jNewCaption3	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJNewCaption3() {
		if (jNewCaption3 == null) {
			jNewCaption3 = new JTextField();
			jNewCaption3.setBounds(new Rectangle(0, 130, 416, 20));
		}
		return jNewCaption3;
	}
	/**
	 * This method initializes jNewCaption4	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJNewCaption4() {
		if (jNewCaption4 == null) {
			jNewCaption4 = new JTextField();
			jNewCaption4.setBounds(new Rectangle(0, 150, 416, 20));
		}
		return jNewCaption4;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
