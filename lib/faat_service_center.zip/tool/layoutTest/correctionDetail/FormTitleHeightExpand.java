package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import configuration.ConfigDom;
 


public class FormTitleHeightExpand
{
	// reuse for page
	private Node mNode;
	private String Height; 
	private int errorType = -1;
	public FormTitleHeightExpand (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
		errorType = errObj.ErrorType;
	}
	
	public String getExpandSetting()
	{
		return Height;
	}
	public String getUserInputData()
	{
		String desp = null;
		String title = null;
		if( errorType == LayoutErrorType.FORM_TITLE_AUTO_HEIGHT_FIT)
		{
			desp = "Form Title Height Do not Expand to fit";
			title = "Form Title Height Correction";
		}
		else if ( errorType == LayoutErrorType.PAGE_HEIGHT_EXPAND)
		{
			desp = "Page Index height Do not Expand to fit";
			title = "Page Index Height Correction";
		}
	    String[] ValueOption = new String[] { "Height DO NOT Expand to fit" };
	    Height = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        desp,title,JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), ValueOption, "Height DO NOT Expand to fit");
	    return Height;
	 }
	
	public boolean Correction()
	{
		if( Height == null)
			return false;
		String correctHeight = null;
		mNode.getAttributes().removeNamedItem("minH");
		Document HDocument = mNode.getOwnerDocument();
		Attr HAttr = HDocument.createAttribute("h");
		if( errorType == LayoutErrorType.FORM_TITLE_AUTO_HEIGHT_FIT)
			correctHeight = ConfigDom.getStandardFormTitleHeight() + "mm";
		else if ( errorType == LayoutErrorType.PAGE_HEIGHT_EXPAND)
			correctHeight = ConfigDom.getStandardPageIndexHeight() + "mm";
		else
			return false;
		HAttr.setNodeValue(correctHeight);
		Element HElment = (Element)mNode;
		HElment.setAttributeNode(HAttr);
		return true;
	}
}