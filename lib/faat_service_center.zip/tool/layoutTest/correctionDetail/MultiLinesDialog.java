package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/* Currently only allow add mutiline and height auto to fit,
 * the cancel function is to be added in the future.
 */


public class MultiLinesDialog

{
	private Node mNode;
	private String isAllowMutiLine ;
	//public String isAllowHeightAutoFit ;
	public MultiLinesDialog (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
	}
	
	public String getLineSetting()
	{
		return isAllowMutiLine;
	}
	public void getUserInputData()
	{
		JFrame WrapFrame = new JFrame();
	    String[] MutiLineOption = new String[] { "YES", "NO"};
	    isAllowMutiLine = (String) JOptionPane.showInputDialog(
	        WrapFrame,
	        "Please choose whether the field allows mutiple lines or not ",
	        "Field Layout Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), MutiLineOption, "YES");
	    
	    /*String[] HeightOption = new String[] { "YES", "NO"};
	    isAllowHeightAutoFit = (String) JOptionPane.showInputDialog(
		        WrapFrame,
		        "Please Choose whether the field height allows auto to fit ",
		        "Field Layout Correction", JOptionPane.INFORMATION_MESSAGE,
		        new ImageIcon("java2sLogo.GIF"), HeightOption, "YES");
	    */
	 }
	
	private void SetAllowMultiLine()
	{
		NodeList child = mNode.getChildNodes();
		Node item = null;
		for( int i = 0; i < child.getLength(); i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("ui"))
			{
				Node grandson = null;
				NodeList grand = item.getChildNodes();
				for( int j = 0 ; j < grand.getLength(); j ++)
				{
					grandson = grand.item(j);
					if( grandson.getNodeName().equals("textEdit"))
					{
						if( isAllowMutiLine.equals("NO") )
							return;
						Document FontDocument = grandson.getOwnerDocument();
						Attr SizeAttr = FontDocument.createAttribute("multiLine");
						SizeAttr.setNodeValue("1");
						Element FontElement = (Element)grandson;
						FontElement.setAttributeNode(SizeAttr);
					}
				}
			}
		}
	}
	
	
	/*public void SetHeightAutoFit()
	{
		if( mNode.getAttributes().getNamedItem("h") == null)
		{
			// already height auto to fit!
			return;
		}
		String originHeight = mNode.getAttributes().getNamedItem("h").getNodeValue();
		mNode.getAttributes().removeNamedItem("h");
		Document FontDocument = mNode.getOwnerDocument();
		Attr MinHAttr = FontDocument.createAttribute("minH");
		MinHAttr.setNodeValue(originHeight);
		Element FontElement = (Element)mNode;
		FontElement.setAttributeNode(MinHAttr);
	}
	*/
	
	public boolean Correction()
	{
		// do the main correction here!
		//if(( isAllowMutiLine == null ) && ( isAllowHeightAutoFit == null))
		//if( isAllowHeightAutoFit == null )
		//	return false;
		if( isAllowMutiLine == null)
			return false;
		SetAllowMultiLine();
		//if ( isAllowHeightAutoFit != null )
		//	SetHeightAutoFit();
		return true;
	}
 
	

}