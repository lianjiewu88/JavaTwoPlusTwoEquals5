package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
 



public class FieldValueDialog

{
	private Node mNode;
	private String ValueAccess;
	public FieldValueDialog (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
	}
	
	public String getUserInputData()
	{
	    String[] ValueOption = new String[] { "User entered-Optional", "User entered-Recommended",
	        "User entered-Required", "Calculated-Read Only","Calculated-User can override","Read Only" };
	    ValueAccess = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Please select the right setting for Value Type",
	        "Value Type Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), ValueOption, "Read Only");
	    System.out.println("User's input: " + ValueAccess);

	    return ValueAccess;
	 }
	public String getAccessMode()
	{
		return ValueAccess;
	}
	
	public boolean Correction()
	{
		if( ValueAccess == null)
			return false;
		if( !ValueAccess.equals("Read Only"))
		{
			   String message = "The Correct Setting of the field\n"
			        + "Should be ReadOnly\n";
			    JOptionPane.showMessageDialog(new JFrame(), message, "ERROR",
			        JOptionPane.ERROR_MESSAGE);
			   return false;
		}
		// do the main correction here!
		// Currently should only set to ReadOnly!
		Document FieldDocument = mNode.getOwnerDocument();
		Attr Access = FieldDocument.createAttribute("access");
		Access.setNodeValue("readOnly");
		Element temp = (Element)mNode;
		temp.setAttributeNode(Access);
		return true;
	}
}