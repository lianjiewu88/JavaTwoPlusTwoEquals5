package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
 



public class HAlignDialog

{
	private Node mNode;
	private String hAlignSetting; 
	public HAlignDialog(ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
	}
	
	public String getHAlignSetting()
	{
		return hAlignSetting;
	}
	public String getUserInputData()
	{
	    String[] ValueOption = new String[] { "Left-Aligned","Right-Aligned" };
	    hAlignSetting = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Choose the Correct Alignment Setting",
	        "Alignment Setting Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), ValueOption, "Left-Aligned");
	    System.out.println("User's input: " + hAlignSetting);

	    return hAlignSetting;
	 }
	
	public boolean Correction()
	{
		if( hAlignSetting == null)
			return false;
		if( hAlignSetting.equals("Left-Aligned"))
		// previous setting should only be middle or right,delete the para node
		{
			mNode.getAttributes().removeNamedItem("hAlign");
			return true;
		}
		// right-aligned,two situations
		if( mNode.getAttributes().getNamedItem("hAlign") != null)
		{
			// from middle to right
			mNode.getAttributes().getNamedItem("hAlign").setNodeValue("right");
			return true;
		}
		// from left to right,should create a node called hAlign
		Document hAlignDocument = mNode.getOwnerDocument();
		Attr hAlignAttr = hAlignDocument.createAttribute("hAlign");
		hAlignAttr.setNodeValue("right");
		Element hAlignElement = (Element)mNode;
		hAlignElement.setAttributeNode(hAlignAttr);
		return true;
	}
}