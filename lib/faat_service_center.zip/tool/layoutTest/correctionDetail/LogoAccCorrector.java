package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;


public class LogoAccCorrector

{
	private Node mNode;
	private String CorrectAcc;
	public LogoAccCorrector (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
	}
	
	public String getLogoAcc()
	{
		return CorrectAcc;
	}
	
	public String getUserInputData()
	{
	    String[] plays = new String[] { "None", "Caption",
	        "ToolTip", "Custom Text" };
	    CorrectAcc = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Please select the right setting for accessibility ",
	        "Accessibility Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), plays, "SAP Form Team");
	    System.out.println("User's input: " + CorrectAcc);

	    return CorrectAcc;
	 }
	
	private void CorrectionFromCustomToNone()
	{
		System.out.println("Custom->None!");
		Document AssistNodeParentDocument = mNode.getOwnerDocument();
		Element AssistNode = AssistNodeParentDocument.createElement("assist");
		Element speakNode = AssistNodeParentDocument.createElement("speak");
		AssistNode.appendChild(speakNode);
		Attr disable = AssistNodeParentDocument.createAttribute("disable");
		disable.setNodeValue("1");
		speakNode.setAttributeNode(disable);
		mNode.appendChild(AssistNode);
	}
	
	private void CorrectionToNone()
	{
		NodeList child = mNode.getChildNodes();
		Node item = null;
		System.out.println("Child Number: " + child.getLength());
		for( int i = 0; i < child.getLength(); i++)
		{
			item = child.item(i);
			System.out.println("Child name: " + item.getNodeName().toString());
			if( item.getNodeName().equals("assist"))
			{
				Node grandson = null;
				NodeList grand = item.getChildNodes();
				for( int j = 0 ; j < grand.getLength(); j ++)
				{
					grandson = grand.item(j);
					if( grandson.getNodeName().equals("speak"))
					// Speak Node found!
					{
						System.out.println("VC:" + grandson.getAttributes().
								getNamedItem("priority").getNodeValue());
						
						Document AssistNodeDocument = item.getOwnerDocument();
						Element newNode = AssistNodeDocument.createElement("speak");
					    Attr disable = AssistNodeDocument.createAttribute("disable");
					    disable.setNodeValue("1");
					    newNode.setAttributeNode(disable);
						item.replaceChild(newNode, grandson);
						return;
					}
				}
			}
		}
		// none Assist Node found ,so the original Setting is custom
		// should create a new node
		CorrectionFromCustomToNone();
		return;
		
	}
	
	private void CorrectionToCaption()
	{
		NodeList child = mNode.getChildNodes();
		Node item = null;
		System.out.println("Child Number: " + child.getLength());
		for( int i = 0; i < child.getLength(); i++)
		{
			item = child.item(i);
			System.out.println("Child name: " + item.getNodeName().toString());
			if( item.getNodeName().equals("assist"))
			{
				Node grandson = null;
				NodeList grand = item.getChildNodes();
				for( int j = 0 ; j < grand.getLength(); j ++)
				{
					grandson = grand.item(j);
					if( grandson.getNodeName().equals("speak"))
					{
						if( grandson.getAttributes().getNamedItem("disable") != null)
						{
							// none -> Caption
							Document AssistNodeDocument = item.getOwnerDocument();
							Element newNode = AssistNodeDocument.createElement("speak");
							Attr Priority = AssistNodeDocument.createAttribute("priority");
							Priority.setNodeValue("caption");
							newNode.setAttributeNode(Priority);
							item.replaceChild(newNode, grandson);
							return;
						}
						else
						{
							// name,tooltip -> caption
							grandson.getAttributes().getNamedItem("priority").setNodeValue("caption");
							return;
						}
					}
				}
				// custom -> caption
				
			}
		}
		// none Assist Node found ,so the original Setting is custom
		// should create a new node
		CorrectionFromCustomToCaption();
		return;
		
	}
	
	private void CorrectionFromCustomToCaption()
	{
		System.out.println("Custom->Caption!");
		Document AssistNodeParentDocument = mNode.getOwnerDocument();
		Element AssistNode = AssistNodeParentDocument.createElement("assist");
		Element speakNode = AssistNodeParentDocument.createElement("speak");
		AssistNode.appendChild(speakNode);
		Attr priority = AssistNodeParentDocument.createAttribute("priority");
		priority.setNodeValue("caption");
		speakNode.setAttributeNode(priority);
		mNode.appendChild(AssistNode);
	}

	private void CorrectionToToolTip()
	{
		NodeList child = mNode.getChildNodes();
		Node item = null;
		System.out.println("Child Number: " + child.getLength());
		for( int i = 0; i < child.getLength(); i++)
		{
			item = child.item(i);
			System.out.println("Child name: " + item.getNodeName().toString());
			if( item.getNodeName().equals("assist"))
			{
				Node grandson = null;
				NodeList grand = item.getChildNodes();
				for( int j = 0 ; j < grand.getLength(); j ++)
				{
					grandson = grand.item(j);
					if( grandson.getNodeName().equals("speak"))
					{
						if( grandson.getAttributes().getNamedItem("disable") != null)
						{
							// none -> Tooltip
							Document AssistNodeDocument = item.getOwnerDocument();
							Element newNode = AssistNodeDocument.createElement("speak");
							Attr Priority = AssistNodeDocument.createAttribute("priority");
							Priority.setNodeValue("toolTip");
							newNode.setAttributeNode(Priority);
							item.replaceChild(newNode, grandson);
							return;
						}
						else
						{
							// name,tooltip -> tooltip
							grandson.getAttributes().getNamedItem("priority").setNodeValue("toolTip");
							return;
						}
					}
				}
				// custom -> ToolTip
				
			}
		}
		// none Assist Node found ,so the original Setting is custom
		// should create a new node
		CorrectionFromCustomToToolTip();
		return;
		
	}

	private void CorrectionFromCustomToToolTip()
	{
		System.out.println("Custom->ToolTip!");
		Document AssistNodeParentDocument = mNode.getOwnerDocument();
		Element AssistNode = AssistNodeParentDocument.createElement("assist");
		Element speakNode = AssistNodeParentDocument.createElement("speak");
		AssistNode.appendChild(speakNode);
		Attr priority = AssistNodeParentDocument.createAttribute("priority");
		priority.setNodeValue("toolTip");
		speakNode.setAttributeNode(priority);
		mNode.appendChild(AssistNode);
	}
	public boolean Correction()
	{
		System.out.println(" in Correction()");
		// do the main correction here!
		if( CorrectAcc == null)
			return false;
		if ( CorrectAcc.equals("None"))
			CorrectionToNone();
		else if( CorrectAcc.equals("Caption"))
			CorrectionToCaption();
		else if( CorrectAcc.equals("ToolTip"))
			CorrectionToToolTip();
		return true;
	}
}