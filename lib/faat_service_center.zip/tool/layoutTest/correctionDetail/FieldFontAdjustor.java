package layoutTest.correctionDetail;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;




public class FieldFontAdjustor
{
	private Node rootNode = null;
	private String newFontSetting = null;
	public FieldFontAdjustor(Node node,String newFont)
	{
		rootNode = node;
		newFontSetting = newFont;
	}
	public void DoFontChange()
	{
		NodeList child = rootNode.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length; i ++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("font"))
			{
				if( item.getAttributes().getNamedItem("typeface") == null )
					continue;
				item.getAttributes().getNamedItem("typeface").setNodeValue(newFontSetting);
			}
			if( item.getNodeName().equals("caption"))
			{
				ChangeCaptionFont(item);
			}
		}
	}
	private void ChangeCaptionFont(Node node)
	{
		NodeList child = rootNode.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length; i ++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("font"))
			{
				if( item.getAttributes().getNamedItem("typeface") == null )
					return;
				item.getAttributes().getNamedItem("typeface").setNodeValue(newFontSetting);
			}
		}
	}
	
}
