package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;



public class SubformLayoutDialog

{
	private Node mNode;
	private String LayoutType;
	public SubformLayoutDialog (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
	}
	
	public String getLayoutSetting()
	{
		return LayoutType;
	}
	public String getUserInputData()
	{
	    String[] SubformOption = new String[] { "Top to Bottom","Western Text","Positioned" };
	    LayoutType = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Please select the right layout type for subform",
	        "Subform Layout Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), SubformOption, "Top to Bottom");
	    System.out.println("User's input: " + LayoutType);

	    return LayoutType;
	 }
	
	private void SetToFlow()
	{
		// the layout attribute does not exist
		Document FontDocument = mNode.getOwnerDocument();
		Attr FlowAttr = FontDocument.createAttribute("layout");
		if( LayoutType.equals("Top to Bottom"))
			FlowAttr.setNodeValue("tb");
		else if( LayoutType.equals("Western Text"))
			FlowAttr.setNodeValue("lr-tb");
		else
		{
			System.out.println("Layout Type Wrong: " + LayoutType);
			System.exit(0);
		}
		Element FontElement = (Element)mNode;
		FontElement.setAttributeNode(FlowAttr);
	}
	
	private void SetToPosition()
	{
		//the layout atttribute definately exist!
		// currently does not support set subform to position
		return;
		//mNode.getAttributes().removeNamedItem("layout");
	}
	
	public boolean Correction()
	{
		if( LayoutType == null)
		{
			// user click cancel button!
			return false;
		}
		// do the main correction here!
		if( LayoutType.equals("Positioned"))
		{
			SetToPosition();
			return false;
		}
		SetToFlow();
		return true;
	}
}