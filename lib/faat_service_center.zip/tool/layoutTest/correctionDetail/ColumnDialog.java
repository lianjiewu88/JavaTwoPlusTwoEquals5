package layoutTest.correctionDetail;

import javax.swing.JPanel;
import java.awt.Frame;
import java.awt.BorderLayout;
import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;
import java.awt.Dimension;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import org.w3c.dom.Node;
import java.awt.Rectangle;
import java.util.Vector;


public class ColumnDialog extends JDialog 
{

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JButton jOKButton = null;

	private JButton jCancelButton1 = null;

	private Node root = null;
	
	private Vector<String> HeadeNameList = null;
	
	private JPanel jbuttonPanel = null;

	private JComboBox jleftComboBox = null;

	private JComboBox jrightComboBox = null;

	private JPanel jPanel1 = null;

	private JPanel jlabelPanel = null;

	private JLabel jleftLabel = null;

	private JLabel jrightLabel = null;
	
	private String leftSelected = null;
	
	private String rightSelected = null;
	
	private int leftIndex = -1;
	
	private int rightIndex = -1;
	
	private boolean needRefreshTree = true;
	
	private boolean exchangeOK = true;

	/**
	 * This method initializes jOKButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	public boolean IsExchangeOK()
	{
		return exchangeOK;
	}
	private JButton getJOKButton() {
		if (jOKButton == null) {
			jOKButton = new JButton();
			jOKButton.setPreferredSize(new Dimension(75, 23));
			jOKButton.setText("OK");
			jOKButton.addActionListener(new java.awt.event.ActionListener() 
			{
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					leftIndex = HeadeNameList.indexOf(leftSelected);
					rightIndex = HeadeNameList.indexOf(rightSelected);
					if(!checkValidity())
					{
						CloseDialog();
						System.out.println("The same column,close the dialog");
						exchangeOK = false;
						return;
					}
					System.out.println("left: " + leftIndex + " right: " + rightIndex);
					TableColumnAdjustor adjustor = new TableColumnAdjustor(root);
					adjustor.StartAdjustment(leftIndex, rightIndex);
					CloseDialog();
				}
			});
		}
		return jOKButton;
	}
	private void CloseDialog()
	{
		this.dispose();
		
	}
	
	public boolean needRefreshTree()
	{
		return needRefreshTree;
	}
	
	private void handleDefaultSetting()
	{
		if( leftIndex == -1)
			leftIndex = 0;
		if (rightIndex == -1)
			rightIndex = 0;
	}
	private boolean checkValidity()
	{
		handleDefaultSetting();
		String errorMessage = null;
		// should handle user has not choose anything
		if( leftIndex == rightIndex)
		{
			errorMessage = "You choose the same column,no need to change location";
			ErrorReport(errorMessage);
			return false;
		}
		else if( leftIndex > rightIndex)
		{
			int temp = rightIndex;
			rightIndex = leftIndex;
			leftIndex = temp;
		}
		return true;
		
	}
	private void ErrorReport(String Message)
	{
	    JOptionPane.showMessageDialog(this, Message, "ERROR",
	        JOptionPane.ERROR_MESSAGE);
	
	}
	/**
	 * This method initializes jCancelButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJCancelButton1() {
		if (jCancelButton1 == null) {
			jCancelButton1 = new JButton();
			jCancelButton1.setPreferredSize(new Dimension(75, 23));
			jCancelButton1.setText("Cancel");
			jCancelButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					needRefreshTree = false;
					exchangeOK = false;
					CloseDialog();
					System.out.println("Cancel actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jCancelButton1;
	}

	/**
	 * This method initializes jbuttonPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJbuttonPanel() {
		if (jbuttonPanel == null) {
			jbuttonPanel = new JPanel();
			jbuttonPanel.setLayout(new FlowLayout());
			jbuttonPanel.add(getJOKButton(), null);
			jbuttonPanel.add(getJCancelButton1(), null);
		}
		return jbuttonPanel;
	}

	/**
	 * This method initializes jleftComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJleftComboBox() {
		if (jleftComboBox == null) 
		{
			jleftComboBox = new JComboBox(HeadeNameList);
			jleftComboBox.setPreferredSize(new Dimension(150, 25));
			jleftComboBox.setMaximumRowCount(80);
			jleftComboBox.setBounds(new Rectangle(4, 26, 150, 25));
			jleftComboBox.addActionListener(new java.awt.event.ActionListener() 
			{
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JComboBox cb = (JComboBox)e.getSource();
					leftSelected = (String)cb.getSelectedItem();
					System.out.println("Left: " + leftSelected); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jleftComboBox;
	}

	/**
	 * This method initializes jrightComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJrightComboBox() 
	{
		if (jrightComboBox == null) 
		{
			jrightComboBox = new JComboBox(HeadeNameList);
			jrightComboBox.setPreferredSize(new Dimension(150, 25));
			jrightComboBox.setMaximumRowCount(80);
			jrightComboBox.setBounds(new Rectangle(159, 25, 150, 25));
			jrightComboBox.addActionListener(new java.awt.event.ActionListener() 
			{
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JComboBox cb = (JComboBox)e.getSource();
					rightSelected = (String)cb.getSelectedItem();
					System.out.println("Right: " + rightSelected); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jrightComboBox;
	}

	/**
	 * This method initializes jPanel1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			jPanel1 = new JPanel();
			jPanel1.setLayout(null);
			jPanel1.add(getJleftComboBox(), null);
			jPanel1.add(getJrightComboBox(), null);
		}
		return jPanel1;
	}

	/**
	 * This method initializes jlabelPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJlabelPanel() {
		if (jlabelPanel == null) {
			jlabelPanel = new JPanel();
			jlabelPanel.setLayout(new FlowLayout());
			jlabelPanel.add(getJleftLabel(), null);
			jlabelPanel.add(getJrightLabel(), null);
		}
		return jlabelPanel;
	}

	/**
	 * This method initializes jleftLabel	
	 * 	
	 * @return javax.swing.JLabel	
	 */
	private JLabel getJleftLabel() {
		if (jleftLabel == null) {
			jleftLabel = new JLabel();
			jleftLabel.setText("Choose left table header");
			jleftLabel.setPreferredSize(new Dimension(150, 23));
		}
		return jleftLabel;
	}

	/**
	 * This method initializes jrightLabel	
	 * 	
	 * @return javax.swing.JLabel	
	 */
	private JLabel getJrightLabel() {
		if (jrightLabel == null) {
			jrightLabel = new JLabel();
			jrightLabel.setText("Choose right table header");
			jrightLabel.setPreferredSize(new Dimension(150, 23));
		}
		return jrightLabel;
	}

	

	/**
	 * @param owner
	 */
	public ColumnDialog(Frame owner,Node node,Vector<String> namelist) 
	{
		super(owner);
		root = node;
		HeadeNameList = (Vector<String>)namelist.clone();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(320, 178);
		this.setContentPane(getJContentPane());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getJbuttonPanel(), BorderLayout.SOUTH);
			jContentPane.add(getJPanel1(), BorderLayout.CENTER);
			jContentPane.add(getJlabelPanel(), BorderLayout.NORTH);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
