package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class FontTypeDialog

{
	private Node mNode;
	private String FontType;
	public FontTypeDialog (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
	}
	
	public String getFontType()
	{
		return FontType;
	}
	public String getUserInputData()
	{
	    String[] SubformOption = new String[] { "Bold", "Regular" };
	    FontType = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Please select the right Font type",
	        "Field Font Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), SubformOption, "Regular");
	    System.out.println("Font Type: " + FontType);

	    return FontType;
	 }
	
	private boolean ValueFontTypeCorrection()
	{
		System.out.println("in ValueFontTypeCorrection()");
		if( mNode.getAttributes().getNamedItem("weight") != null)
		{
			if( FontType.equals("Regular"))
			{
				// remove the attribute weight
				mNode.getAttributes().removeNamedItem("weight");
				return true;
			}
			else
			{
				mNode.getAttributes().getNamedItem("weight").setNodeValue("bold");
				System.out.println("Name: " + mNode.getNodeName());
				return true;
			}
		}
		else
		{
			System.out.println("no weight Subnode exists");
			// no size node exists!
			if( FontType.equals("Regular"))
			{
				// need not handle 
				return false;
			}
			System.out.println("Name: " + mNode.getNodeName());
			Document FontDocument = mNode.getOwnerDocument();
			Attr SizeAttr = FontDocument.createAttribute("weight");
			SizeAttr.setNodeValue("bold");
			Element FontElement = (Element)mNode;
			FontElement.setAttributeNode(SizeAttr);
			return true;
		}
		
	}
	
	private boolean CaptionFontTypeCorrection()
	{
		if( FontType.equals("Regular"))
		{
			String message = "Field Caption Should Always be Bold";
			    JOptionPane.showMessageDialog(new JFrame(), message, "ERROR",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
		NodeList child = mNode.getChildNodes();
		Node item = null;
		int size = child.getLength();
		for( int i = 0; i < size; i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("font"))
			{
				if( item.getAttributes().getNamedItem("weight") != null)
				{
					item.getAttributes().getNamedItem("weight").setNodeValue(FontType);
				}
				else
				{
					// no size node exists!
					System.out.println("Node: " + item.getNodeName() + " Should Create a new weight Attribute");
					System.out.println("Already Attr: " + item.getAttributes().getNamedItem("typeface").getNodeName());
					//System.exit(0);
					Document FontDocument = item.getOwnerDocument();
					Attr SizeAttr = FontDocument.createAttribute("weight");
					SizeAttr.setNodeValue("bold");
					Element FontElement = (Element)item;
					FontElement.setAttributeNode(SizeAttr);
				}
			}
		}
		return true;
	}
	public boolean Correction()
	{
		// do the main correction here!
		System.out.println("Node Name: " + mNode.getNodeName());
		if( FontType == null)
			return false;
		if( mNode.getNodeName().equals("font"))
		{
			return ValueFontTypeCorrection();
		}
		else if( mNode.getNodeName().equals("caption"))
		{
			return CaptionFontTypeCorrection();
		}
		else
		{
			// can not execute here
			System.out.println("Error!");
			System.exit(0);
			return false;
		}
	}
}