package layoutTest.correctionDetail;


import java.util.Vector;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.Tool;




class CaptionAdjustor
{
	private Node changeNode = null;
	private Node CaptionValueNode = null;
	private Node BodyNode = null;
	private Vector NewCaptionList = null;
	private int TextIndex = 0;
	boolean isDraw = false;
	boolean isField = false;
	public CaptionAdjustor(Node node,Vector NewCaption)
	{
		changeNode = node;
		NewCaptionList = NewCaption;
	}
	private boolean checkChangeValidity()
	{
		if( changeNode.getNodeName().equals("field"))
		{
			isField = true;
			CaptionValueNode = GetCaptionValueNode();
		}
		else if( changeNode.getNodeName().equals("draw"))
		{
			isDraw = true;
			BodyNode = GetBodyNode();
		}
		if((isField) && (CaptionValueNode == null))
			return false;
		return true;
	}
	private boolean isSpaceRunNode(Node node)
	{
		if( node.getAttributes() == null)
			return false;
		if( node.getAttributes().getNamedItem("style") == null)
			return false;
		if( node.getAttributes().getNamedItem("style").getNodeValue().equals("xfa-spacerun:yes"))
			return true;
		return false;
	}
	private void SetText(Node node)
	{
		if( TextIndex == NewCaptionList.size())
			return;
		if(isSpaceRunNode(node))
			return;
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for(int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("#text"))
			{
				String Value = item.getNodeValue();
				String formatedValue = Value.trim();
				if( formatedValue.equalsIgnoreCase("") || (formatedValue.equalsIgnoreCase(" ")))
					continue;
				System.out.println("Vector index: " + TextIndex);
				String content = (String)NewCaptionList.elementAt(TextIndex++);
				System.out.println("Want to Add node: " + content);
				item.setNodeValue(content);
				System.out.println("this is a text node: " + item.getNodeValue());
			}
			else if ( item.getNodeName().equals("span"))
				SetText(item);
		}
	}
	public boolean StartCaptionAdjust()
	{
		if( checkChangeValidity() == false)
			return false;
		if( isField)
		{
			Node ValueNode = Tool.getNodebyRoot("text",CaptionValueNode);
			System.out.println("Try to change to new caption: " + NewCaptionList.elementAt(0));
			ValueNode.setTextContent((String)NewCaptionList.elementAt(0));
			return true;
		}
		else if ( isDraw)
		{
			Node ValueNode = Tool.getNodebyRoot("value",changeNode);
			Node textNode = Tool.getNodebyRoot("text",ValueNode);
			{
				if (textNode == null)
				{
					NodeList child = BodyNode.getChildNodes();
					int length = child.getLength();
					Node item = null;
					for(int i = 0; i < length;i++)
					{
						item = child.item(i);
						if( item.getNodeName().equals("p") || (item.getNodeName().equals("span")))
						{
							SetText(item);
						}
						System.out.println("Value: " + item.getTextContent());
					}
				}
				else
				{
					textNode.setTextContent((String)NewCaptionList.elementAt(0));
					System.out.println("Set New Caption for Draw: " + NewCaptionList.elementAt(0));
					return true;
				}
			}
		}
		return false;
	}
	
	private Node GetCaptionValueNode()
	{
		NodeList child = changeNode.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for(int i =0; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("caption"))
			{
				NodeList CaptionChild = item.getChildNodes();
				int size = CaptionChild.getLength();
				Node subItem = null;
				for(int j = 0; j < size; j++)
				{
					subItem = CaptionChild.item(j);
					if( subItem.getNodeName().equals("value"))
						return subItem;
				}
			}
		}
		return null;
	}
	private Node GetBodyNode()
	{
		Node ValueNode = Tool.getNodebyRoot("value",changeNode);
		Node exDataNode = Tool.getNodebyRoot("exData",ValueNode);
		return Tool.getNodebyRoot("body",exDataNode);
	}
}
