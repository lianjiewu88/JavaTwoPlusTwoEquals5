package layoutTest.correctionDetail;

import org.w3c.dom.Node;
import utilities.Tool;
public class XSDLink
{
	private Node connection = null;
	public XSDLink(Node node)
	{
		connection = node;
	}
	public boolean correct()
	{
		Node xsdConnection = Tool.getNodebyRoot("xsdConnection",connection);
		if( xsdConnection == null)
		{
			Tool.ErrorReport("xsdConnection node missing,can not remove XSD!");
			return false;
		}
		Node uri = Tool.getNodebyRoot("uri",xsdConnection);
		if( uri == null)
			return false;
		uri.setTextContent("");
		Tool.InfoReport("Remove XSD Link Successfully");
		return true;
	}
}