package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Node;
 
public class VAlignDialog

{
	private Node mNode;
	private String vAlignSetting; 
	public VAlignDialog(ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
	}
	
	public String getVAlignSetting()
	{
		return vAlignSetting;
	}
	public String getUserInputData()
	{
	    String[] ValueOption = new String[] { "Top-Aligned" };
	    vAlignSetting = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Choose the Correct Alignment Setting",
	        "Alignment Setting Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), ValueOption, "Top-Aligned");
	    System.out.println("User's input: " + vAlignSetting);

	    return vAlignSetting;
	 }
	
	public boolean Correction()
	{
		if( vAlignSetting == null)
			return false;
		// previous setting should only be center or bottom,just delete the para node
		if( mNode.getAttributes().getNamedItem("vAlign") == null)
			return false;
		mNode.getAttributes().removeNamedItem("vAlign");
		return true;

	}
}