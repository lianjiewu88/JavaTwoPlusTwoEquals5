package layoutTest.correctionDetail;

import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class FontDialog extends JDialog {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel jStatusLabel = null;

	private JTextField jCurrentFont = null;

	private String newFontSetting = null;
	
	private String currentFontSetting = null;
	
	private JLabel jNewInputLabel = null;

	private JComboBox jComboBox = null;

	private JButton jOKButton = null;

	private JButton jOKButton1 = null;

	private Node node = null;
	
	private boolean isFontChangeOK = true;
	
	public boolean isFontChangeOK()
	{
		return isFontChangeOK;
	}

	private JTextField getJCurrentFont() {
		if (jCurrentFont == null) {
			jCurrentFont = new JTextField();
			jCurrentFont.setBounds(new Rectangle(138, 16, 143, 30));
			jCurrentFont.setMinimumSize(new Dimension(38, 30));
			jCurrentFont.setEditable(false);
			jCurrentFont.setPreferredSize(new Dimension(38, 30));
			SetBold(jCurrentFont);
		}
		return jCurrentFont;
	}

	private JComboBox getJComboBox() 
	{
		if (jComboBox == null) 
		{
			String[] FontSetting = {"Arial","Adobe Song Std L","Arial Black","Adobe Arabic",
					"Adobe Hebrew","Adobe Song Std L","Adobe Thai",
					"Bell Gothic Std Black","Bell Gothic Std Light","Courier Std",
					"Kozuka Mincho Std M","Kozuka Gothic Pro M","Letter Gothic Std",
					"Minion Pro","Myriad Pro",};
			jComboBox = new JComboBox(FontSetting);
			jComboBox.setBounds(new Rectangle(139, 60, 142, 31));
			jComboBox.addActionListener(new java.awt.event.ActionListener() 
			{
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					JComboBox cb = (JComboBox)e.getSource();
					newFontSetting = (String)cb.getSelectedItem();
					System.out.println("New Font: " + newFontSetting); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jComboBox;
	}

	private boolean CheckIfNeedChange()
	{
		if(( newFontSetting == null ) || ( currentFontSetting == null))
			return false;
		if( currentFontSetting.equals(newFontSetting))
			return false;
		return true;
	}
	
	private void ErrorReport(String Message)
	{
	    JOptionPane.showMessageDialog(new JFrame(), Message, "ERROR",
	        JOptionPane.ERROR_MESSAGE);
	}
	private JButton getJOKButton() 
	{
		if (jOKButton == null) {
			jOKButton = new JButton();
			jOKButton.setText("OK");
			jOKButton.setLocation(new Point(27, 134));
			jOKButton.setSize(new Dimension(75, 20));
			jOKButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					System.out.println("Current Font: " + currentFontSetting);
					System.out.println("New Font: " + newFontSetting);
					if( !CheckIfNeedChange())
					{
						isFontChangeOK = false;
						ErrorReport("Please choose a font different from the current one");
					}
					FieldFontAdjustor fontAdjustor = new FieldFontAdjustor(node,newFontSetting);
					fontAdjustor.DoFontChange();
					isFontChangeOK = true;
					CloseDialog();
				}
			});
		}
		return jOKButton;
	}

	private void CloseDialog()
	{
		this.dispose();
	}
	/**
	 * This method initializes jOKButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJOKButton1() {
		if (jOKButton1 == null) {
			jOKButton1 = new JButton();
			jOKButton1.setText("Cancel");
			jOKButton1.setSize(new Dimension(75, 20));
			jOKButton1.setLocation(new Point(167, 134));
			jOKButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					isFontChangeOK = false;
					CloseDialog();
				}
			});
		}
		return jOKButton1;
	}

	
	/**
	 * @param owner
	 */
	public FontDialog(Frame owner,Node Inputnode) {
		super(owner);
		node = Inputnode;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		this.setTitle("Font Property Dialog");
		this.setName("Font Property Dialog");
		this.setContentPane(getJContentPane());
		SetCurrentFontSetting();
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jNewInputLabel = new JLabel();
			jNewInputLabel.setText("New Font Setting");
			jNewInputLabel.setSize(new Dimension(119, 30));
			jNewInputLabel.setLocation(new Point(16, 61));
			jStatusLabel = new JLabel();
			jStatusLabel.setPreferredSize(new Dimension(38, 30));
			jStatusLabel.setLocation(new Point(14, 16));
			jStatusLabel.setSize(new Dimension(119, 30));
			jStatusLabel.setText(" Current Font Setting");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(jStatusLabel, null);
			jContentPane.add(getJCurrentFont(), null);
			jContentPane.add(jNewInputLabel, null);
			jContentPane.add(getJComboBox(), null);
			jContentPane.add(getJOKButton(), null);
			jContentPane.add(getJOKButton1(), null);
		}
		return jContentPane;
	}
	private void SetCurrentFontSetting()
	{
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length; i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("font"))
			{
				if( item.getAttributes().getNamedItem("typeface") == null)
					continue;
				currentFontSetting = item.getAttributes().getNamedItem("typeface").getNodeValue();
				jCurrentFont.setText(currentFontSetting);
				return;
			}
			else if ( item.getNodeName().equals("caption"))
			{ 
				HandleCaptionFont(item);
				return;
			}
		}
	}
	private void SetBold(JTextField textfield)
	{
		JTextField input = textfield;
		Font oldFont = textfield.getFont();
		Font newFont = new Font(oldFont.getFontName(),oldFont.getStyle() | Font.BOLD,14);
		input.setFont(newFont);
	}
	private void HandleCaptionFont(Node node)
	{
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length; i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("font"))
			{
				if( item.getAttributes().getNamedItem("typeface") == null)
					continue;
				currentFontSetting = item.getAttributes().getNamedItem("typeface").getNodeValue();
				jCurrentFont.setText(currentFontSetting);
				return;
			}
		}
	}
}
