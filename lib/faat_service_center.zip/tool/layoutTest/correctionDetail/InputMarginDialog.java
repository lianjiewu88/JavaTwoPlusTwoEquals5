package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Dimension;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.awt.Point;
import java.awt.Color;
import java.awt.Rectangle;


public class InputMarginDialog extends JDialog {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private Node mNode = null;
	
	private JTextField jTopMargin = null;

	private JTextField jBottomMargin = null;

	private JTextField jLeftMargin = null;

	private JTextField jRightMargin = null;

	private JLabel jTopLabel = null;

	private JLabel jBottomLabel = null;

	private JLabel jLeftLabel = null;

	private JLabel jRightLabel = null;

	private JButton jButtonOK = null;

	private JButton jButtonCancel = null;
	
	public boolean isCorrectRealDone = false;
	
	private String InputTopMargin = null;
	
	private String InputBottomMargin = null;
	
	private String InputLeftMargin = null;
	
	private String InputRightMargin = null;
	/**
	 * @param owner
	 */
	public InputMarginDialog(Frame owner,ErrorTraceObject errObj) {
		
		super(owner);
		mNode = errObj.getNode();
		setModal(true);
		initialize();
	}


	public String getInput()
	{
		String inputMargin = InputTopMargin + "." + InputBottomMargin + "." + 
		InputLeftMargin + "." + InputRightMargin;
		return inputMargin;
	}
	
	private void initialize() {
		this.setSize(300, 200);
		this.setForeground(Color.gray);
		this.setTitle("Field Margin Setting");
		this.setLocation(new Point(90, 90));
		this.setContentPane(getJContentPane());
	}

	private void CloseDialog()
	{
		this.dispose();
	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jRightLabel = new JLabel();
			jRightLabel.setText("  Right Margin:");
			jRightLabel.setBounds(new Rectangle(43, 80, 100, 20));
			jRightLabel.setPreferredSize(new Dimension(100, 20));
			jLeftLabel = new JLabel();
			jLeftLabel.setText("  Left Margin:");
			jLeftLabel.setBounds(new Rectangle(43, 55, 100, 20));
			jLeftLabel.setPreferredSize(new Dimension(100, 20));
			jBottomLabel = new JLabel();
			jBottomLabel.setText("  Bottom Margin:");
			jBottomLabel.setBounds(new Rectangle(43, 30, 100, 20));
			jBottomLabel.setPreferredSize(new Dimension(100, 20));
			jTopLabel = new JLabel();
			jTopLabel.setText("  Top Margin:");
			jTopLabel.setVerticalAlignment(SwingConstants.CENTER);
			jTopLabel.setBounds(new Rectangle(43, 5, 100, 20));
			jTopLabel.setPreferredSize(new Dimension(100, 20));
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(jTopLabel, null);
			jContentPane.add(getJTopMargin(), null);
			jContentPane.add(jBottomLabel, null);
			jContentPane.add(getJBottomMargin(), null);
			jContentPane.add(jLeftLabel, null);
			jContentPane.add(getJLeftMargin(), null);
			jContentPane.add(jRightLabel, null);
			jContentPane.add(getJRightMargin(), null);
			jContentPane.add(getJButtonOK(), null);
			jContentPane.add(getJButtonCancel(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jTopMargin	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTopMargin() {
		if (jTopMargin == null) {
			jTopMargin = new JTextField();
			jTopMargin.setPreferredSize(new Dimension(100, 20));
			jTopMargin.setBounds(new Rectangle(148, 5, 100, 20));
		}
		return jTopMargin;
	}

	/**
	 * This method initializes jBottomMargin	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJBottomMargin() {
		if (jBottomMargin == null) {
			jBottomMargin = new JTextField();
			jBottomMargin.setPreferredSize(new Dimension(100, 20));
			jBottomMargin.setBounds(new Rectangle(148, 30, 100, 20));
		}
		return jBottomMargin;
	}

	/**
	 * This method initializes jLeftMargin	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJLeftMargin() {
		if (jLeftMargin == null) {
			jLeftMargin = new JTextField();
			jLeftMargin.setPreferredSize(new Dimension(100, 20));
			jLeftMargin.setBounds(new Rectangle(148, 55, 100, 20));
		}
		return jLeftMargin;
	}

	/**
	 * This method initializes jRightMargin	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJRightMargin() {
		if (jRightMargin == null) {
			jRightMargin = new JTextField();
			jRightMargin.setPreferredSize(new Dimension(100, 20));
			jRightMargin.setBounds(new Rectangle(148, 80, 100, 20));
		}
		return jRightMargin;
	}

	/*public   EnterKeyListener   implements   KeyListener   
	{   
		public   void   keyTyped(KeyEvent   e)
		{   
			if(e.getKeyChar()   ==   "\n")   
			{   
	        }   
	    }   
	          
	    public   void   keyPressed(KeyEvent   e){}   
	    public   void   keyReleased(KeyEvent   e){}   
	}*/
	


	   
	private JButton getJButtonOK() 
	{
		if (jButtonOK == null) 
		{
			jButtonOK = new JButton();
			jButtonOK.setPreferredSize(new Dimension(80, 20));
			jButtonOK.setBounds(new Rectangle(44, 133, 80, 20));
			jButtonOK.setText("OK");
			jButtonOK.setToolTipText("Start Margin Correction");
			
			jButtonOK.addActionListener(new java.awt.event.ActionListener() 
			{
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					
					InputTopMargin = jTopMargin.getText();
					if( !InputTopMargin.contains("mm"))
						InputTopMargin += "mm";
					
					InputBottomMargin = jBottomMargin.getText();
					if( !InputBottomMargin.contains("mm"))
						InputBottomMargin += "mm";
					
					InputLeftMargin = jLeftMargin.getText();
					if( !InputLeftMargin.contains("mm"))
						InputLeftMargin += "mm";
					
					InputRightMargin = jRightMargin.getText();
					if( !InputRightMargin.contains("mm"))
						InputRightMargin += "mm";
					
					System.out.println("Customer input, top: " + InputTopMargin + " Bottom: " + InputBottomMargin
							+ " Left: " + InputLeftMargin + " Right: " + InputRightMargin); 
					NodeList childs = mNode.getChildNodes();
					Node item = null;
					for (int i=0;i<childs.getLength();i++)
					{
						item = childs.item(i);
						if(item.getNodeName().equals("margin"))
						{
							Document MarginDocument = item.getOwnerDocument();
							Element MarginNode = (Element)item;
							if( item.getAttributes().getNamedItem("topInset") == null)
							{
								Attr top = MarginDocument.createAttribute("topInset");
								top.setNodeValue(InputTopMargin);
								MarginNode.setAttributeNode(top);
							}
							else
								item.getAttributes().getNamedItem("topInset").setNodeValue(InputTopMargin);
							if( item.getAttributes().getNamedItem("bottomInset") == null)
							{
								Attr bottom = MarginDocument.createAttribute("bottomInset");
								bottom.setNodeValue(InputBottomMargin);
								MarginNode.setAttributeNode(bottom);
							}
							else
								item.getAttributes().getNamedItem("bottomInset").setNodeValue(InputBottomMargin);
							if( item.getAttributes().getNamedItem("leftInset") == null)
							{
								Attr left = MarginDocument.createAttribute("leftInset");
								left.setNodeValue(InputLeftMargin);
								MarginNode.setAttributeNode(left);
							}
							else
								item.getAttributes().getNamedItem("leftInset").setNodeValue(InputLeftMargin);
							if( item.getAttributes().getNamedItem("rightInset") == null)
							{
								Attr right = MarginDocument.createAttribute("rightInset");
								right.setNodeValue(InputRightMargin);
								MarginNode.setAttributeNode(right);
							}
							else 
								item.getAttributes().getNamedItem("rightInset").setNodeValue(InputRightMargin);
						}
					}
					isCorrectRealDone = true;
					CloseDialog(); 
				}
			});
		}
		return jButtonOK;
	}

	public boolean isMarginCorrectionReallyDone()
	{
		return isCorrectRealDone;
	}
	/**
	 * This method initializes jButtonCancel	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCancel() {
		if (jButtonCancel == null) {
			jButtonCancel = new JButton();
			jButtonCancel.setPreferredSize(new Dimension(80, 20));
			jButtonCancel.setBounds(new Rectangle(163, 133, 80, 20));
			jButtonCancel.setText("Cancel");
			jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					CloseDialog();
					System.out.println("Cancel actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButtonCancel;
	}
	/*public static void main(String[] args) {
		InputMarginDialog a = new InputMarginDialog (null );
	}
	*/
}  //  @jve:decl-index=0:visual-constraint="177,-1"
