package layoutTest.correctionDetail;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import layoutTest.internalStructure.ErrorTraceObject;
import org.w3c.dom.Node;
import configuration.ConfigDom;

public class LogoHeightCorrector
{
	private Node mNode;
	private String CorrectHeight;
	public LogoHeightCorrector (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
		CorrectHeight = ConfigDom.getLogoHeight(); 
	}
	public String getUserInputData()
	{
	    String[] plays = new String[] { CorrectHeight };
	    CorrectHeight = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Please select the right height setting for Logo",
	        "Logo Height Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), plays, "SAP Form Team");
	    return CorrectHeight;
	}
	public boolean Correction()
	{
		if( CorrectHeight == null)
			return false;
		mNode.getAttributes().getNamedItem("h").setNodeValue(CorrectHeight);
		return true;
	}
}