package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Node;

import configuration.ConfigDom;

public class FormTitleWidth
{
	private Node mNode;
	private String Width;
	private String correctWidth = null;
	public FormTitleWidth (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
		correctWidth = ConfigDom.getStandardFormTitleWidth() + "mm";
	}
	
	public String getWidth()
	{
		return Width;
	}
	public String getUserInputData()
	{
	    String[] ValueOption = new String[] { correctWidth };
	    Width = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Please select the right width for Form Title",
	        "Form Title Width Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), ValueOption, correctWidth);
	    System.out.println("User's input: " + Width);

	    return Width;
	 }
	
	public boolean Correction()
	{
		if( Width == null)
			return false;
		if( !Width.equals(correctWidth))
		{
			   String message = "The Correct Setting of the field\n"
			        + "Should be 86mm\n";
			    JOptionPane.showMessageDialog(new JFrame(), message, "ERROR",
			        JOptionPane.ERROR_MESSAGE);
			   return false;
		}
		// do the main correction here!
		mNode.getAttributes().getNamedItem("w").setNodeValue(correctWidth);
		return true;
	}
}