package layoutTest.correctionDetail;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import configuration.ConfigDom;
import utilities.Tool;
public class DataFileLink
{
	private Node template = null;
	public DataFileLink(Node node)
	{
		template = node;
	}
	public boolean correct()
	{
		NodeList child = template.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName() != null)
			{
				if( item.getTextContent() != null)
				{
					if( item.getTextContent().contains(ConfigDom.getDataFileLinkNodeName()))
					{
						item.setTextContent("");
						Tool.InfoReport("Data File Link Removed Successfully");
						return true;
					}
				}
			}
		}
		return false;
	}
}