package layoutTest.correctionDetail;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import layoutTest.internalStructure.ErrorTraceObject;
import org.w3c.dom.Node;
import configuration.ConfigDom;

public class LogoWidthCorrector
{
	private Node mNode;
	private String CorrectWidth;
	public LogoWidthCorrector (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
		CorrectWidth = ConfigDom.getLogoWidth();
	}
	public String getUserInputData()
	{
	    String[] plays = new String[] { CorrectWidth };
	    CorrectWidth = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Please select the right width setting for Logo",
	        "Logo Width Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), plays, "SAP Form Team");
	    return CorrectWidth;
	}
	public boolean Correction()
	{
		if( CorrectWidth == null)
			return false;
		mNode.getAttributes().getNamedItem("w").setNodeValue(CorrectWidth);
		return true;
	}
}