package layoutTest.correctionDetail;

import configuration.ConfigDom;
import javax.swing.tree.DefaultMutableTreeNode;

public class NodeDestructor

{
	private DefaultMutableTreeNode deleteNode = null;
	
	private boolean shouldDelete = false;
	public NodeDestructor(DefaultMutableTreeNode node)
	{
		deleteNode = node;
		if( node == null)
		{
			System.out.println("Try to delete a null node");
			System.exit(0);
		}
	}
	private void CheckIfcanDelete()
	{
		System.out.println("Want to delete node: " + deleteNode.toString());
		String location = ConfigDom.getNodeLocation(deleteNode);
		if( location == null)
		{
			System.out.println("want to delete node: " + deleteNode.toString() + " location null!");
		}
		if( location.equalsIgnoreCase(ConfigDom.getTableLocation()))
			return;
		if( location.equalsIgnoreCase(ConfigDom.getHeaderLocation()))
			return;
		if( location.equalsIgnoreCase(ConfigDom.getRowLocation()))
			return;
		if( location == null)
			return;
		shouldDelete = true;
	}
	
	public boolean DeleteNode()
	{
		CheckIfcanDelete();
		if( shouldDelete)
		{
			deleteNode.removeFromParent();
			return true;
		}
		return false;
	}
}