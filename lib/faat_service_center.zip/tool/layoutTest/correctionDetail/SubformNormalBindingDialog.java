package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;



public class SubformNormalBindingDialog

{
	private Node mNode;
	private String Binding;
	public SubformNormalBindingDialog (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
	}
	public String getBindingSetting()
	{
		return Binding;
	}
	public String getUserInputData()
	{
	    String[] SubformOption = new String[] { "None" };
	    Binding = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Subform should Set Binding To None",
	        "Subform Binding Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), SubformOption, "None");
	    System.out.println("User's input: " + Binding);

	    return Binding;
	 }
	
	private void SetToNone()
	{
		// the bind attribute does not exist
		Document FontDocument = mNode.getOwnerDocument();
		Element BindNode = FontDocument.createElement("bind");
		Attr BindAttr = FontDocument.createAttribute("match");
		BindAttr.setNodeValue("none");
		BindNode.setAttributeNode(BindAttr);
		mNode.appendChild(BindNode);
	}
	
	
	public boolean Correction()
	{
		// do the main correction here!
		if( Binding == null)
			return false;
		SetToNone();
		return true;
	}
}