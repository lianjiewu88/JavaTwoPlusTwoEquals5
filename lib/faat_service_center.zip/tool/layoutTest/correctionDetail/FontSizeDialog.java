package layoutTest.correctionDetail;

import layoutTest.internalStructure.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class FontSizeDialog

{
	private Node mNode;
	private String FontSize;
	public FontSizeDialog (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
	}
	
	public String getFontSize()
	{
		return FontSize;
	}
	public String getUserInputData()
	{
	    String[] SubformOption = new String[] { "7pt","8pt","9pt","10pt","11pt","12pt"
	    		,"13pt","14pt","15pt","16pt"};
	    FontSize = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Please select the right Font Size",
	        "Field Font Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), SubformOption, "8PT");
	    System.out.println("Font Size: " + FontSize);

	    return FontSize;
	 }
	
	private void CaptionFontSizeCorrection()
	{
		NodeList child = mNode.getChildNodes();
		Node item = null;
		for( int i = 0; i < child.getLength(); i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("font"))
			{
				if( item.getAttributes().getNamedItem("size") != null)
				{
					item.getAttributes().getNamedItem("size").setNodeValue(FontSize);
				}
				else
				{
					// no size node exists!
					Document FontDocument = item.getOwnerDocument();
					Attr SizeAttr = FontDocument.createAttribute("size");
					SizeAttr.setNodeValue(FontSize);
					Element FontElement = (Element)item;
					FontElement.setAttributeNode(SizeAttr);
				}
			}
		}
	}

	private void ValueFontSizeCorrection()
	{
		if( mNode.getAttributes().getNamedItem("size") != null)
			mNode.getAttributes().getNamedItem("size").setNodeValue(FontSize);
		else
		{
			// no size node exists!
			Document FontDocument = mNode.getOwnerDocument();
			Attr SizeAttr = FontDocument.createAttribute("size");
			SizeAttr.setNodeValue(FontSize);
			Element FontElement = (Element)mNode;
			FontElement.setAttributeNode(SizeAttr);
		}
		
	}
	
	public boolean Correction()
	{
		// do the main correction here!
		// two conditons here Caption font size or value font size
		System.out.println("Node Name: " + mNode.getNodeName());
		if( FontSize == null)
			return false;
		if( mNode.getNodeName().equals("font"))
		{
			ValueFontSizeCorrection();
		}
		else if( mNode.getNodeName().equals("caption"))
		{
			CaptionFontSizeCorrection();
		}
		else
		{
			// can not execute here
			System.out.println("Error!");
			System.exit(0);
		}
		return true;
	}
}