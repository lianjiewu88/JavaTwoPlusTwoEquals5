package layoutTest.correctionDetail;

import javax.swing.JPanel;
import java.awt.Frame;
import java.awt.BorderLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.FlowLayout;

public class DeleteDialog extends JDialog {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel jLabel = null;

	private JButton jOKButton = null;

	private JButton jCancelButton1 = null;

	private JPanel jPanel = null;
	
	private DefaultMutableTreeNode deleteNode = null;
	
	private boolean isDeleteOK = true;

	/**
	 * @param owner
	 */
	public boolean IsDeleteOK()
	{
		return isDeleteOK;
	}
	public boolean NeedRefreshTree()
	{
		return isDeleteOK;
	}
	public DeleteDialog(Frame owner,DefaultMutableTreeNode node) 
	{
		super(owner);
		deleteNode = node;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(423, 136);
		this.setTitle("Node Delete Dialog");
		this.setContentPane(getJContentPane());
	}
	private void CloseDialog()
	{
		this.dispose();
		
	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel = new JLabel();
			jLabel.setText("           Do you really want to delete the node?");
			jLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(jLabel, BorderLayout.NORTH);
			jContentPane.add(getJPanel(), BorderLayout.SOUTH);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jOKButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJOKButton() {
		if (jOKButton == null) {
			jOKButton = new JButton();
			jOKButton.setPreferredSize(new Dimension(75, 23));
			jOKButton.setText("OK");
			jOKButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					NodeDestructor nodeDestructor = new NodeDestructor(deleteNode);
					isDeleteOK = nodeDestructor.DeleteNode();
					CloseDialog();
				}
			});
		}
		return jOKButton;
	}

	/**
	 * This method initializes jCancelButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJCancelButton1() {
		if (jCancelButton1 == null) {
			jCancelButton1 = new JButton();
			jCancelButton1.setPreferredSize(new Dimension(75, 23));
			jCancelButton1.setText("Cancel");
			jCancelButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) 
				{
					isDeleteOK = false;
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
					CloseDialog();
				}
			});
		}
		return jCancelButton1;
	}

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setLayout(new FlowLayout());
			jPanel.add(getJOKButton(), null);
			jPanel.add(getJCancelButton1(), null);
		}
		return jPanel;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
