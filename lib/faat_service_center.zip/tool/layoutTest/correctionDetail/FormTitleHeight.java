package layoutTest.correctionDetail;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import layoutTest.internalStructure.ErrorTraceObject;

import org.w3c.dom.Node;

import configuration.ConfigDom;

public class FormTitleHeight
{
	private Node mNode;
	private String correctHeight = null;
	public FormTitleHeight (ErrorTraceObject errObj)
	{
		mNode = errObj.getNode();
		correctHeight = ConfigDom.getStandardFormTitleHeight() + "mm";
	}
	
	public String getHeight()
	{
		return correctHeight;
	}
	public String getUserInputData()
	{
	    String[] ValueOption = new String[] { correctHeight };
	    correctHeight = (String) JOptionPane.showInputDialog(
	        new JFrame(),
	        "Please select the right height for Form Title",
	        "Form Title Height Correction", JOptionPane.INFORMATION_MESSAGE,
	        new ImageIcon("java2sLogo.GIF"), ValueOption, correctHeight);
	    System.out.println("User's input: " + correctHeight);
	    return correctHeight;
	 }
	public boolean Correction()
	{
		if( correctHeight == null)
			return false;
		// do the main correction here!
		mNode.getAttributes().getNamedItem("h").setNodeValue(correctHeight);
		return true;
	}
}