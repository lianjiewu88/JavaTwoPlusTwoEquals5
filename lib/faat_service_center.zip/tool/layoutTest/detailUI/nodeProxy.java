package layoutTest.detailUI;

import org.w3c.dom.Node;

import utilities.Tool;

public class nodeProxy
{
	private Node node = null;
	public nodeProxy(Node current)
	{
		node = current;
	}

	
	/* Disable on 2008-08-21
	 * private Node getNodebyRoot(String subNodeName,Node root)
	{
		if( root == null)
			return root;
		NodeList child = root.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals(subNodeName))
				return item;
		}
		return null;
	}*/
	public String getNodeTechnicalName()
	{
		return Tool.getAttributeValue("name",node);
	}
	public String getNodeX()
	{
		return Tool.getAttributeValue("x",node);
	}
	public String getNodeY()
	{
		return Tool.getAttributeValue("y",node);
	}
}