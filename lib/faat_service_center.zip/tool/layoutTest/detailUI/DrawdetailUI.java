package layoutTest.detailUI;

import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Point;
import javax.swing.JButton;
import org.w3c.dom.Node;

public class DrawdetailUI extends JDialog {

	private static final long serialVersionUID = 1L;
	
	private nodeProxy proxy = null;

	private JPanel jContentPane = null;

	private JLabel jNameLabel = null;

	private JLabel jFieldValue = null;

	private JLabel jXLabel = null;

	private JLabel jYLabel = null;

	private JLabel jXValueLabel = null;

	private JLabel jYValueLabel = null;

	private JLabel jWidthLabel = null;

	private JLabel jWidthValueLabel = null;

	private JLabel jHeightLabel = null;

	private JLabel jHeightValueLabel = null;

	private JLabel jWidthExpandLabel = null;

	private JLabel jWELabel = null;

	private JLabel jHeightExpandToFitLabel = null;

	private JLabel jHELabel = null;

	private JLabel jLabel = null;

	private JLabel jLeftLabel = null;

	private JLabel jLeftValueLabel = null;

	private JLabel jRightLabel = null;

	private JLabel jRightValueLabel = null;

	private JLabel jBottomLabel = null;

	private JLabel jBottomValueLabel = null;

	private JLabel jTopLabel = null;

	private JLabel jTopValueLabel = null;

	private JLabel jTextLabel = null;

	private JLabel jTextValueLabel = null;

	private JLabel jPresence = null;

	private JLabel jPresenceValueLabel = null;

	private JLabel jACCLabel = null;

	private JLabel jPresenceLabel = null;

	private JLabel jFontLabel = null;

	private JLabel jFontValueLabel = null;

	private JLabel jFontSize = null;

	private JLabel jFontjLabel = null;

	private JLabel jParaLabel = null;

	private JLabel jHorizonLabel = null;

	private JLabel jHValueLabel = null;

	private JLabel jVertical = null;

	private JLabel jVerticalValue = null;

	private JButton jButton = null;
	
	private Node node = null;

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(239, 240, 66, 23));
			jButton.setText("OK");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton;
	}


	
	/**
	 * @param owner
	 */
	public DrawdetailUI(Frame owner,Node currentNode) {
		super(owner);
		initialize();
		node = currentNode;
		proxy = new nodeProxy(node);
		ShowDetail();
	}
	
	// print all the detail information for this field
	private void ShowDetail()
	{
		jFieldValue.setText(proxy.getNodeTechnicalName());
		jXValueLabel.setText(proxy.getNodeX());
		jYValueLabel.setText(proxy.getNodeY());
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(421, 317);
		this.setTitle("Detail Information");
		this.setContentPane(getJContentPane());
	}

	public static void main(String[] arg)
	{
		DrawdetailUI a = new DrawdetailUI(null,null);
		a.setVisible(true);
		a.setEnabled(true);
	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jVerticalValue = new JLabel();
			jVerticalValue.setText("");
			jVerticalValue.setLocation(new Point(281, 205));
			jVerticalValue.setSize(new Dimension(101, 16));
			jVertical = new JLabel();
			jVertical.setText("Vertical:");
			jVertical.setLocation(new Point(178, 205));
			jVertical.setSize(new Dimension(77, 16));
			jHValueLabel = new JLabel();
			jHValueLabel.setText("");
			jHValueLabel.setLocation(new Point(281, 184));
			jHValueLabel.setSize(new Dimension(101, 16));
			jHorizonLabel = new JLabel();
			jHorizonLabel.setText("Horizon:");
			jHorizonLabel.setLocation(new Point(178, 184));
			jHorizonLabel.setSize(new Dimension(77, 16));
			jParaLabel = new JLabel();
			jParaLabel.setText("Paragraph Settings");
			jParaLabel.setLocation(new Point(178, 163));
			jParaLabel.setSize(new Dimension(138, 16));
			jFontjLabel = new JLabel();
			jFontjLabel.setText("");
			jFontjLabel.setLocation(new Point(281, 140));
			jFontjLabel.setSize(new Dimension(101, 16));
			jFontSize = new JLabel();
			jFontSize.setText("Font Size:");
			jFontSize.setLocation(new Point(178, 140));
			jFontSize.setSize(new Dimension(78, 16));
			jFontValueLabel = new JLabel();
			jFontValueLabel.setText("");
			jFontValueLabel.setLocation(new Point(281, 120));
			jFontValueLabel.setSize(new Dimension(101, 16));
			jFontLabel = new JLabel();
			jFontLabel.setText("Font:");
			jFontLabel.setLocation(new Point(178, 120));
			jFontLabel.setSize(new Dimension(78, 16));
			jPresenceLabel = new JLabel();
			jPresenceLabel.setText("");
			jPresenceLabel.setLocation(new Point(281, 73));
			jPresenceLabel.setSize(new Dimension(103, 16));
			jACCLabel = new JLabel();
			jACCLabel.setText("Accessibility:");
			jACCLabel.setLocation(new Point(178, 73));
			jACCLabel.setSize(new Dimension(88, 16));
			jPresenceValueLabel = new JLabel();
			jPresenceValueLabel.setText("");
			jPresenceValueLabel.setLocation(new Point(281, 52));
			jPresenceValueLabel.setSize(new Dimension(103, 16));
			jPresence = new JLabel();
			jPresence.setText("Presence:");
			jPresence.setLocation(new Point(178, 52));
			jPresence.setSize(new Dimension(74, 16));
			jTextValueLabel = new JLabel();
			jTextValueLabel.setText("");
			jTextValueLabel.setLocation(new Point(281, 29));
			jTextValueLabel.setSize(new Dimension(104, 16));
			jTextLabel = new JLabel();
			jTextLabel.setText("Text:");
			jTextLabel.setLocation(new Point(178, 29));
			jTextLabel.setSize(new Dimension(74, 16));
			jTopValueLabel = new JLabel();
			jTopValueLabel.setText("");
			jTopValueLabel.setLocation(new Point(87, 247));
			jTopValueLabel.setSize(new Dimension(78, 16));
			jTopLabel = new JLabel();
			jTopLabel.setText("Top:");
			jTopLabel.setLocation(new Point(11, 247));
			jTopLabel.setSize(new Dimension(65, 16));
			jBottomValueLabel = new JLabel();
			jBottomValueLabel.setText("");
			jBottomValueLabel.setLocation(new Point(87, 226));
			jBottomValueLabel.setSize(new Dimension(78, 16));
			jBottomLabel = new JLabel();
			jBottomLabel.setText("Bottom:");
			jBottomLabel.setLocation(new Point(11, 226));
			jBottomLabel.setSize(new Dimension(65, 16));
			jRightValueLabel = new JLabel();
			jRightValueLabel.setText("");
			jRightValueLabel.setLocation(new Point(87, 205));
			jRightValueLabel.setSize(new Dimension(78, 16));
			jRightLabel = new JLabel();
			jRightLabel.setText("Right:");
			jRightLabel.setLocation(new Point(11, 205));
			jRightLabel.setSize(new Dimension(65, 16));
			jLeftValueLabel = new JLabel();
			jLeftValueLabel.setText("");
			jLeftValueLabel.setLocation(new Point(87, 184));
			jLeftValueLabel.setSize(new Dimension(78, 16));
			jLeftLabel = new JLabel();
			jLeftLabel.setText("Left:");
			jLeftLabel.setLocation(new Point(11, 184));
			jLeftLabel.setSize(new Dimension(65, 16));
			jLabel = new JLabel();
			jLabel.setText("Margin Setting");
			jLabel.setLocation(new Point(11, 163));
			jLabel.setSize(new Dimension(126, 16));
			jHELabel = new JLabel();
			jHELabel.setText("");
			jHELabel.setLocation(new Point(144, 140));
			jHELabel.setPreferredSize(new Dimension(8, 16));
			jHELabel.setSize(new Dimension(21, 16));
			jHeightExpandToFitLabel = new JLabel();
			jHeightExpandToFitLabel.setText("Height Expand To Fit:");
			jHeightExpandToFitLabel.setLocation(new Point(11, 140));
			jHeightExpandToFitLabel.setSize(new Dimension(126, 16));
			jWELabel = new JLabel();
			jWELabel.setText("");
			jWELabel.setLocation(new Point(144, 120));
			jWELabel.setSize(new Dimension(21, 16));
			jWidthExpandLabel = new JLabel();
			jWidthExpandLabel.setText("Width Expand To Fit:");
			jWidthExpandLabel.setLocation(new Point(11, 120));
			jWidthExpandLabel.setSize(new Dimension(126, 16));
			jHeightValueLabel = new JLabel();
			jHeightValueLabel.setText("");
			jHeightValueLabel.setLocation(new Point(87, 98));
			jHeightValueLabel.setSize(new Dimension(78, 16));
			jHeightLabel = new JLabel();
			jHeightLabel.setText("Height:");
			jHeightLabel.setLocation(new Point(11, 98));
			jHeightLabel.setPreferredSize(new Dimension(38, 16));
			jHeightLabel.setSize(new Dimension(65, 16));
			jWidthValueLabel = new JLabel();
			jWidthValueLabel.setText("");
			jWidthValueLabel.setLocation(new Point(87, 73));
			jWidthValueLabel.setSize(new Dimension(79, 16));
			jWidthLabel = new JLabel();
			jWidthLabel.setText("Width:");
			jWidthLabel.setLocation(new Point(11, 73));
			jWidthLabel.setSize(new Dimension(65, 16));
			jYValueLabel = new JLabel();
			jYValueLabel.setText("");
			jYValueLabel.setLocation(new Point(87, 52));
			jYValueLabel.setSize(new Dimension(79, 16));
			jXValueLabel = new JLabel();
			jXValueLabel.setText("");
			jXValueLabel.setLocation(new Point(87, 29));
			jXValueLabel.setSize(new Dimension(78, 16));
			jYLabel = new JLabel();
			jYLabel.setText("Y:");
			jYLabel.setLocation(new Point(11, 52));
			jYLabel.setSize(new Dimension(65, 16));
			jXLabel = new JLabel();
			jXLabel.setText("X:");
			jXLabel.setLocation(new Point(11, 29));
			jXLabel.setSize(new Dimension(65, 16));
			jFieldValue = new JLabel();
			jFieldValue.setBounds(new Rectangle(87, 9, 266, 16));
			jFieldValue.setText("");
			jNameLabel = new JLabel();
			jNameLabel.setText("Field Name:");
			jNameLabel.setLocation(new Point(11, 9));
			jNameLabel.setSize(new Dimension(70, 16));
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(jNameLabel, null);
			jContentPane.add(jFieldValue, null);
			jContentPane.add(jXLabel, null);
			jContentPane.add(jYLabel, null);
			jContentPane.add(jXValueLabel, null);
			jContentPane.add(jYValueLabel, null);
			jContentPane.add(jWidthLabel, null);
			jContentPane.add(jWidthValueLabel, null);
			jContentPane.add(jHeightLabel, null);
			jContentPane.add(jHeightValueLabel, null);
			jContentPane.add(jWidthExpandLabel, null);
			jContentPane.add(jWELabel, null);
			jContentPane.add(jHeightExpandToFitLabel, null);
			jContentPane.add(jHELabel, null);
			jContentPane.add(jLabel, null);
			jContentPane.add(jLeftLabel, null);
			jContentPane.add(jLeftValueLabel, null);
			jContentPane.add(jRightLabel, null);
			jContentPane.add(jRightValueLabel, null);
			jContentPane.add(jBottomLabel, null);
			jContentPane.add(jBottomValueLabel, null);
			jContentPane.add(jTopLabel, null);
			jContentPane.add(jTopValueLabel, null);
			jContentPane.add(jTextLabel, null);
			jContentPane.add(jTextValueLabel, null);
			jContentPane.add(jPresence, null);
			jContentPane.add(jPresenceValueLabel, null);
			jContentPane.add(jACCLabel, null);
			jContentPane.add(jPresenceLabel, null);
			jContentPane.add(jFontLabel, null);
			jContentPane.add(jFontValueLabel, null);
			jContentPane.add(jFontSize, null);
			jContentPane.add(jFontjLabel, null);
			jContentPane.add(jParaLabel, null);
			jContentPane.add(jHorizonLabel, null);
			jContentPane.add(jHValueLabel, null);
			jContentPane.add(jVertical, null);
			jContentPane.add(jVerticalValue, null);
			jContentPane.add(getJButton(), null);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="70,11"
