package mockupTool;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import utilities.Tool;

public class XMLDataFileRetriever
{
	private Document doc;
	private DocumentBuilder dombuilder;
	private DocumentBuilderFactory domfac;
	private Element root = null;
	private Node FMTRootNode = null;
	public XMLDataFileRetriever()
	{
		domfac = DocumentBuilderFactory.newInstance();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}
	public void LoadXMLDataFile(String path)
	{
		try 
		{
			InputStream inputXML = new FileInputStream(path);
			doc = dombuilder.parse(inputXML);
			root = doc.getDocumentElement();
			for( int i = 0 ; i < root.getChildNodes().getLength();i++)
			{
				if( root.getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE)
				{
					FMTRootNode = root.getChildNodes().item(i);
					System.out.println("name: " + root.getChildNodes().item(i).getNodeName());
				}
			}
		}
		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
	}
	
	private String[] formatPath(String path)
	{
		path = path.replace('.','/');
		String[] pathCollection = path.split("/");
		System.out.println("Path Length: " + pathCollection.length);
		for( int i = 0 ; i < pathCollection.length;i++)
		{
			System.out.println("i:" + i  + " Path:" + pathCollection[i]);
		}
		return pathCollection;
	}
	
	private String[] formatExcelPath(String path)
	{
		String[] pathCollection = path.split("/");
		System.out.println("Path Length: " + pathCollection.length);
		for( int i = 0 ; i < pathCollection.length;i++)
		{
			System.out.println("i:" + i  + " Path:" + pathCollection[i]);
		}
		return pathCollection;
	}
	
	public String getContentbyExcelPath(String path)
	{
		if( path == null)
			return null;
		String[] pathCollection = formatExcelPath(path);
		int length = pathCollection.length;
		if( length <= 3)
			return null;
		Node currentNode = Tool.getNodebyRoot(pathCollection[3],FMTRootNode);
		if( currentNode == null)
			return null;
		int i = 4;
		Node previous = null;
		for(;i < length;i++)
		{
			previous = currentNode;
			currentNode = Tool.getNodebyRoot(pathCollection[i],currentNode);
			if( currentNode == null)
				break;
		}
		if( currentNode != null)
			return currentNode.getTextContent();
		// may be unit code,filter the @ sign
		String possibleUnit = pathCollection[i].substring(1,pathCollection[i].length());
		if( previous.getAttributes().getNamedItem(possibleUnit) != null)
			return previous.getAttributes().getNamedItem(possibleUnit).getNodeValue();
		return null;
	}
	// input path is the designer path format
	public String getContentbyDesignerPath(String path)
	{
		if( path == null)
			return null;
		String[] pathCollection = formatPath(path);
		int length = pathCollection.length;
		if( length <= 1)
			return null;
		Node currentNode = Tool.getNodebyRoot(pathCollection[2],FMTRootNode);
		if( currentNode == null)
			return null;
		int i = 3;
		Node previous = null;
		for(;i < length;i++)
		{
			previous = currentNode;
			currentNode = Tool.getNodebyRoot(pathCollection[i],currentNode);
			if( currentNode == null)
				break;
		}
		if( currentNode != null)
			return currentNode.getTextContent();
		// may be attribute Node
		if( previous.getAttributes().getNamedItem(pathCollection[i]) != null)
			return previous.getAttributes().getNamedItem(pathCollection[i]).getNodeValue();
		return null;
	}
	
	public static void main(String[] arg)
	{
		XMLDataFileRetriever retriever = new XMLDataFileRetriever();
		retriever.LoadXMLDataFile("./data.xml");
		String path = "$record.DeliveryNote.VendorParty.FormAddress.FirstPostalRegulationsCompliantAddressLine.Description";
		System.out.println("Data: " + retriever.getContentbyDesignerPath(path));
	}
}