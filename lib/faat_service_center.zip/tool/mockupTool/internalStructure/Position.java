package mockupTool.internalStructure;

public class Position
{
	private int row = 1;
	private int column = 1;
	private int TableStartRow = -1;
	private int TableStartColumn = -1;
	private int TableHeaderNumber = -1;
	private int TableRowNumber = 1;
	private int RightInfoStartRow = -1;	// They are used to postformat the excel
	private int RightInfoEndRow = -1;
	private int pageCounterRow = -1;
	private int pageCounterColumn = -1;
	private int RightSigStartRow = -1;
	private int RightSigEndRow = -1;
	private int SummaryBlockStartRow = -1;
	private int SummaryBlockEndRow = -1;
	private int SignatureBlockStartRow = -1;
	private int SignatureBlockEndRow = -1;
	private boolean isTableMultiLine = false;
	
	public void moveToPosition(int r,int c)
	{
		row = r;
		column = c;
	}
	public void setSignatureBlockStartRow(int row)
	{
		SignatureBlockStartRow = row;
	}
	public int getSignatureBlockStartRow()
	{
		return SignatureBlockStartRow;
	}
	public void setSignatureBlockEndRow(int row)
	{
		SignatureBlockEndRow = row;
	}
	public int getSignatureBlockEndRow()
	{
		return SignatureBlockEndRow;
	}
	// test function
	public void traceSummaryBlock()
	{
		System.out.println("Summary Start Row: " + SummaryBlockStartRow);
		System.out.println("Summary End Row: " + SummaryBlockEndRow);
	}
	public void traceSignatureBlock()
	{
		System.out.println("Signature Block Start Row: " + SignatureBlockStartRow);
		System.out.println("Signature Block End Row: " + SignatureBlockEndRow);
	}
	public void setSummaryBlockStart(int row)
	{
		SummaryBlockStartRow = row;
	}
	public void setSummaryBlockEnd(int row)
	{
		SummaryBlockEndRow = row;
	}
	public int getSummaryBlockStart()
	{
		return SummaryBlockStartRow;
	}
	public int getSummaryBlockEnd()
	{
		return SummaryBlockEndRow;
	}
	public void setSigRightStartRow(int row)
	{
		RightSigStartRow = row;
	}
	public void setSigRightEndRow(int row)
	{
		RightSigEndRow = row;
	}
	public int getSigRightStartRow()
	{
		return RightSigStartRow;
	}
	public int getSigRightEndRow()
	{
		return RightSigEndRow;
	}
	public void setPageCounterPosition(int row,int column)
	{
		pageCounterRow = row;
		pageCounterColumn = column;
	}
	public int getPageRow()
	{
		return pageCounterRow;
	}
	public int getPageColumn()
	{
		return pageCounterColumn;
	}
	public void setRightInfoStartRow(int row)
	{
		RightInfoStartRow = row;
	}
	
	public void setRightInfoEndRow(int row)
	{
		RightInfoEndRow = row;
	}
	public int getRightInfoStartRow()
	{
		return RightInfoStartRow;
	}
	public int getRightInfoEndRow()
	{
		return RightInfoEndRow;
	}
	public int getTableStartRow()
	{
		return TableStartRow;
	}
	public int getTableRowNumber()
	{
		return TableRowNumber;
	}
	public int getTableStartColumn()
	{
		return TableStartColumn;
	}
	
	public int getTableHeaderNumber()
	{
		return TableHeaderNumber;
	}
	
	public void moveToNextContentRow()
	{
		if( isTableMultiLine)
		{
			row += 2;
			column = 1;
		}
		else
		{
			row++;
			column = 1;
		}
	}
	
	public void markTableRowNumber(int n)
	{
		TableRowNumber = n;
	}
	
	public void addTableRowNumber()
	{
		TableRowNumber++;
	}
	
	public void markTableHeaderNumber(int n)
	{
		TableHeaderNumber = n;
	}
	public void markTablePosition(int r,int c)
	{
		TableStartRow = r;
		TableStartColumn = c;
	}
	
	public void moveToNextColumn()
	{
		column++;
	}
	
	public void markMultiLine()
	{
		isTableMultiLine = true;
	}
	public int getRow()
	{
		return row;
	}
	
	public Position snapShot()
	{
		Position snap = new Position();
		snap.moveToPosition(row, column);
		return snap;
	}
	
	public int getColumn()
	{
		return column;
	}
	public void moveToNextRow()
	{
		row++;
	}
	
	public void moveToNewColumn(int c)
	{
		column = c;
	}
	
	public void moveToNewRow(int r)
	{
		row = r;
	}
	public void trace()
	{
		System.out.println("Currently in row:->" + row + " column:->" + column);
	}
	public void moveToPreviousColumn()
	{
		--column;
	}
}