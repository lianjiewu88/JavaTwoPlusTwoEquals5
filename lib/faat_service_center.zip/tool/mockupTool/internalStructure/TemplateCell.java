package mockupTool.internalStructure;

public class TemplateCell
{
	private String cellType = null;
	private String caption = null;
	private String defaultValue = null;
	private String bindPath = null;
	private String CorrespondingFieldinDesigner = null;
	private String CorrespondingFieldType = null;
	private int freetextIndex = -1; // used specically for free text block
	private int row = -1;
	private int column = -1;
	
	public void setPosition(int r,int c)
	{
		row = r;
		column = c;
	}
	
	public int getFreeTextIndex()
	{
		return freetextIndex;
	}
	public void setFreeTextIndex(int index)
	{
		freetextIndex = index;
	}
	public void setCorrespondingFieldType(String type)
	{
		if( type != null)
			CorrespondingFieldType = type;
	}
	public String getCorrespondingFieldType()
	{
		return CorrespondingFieldType;
	}
	public void setFieldNameforDesigner(String name)
	{
		if( name != null)
			CorrespondingFieldinDesigner = name;
	}
	public String getFieldNameforDesigner()
	{
		return CorrespondingFieldinDesigner;
	}
	public String getBindpath()
	{
		return bindPath;
	}
	
	public String getCaption()
	{
		return caption;
	}
	
	public String getDefaultValue()
	{
		return defaultValue;
	}
	
	public int getRow()
	{
		return row;
	}
	
	public int getColumn()
	{
		return column;
	}
	public void setCellType(String t)
	{
		cellType = t;
	}
	
	public String getType()
	{
		return cellType;
	}
	public void setCaption(String ca)
	{
		caption = ca;
	}
	
	public void setDefaultValue(String v)
	{
		defaultValue = v;
	}
	
	public void setBindPath(String path)
	{
		bindPath = path;
	}
}