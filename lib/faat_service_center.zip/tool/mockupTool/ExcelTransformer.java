package mockupTool;

import configuration.*;
import mockupTool.internalStructure.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import utilities.Tool;


public class ExcelTransformer
{
	private Document doc;
	private DocumentBuilder dombuilder;
	private DocumentBuilderFactory domfac;
	private Element root = null;
	private Node TableNode = null;
	private Vector<TemplateCell> TemplateCellCollection = null;
	private Position position = null;
	private JList listHandler = null;
	private DefaultListModel listModeHandler = null;
	private String XMLDataFile = null;
	public ExcelTransformer(Vector<TemplateCell> cellCollection,Position pos)
	{
		domfac = DocumentBuilderFactory.newInstance();
		position = pos;
		TemplateCellCollection = cellCollection;
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}
	public void getListHandler(JList list,DefaultListModel listMode)
	{
		listHandler = list;
		listModeHandler = listMode;
	}
	
	private String FormatSavePath(String path)
	{
		int index = path.lastIndexOf('.');
		if( index != -1)
			return path;
		String newPath = path + ".xml";
		return newPath;
	}
	public String SaveAs(String path)
	{
		String formattedPath = FormatSavePath(path);
		File newFile = new File(formattedPath);
		if( newFile.exists())
			return null;
		try
		{   
             TransformerFactory tff = TransformerFactory.newInstance();   
             Transformer tf = tff.newTransformer();   
             DOMSource source = new DOMSource(doc);
             StreamResult rs = new StreamResult(formattedPath);
             tf.transform(source,rs);  
             tf.reset();
        }
		catch(Exception   e1)
		{   
             e1.printStackTrace();   
		}  
		return formattedPath;
	}
	
	private void GenerateMatrix(int rowNum,int colNum)
	{
		for( int i = 0 ; i < rowNum; i++)
			GenerateRowInstance(colNum);
		ModifyCorrespondingAttribute(rowNum,colNum);
	}
	
	private void ModifyCorrespondingAttribute(int r,int c)
	{
		TableNode.getAttributes().getNamedItem("ss:ExpandedColumnCount").setNodeValue(String.valueOf(c));
		TableNode.getAttributes().getNamedItem("ss:ExpandedRowCount").setNodeValue(String.valueOf(r));
	}
	private void GenerateRowInstance(int colNum)
	{
		Document ParentDocument = TableNode.getOwnerDocument();
		Element RowNode = ParentDocument.createElement("Row");
		Attr Type = ParentDocument.createAttribute("ss:AutoFitHeight");
		Type.setNodeValue("0");
		RowNode.setAttributeNode(Type);
		
		for( int i = 0 ; i < colNum;i++)
		{
			Element cell = generateCell(RowNode);
			RowNode.appendChild(cell);
		}
		TableNode.appendChild(RowNode);
	}
	
	private Element generateCell(Node rowInstance)
	{
		Document ParentDocument = rowInstance.getOwnerDocument();
		Element CellNode = ParentDocument.createElement("Cell");
		Element DataNode = ParentDocument.createElement("Data");
		Attr Type = ParentDocument.createAttribute("ss:Type");
		Type.setNodeValue("String");
		Attr Style = ParentDocument.createAttribute("ss:StyleID");
		// default Style value
		Style.setNodeValue("Default");
		CellNode.setAttributeNode(Style);
		DataNode.setAttributeNode(Type);
		CellNode.appendChild(DataNode);
		// add this custom node to implement writing back feature
		Element FormNode = ParentDocument.createElement("Form");
		Attr FieldStyle = ParentDocument.createAttribute("style");
		FieldStyle.setNodeValue("Default");
		FormNode.setAttributeNode(FieldStyle);
		CellNode.appendChild(FormNode);
		
		return CellNode;
	}
	
	/*
	 * Main transform Engine here
	 */
	private void WriteBackToExcel()
	{
		int TemplateCellNumber = TemplateCellCollection.size();
		TemplateCell cell = null;
		System.out.println("Totally: " + TemplateCellNumber + " need to write back to excel!");
		for( int i = 0 ; i < TemplateCellNumber; i++)
		{
			cell = TemplateCellCollection.elementAt(i);
			if( cell.getType().equals("Logo"))
				HandleLogo(cell);
			else if ( cell.getType().equals("Title"))
				HandleTitle(cell);
			else if ( cell.getType().equals("Caption"))
				HandleCaption(cell);
			else if ( cell.getType().equals("DefalutValue"))
				HandleDefaultValue(cell);
			else if ( cell.getType().equals("PageCounter"))
				HandlePageCounter(cell);
			else if ( cell.getType().equals("TableHeader"))
				HandleTableHeader(cell);
			else if ( cell.getType().equals("TableCell"))
				HandleTableCell(cell);
			else if ( cell.getType().equals("RemarkCell"))
				HandleRemarkCell(cell);
			else if ( cell.getType().equals("FreeTextCell"))
				HandleFreeTextCell(cell);
				//HandleTableCell(cell);
			else if ( cell.getType().equals("Dummy"))
				FormatExcelTable();
		}
		// should align the cells in the right so that they have the same width
		PostFormatExcel();
	}

	private Node getFirstRow()
	{
		NodeList child = TableNode.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("Row"))
				return item;
		}
		return null;
	}
	private void SetDefaultColumnWidth()
	{
		Node firstRow = getFirstRow();
		// should insert before the first Row
		Document tableDocument = TableNode.getOwnerDocument();
		Element[] columns = new Element[5];
		for(int i = 0; i < 5;i++ )
		{
			columns[i] = tableDocument.createElement("Column");
			Attr autoWidth = tableDocument.createAttribute("ss:AutoFitWidth");
			Attr Width = tableDocument.createAttribute("ss:Width");
			autoWidth.setNodeValue("0");
			columns[i].setAttributeNode(autoWidth);
			columns[i].setAttributeNode(Width);
			TableNode.insertBefore(columns[i],firstRow);
		}
		columns[0].getAttributeNode("ss:Width").setNodeValue("94.2");
		columns[1].getAttributeNode("ss:Width").setNodeValue("108");
		columns[2].getAttributeNode("ss:Width").setNodeValue("72");
		columns[3].getAttributeNode("ss:Width").setNodeValue("112.2");
		columns[4].getAttributeNode("ss:Width").setNodeValue("54");
	}
	private void PostFormatExcel()
	{
		AlignLogoPosition();
		// post format the right info block if any
		AlignRightInfoBlock();
		AlignPageCounter();
		position.traceSummaryBlock();
		AlignSummaryBlock();
		AlignSignatureBlock();
		SetDefaultColumnWidth();
	}
	
	private void AlignSignatureBlock()
	{
		Node SignatureImage = null;
		Node Data = null;
		for( int i = position.getSignatureBlockStartRow();i < position.getSignatureBlockEndRow();i++)
		{
			// only check the first column is enough
			Node Cell = getNodebyPosition(i,1);
			if( Cell == null)
				continue;
			Data = Tool.getNodebyRoot("Data",Cell);
			if( Data == null)
				continue;
			if( Data.getTextContent().length() == 0)
			{
				SignatureImage = Cell;
				break;
			}
		}
		if( SignatureImage == null)
			return;
		AdaptImageRowHeight(SignatureImage.getParentNode());
	}
	
	private void AdaptImageRowHeight(Node AdaptRow)
	{
		if( AdaptRow == null)
			return;
		if( AdaptRow.getAttributes().getNamedItem("ss:Height") != null)
		{
			AdaptRow.getAttributes().getNamedItem("ss:Height").setNodeValue(String.valueOf(ConfigDom.getDefaultSignatureImageHeight()));
			return;
		}
		Document RowDocument = AdaptRow.getOwnerDocument();
		Attr height = RowDocument.createAttribute("ss:Height");
		height.setNodeValue(String.valueOf(ConfigDom.getDefaultSignatureImageHeight()));
		AdaptRow.getAttributes().setNamedItem(height);
	}
	
	private void AlignSummaryBlock()
	{
		if(( position.getSummaryBlockStart() == -1) || ( position.getSummaryBlockEnd() == -1))
			return;
		Node Cell = null;
		String style = null;
		position.traceSummaryBlock();
		position.setSignatureBlockStartRow(position.getSummaryBlockEnd());
		position.traceSignatureBlock();
		System.out.println("here");
		for( int i = position.getSummaryBlockStart();i < position.getSummaryBlockEnd();i++)
		{
			Cell = getNodebyPosition(i,ConfigDom.getDefaultSigRightStartingColumninExcel());
			if( Cell == null)
				continue;
			style = Tool.getAttributeValue("ss:StyleID",Cell);
			if( style == null)
				continue;
			if( style.equals("Default"))
				continue;
			MergeCellbyPosition(i,ConfigDom.getDefaultSigRightStartingColumninExcel());
			LeftMergeCell(i,1,1);
		}
		for( int j = position.getSummaryBlockStart();j<position.getSummaryBlockEnd();j++)
		{
			for( int k = 1; k < ConfigDom.getMaxColumninExcelTransformation();k++)
			{
				Node instance = getNodebyPosition(j,k);
				if( instance == null)
					continue;
				Node form = Tool.getNodebyRoot("Form",instance);
				if( form == null)
					continue;
				System.out.println("Row: " + j + " Column: " + k);
				Node data = Tool.getNodebyRoot("Data",instance);
				if( data.getTextContent().length() != 0 )
				{
					if( form.getAttributes().getNamedItem("style") != null)
						form.getAttributes().getNamedItem("style").setNodeValue("SummaryField");
				}
			}
		}
	}
	private void AlignPageCounter()
	{
		if(( position.getPageColumn() == -1) || (position.getPageRow() == -1))
			return;
		MergeCellbyPosition(position.getPageRow(),position.getPageColumn());
	}
	private void AlignRightInfoBlock()
	{
		if(( position.getRightInfoStartRow() == -1 ) || ( position.getRightInfoEndRow() == -1))
			return;
		System.out.println("Format from: " + position.getRightInfoStartRow() + " to: " + position.getRightInfoEndRow());
		for( int i = position.getRightInfoStartRow(); i <= position.getRightInfoEndRow();i++)
			MergeCellbyPosition(i,ConfigDom.getDefaultRightInfoStartingColumninExcel() + 1);
	}
	private void AlignLogoPosition()
	{
		MergeCellbyPosition(1,ConfigDom.getDefaultLogoColumninExcel(),
				ConfigDom.getExcelStyleForLogo(),ConfigDom.getDefaultLogo());
	}
	private void MergeCellbyPosition(int row,int column)
	{
		Node Cell = getNodebyPosition(row,column);
		if( Cell == null)
		{
			System.out.println("Can't find corresponding Cell in R" + row + "C" + column);
			return;
		}
		String newStyle = Tool.getAttributeValue("ss:StyleID",Cell);
		if( newStyle == null)
		{
			System.out.println("Cell StyleID Empty!");
			return;
		}
		Node data = Tool.getNodebyRoot("Data",Cell);
		if( data == null)
		{
			System.out.println("Data Node Missing!");
			return;
		}
		String value = data.getTextContent();
		MergeCellbyPosition(row,column,newStyle,value);
	}
	
	private void MergeCellbyPosition(int row,int column,String newStyle,String newValue)
	{
		Node Cell = getNodebyPosition(row,column);
		if( Cell == null)
		{
			System.out.println("Can't find corresponding Cell in R" + row + "C" + column);
			return;
		}
		Node Row = Cell.getParentNode();
		Document RowDocument = Row.getOwnerDocument();
		NodeList child = Row.getChildNodes();
		int number = child.getLength();
		System.out.println("Child Number: " + number);
		System.out.println("Node name: " + Row.getNodeName());
		Node item = null;
		boolean isFoundMergeStartCell = false;
		Vector<Node> deleteNodes = new Vector<Node>();
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( item.getNodeName() == null)
				continue;
			if(!item.getNodeName().equals("Cell"))
				continue;
			if( item.isSameNode(Cell))
			{
				isFoundMergeStartCell = true;
				continue;
			}
			if( isFoundMergeStartCell ) 
			{
				deleteNodes.add(item);
			}
		}
		for( int j = 0 ; j < deleteNodes.size();j++)
			Row.removeChild(deleteNodes.elementAt(j));
		Node Form = Tool.getNodebyRoot("Form",Cell);
		
		Element CellNode = RowDocument.createElement("Cell");
		Attr Style = RowDocument.createAttribute("ss:StyleID");
		Style.setNodeValue(newStyle);
		CellNode.setAttributeNode(Style);
		
		Attr merge = RowDocument.createAttribute("ss:MergeAcross");
		int mergeSpan = position.getTableHeaderNumber() - column;
		merge.setNodeValue(String.valueOf(mergeSpan));
		CellNode.setAttributeNode(merge);
		
		Element FormNode = RowDocument.createElement("Form");
		Attr style = RowDocument.createAttribute("style");
		style.setNodeValue(Tool.getAttributeValue("style",Form));
		FormNode.setAttributeNode(style);
		FormNode.setTextContent(Form.getTextContent());
		
		Element DataNode = RowDocument.createElement("Data");
		Attr Type = RowDocument.createAttribute("ss:Type");
		Type.setNodeValue("String");
		DataNode.setAttributeNode(Type);
		DataNode.setTextContent(newValue);
		CellNode.appendChild(DataNode);
		CellNode.appendChild(FormNode);
		
		Row.replaceChild(CellNode,Cell);
	}
	private void LeftMergeCell(int row,int column,int mergeCount)
	{
		Node Cell = getNodebyPosition(row,column);
		if( Cell == null)
		{
			System.out.println("Can't find corresponding Cell in R" + row + "C" + column);
			return;
		}
		String newStyle = Tool.getAttributeValue("ss:StyleID",Cell);
		if( newStyle == null)
		{
			System.out.println("Cell StyleID Empty!");
			return;
		}
		Node data = Tool.getNodebyRoot("Data",Cell);
		if( data == null)
		{
			System.out.println("Data Node Missing!");
			return;
		}
		String value = data.getTextContent();
		LeftMergeCellbyPosition(row,column,newStyle,value,mergeCount);
	}
	private void LeftMergeCellbyPosition(int row,int column,String newStyle,String newValue,int mergeCount)
	{
		Node Cell = getNodebyPosition(row,column);
		if( Cell == null)
		{
			System.out.println("Can't find corresponding Cell in R" + row + "C" + column);
			return;
		}
		Node Row = Cell.getParentNode();
		Document RowDocument = Row.getOwnerDocument();
		NodeList child = Row.getChildNodes();
		int number = child.getLength();
		System.out.println("Child Number: " + number);
		System.out.println("Node name: " + Row.getNodeName());
		Node item = null;
		int CellIndex = 0;
		boolean isFoundMergeStartCell = false;
		Vector<Node> deleteNodes = new Vector<Node>();
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( item.getNodeName() == null)
				continue;
			if(!item.getNodeName().equals("Cell"))
				continue;
			CellIndex++;
			if( item.isSameNode(Cell))
			{
				isFoundMergeStartCell = true;
				continue;
			}
			if( isFoundMergeStartCell ) 
			{
				deleteNodes.add(item);
			}
			if( CellIndex >= mergeCount)
				break;
		}
		for( int j = 0 ; j < deleteNodes.size();j++)
			Row.removeChild(deleteNodes.elementAt(j));
		Element CellNode = RowDocument.createElement("Cell");
		Attr Style = RowDocument.createAttribute("ss:StyleID");
		Style.setNodeValue(newStyle);
		CellNode.setAttributeNode(Style);
		
		Attr merge = RowDocument.createAttribute("ss:MergeAcross");
		merge.setNodeValue(String.valueOf(mergeCount));
		CellNode.setAttributeNode(merge);
		
		Element DataNode = RowDocument.createElement("Data");
		Attr Type = RowDocument.createAttribute("ss:Type");
		Type.setNodeValue("String");
		DataNode.setAttributeNode(Type);
		DataNode.setTextContent(newValue);
		CellNode.appendChild(DataNode);
		
		Row.replaceChild(CellNode,Cell);
	}
	private void MergeCell(TemplateCell cell,String newStyle,String newValue)
	{
		MergeCellbyPosition(cell.getRow(),cell.getColumn(),newStyle,newValue);
	}
	private void HandleRemarkCell(TemplateCell cell)
	{
		MergeCell(cell,ConfigDom.getExcelStyleForTable(),cell.getDefaultValue());
		Node RemarkCell = getNodebyPosition(cell.getRow(),1);
		Node Form = Tool.getNodebyRoot("Form",RemarkCell);
		if( Form == null)
			return;
		Form.getAttributes().getNamedItem("style").setNodeValue(cell.getCorrespondingFieldType());
		Form.setTextContent(cell.getFieldNameforDesigner());
	}
	private void FormatExcelTable()
	{
		int startRow = position.getTableStartRow();
		MarkTableHeader(startRow);
		int startColumn = position.getTableStartColumn();
		int rowNumber = position.getTableRowNumber();
		MarkTableContentRow(startRow,rowNumber);
		//MarkRemarkRow(startRow,rowNumber);
		int columnNumber = position.getTableHeaderNumber();
		System.out.println("Start Row:" + startRow + "Start Column: " + startColumn + 
				" total row: " + rowNumber + " total column: " + columnNumber);
		for( int i = startRow + 1; i < startRow + rowNumber + 1; i++)
		{
			for( int j = startColumn; j < startColumn + columnNumber; j++)
			{
				Node cell = getNodebyPosition(i,j);
				if( cell == null)
					continue;
				cell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ConfigDom.getExcelStyleForTable());
			}
		}
	}
	
	
		
	private void MarkTableContentRow(int startRow,int rowNumber)
	{
		Node cell = null;
		Node form = null;
		for( int j = startRow + 1; j < startRow + rowNumber;j++)
		{
			int index = 1;
			for( int i = 1; i < ConfigDom.getMaxColumninExcelTransformation();i++)
			{
				cell = getNodebyPosition(j,i);
				if( cell == null)
					continue;
				form = Tool.getNodebyRoot("Form",cell);
				if( form == null)
					continue;
				Document formDocument = form.getOwnerDocument();
				Attr tableindex = formDocument.createAttribute("tableindex");
				tableindex.setNodeValue(String.valueOf(index++));
				form.getAttributes().setNamedItem(tableindex);
				form.getAttributes().getNamedItem("style").setNodeValue("TableCell");
			}
		}
	}
	private void MarkTableHeader(int startRow)
	{
		Node cell = null;
		Node form = null;
		int index = 1;
		for( int i = 1; i < ConfigDom.getMaxColumninExcelTransformation();i++)
		{
			cell = getNodebyPosition(startRow,i);
			if( cell == null)
				continue;
			form = Tool.getNodebyRoot("Form",cell);
			if( form == null)
				continue;
			Document formDocument = form.getOwnerDocument();
			Attr tableindex = formDocument.createAttribute("tableindex");
			tableindex.setNodeValue(String.valueOf(index++));
			form.getAttributes().setNamedItem(tableindex);
			form.getAttributes().getNamedItem("style").setNodeValue("TableHeader");
		}
	}
	private void HandleTableHeader(TemplateCell cell)
	{
		Node data = getExcelDataNodetoWrite(cell);
		if( data == null)
			return;
		data.setTextContent(cell.getCaption());
		Node Cell = data.getParentNode();
		Node Form = Tool.getNodebyRoot("Form",Cell);
		if( Form != null)
		{
			Form.setTextContent(cell.getFieldNameforDesigner());
			Form.getAttributes().getNamedItem("style").setNodeValue(cell.getCorrespondingFieldType());
		}
		Cell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ConfigDom.getExcelStyleForTable());
		String status = "Table Header: " + cell.getCaption() + " has been written into Excel at row:" + cell.getRow() + " column:" + cell.getColumn();
		WriteJList(status);
	}
	
	private void HandleTitle(TemplateCell cell)
	{
		Node data = getExcelDataNodetoWrite(cell);
		if( data == null)
			return;
		data.setTextContent(cell.getCaption());
		Node Cell = data.getParentNode();
		Node Form = Tool.getNodebyRoot("Form",Cell);
		if( Form != null)
		{
			Form.setTextContent(cell.getFieldNameforDesigner());
			Form.getAttributes().getNamedItem("style").setNodeValue(cell.getCorrespondingFieldType());
		}
		Cell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ConfigDom.getExcelStyleForTitle());
		System.out.println("Write Title data!");
		String status = "Form Title: " + cell.getCaption() + " has been written into Excel at row:" + cell.getRow() + " column:" + cell.getColumn();
		WriteJList(status);
	}
	private void HandlePageCounter(TemplateCell cell)
	{
		Node data = getExcelDataNodetoWrite(cell);
		if( data == null)
			return;
		data.setTextContent("Page:  /   ");
		Node Cell = data.getParentNode();
		Node Form = Tool.getNodebyRoot("Form",Cell);
		if( Form != null)
		{
			Form.setTextContent(cell.getFieldNameforDesigner());
			Form.getAttributes().getNamedItem("style").setNodeValue(cell.getCorrespondingFieldType());
		}
		Cell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ConfigDom.getExcelStyleForPage());
	}
	
	private void HandleTableCell(TemplateCell cell)
	{
		Node data = getExcelDataNodetoWrite(cell);
		if( data == null)
			return;
		data.setTextContent(cell.getCaption());
		TraceTemplateCellPosition(cell);
		Node Cell = data.getParentNode();
		Node Form = Tool.getNodebyRoot("Form",Cell);
		if( Form != null)
		{
			Form.setTextContent(cell.getFieldNameforDesigner());
			Form.getAttributes().getNamedItem("style").setNodeValue(cell.getCorrespondingFieldType());
		}
		Cell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ConfigDom.getExcelStyleForTable());
		String status = "Table Cell: " + cell.getCaption() + " has been written into Excel at row:" + cell.getRow() + " column:" + cell.getColumn();
		WriteJList(status);
	}
	
	private Node getExcelDataNodetoWrite(TemplateCell cell)
	{
		Node value = getNodebyPosition(cell.getRow(),cell.getColumn());
		if( value == null)
		{
			System.out.println("Can not find corresponding cell in row:" +
					cell.getRow() + " column:" + cell.getColumn());
			return null;
		}
		return Tool.getNodebyRoot("Data",value);
	}
	private void HandleDefaultValue(TemplateCell cell)
	{
		Node data = getExcelDataNodetoWrite(cell);
		if( data == null)
			return;
		data.setTextContent(cell.getDefaultValue());
		Node Cell = data.getParentNode();
		Node Form = Tool.getNodebyRoot("Form",Cell);
		if( Form != null)
		{
			Form.setTextContent(cell.getFieldNameforDesigner());
			Form.getAttributes().getNamedItem("style").setNodeValue(cell.getCorrespondingFieldType());
		}
		Cell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ConfigDom.getExcelStyleForDefaultValue());
		String status = "Default Value: " + cell.getDefaultValue() + 
		" has been written into Excel at row: " + cell.getRow() + " column: " + cell.getColumn();
		WriteJList(status);
	}
	private void HandleFreeTextCell(TemplateCell cell)
	{
		MergeCell(cell,ConfigDom.getExcelStyleForFreeTextBlock(),cell.getCaption());
		Node data = getExcelDataNodetoWrite(cell);
		if( data == null)
			return;
		Node Cell = data.getParentNode();
		Node Form = Tool.getNodebyRoot("Form",Cell);
		if( Form != null)
		{
			Form.setTextContent(cell.getFieldNameforDesigner());
			Form.getAttributes().getNamedItem("style").setNodeValue(cell.getCorrespondingFieldType());
		}
		Document formDoc = Form.getOwnerDocument();
		Attr index = formDoc.createAttribute("freetextIndex");
		index.setNodeValue(String.valueOf(cell.getFreeTextIndex()));
		Form.getAttributes().setNamedItem(index);
	}
	
	// test function
	private void TraceTemplateCellPosition(TemplateCell cell)
	{
		System.out.println("Cell Value: " + cell.getCaption());
		System.out.println("Cell Row: " + cell.getRow());
		System.out.println("Cell Column: " + cell.getColumn());
	}
	private void HandleCaption(TemplateCell cell)
	{
		
		Node data = getExcelDataNodetoWrite(cell);
		if( data == null)
			return;
		data.setTextContent(cell.getCaption());
		Node Cell = data.getParentNode();
		Node Form = Tool.getNodebyRoot("Form",Cell);
		if( Form != null)
		{
			Form.setTextContent(cell.getFieldNameforDesigner());
			Form.getAttributes().getNamedItem("style").setNodeValue(cell.getCorrespondingFieldType());
		}
		Cell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ConfigDom.getExcelDummyStyle());
		String status = "Caption: " + cell.getCaption() + " has been written into Excel at row:" + cell.getRow() + " column:" + cell.getColumn();
		System.out.println(status);
		WriteJList(status);
	}
	private void HandleLogo(TemplateCell cell)
	{
		Node data = getExcelDataNodetoWrite(cell);
		if( data == null)
			return;
		data.setTextContent(ConfigDom.getDefaultLogo());
		Node Cell = data.getParentNode();
		Node Form = Tool.getNodebyRoot("Form",Cell);
		if( Form != null)
		{
			Form.setTextContent(cell.getFieldNameforDesigner());
			Form.getAttributes().getNamedItem("style").setNodeValue(cell.getCorrespondingFieldType());
		}
		Cell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ConfigDom.getExcelStyleForLogo());
		System.out.println("Write logo data!");
		String status = "Form Logo has been written into Excel at row:" + cell.getRow() + " column:" + cell.getColumn();
		WriteJList(status);
	}
	
	private void WriteJList(String data)
	{
		listModeHandler.addElement(data);
		listModeHandler.addElement("\n");
	}
	// test function
	public void TraceFileInfo(String xdp,String xml)
	{
		listModeHandler.clear();
		listHandler.setModel(listModeHandler);
		String status = "Template File: " + xdp;
		WriteJList(status);
		status = "XML Data File: " + xml;
		WriteJList(status);
		XMLDataFile = xml;
	}
	private Node getNodebyPosition(int row,int column)
	{
		Node rowInstance = getRowInstancebyIndex(row);
		if( rowInstance == null)
			return null;
		return getCellInstancebyIndex(column,rowInstance);
	}
	
	private Node getCellInstancebyIndex(int column,Node row)
	{
		NodeList Cells = row.getChildNodes();
		int CellNumber = Cells.getLength();
		Node item = null;
		int realColumnIndex = 0;
		int relativeColumnIndex = -1;
		for( int i = 0 ; i < CellNumber;i++)
		{
			item = Cells.item(i);
			if( item.getNodeName().equals("Cell"))
			{
				realColumnIndex++;
				relativeColumnIndex = getRelativeIndex(item,realColumnIndex);
				if( relativeColumnIndex != -1)
					realColumnIndex = relativeColumnIndex;
				if( relativeColumnIndex == column)
					return item;
			}
		}
		return null;
	}
	
	private Node getRowInstancebyIndex(int row)
	{
		NodeList Rows = TableNode.getChildNodes();
		int RowNumber = Rows.getLength();
		Node item = null;
		int realRowIndex = 0;
		int relativeIndex = -1;
		for( int i = 0 ; i < RowNumber;i++)
		{
			item = Rows.item(i);
			if( item.getNodeName().equals("Row"))
			{
				realRowIndex++;
				relativeIndex = getRelativeIndex(item,realRowIndex);
				if( relativeIndex != -1)
					realRowIndex = relativeIndex;
				if( realRowIndex == row)
					return item;
			}
		}
		return null;
	}
	private int getRelativeIndex(Node node,int realIndex)
	{
		if( node.getAttributes().getNamedItem("ss:Index") == null)
			return realIndex;
		return Integer.valueOf(node.getAttributes().getNamedItem("ss:Index").getNodeValue());
	}

	private void AddTemplateFilePath(String path)
	{
		Document rootDocument = root.getOwnerDocument();
		Attr template = rootDocument.createAttribute("templatePath");
		template.setNodeValue(path);
		root.setAttributeNode(template);
		
	}
	private void AddXMLDataFilePath(String xml)
	{
		if( xml == null)
			return;
		Document rootDocument = root.getOwnerDocument();
		Attr template = rootDocument.createAttribute("xmlDataFilePath");
		template.setNodeValue(xml);
		root.setAttributeNode(template);
	}
	// pre format excel: generate a full rank matrix
	public void FormatRawExcel(String filePath,String templateFilePath)
	{
		InputStream inputXML = null;
		try 
		{
			inputXML = new FileInputStream(filePath);
			doc = dombuilder.parse(inputXML);
			root = doc.getDocumentElement();
			AddTemplateFilePath(templateFilePath);
			AddXMLDataFilePath(XMLDataFile);
			Node WorkSheet = Tool.getNodebyRoot("Worksheet",root);
			if( WorkSheet != null)
				System.out.println("Found WorkSheet!");
			else 
				return;
			TableNode = Tool.getNodebyRoot("Table",WorkSheet);
			if( TableNode != null)
				System.out.println("Found Table");
			else
				return;
			// generate a 8 * 100 matrix
			GenerateMatrix(ConfigDom.getMaxRowinExcelTransformation(),ConfigDom.getMaxColumninExcelTransformation());
		} 
		catch (FileNotFoundException e1) 
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		catch (SAXException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WriteBackToExcel();
		return;
		// should check if it is a well format document
	}
	/*public static void main(String[] arg)
	{
		ExcelTransformer t = new ExcelTransformer(null);
		t.FormatRawExcel("./1.xml");
		t.SaveAs("./2.xml");
	}*/
	
	
}