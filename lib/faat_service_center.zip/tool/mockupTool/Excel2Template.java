package mockupTool;

import utilities.*;
import excelFormat.excelHandler;
import excelFormat.internalStructure.*;
import configuration.ConfigDom;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

class TemplateNodeName
{
	private String name = null;
	public TemplateNodeName(String Name)
	{
		name = Name;
	}
	public String getName()
	{
		return name;
	}
	public boolean equals(Object obj)
	{
		if( !(obj instanceof TemplateNodeName))
			return false;
		TemplateNodeName object = (TemplateNodeName)obj;
		return name.equals(object.getName());
	}
	public int hashCode()
	{
		return 37 + name.hashCode();
	}
}
class TemplateFieldNode
{
	private String type = null;
	private Node DesignerNode = null;
	public TemplateFieldNode(String Style,Node node)
	{
		if( Style != null)
			type = Style;
		DesignerNode = node;
	}
	public String getType()
	{
		return type;
	}
	public Node getDesignerNode()
	{
		return DesignerNode;
	}
}

public class Excel2Template
{
	private Document docForExcel;
	private Document docForTemplate;
	private DocumentBuilder dombuilder;
	private DocumentBuilderFactory domfac;
	private Element rootForExcel = null;
	private Element rootForTemplate = null;
	private FileCopyFactory filecopy;
	private String ExcelPath = null;
	private String SavedTemplatePath = null;
	private String TemplatePath = null;
	private Node TableNode = null;
	private Node formContentNode = null;
	private Node firstSummaryNode = null;
	private Node firstSignatureNode = null;
	private Node WorkSheet = null;
	private Node DesignerTableNode = null;
	private Node nestedRowDataNode = null; // the second line content row node
	private HashMap<TemplateNodeName,Node> TemplateFieldsCollection = null; // first map
	private HashMap<TemplateNodeName,Node> ExcelFieldsCollection = null; // second map
	private HashMap<Node,TemplateFieldNode> CounterNodeMap = null;
	private int newNameIndex = 0;
	private int relativePosition = -1;
	private int previousMaxInfoHeight = -1;
	private final int PREVIOUS = -2;
	private final int NEXTSIBLING = -3;
	private final String EMPTY = "";
	private boolean isDefaultValue = false;
	private boolean isFirstSummaryNode = true;
	private boolean isFirstSignatureNode = true;
	private boolean isFreeTextHandled = false;
	private boolean isHighLightNewField = false;
	private excelHandler excelPathExtractor = null;
	private XMLDataFileRetriever XMLContentRetriever = null;
	private DefaultListModel ListMode = null;
	private JList jList = null;
	public Excel2Template(String excelpath)
	{
		domfac = DocumentBuilderFactory.newInstance();
		ExcelPath = excelpath;
		TemplateFieldsCollection = new HashMap<TemplateNodeName,Node>();
		ExcelFieldsCollection = new HashMap<TemplateNodeName,Node>();
		CounterNodeMap = new HashMap<Node,TemplateFieldNode>();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void setHighLightOption(int option)
	{
		if( option == JOptionPane.YES_OPTION)
			isHighLightNewField = true;
		else
			isHighLightNewField = false;
	}
	
	public void setSavedTemplatePath(String path)
	{
		SavedTemplatePath = path;
	}
	// main engine here
	private void HandleTableNode()
	{
		WorkSheet = getNodebyRoot("Worksheet",rootForExcel);
		if( WorkSheet == null)
			return;
		TableNode = getNodebyRoot("Table",WorkSheet);
		if( TableNode == null)
			return;
		System.out.println("Get Table Node OK!");
		Node item = null;
		NodeList child = TableNode.getChildNodes();
		int length = child.getLength();
		for(int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("Row"))
				HandleRowInstance(item);
		}
		AdaptContentArea();
	}
	private void HandleRowInstance(Node node)
	{
		Node item = null;
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		for(int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("Cell"))
				HandleCellInstance(item);
		}
	}
	private void HandleCellInstance(Node node)
	{
		Node data = getNodebyRoot("Data",node);
		if( data == null)
			return;
		// most of the cell node should be this type:dummy node.
		if( data.getTextContent() == null)
			return;
		if( data.getTextContent().length() == 0 )
			return;
		
		System.out.println("cell!!! ->" + data.getTextContent());
		if( data.getTextContent().equals("aa"))
		{
			System.out.println("here");
			
		}
		Node FormNode = getNodebyRoot("Form",node);
		if( FormNode == null)
		{
			FormNode = getNodebyRoot("ss:Form",node);
			if( FormNode == null)
			{
				// indicate that this cell is newly added by Service Advisor!
				System.out.println("Ready to Add new Field into the Template: " + data.getTextContent());
				if( data.getTextContent().equals("bbbb"))
					System.out.println("1");
				AddNewTemplateField(node);
				return;
			}
		}
		String style = Tool.getAttributeValue("style",FormNode);
		if( style != null && style.equals("RemarkCell"))
		{
			AdaptTemplateField(data,FormNode);
			return;
		}
		if ( FormNode.getTextContent().length() == 0 )
		{
			AddNewTemplateField(node);
			return;
		}
		// add into the ExcelFieldsCollection if it is not Default value
		if( !FormNode.getTextContent().equals("DefalutValue"))
		{
			TemplateNodeName TemplateName = new TemplateNodeName(FormNode.getTextContent());
			ExcelFieldsCollection.put(TemplateName,node);
		}
		AdaptTemplateField(data,FormNode);
	}
	
	private String getExcelNodeStyle(Node node)
	{
		Node form = getNodebyRoot("Form",node);
		if( form == null)
		{
			form = getNodebyRoot("ss:Form",node);
			if( form == null)
				return null;
		}
		return Tool.getAttributeValue("style",form);
	}
	
	private Node HorizontalSearchCounterNode(Node cell)
	{
		Node previous = cell.getPreviousSibling();
		while( previous != null)
		{
			if( previous.getNodeName().equals("Cell"))
			{
				//System.out.println("Previous Name: " + getNodebyRoot("Data",previous).getTextContent());
				return previous;
			}
			previous = previous.getPreviousSibling();
		}
		return null;
	}
	
	private String getFieldStyle(Node Cell)
	{
		TemplateFieldNode DesignerNode = CounterNodeMap.get(Cell);
		if( DesignerNode != null)
		{
			return DesignerNode.getType();
		}
		else 
			return getExcelNodeStyle(Cell);
	}
	private boolean isNodeaboveSignatureBlock(Node node)
	{
		if( firstSignatureNode == null)
		/* means that currently it has not traversed the signature block! */
			return true;
		Node NextRow = getNextRow(node.getParentNode());
		NodeList child = null;
		while( NextRow != null)
		{
			child = NextRow.getChildNodes();
			for( int i = 0 ; i < child.getLength();i++)
			{
				if( child.item(i).isSameNode(firstSignatureNode))
					return true;
			}
			NextRow = getNextRow(NextRow);
		}
		return false;
	}
	private void AddNewTemplateField(Node node)
	{
		String style = getExcelNodeStyle(node);
		Node CounterNode = null;
		if( (style != null) && ( style.equals("TableHeader")))
		{
			AddNewTableHeaderinDesigner(node);
			return;
		}
		Node previous = HorizontalSearchCounterNode(node);
		if( getFieldStyle(previous) != null && getFieldStyle(previous).equals("SummaryField"))
		{
			AddNewSummaryCellNodeinDesigner(node,previous);
			return;
		}
		if( isNodebehindSummaryBlock(node))
		{
			if( isNodeaboveSignatureBlock(node))
			{
				CounterNode = getSummSigItemCounterNode(node,"SummaryField");
				AddNewSummaryCellNodeinDesigner(node,CounterNode);
			}
			else
			{
				CounterNode = getSummSigItemCounterNode(node,"SignatureField");
				AddNewSignatureCellNodeinDesigner(node,CounterNode);
			}
			return;
		}
		CounterNode = getCounterNode(node);
		if( CounterNode == null)
		{
			stop();
			return;
		}
		// check if CounterPart has already a Coppresonding node in the HashMap
		if( CounterNodeMap.get(CounterNode) == null)
		{
			style = getCounterNodeStyle(CounterNode);
			if( style == null)
				return;
		}
		else 
			style = CounterNodeMap.get(CounterNode).getType();
		//stop();
		if( style.equals("Caption") && ( isDefaultValue == false))
		{
			// it is possible that it is a summary block
			if( isNodebehindSummaryBlock(node))
			{
				CounterNode = getSummSigItemCounterNode(node,"SummaryField");
				AddNewSummaryCellNodeinDesigner(node,CounterNode);
				return;
			}
			AddNewCaptionNodeinDesigner(node,CounterNode);
		}
		else if ( style.equals("RemarkCell"))
			AddNewRemarkCellNodeinDesigner(node,CounterNode);
		else if ( style.equals("SummaryField"))
			AddNewSummaryCellNodeinDesigner(node,CounterNode);
		else if ( style.equals("FreeTextCell"))
			AddNewFreeTextCellNodeinDesigner(node,CounterNode);
		else if ( style.equals("DefalutValue") || isDefaultValue )
		{
			AddNewDefaultValueNodeinDesigner(node);
			// one time use
			isDefaultValue = false;
		}
	}
	
	private void AddNewFreeTextCellNodeinDesigner(Node node,Node CounterNode)
	{
		Node CounterNodeinDesigner = getCounterNodeDesignerField(CounterNode);
		if( CounterNodeinDesigner == null)
			return;
		Node value = getNodebyRoot("value",CounterNodeinDesigner);
		if( value == null)
			return;
		Node exData = getNodebyRoot("exData",value);
		if( exData == null)
			return;
		Node body = getNodebyRoot("body",exData);
		if( body == null)
			return;
		Element inputElement = Tool.createInputElement(body);
		Element seperator = Tool.createSeperatorElement(body);
		inputElement.setTextContent(getNodebyRoot("Data",node).getTextContent());
		body.appendChild(seperator);
		body.appendChild(inputElement);
		TemplateFieldNode DesignerNode = new TemplateFieldNode("FreeTextCell",CounterNodeinDesigner);
		CounterNodeMap.put(node,DesignerNode);
	}
	private void ModifyDummySubform(Node subform)
	{
		String name = Tool.getAttributeValue("name",subform);
		if( name == null)
			return;
		if( name.contains("dummy"))
		{
			name = "NewCreatedSubform" + newNameIndex++;
			subform.getAttributes().getNamedItem("name").setNodeValue(name);
		}
	}
	
	private int getCounterFieldRelativeIndexinDesigner(Node TemplateField)
	{
		int index = 0;
		Node subform = TemplateField.getParentNode();
		NodeList children = subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals("field") || item.getNodeName().equals("draw"))
				index++;
			if( item.isSameNode(TemplateField))
				return index;
		}
		return -1;
	}
	private Node getDesignerFieldbyIndex(Node Subform,int index)
	{
		NodeList children = Subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		int step = 0;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals("field") || item.getNodeName().equals("draw"))
				step++;
			if( step == index)
				return item;
		}
		return null;
	}
	
	private void ResetNewFieldHeight(Node node)
	{
		if( node.getAttributes().getNamedItem("h") !=null)
			node.getAttributes().getNamedItem("h").setNodeValue("5mm");
		else
			node.getAttributes().getNamedItem("minH").setNodeValue("5mm");
	}
	private void AddNewsignatureFieldintoSubform(Node CellNode,Node CounterField,Node NewCreatedField,Node Subform)
	{
		int index = getCounterFieldRelativeIndexinDesigner(CounterField);
		if( index == -1)
			return;
		System.out.println("Counter Index:" + index);
		// signature image
		if( !CellNode.getParentNode().isSameNode(firstSignatureNode.getParentNode()))
			ResetNewFieldHeight(NewCreatedField);
		Node insertedNode = getDesignerFieldbyIndex(Subform,index+1);
		if( insertedNode == null)
			Subform.appendChild(NewCreatedField);
		else
			Subform.insertBefore(NewCreatedField,insertedNode);
	}
	private void AddNewSignatureCellNodeinDesigner(Node node,Node CounterNode)
	{
		Node CounterNodeinDesigner = getCounterNodeDesignerField(CounterNode);
		if( CounterNodeinDesigner == null)
			return;
		Node NewFieldinDesigner = CounterNodeinDesigner.cloneNode(true);
		if( NewFieldinDesigner == null)
		{
			System.out.println("Cannot Create a New Field in Designer!");
			stop();
		}
		if( isHighLightNewField)
			highLightTableHeader(NewFieldinDesigner);
		CleanDataBinding(NewFieldinDesigner);
		int index = getCellRelativeIndex(node);
		System.out.println("index:" + index );
		Node newSigFieldSubform = getSignatureFieldWraperSubform(CounterNode,index);
		AddNewsignatureFieldintoSubform(node,CounterNodeinDesigner,NewFieldinDesigner,newSigFieldSubform);
		//newSigFieldSubform.appendChild(NewFieldinDesigner);
		ModifyDummySubform(newSigFieldSubform);
		Node value = getNodebyRoot("value",NewFieldinDesigner);
		if( value == null)
		//	return;
		{
			CreateNewValueNode(NewFieldinDesigner,getNodebyRoot("Data",node).getTextContent());
			String fieldName = "NewCreatedFieldName" + newNameIndex++;
			NewFieldinDesigner.getAttributes().getNamedItem("name").setNodeValue(fieldName);
			TemplateFieldNode DesignerNode = new TemplateFieldNode("SignatureField",NewFieldinDesigner);
			CounterNodeMap.put(node,DesignerNode);
			//if( isLastNodetobeHandled(node))
			//{
			//stop();
			if( isSignatureWidthNeedRecalculation(node))
				RecalculateSignatureBlockWidth(node);
			//}
			return;
		}
		Node text = getNodebyRoot("text",value);
		if( text == null)
			text = getNodebyRoot("decimal",value);
		text.setTextContent(getNodebyRoot("Data",node).getTextContent());
		String fieldName = "NewCreatedFieldName" + newNameIndex++;
		NewFieldinDesigner.getAttributes().getNamedItem("name").setNodeValue(fieldName);
		TemplateFieldNode DesignerNode = new TemplateFieldNode("SignatureField",NewFieldinDesigner);
		CounterNodeMap.put(node,DesignerNode);
		//if( isLastNodetobeHandled(node))
		//{
		//stop();
		if( isSignatureWidthNeedRecalculation(node))
			RecalculateSignatureBlockWidth(node);
		//}
	}
	
	private void RecalculateSignatureBlockWidth(Node CellNode)
	{
		TemplateFieldNode designerNode = CounterNodeMap.get(CellNode);
		if( designerNode == null)
			return;
		Node Subform = designerNode.getDesignerNode().getParentNode().getParentNode();
		Vector<Node> SubformVec = new Vector<Node>();
		String name = null;
		NodeList children = Subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i= 0 ; i < length;i++)
		{
			item = children.item(i);
			if( !item.getNodeName().equals("subform"))
				continue;
			name = Tool.getAttributeValue("name",item);
			if( name == null)
				continue;
			if( !name.contains("dummy"))
				SubformVec.add(item);
		}
		if( SubformVec.isEmpty())
			return;
		int realWidthPerSubform = (int) (ConfigDom.getMaxFormWidth() / SubformVec.size());
		System.out.println("Real Width: " + realWidthPerSubform);
		//stop();
		SetSubformWidth(SubformVec,realWidthPerSubform);
	}
	
	private void SetSubformWidth(Vector<Node> SubformVec,int width)
	{
		NodeList children = null;
		int length = 0;
		Node item = null;
		for( int i = 0 ; i < SubformVec.size(); i++)
		{
			children = SubformVec.elementAt(i).getChildNodes();
			length = children.getLength();
			for( int j = 0; j < length;j++)
			{
				item = children.item(j);
				if( (!item.getNodeName().equals("draw")) && ( !item.getNodeName().equals("field")))
					continue;
				item.getAttributes().getNamedItem("w").setNodeValue("" + width + "mm");
			}
		}
	}
	
	private int getSubformWidth(Node node)
	{
		NodeList children = node.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i= 0 ; i < length;i++)
		{
			item = children.item(i);
			if( !item.getNodeName().equals("draw") && !item.getNodeName().equals("field"))
				continue;
			String width = Tool.getAttributeValue("w",item);
			if( width == null)
			{
				System.out.println("Draw/Field Width 0!");
				continue;
			}
			return getRealValue(width);
		}
		System.out.println("Subform Width 0!");
		return 0;
	}
	private boolean isSignatureWidthNeedRecalculation(Node node)
	{
		TemplateFieldNode DesignerNode = CounterNodeMap.get(node);
		if(DesignerNode == null)
			return false;
		Node Subform = DesignerNode.getDesignerNode().getParentNode().getParentNode();
		if( Subform == null)
			return false;
		int totalWidth = 0; 
		NodeList children = Subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i= 0 ; i < length;i++)
		{
			item = children.item(i);
			if( !item.getNodeName().equals("subform"))
				continue;
			String name = Tool.getAttributeValue("name",item);
			System.out.println("Subform: " + name);
			totalWidth += getSubformWidth(item);
		}
		System.out.println("Total Width: " + totalWidth);
		if( totalWidth > ConfigDom.getMaxFormWidth())
			return true;
		//stop();
		return false;
	}
	private Node getSignatureFieldWraperSubform(Node CounterNode,int index)
	{
		Node CounterNodeDesignerNode = getCounterNodeDesignerField(CounterNode);
		if( CounterNodeDesignerNode == null)
			return null;
		return getInstancebyIndex(CounterNodeDesignerNode.getParentNode().getParentNode(),index,"subform"); 
	}
	private Node getSummSigItemCounterNode(Node node,String type)
	{
		System.out.println("want to search type: " + type);
		Node previous = node.getPreviousSibling();
		TemplateFieldNode designerNode = null;
		while( previous != null)
		{
			designerNode = CounterNodeMap.get(previous);
			if( designerNode == null)
			{
				previous = previous.getPreviousSibling();
				System.out.println("1");
				continue;
			}
			if( designerNode.getType().equals(type))
				return previous;
			previous = previous.getPreviousSibling();
			System.out.println("12");
		}
		Node previousRow = getPreviousRow(node.getParentNode());
		while( previousRow != null)
		{
			Node counterNode = getInstancebyIndex(previousRow,1,"Cell");
			if( counterNode == null)
			{
				previousRow = getPreviousRow(previousRow);
				continue;
			}
			
			designerNode = CounterNodeMap.get(counterNode);
			if( designerNode == null)
			{
				previousRow = getPreviousRow(previousRow);
				continue;
			}
			System.out.println("Designer Type: " + designerNode.getType());
			if( designerNode.getType().equals(type))
				return counterNode;
			previousRow = getPreviousRow(previousRow);
		}
			
		System.out.println("nothing find!");
		stop();
		return null;
	}
	private boolean isNodebehindSummaryBlock(Node node)
	{
		// if the node is located in the same line,it also should be regarded
		// as behind summary field
		Node LeftNode = node.getPreviousSibling();
		Node form = null;
		while( LeftNode != null)
		{
			if( !LeftNode.getNodeName().equals("Cell"))
			{
				LeftNode = LeftNode.getPreviousSibling();
				continue;
			}
			form = getNodebyRoot("Form",LeftNode);
			if( form == null)
			{
				form = getNodebyRoot("ss:Form",LeftNode);
				if( form == null)
				{
					LeftNode = LeftNode.getPreviousSibling();
					continue;
				}
			}
			if( Tool.getAttributeValue("style",form).equals("SummaryField"))
				return true;
			LeftNode = LeftNode.getPreviousSibling();
		}
		Node PreviousRow = getPreviousRow(node.getParentNode());
		NodeList child = null;
		while( PreviousRow != null)
		{
			child = PreviousRow.getChildNodes();
			for( int i = 0 ; i < child.getLength();i++)
			{
				if( child.item(i).isSameNode(firstSummaryNode))
					return true;
			}
			PreviousRow = getPreviousRow(PreviousRow);
		}
		return false;
	}
	
	// test function
	/*private void AddNewSubform(Node node)
	{
		Document doc = node.getOwnerDocument();
		Element sub = doc.createElement("sqweorm");
		Attr name = doc.createAttribute("nqweame");
		name.setNodeValue("wanqwegwei");
		sub.setAttributeNode(name);
		Attr width = doc.createAttribute("wasd");
		width.setNodeValue("1qqwe0mm");
		sub.setAttributeNode(width);
		node.appendChild(sub);
	}*/
	
	private boolean isFirstCell(Node node)
	{
		Node previous = node.getPreviousSibling();
		while ( previous != null)
		{
			if( previous.getNodeName().equals("Cell"))
				return false;
			previous = previous.getPreviousSibling();
		}
		return true;
	}
	private void AddNewSummaryCellNodeinDesigner(Node node,Node CounterNode)
	{
		boolean isFirstElement = false;
		Node subform = null;
		if( isFirstCell(node))
		{
			Node ownParent = getCounterNodeDesignerField(CounterNode).getParentNode().getNextSibling();
			while( ownParent != null)
			{
				if( ownParent.getNodeName().equals("subform"))
					break;
				ownParent = ownParent.getNextSibling();
			}
			if( ownParent != null)
				subform = ownParent;
			else
			{
				System.out.println("can not find new subform!");
				stop();
				return;
			}
			isFirstElement = true;
		}
		Node CounterNodeinDesigner = getCounterNodeDesignerField(CounterNode);
		if( CounterNodeinDesigner == null)
			return;
		Node NewFieldinDesigner = CounterNodeinDesigner.cloneNode(true);
		if( NewFieldinDesigner == null)
		{
			System.out.println("Cannot Create a New Field in Designer!");
			stop();
		}
		if( isHighLightNewField)
			highLightTableHeader(NewFieldinDesigner);
		CleanDataBinding(NewFieldinDesigner);
		int index = getCellRelativeIndex(node);
		if( isFirstElement && index == 1)
			subform.appendChild(NewFieldinDesigner);
		else if ( isFirstElement && index != 1)
		{
			for( int j = 0 ; j < index-1;j++)
			// should also retrieve those dummy cell before "node"
				AddHiddenSubformtoOccupySpace(node,"SummaryField",NewFieldinDesigner,subform,index+1);
			subform.appendChild(NewFieldinDesigner);
		}
		else
		{
			int dummyNumber = getPreviousDummyCellNumber(node);
			System.out.println("dummy: " + dummyNumber);
			for( int k = 0 ; k < dummyNumber;k++)
				AddHiddenSubformtoOccupySpace(node,"SummaryField",NewFieldinDesigner,CounterNodeinDesigner.getParentNode(),index - k - 1);
			CounterNodeinDesigner.getParentNode().appendChild(NewFieldinDesigner);
		}
		Node value = getNodebyRoot("value",NewFieldinDesigner);
		if( value == null)
		//	return;
		{
			CreateNewValueNode(NewFieldinDesigner,getNodebyRoot("Data",node).getTextContent());
			String fieldName = "NewCreatedFieldName" + newNameIndex++;
			NewFieldinDesigner.getAttributes().getNamedItem("name").setNodeValue(fieldName);
			TemplateFieldNode DesignerNode = new TemplateFieldNode("SummaryField",NewFieldinDesigner);
			CounterNodeMap.put(node,DesignerNode);
			if( isLastNodetobeHandled(node))
			{
				//stop();
				if( isSummaryWidthNeedRecalculation(node))
					RecalculateSummaryBlockWidth(node);
			}
			return;
		}
		Node text = getNodebyRoot("text",value);
		if( text == null)
			text = getNodebyRoot("decimal",value);
		text.setTextContent(getNodebyRoot("Data",node).getTextContent());
		String fieldName = "NewCreatedFieldName" + newNameIndex++;
		NewFieldinDesigner.getAttributes().getNamedItem("name").setNodeValue(fieldName);
		TemplateFieldNode DesignerNode = new TemplateFieldNode("SummaryField",NewFieldinDesigner);
		CounterNodeMap.put(node,DesignerNode);
		if( isLastNodetobeHandled(node))
		{
			//stop();
			if( isSummaryWidthNeedRecalculation(node))
				RecalculateSummaryBlockWidth(node);
		}
	}
	
	private int getRealValue(String w)
	{
		int index = w.indexOf("m");
		if ( index != -1)
			return (int) Float.parseFloat(w.substring(0,index));
		// unit: inch
		index = w.indexOf("i");
		if( index == -1)
			return 0;
		return (int) (Float.parseFloat(w.substring(0,index)) * 25.4);
	}
	private boolean isSummaryWidthNeedRecalculation(Node node)
	{
		TemplateFieldNode DesignerNode = CounterNodeMap.get(node);
		if(DesignerNode == null)
			return false;
		Node Subform = DesignerNode.getDesignerNode().getParentNode();
		if( Subform == null)
			return false;
		int totalWidth = 0; 
		NodeList children = Subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i= 0 ; i < length;i++)
		{
			item = children.item(i);
			if( !item.getNodeName().equals("field") && !item.getNodeName().equals("draw"))
				continue;
			String name = Tool.getAttributeValue("name",item);
			String width = Tool.getAttributeValue("w",item);
			System.out.println("Name: " + name + " Width: " + width);
			if( width == null)
				continue;
			totalWidth += getRealValue(width);
		}
		System.out.println("Total Width: " + totalWidth);
		if( totalWidth > ConfigDom.getMaxFormWidth())
			return true;
		//stop();
		return false;
		
	}
	// those dummy cells leads to the space displayed in the excel
	private int getPreviousDummyCellNumber(Node node)
	{
		int ownIndex = getCellRelativeIndex(node);
		if( ownIndex == -1)
			return 0;
		Node previous = node.getPreviousSibling();
		while ( previous != null)
		{
			if( !previous.getNodeName().equals("Cell"))
			{
				previous = previous.getPreviousSibling();
				continue;
			}
			if( getNodebyRoot("Data",previous).getTextContent().length() != 0)
				break;
			previous = previous.getPreviousSibling();
		}
		if( previous == null)
			return 0;
		int previousIndex = getCellRelativeIndex(previous);
		if( previousIndex == -1)
			return 0;
		return ownIndex - previousIndex - 1;
	}
	
	private void AddHiddenSubformtoOccupySpace(Node CellNode,String style,Node NewFieldinDesigner,Node subform,int index)
	{
		Node dummyCellNode = getInstancebyIndex(CellNode.getParentNode(),index,"Cell");
		if( dummyCellNode == null)
		{
			System.out.println("Cannot find Dummy Cell @index: " + index);
			return;
		}
		Node hiddenNode = NewFieldinDesigner.cloneNode(true);
		CleanDataBinding(hiddenNode);
		String fieldName = "NewCreatedFieldName" + newNameIndex++;
		hiddenNode.getAttributes().getNamedItem("name").setNodeValue(fieldName);
		Document hiddenDocument = hiddenNode.getOwnerDocument();
		Attr presence = hiddenDocument.createAttribute("presence");
		presence.setNodeValue("invisible");
		hiddenNode.getAttributes().setNamedItem(presence);
		subform.appendChild(hiddenNode);
		// should also insert into counterMap
		TemplateFieldNode space = new TemplateFieldNode("style",hiddenNode);
		CounterNodeMap.put(dummyCellNode,space);
	}
	private void AddNewRemarkCellNodeinDesigner(Node Code,Node CounterNode)
	{
		Node CounterNodeinDesigner = getCounterNodeDesignerField(CounterNode);
		if( CounterNodeinDesigner == null)
			return;
		Node NewFieldinDesigner = CounterNodeinDesigner.cloneNode(true);
		if( NewFieldinDesigner == null)
		{
			System.out.println("Cannot Create a New Field in Designer!");
			stop();
		}
		if( isHighLightNewField)
			highLightTableHeader(NewFieldinDesigner);
		CleanDataBinding(NewFieldinDesigner);
		CounterNodeinDesigner.getParentNode().appendChild(NewFieldinDesigner);
		Node value = getNodebyRoot("value",NewFieldinDesigner);
		if( value == null)
		//	return;
		{
			CreateNewValueNode(NewFieldinDesigner,getNodebyRoot("Data",Code).getTextContent());
			String fieldName = "NewCreatedFieldName" + newNameIndex++;
			NewFieldinDesigner.getAttributes().getNamedItem("name").setNodeValue(fieldName);
			TemplateFieldNode DesignerNode = new TemplateFieldNode("RemarkCell",NewFieldinDesigner);
			CounterNodeMap.put(Code,DesignerNode);
			return;
		}
		Node text = getNodebyRoot("text",value);
		if( text == null)
			return;
		text.setTextContent(getNodebyRoot("Data",Code).getTextContent());
		String fieldName = "NewCreatedFieldName" + newNameIndex++;
		NewFieldinDesigner.getAttributes().getNamedItem("name").setNodeValue(fieldName);
		TemplateFieldNode DesignerNode = new TemplateFieldNode("RemarkCell",NewFieldinDesigner);
		CounterNodeMap.put(Code,DesignerNode);
	}
	private void CreateNewValueNode(Node DesignerNode,String defaultValue)
	{
		Document doc = DesignerNode.getOwnerDocument();
		Element value = doc.createElement("value");
		Element text = doc.createElement("text");
		text.setTextContent(defaultValue);
		value.appendChild(text);
		DesignerNode.appendChild(value);
	}
	// dummy add: since the default and caption share the same node in the designer
	private void AddNewDefaultValueNodeinDesigner(Node Cell)
	{
		Node LeftNode = getLeftNode(Cell);
		if( LeftNode == null)
			return;
		Node DesignerNode = getCounterNodeDesignerField(LeftNode);
		if( DesignerNode == null)
			return;
		Node value = getNodebyRoot("value",DesignerNode);
		if( value == null)
		//	return;
		{
			CreateNewValueNode(DesignerNode,getNodebyRoot("Data",Cell).getTextContent());
			TemplateFieldNode defaultNode = new TemplateFieldNode("DefalutValue",DesignerNode);
			CounterNodeMap.put(Cell,defaultNode);
			return;
		}
		Node text = getNodebyRoot("text",value);
		if( text == null)
			return;
		text.setTextContent(getNodebyRoot("Data",Cell).getTextContent());
		TemplateFieldNode defaultNode = new TemplateFieldNode("DefalutValue",DesignerNode);
		CounterNodeMap.put(Cell,defaultNode);
	}
	private Node getLeftNode(Node Cell)
	{
		int currentIndex = getCellRelativeIndex(Cell);
		if( currentIndex == -1)
			return null;
		return getInstancebyIndex(Cell.getParentNode(),currentIndex - 1,"Cell");
	}
	private int getTableCellIndex(Node cellNode)
	{
		Node form = getNodebyRoot("Form",cellNode);
		{
			if( form == null)
			{
				form = getNodebyRoot("ss:Form",cellNode);
				if( form == null)
					return -1;
			}
		}
		return Integer.parseInt(Tool.getAttributeValue("tableindex",form));
	}
	
	private void AddNewTableHeaderinDesigner(Node CellNode)
	{
		Node left = getLeftTableCell(CellNode);
		if( left != null)
		{
			Node DesignerNode = getCounterNodeDesignerField(left);
			if( DesignerNode == null)
			{
				System.out.println("Table Header's left Node has not corresponding " + 
						"node in the Designer!");
				//stop();
				return;
			}
			System.out.println("Left Node's Designer Node name: " + Tool.getAttributeValue("name",DesignerNode));
			Node newHeader = DesignerNode.cloneNode(true);
			// should judge where should this new created node be inserted
			Node right = getRightTableCell(CellNode);
			if( right == null)
			{
				// the last
				DesignerNode.getParentNode().appendChild(newHeader);
			}
			else
			{
				Node rightDesignerNode = getCounterNodeDesignerField(right);
				if( rightDesignerNode == null)
					DesignerNode.getParentNode().appendChild(newHeader);
				else
					DesignerNode.getParentNode().insertBefore(newHeader,rightDesignerNode);
			}
			String fieldName = "NewCreatedFieldName" + newNameIndex++;
			newHeader.getAttributes().getNamedItem("name").setNodeValue(fieldName);
			ModifyTableHeaderName(CellNode,newHeader);
			System.out.println("Append New Table header: " + fieldName + " ok!");
			int index = getTableCellIndex(CellNode);
			System.out.println("Append New Table header in index: " + index);
			AddNewContentRowFieldinDesigner(CellNode,index);
			RecalculateTableWidth(CellNode,index);
			if( isHighLightNewField)
				highLightTableHeader(newHeader);
		}
		// it is impossible to insert some header in the front table due to excel limitation
	}
	
	private void highLightTableHeader(Node node)
	{
		Node border = getNodebyRoot("border",node);
		if( border == null)
		{
			Document nodeDoc = node.getOwnerDocument();
			Element borderNode = nodeDoc.createElement("border");
			Element Fill = nodeDoc.createElement("fill");
			Element Color = nodeDoc.createElement("color");
			Attr Value = nodeDoc.createAttribute("value");
			Value.setNodeValue("255,0,255");
			Color.setAttributeNode(Value);
			Fill.appendChild(Color);
			borderNode.appendChild(Fill);
			node.appendChild(borderNode);
			return;
		}
		Node fillNode = getNodebyRoot("fill",border);
		if( fillNode != null)
			return;
		Document document = border.getOwnerDocument();
		Element fill = document.createElement("fill");
		Element color = document.createElement("color");
		Attr value = document.createAttribute("value");
		value.setNodeValue("255,0,255");
		color.setAttributeNode(value);
		fill.appendChild(color);
		border.appendChild(fill);
	}
	// if there are multilines,only retrieve first line
	private String getTableHeaderString(Node TableHeader)
	{
		Node value = getNodebyRoot("value",TableHeader);
		if( value == null)
			return EMPTY;
		Node text = getNodebyRoot("text",value);
		if( text != null)
		{
			String whole = text.getTextContent();
			if( whole.indexOf("/") != -1)
				return whole.split("/")[0];
			return whole;
		}
		Node exData = getNodebyRoot("exData",value);
		if( exData == null)
		{
			return getNodebyRoot("decimal",value).getTextContent();
		}
		Node body = getNodebyRoot("body",exData);
		return getNodebyRoot("p",body).getTextContent();
		
	}
	
	private void RecalculateSummaryBlockWidth(Node CellNode)
	{
		Node HeaderSubform = CellNode.getParentNode();
		Node Cell = null;
		String totalValue = EMPTY;
		int index = getCellRelativeIndex(CellNode);
		Node[] NodeHolder = new Node[index+1];
		String name = null;
		for( int i = 1;i < index + 1;i++)
		{
			Cell = getInstancebyIndex(HeaderSubform,i,"Cell");
			String cellName = getNodebyRoot("Data",Cell).getTextContent();
			if( cellName.length() != 0 )
			{
				System.out.println("Cell Name : " + cellName);
				NodeHolder[i] = getCounterNodeDesignerField(Cell);
				name = Tool.getAttributeValue("name",NodeHolder[i]);
				System.out.println("Adobe Name:" + name);
				totalValue += getNodebyRoot("Data",Cell).getTextContent();
			}
			else
			{
				totalValue += "dummy";
				NodeHolder[i] = getCounterNodeDesignerField(Cell);
			}
		}
		System.out.println("Total:" + totalValue);
		System.out.println("Total length:" + totalValue.length());
		float perWidth = ConfigDom.getMaxFormWidth() / (float)totalValue.length();
		System.out.println("per Width: " + perWidth);
		float RealWidth = 0;
		for( int j = 1;j < index + 1;j++)
		{
			String item = getTableHeaderString(NodeHolder[j]);
			System.out.println("item value: " + item);
			System.out.println("Table header: " + Tool.getAttributeValue("name",NodeHolder[j]));
			RealWidth = perWidth * item.length();
			System.out.println("Width: " + RealWidth );
			String w = RealWidth + "mm";
			System.out.println("Ready to set RealWidth: " + w + " for Field:" + Tool.getAttributeValue("name",NodeHolder[j]));
			NodeHolder[j].getAttributes().getNamedItem("w").setNodeValue(w);
		}
		//stop();
	}
	private void RecalculateTableWidth(Node CellNode,int totalColumn)
	{
		Node HeaderSubform = CellNode.getParentNode();
		Node Cell = null;
		String totalValue = EMPTY;
		String totalWidth = EMPTY;
		Node[] NodeHolder = new Node[totalColumn+1];
		for( int i = 1;i < totalColumn + 1;i++)
		{
			Cell = getInstancebyIndex(HeaderSubform,i,"Cell");
			NodeHolder[i] = getCounterNodeDesignerField(Cell);
			totalValue += getTableHeaderString(NodeHolder[i]);
		}
		//System.out.println("Total:" + totalValue);
		//System.out.println("Total length:" + totalValue.length());
		float perWidth = ConfigDom.getMaxFormWidth() / (float)totalValue.length();
		//System.out.println("per Width: " + perWidth);
		float RealWidth = 0;
		for( int j = 1;j < totalColumn + 1;j++)
		{
			String item = getTableHeaderString(NodeHolder[j]);
			//System.out.println("Table header: " + getAttributeValue("name",NodeHolder[j]));
			RealWidth = perWidth * item.length();
			//System.out.println("Width: " + RealWidth );
			String w = RealWidth + "mm";
			NodeHolder[j].getAttributes().getNamedItem("w").setNodeValue(w);
			totalWidth += ( w + " ") ;
		}
		Node DesignerHeaderSubform = NodeHolder[1].getParentNode();
		Node Table = DesignerHeaderSubform.getParentNode();
		DesignerTableNode = DesignerHeaderSubform;
		totalWidth = "\"" + totalWidth + "\"";
		//System.out.println("Total Width: " + totalWidth);
		Table.getAttributes().getNamedItem("columnWidths").setNodeValue(totalWidth);
	}
	
	private void SetWidthForDemo()
	{
		NodeList child = DesignerTableNode.getChildNodes();
		int length = child.getLength();
		Node item = null;
		Vector<Node> NodeHolder = new Vector<Node>();
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("draw"))
				NodeHolder.addElement(item);
		}
		NodeHolder.elementAt(0).getAttributes().getNamedItem("w").setNodeValue("14mm");
		NodeHolder.elementAt(1).getAttributes().getNamedItem("w").setNodeValue("23.7mm");
		NodeHolder.elementAt(2).getAttributes().getNamedItem("w").setNodeValue("22mm");
		NodeHolder.elementAt(3).getAttributes().getNamedItem("w").setNodeValue("15.8mm");
		NodeHolder.elementAt(4).getAttributes().getNamedItem("w").setNodeValue("13mm");
		NodeHolder.elementAt(5).getAttributes().getNamedItem("w").setNodeValue("15mm");
		NodeHolder.elementAt(6).getAttributes().getNamedItem("w").setNodeValue("27.68mm");
		NodeHolder.elementAt(7).getAttributes().getNamedItem("w").setNodeValue("22mm");
		NodeHolder.elementAt(8).getAttributes().getNamedItem("w").setNodeValue("23mm");
		String total = "14mm 23.7mm 22mm 15.8mm 13mm 15mm 27.68mm 22mm 23mm";
		DesignerTableNode.getParentNode().getAttributes().getNamedItem("columnWidths").setNodeValue(total);
	}
	private void AddNewContentRowFieldinDesigner(Node CellNode,int index)
	{
		Node Row = CellNode.getParentNode();
		Node firstContentRow = getNextRow(Row);
		if( firstContentRow == null)
			return;
		Node CellNodeforContentRow = getInstancebyIndex(firstContentRow,index-1,"Cell");
		if( CellNodeforContentRow == null)
			return;
		Node DesignerNode = getCounterNodeDesignerField(CellNodeforContentRow);
		if( DesignerNode == null)
		{
			stop();
			return;
		}
		Node newContentRow = DesignerNode.cloneNode(true);
		CleanDataBinding(newContentRow);
		if( isHighLightNewField)
			highLightTableHeader(newContentRow);
		String fieldName = "NewCreatedFieldName" + newNameIndex++;
		newContentRow.getAttributes().getNamedItem("name").setNodeValue(fieldName);
		TemplateNodeName NameforNewCreatedContentRow = new TemplateNodeName(fieldName);
		TemplateFieldsCollection.put(NameforNewCreatedContentRow,newContentRow);
		UpdateContentRowFieldAccordingtoExcelNode(newContentRow,CellNode,index);
		TemplateFieldNode contentField = new TemplateFieldNode("TableCell",newContentRow);
		DesignerNode.getParentNode().appendChild(newContentRow);
		System.out.println("Add " + getCellNodeName(CellNodeforContentRow) + "->" + fieldName);
		Node RealCellNode = getInstancebyIndex(firstContentRow,index,"Cell");
		CounterNodeMap.put(RealCellNode,contentField);
	}
	private void UpdateContentRowFieldAccordingtoExcelNode(Node newContentRowNode,Node Cell,int index)
	{
		Node Row = Cell.getParentNode();
		Node firstContentRow = getNextRow(Row);
		String newDefaultValue = "";
		if( firstContentRow == null)
			return;
		Node RealCellNode = getInstancebyIndex(firstContentRow,index,"Cell");
		if( RealCellNode == null)
			return;
		Node data = getNodebyRoot("Data",RealCellNode);
		if( data == null)
			return;
		newDefaultValue += ( "\"" + data.getTextContent() + "\"");
		// retrieve second content row
		Node secondContentRow = getNextRow(firstContentRow);
		if( secondContentRow != null)
		{
			Node secondCellNode = getInstancebyIndex(secondContentRow,index,"Cell");
			if( secondCellNode != null)
			{
				data = getNodebyRoot("Data",secondCellNode);
				if( data != null && data.getTextContent().length() != 0)
				{
					newDefaultValue += "+" + "\"" + "\\n" + "\"";
					newDefaultValue += ("+" + "\"" + data.getTextContent() + "\"");
				}
			}
		}
		System.out.println("new default Value: " + newDefaultValue);
		if( newDefaultValue.contains("belle"))
			System.out.println("here");
		Node form = getNodebyRoot("Form",RealCellNode);
		if( form == null)
		{
			form = getNodebyRoot("ss:Form",RealCellNode);
			if( form == null)
				return;
		}
		// currently the form node will not have adobe node's name
		AppendScripttoTemplateFieldbyName(Tool.getAttributeValue("name",newContentRowNode),newDefaultValue);
	}
	private void AppendScripttoTemplateFieldbyName(String name,String scriptValue)
	{
		Node TemplateNode = findTemplateNodeFromMap(name);
		if( TemplateNode == null)
		{
			System.out.println("Cann't find Template Node for: " + name);
			return;
		}
		Node Oldevent = getNodebyRoot("event",TemplateNode);
		if( Oldevent != null)
		{
			Node Oldscript = getNodebyRoot("script",Oldevent);
			if( Oldscript != null)
			{
				Oldscript.setTextContent("this.rawValue = " + scriptValue);
				return;
			}
		}
		Document document = TemplateNode.getOwnerDocument();
		Element event = document.createElement("event");
		Attr activity = document.createAttribute("activity");
		activity.setNodeValue("initialize");
		event.setAttributeNode(activity);
		
		Element script = document.createElement("script");
		Attr contentType = document.createAttribute("contentType");
		contentType.setNodeValue("application/x-javascript");
		script.setAttributeNode(contentType);
		script.setTextContent("this.rawValue = " + scriptValue);
		event.appendChild(script);
		TemplateNode.appendChild(event);
		
	}
	private String getCellNodeName(Node cell)
	{
		if( getNodebyRoot("Data",cell) == null)
			return null;
		return getNodebyRoot("Data",cell).getTextContent();
	}
	private void ModifyTableHeaderName(Node CellNode,Node newHeader)
	{
		String newValue = getNodebyRoot("Data",CellNode).getTextContent();
		System.out.println("new Value: " + newValue);
		Node value = getNodebyRoot("value",newHeader);
		if( value == null)
			return;
		Node text = getNodebyRoot("text",value);
		if( text != null)
		{
			text.setTextContent(newValue);
		}
		else
		{
			Node exData = getNodebyRoot("exData",value);
			if( exData == null)
				return;
			Document valueDocument = value.getOwnerDocument();
			Element textElement = valueDocument.createElement("text");
			textElement.setTextContent(newValue);
			value.replaceChild(textElement,exData);
		}
		TemplateFieldNode DesignerNode = new TemplateFieldNode("TableHeader",newHeader);
		CounterNodeMap.put(CellNode,DesignerNode);
		System.out.println("Put: " + CellNode + " into CounterMap!");
	}
	private Node getLeftTableCell(Node CellNode)
	{
		Node Left = CellNode.getPreviousSibling();
		while( Left != null)
		{
			if( Left.getNodeName().equals("Cell"))
				return Left;
			Left = Left.getPreviousSibling();
		}
		return null;
	}
	private Node getRightTableCell(Node CellNode)
	{
		Node right = CellNode.getNextSibling();
		while( right != null)
		{
			if( right.getNodeName().equals("Cell"))
				return right;
			right = right.getNextSibling();
		}
		return null;
	}
	
	private void highLightCaptionFieldinDesigner(Node DesignerNode)
	{
		Document document = DesignerNode.getOwnerDocument();
		Element border = document.createElement("border");
		Element edge = document.createElement("edge");
		Element color = document.createElement("color");
		Attr value = document.createAttribute("value");
		value.setNodeValue("255,0,255");
		color.setAttributeNode(value);
		edge.appendChild(color);
		border.appendChild(edge);
		
		Element corner = document.createElement("corner");
		Attr thickness = document.createAttribute("thickness");
		thickness.setNodeValue("0.18mm");
		corner.setAttributeNode(thickness);
		Element cornerColor = document.createElement("color");
		Attr cornervalue = document.createAttribute("value");
		cornervalue.setNodeValue("255,0,255");
		cornerColor.setAttributeNode(cornervalue);
		corner.appendChild(cornerColor);
		border.appendChild(corner);
	
		DesignerNode.appendChild(border);
	}
	
	// node : cell
	private void AddNewCaptionNodeinDesigner(Node node,Node CounterNode)
	{
		Node CounterNodeinDesigner = getCounterNodeDesignerField(CounterNode);
		if( CounterNodeinDesigner == null)
			return;
		Node NewFieldinDesigner = CounterNodeinDesigner.cloneNode(true);
		CleanDataBinding(NewFieldinDesigner);
		if( isHighLightNewField)
			highLightCaptionFieldinDesigner(NewFieldinDesigner);
		if( NewFieldinDesigner == null)
		{
			System.out.println("Cannot Create a New Field in Designer!");
			stop();
		}
		if( NewFieldinDesigner.getAttributes().getNamedItem("h") !=null)
			NewFieldinDesigner.getAttributes().getNamedItem("h").setNodeValue("5mm");
		else
			NewFieldinDesigner.getAttributes().getNamedItem("minH").setNodeValue("5mm");
		Node caption = getFieldCaptionNode(NewFieldinDesigner);
		if( caption == null)
		{
			return;
		}
		caption.setTextContent(getNodebyRoot("Data",node).getTextContent());
		String name = Tool.getAttributeValue("name",NewFieldinDesigner);
		System.out.println("Set new Caption: " + caption.getTextContent() + " for Field: " + name);
		// insertion is not in the front
		if( relativePosition == PREVIOUS)
		{
			Node CounterNodesSibling = getTemplateFieldNext(CounterNodeinDesigner,"field");
			if( CounterNodesSibling == null)
			{
				// already in the end
				CounterNodeinDesigner.getParentNode().appendChild(NewFieldinDesigner);
			}
			else
			{
				if( CounterNodeinDesigner.getParentNode().isSameNode(CounterNodesSibling.getParentNode()))
					CounterNodeinDesigner.getParentNode().insertBefore(NewFieldinDesigner,CounterNodesSibling);
				else 
					CounterNodeinDesigner.getParentNode().insertBefore(NewFieldinDesigner,CounterNodesSibling.getParentNode());
			}
			ModifyFieldAttrinDesigner(node,NewFieldinDesigner,CounterNode);
		}
		else if (relativePosition == NEXTSIBLING)
		{
			CounterNodeinDesigner.getParentNode().insertBefore(NewFieldinDesigner,CounterNodeinDesigner);
			ModifyFieldAttrinDesigner(node,NewFieldinDesigner,CounterNode);
		}
	
	}
	
	
	private void ModifyFieldAttrinDesigner(Node cell,Node NewFieldinDesigner,Node CounterNode)
	{
		String fieldName = "NewCreatedFieldName" + newNameIndex++;
		NewFieldinDesigner.getAttributes().getNamedItem("name").setNodeValue(fieldName);
		// write back corresponding node into excel source
		//Document formDocument = cell.getOwnerDocument();
		//Element Form = formDocument.createElement("Form");
		//Attr style = formDocument.createAttribute("style");
		// should use the same style as counterpart
		String CounterNodestyle = getCounterNodeStyle(CounterNode);
		//if( CounterNodestyle != null)
		//	style.setNodeValue(CounterNodestyle);
		//Form.setAttributeNode(style);
		// write back the node path in the Designer
		
		//Form.setTextContent(counterForm.getTextContent());
		//cell.appendChild(Form);
		System.out.println("Add new Field in the Designer: " + fieldName);
		TemplateFieldNode DesignerNode = new TemplateFieldNode(CounterNodestyle,NewFieldinDesigner);
		CounterNodeMap.put(cell,DesignerNode);
		
	}
	
	private String getCounterNodeStyle(Node CounterNode)
	{
		Node form = getNodebyRoot("Form",CounterNode);
		if( form == null)
		{
			form = getNodebyRoot("ss:Form",CounterNode);
			if( form == null)
			{
				if( CounterNodeMap.get(CounterNode) == null )
				{
					return null;
				}
				else return CounterNodeMap.get(CounterNode).getType();
			}
		}
		return Tool.getAttributeValue("style",form);
	}
	
	private Node getCounterNodeDesignerField(Node counterNode)
	{
		// should check if there is already a link in the map
		TemplateFieldNode DesignerNode = CounterNodeMap.get(counterNode);
		System.out.println("Get Node: " + getCellNodeName(counterNode) + "s Designer Node!");
		if( DesignerNode != null)
			return DesignerNode.getDesignerNode();
		else
		{
			Node form = getNodebyRoot("Form",counterNode);
			if( form == null)
			{
				form = getNodebyRoot("ss:Form",counterNode);
				if( form == null)
					return null;
			}
			return findTemplateNodeFromMap(form.getTextContent());
		}
	}
	
	
	// return the previous Cell that has the same relative position with Node
	private Node getCounterNode(Node node)
	{
		int cellIndex = getCellRelativeIndex(node);
		if( cellIndex == -1)
			return null;
		Node PreviousRow = getPreviousRow(node.getParentNode());
		if( PreviousRow != null)
		// should check behind instead
		{
			Node CounterNode = getInstancebyIndex(PreviousRow,cellIndex,"Cell");
			// check whether it has already a counter node in the map
			TemplateFieldNode CounterNodeLinkToDesignerNode = CounterNodeMap.get(CounterNode);
			if( CounterNodeLinkToDesignerNode != null)
			{
				relativePosition = PREVIOUS;
				return CounterNode;
			}
			String style = getCounterNodeStyle(CounterNode);
			if( (style != null) && (!style.equals("Default")))
			{
				relativePosition = PREVIOUS;
				return CounterNode;
			}
		}
		Node NextSibling = getNextRow(node.getParentNode());
		if( NextSibling == null)
		{
			/*
			 * both previous and nextsibling is none:
			 * This is the situation when two or more than two empty rows
			 * are input bu Service Advisor
			 */
			if(cellIndex == ConfigDom.getDefaultInfoStartingColumn())
				return BlurredSearchCounterNode(node,"Caption",5,cellIndex);
			return null;
			
		}
		// should check that whether the next sibling node is also a new cell
		// added by Service Advisor or not
		Node CounterNode = getInstancebyIndex(NextSibling,cellIndex,"Cell");
		TemplateFieldNode CounterNodeLinkToDesignerNode = CounterNodeMap.get(CounterNode);
		if( CounterNodeLinkToDesignerNode != null)
		{
			relativePosition = NEXTSIBLING;
			return CounterNode;
		}
		String style = getCounterNodeStyle(CounterNode);
		if( (style != null) && (!style.equals("Default")))
		{
			relativePosition = NEXTSIBLING;
			return CounterNode;
		}
	
		if(cellIndex == ConfigDom.getDefaultInfoStartingColumn())
			return BlurredSearchCounterNode(node,"Caption",5,cellIndex);
		if(cellIndex == ConfigDom.getDefaultRightInfoStartingColumninExcel())
			return BlurredSearchCounterNode(node,"Caption",5,cellIndex);
		if(cellIndex == ConfigDom.getDefaultInfoStartingColumn() + 1)
		{
			isDefaultValue = true;
			return getLeftNode(node);
		}
		if(cellIndex == ConfigDom.getDefaultRightInfoStartingColumninExcel() + 1)
		{
			isDefaultValue = true;
			return getLeftNode(node);
		}
		return null;
	}
	
	private Node BlurredSearchCounterNode(Node node,String targetType,int SearchLevel,int NodeIndex)
	{
		Node Row = node.getParentNode();
		Node Previous = Row.getPreviousSibling();
		String style = null;
		Node CounterNode = null;
		Node NextSible = Row.getNextSibling();
		int RealIndex = 0;
		while( RealIndex < SearchLevel)
		{
			if( Previous == null)
				break;
			//System.out.println("Previous Name: " + Previous.getNodeName());
			if( !Previous.getNodeName().equals("Row") )
			{
				Previous = Previous.getPreviousSibling();
				continue;
			}
			RealIndex++;
			CounterNode = getInstancebyIndex(Previous,NodeIndex,"Cell");
			if( CounterNode == null)
			{
				Previous = Previous.getPreviousSibling();
				continue;
			}
			style = getCounterNodeStyle(CounterNode);
			if( style == null)
			{
				Previous = Previous.getPreviousSibling();
				continue;
			}
			//System.out.println("Previous Type: " + style);
			if( style.equals(targetType))
			{
				relativePosition = PREVIOUS;
				System.out.println("Found in BlurredSearchCounterNode():previous!");
				return CounterNode;
			}
			Previous = Previous.getPreviousSibling();
		}
		RealIndex = 0;
		while( RealIndex < SearchLevel)
		{
			if( NextSible == null)
				break;
			//System.out.println("Next Name: " + NextSible.getNodeName());
			if( !NextSible.getNodeName().equals("Row") )
			{
				NextSible = NextSible.getNextSibling();
				continue;
			}
			RealIndex++;
			CounterNode = getInstancebyIndex(NextSible,NodeIndex,"Cell");
			if( CounterNode == null)
			{
				NextSible = NextSible.getNextSibling();
				continue;
			}
			style = getCounterNodeStyle(CounterNode);
			if( style == null)
			{
				NextSible = NextSible.getNextSibling();
				continue;
			}
			//System.out.println("NextSibling Type: " + style);
			if( style.equals(targetType))
			{
				relativePosition = NEXTSIBLING;
				System.out.println("Found in BlurredSearchCounterNode():nextSibling!");
				return CounterNode;
			}
			NextSible = NextSible.getNextSibling();
		}
		//stop();
		return null;
	}
	/* main execution functionality here
	 * 
	 */
	private void AdaptTemplateField(Node data,Node form)
	{
		String type = Tool.getAttributeValue("style",form);
		if( type == null)
			return;
		if( type.equals("Caption"))
			AdaptTemplateCaptionField(data,form);
		else if ( type.equals("DefalutValue"))
			AdaptTemplateDefaultValue(data,form);
		else if ( type.equals("TableHeader"))
			AdaptTemplateTableHeader(data,form);
		else if ( type.equals("Title"))
			AdaptTemplateTitle(data,form);
		else if ( type.equals("TableCell"))
			AdaptTemplateTableCell(data,form);
		else if ( type.equals("RemarkCell"))
			AdaptTemplateRemarkCell(data,form);
		else if ( type.equals("SummaryField"))
			AdaptTemplateSummaryField(data,form);
		else if ( type.equals("SignatureField"))
			AdaptTemplateSignatureField(data,form);
		else if ( type.equals("FreeTextCell"))
			AdaptTemplateFreeTextField(data,form);
		else
		{
			//System.out.println("Type: "+ type);
		}
	}
	
	// test function
	private void printVec(Vector<String> vec)
	{
		for( int i = 0 ; i < vec.size();i++)
			System.out.println("i: " + i + " value: " + vec.elementAt(i));
	}
	private Vector<String> getFreeTextCollection(Node data,Node form)
	{
		Vector<String> freeCollection = new Vector<String>();
		freeCollection.add(data.getTextContent());
		System.out.println("Add: " + data.getTextContent());
		Node nextRow = getNextRow(data.getParentNode().getParentNode());
		while( nextRow != null)
		{
			Node cell = getNodebyRoot("Cell",nextRow);
			if( cell == null)
			{
				nextRow = getNextRow(nextRow);
				continue;
			}
			Node formNode = getNodebyRoot("Form",cell);
			if( formNode == null)
			{
				formNode = getNodebyRoot("ss:Form",cell);
				if( formNode == null)
					break;
			}
			if( !Tool.getAttributeValue("style",formNode).equals("FreeTextCell"))
				break;
			/*if( getNodebyRoot("Data",cell) == null)
			{
				nextRow = getNextRow(nextRow);
				continue;
			}*/
			Node dataNode = getNodebyRoot("Data",cell);
			if( dataNode == null)
			{
				dataNode = getNodebyRoot("ss:Data",cell);
				if( dataNode == null)
				{
					nextRow = getNextRow(nextRow);
					continue;
				}
			}
			System.out.println("Ready to Add into Vec: " + dataNode.getTextContent());
			freeCollection.add(dataNode.getTextContent());
			nextRow = getNextRow(nextRow);
		}
		printVec(freeCollection);
		return freeCollection;
	}
	private void AdaptTemplateFreeTextField(Node data,Node form)
	{
		if( isFreeTextHandled == false)
			isFreeTextHandled = true;
		else 
			return;
		String templateFieldName = form.getTextContent();
		Node DesignerNode = findTemplateNodeFromMap(templateFieldName);
		if( DesignerNode == null)
			return;
		Node value = getNodebyRoot("value",DesignerNode);
		if( value == null)
			return;
		Node exData = getNodebyRoot("exData",value);
		if( exData == null)
			return;
		Node body = getNodebyRoot("body",exData);
		if( body == null)
			return;
		NodeList children = body.getChildNodes();
		for( int i = 0; i < children.getLength();i++)
		{
			if( children.item(i).getNodeName().equals("p"))
				body.removeChild(children.item(i));
		}
		
		Vector<String> freeTextCollection = getFreeTextCollection(data,form);
		printVec(freeTextCollection);
		if( freeTextCollection.isEmpty())
			return;
		int size = freeTextCollection.size();
		Element inputElement = null;
		Element seperator = null;
		for( int j = 0 ; j < size -1;j++)
		{
			System.out.println("Ready to write: " + freeTextCollection.elementAt(j));
			inputElement = Tool.createInputElement(body);
			inputElement.setTextContent(freeTextCollection.elementAt(j));
			body.appendChild(inputElement);
			seperator = Tool.createSeperatorElement(body);
			body.appendChild(seperator);
		}
		inputElement = Tool.createInputElement(body);
		inputElement.setTextContent(freeTextCollection.elementAt(size-1));
		body.appendChild(inputElement);
		//stop();
	}

	
	private void AdaptTemplateSignatureField(Node data,Node form)
	{
		if( isFirstSignatureNode)
		{
			firstSignatureNode = data.getParentNode();
			isFirstSignatureNode = false;
			// it is too late to execute here
			//AdaptExcelRowHeight(getNextRow(data.getParentNode().getParentNode()));
		}
		System.out.println("Adapt Signature Cell!");
		String DesignerNodePath = form.getTextContent();
		Node TemplateNode = findTemplateNodeFromMap(DesignerNodePath);
		if( TemplateNode == null)
		{
			System.out.println("Cann't find Template Node for: " + DesignerNodePath);
			return;
		}
		System.out.println("FoundTemplate's Name: " + Tool.getAttributeValue("name",TemplateNode));
		Node value = getNodebyRoot("value",TemplateNode);
		if( value == null)
		//	return;
		{
			CreateNewValueNode(TemplateNode,data.getTextContent());
			TemplateFieldNode SigDesignerNode = new TemplateFieldNode("SignatureField",TemplateNode);
			CounterNodeMap.put(data.getParentNode(),SigDesignerNode);
			String status = "Cell(Signature Field) : " + data.getTextContent() + " is written back into Template!";
			WriteJList(status);
			return;
		}
		Node text = getNodebyRoot("text",value);
		if( text == null)
		{
			text = getNodebyRoot("decimal",value);
			if( text == null)
			{
				TryModifyMultiLineHeader(TemplateNode,data);
			}
			else
				text.setTextContent(data.getTextContent());
		}
		else
			text.setTextContent(data.getTextContent());
		System.out.println("Template Field: " + DesignerNodePath);
		System.out.println("Refresh Signature Field For new Value:" + data.getTextContent());
		TemplateFieldNode SigDesignerNode = new TemplateFieldNode("SignatureField",TemplateNode);
		CounterNodeMap.put(data.getParentNode(),SigDesignerNode);
		String status = "Cell(Signature Field) : " + data.getTextContent() + " is written back into Template!";
		WriteJList(status);
	}
	private void AdaptTemplateSummaryField(Node data,Node form)
	{
		if( isFirstSummaryNode)
		{
			firstSummaryNode = data.getParentNode();
			isFirstSummaryNode = false;
		}
		System.out.println("Adapt Summary Cell!");
		String DesignerNodePath = form.getTextContent();
		Node TemplateNode = findTemplateNodeFromMap(DesignerNodePath);
		if( TemplateNode == null)
		{
			System.out.println("Cann't find Template Node for: " + DesignerNodePath);
			return;
		}
		System.out.println("FoundTemplate's Name: " + Tool.getAttributeValue("name",TemplateNode));
		Node value = getNodebyRoot("value",TemplateNode);
		if( value == null)
		//	return;
		{
			CreateNewValueNode(TemplateNode,data.getTextContent());
			TemplateFieldNode SummaryDesignerNode = new TemplateFieldNode("SummaryField",TemplateNode);
			CounterNodeMap.put(data.getParentNode(),SummaryDesignerNode);
			String status = "Cell(SummaryField) : " + data.getTextContent() + " is written back into Template!";
			WriteJList(status);
			return;
		}
		Node text = getNodebyRoot("text",value);
		if( text == null)
		{
			text = getNodebyRoot("decimal",value);
			if( text == null)
			{
				TryModifyMultiLineHeader(TemplateNode,data);
			}
			else
				text.setTextContent(data.getTextContent());
		}
		else
			text.setTextContent(data.getTextContent());
		System.out.println("Template Field: " + DesignerNodePath);
		System.out.println("Refresh Summary Field For new Value:" + data.getTextContent());
		TemplateFieldNode SummaryDesignerNode = new TemplateFieldNode("SummaryField",TemplateNode);
		CounterNodeMap.put(data.getParentNode(),SummaryDesignerNode);
		String status = "Cell(SummaryField) : " + data.getTextContent() + " is written back into Template!";
		WriteJList(status);
	}
	private void AdaptTemplateRemarkCell(Node data,Node form)
	{
		System.out.println("Adapt Remark Cell!");
		String DesignerNodePath = form.getTextContent();
		Node TemplateNode = findTemplateNodeFromMap(DesignerNodePath);
		if( TemplateNode == null)
		{
			System.out.println("Cann't find Template Node for: " + DesignerNodePath);
			return;
		}
		Node value = getNodebyRoot("value",TemplateNode);
		if( value == null)
		//	return;
		{
			CreateNewValueNode(TemplateNode,data.getTextContent());
			TemplateFieldNode RemarkDesignerNode = new TemplateFieldNode("RemarkCell",TemplateNode);
			CounterNodeMap.put(data.getParentNode(),RemarkDesignerNode);
			String status = "Cell(Remark Row) : " + data.getTextContent() + " is written back into Template!";
			WriteJList(status);
			return;
		}
		Node text = getNodebyRoot("text",value);
		text.setTextContent(data.getTextContent());
		TemplateFieldNode RemarkDesignerNode = new TemplateFieldNode("RemarkCell",TemplateNode);
		CounterNodeMap.put(data.getParentNode(),RemarkDesignerNode);
		String status = "Cell(Remark Row) : " + data.getTextContent() + " is written back into Template!";
		WriteJList(status);
	}
	private void AdaptTemplateTableCell(Node data,Node form)
	{
		// single row
		//System.out.println("Data: " + data.getTextContent());
		//System.out.println("Form: " + form.getTextContent());
		if( isTwoCellTheSameTemplateField(data,form) == false )
		{
			AdaptTemplateTableHeader(data,form);
		}
		else // nested content row
		{
			String realValue = "\"" + data.getTextContent() + "\"" + "+\"" + 
			"\\n" + "\"" + "+\"" + nestedRowDataNode.getTextContent() + "\"";
			nestedRowDataNode = null;
			System.out.println("real Value: " + realValue);
			if (realValue.contains("fenglin"))
				System.out.println("here");
			AppendScripttoTemplateField(form,realValue);
		}
	}
	
	private void AppendScripttoTemplateField(Node form,String scriptValue)
	{
		Node TemplateNode = findTemplateNodeFromMap(form.getTextContent());
		if( TemplateNode == null)
		{
			System.out.println("Cann't find Template Node for: " + form.getTextContent());
			return;
		}
		Node Oldevent = getNodebyRoot("event",TemplateNode);
		if( Oldevent != null)
		{
			Node Oldscript = getNodebyRoot("script",Oldevent);
			if( Oldscript != null)
			{
				Oldscript.setTextContent("this.rawValue = " + scriptValue);
				return;
			}
		}
		Document document = TemplateNode.getOwnerDocument();
		Element event = document.createElement("event");
		Attr activity = document.createAttribute("activity");
		activity.setNodeValue("initialize");
		event.setAttributeNode(activity);
		
		Element script = document.createElement("script");
		Attr contentType = document.createAttribute("contentType");
		contentType.setNodeValue("application/x-javascript");
		script.setAttributeNode(contentType);
		script.setTextContent("this.rawValue = " + scriptValue);
		event.appendChild(script);
		TemplateNode.appendChild(event);
		
	}
	
	private Node getNextRowNode(Node data)
	{
		Node Cell = data.getParentNode();
		Node Row = Cell.getParentNode();
		Node NextRow = Row.getNextSibling();
		while( NextRow != null)
		{
			if( NextRow.getNodeName().equals("Row"))
				return NextRow;
			NextRow = NextRow.getNextSibling();
		}
		return null;
	}
	private boolean isTwoCellTheSameTemplateField(Node data,Node form)
	{
		Node NextRow = getNextRowNode(data);
		if( NextRow == null)
			return false;
		NodeList child = NextRow.getChildNodes();
		int length = child.getLength();
		Node Cell = null;
		Node formNode = null;
		String tableIndex = null;
		//String LowerFieldName = null;
		int UpperTableIndex = Integer.parseInt(Tool.getAttributeValue("tableindex",form));
		for( int i = 0 ; i < length;i++)
		{
			Cell = child.item(i);
			if( !Cell.getNodeName().equals("Cell"))
				continue;
			formNode = getNodebyRoot("ss:Form",Cell);
			if( formNode == null)
				continue;
			tableIndex = Tool.getAttributeValue("tableindex",formNode);
			if( tableIndex == null)
				continue;
			if( Integer.parseInt(tableIndex) == UpperTableIndex )
			{
				/*LowerFieldName = formNode.getTextContent();
				// should take those newly added cell node into consideration.
				// which does not have Adobe Node position information
				//if( form.getTextContent().equals(LowerFieldName))
				//{*/
				nestedRowDataNode = getNodebyRoot("Data",Cell);
				return true;
				//}
			}
		}
		return false;
	}
	private void AdaptTemplateTitle(Node data,Node form)
	{
		// wrapper function
		System.out.println("Adapt Form Title!");
		AdaptTemplateTableHeader(data,form);
	}
	private void AdaptTemplateTableHeader(Node data,Node form)
	{
		String templatePath = form.getTextContent();
		//System.out.println("Template Path: " + templatePath);
		Node TemplateNode = findTemplateNodeFromMap(templatePath);
		if( TemplateNode == null)
		{
			System.out.println("Cann't find Template Node for: " + templatePath);
			return;
		}
		Node value = getNodebyRoot("value",TemplateNode);
		if( value == null)
			return;
		Node text = getNodebyRoot("text",value);
		if( text == null)
		{
			TryModifyMultiLineHeader(TemplateNode,data);
			return;
		}
		text.setTextContent(data.getTextContent());
		//System.out.println("Write back Table Header: " + data.getTextContent());
	}
	
	private void TryModifyMultiLineHeader(Node templateNode,Node excelDataNode)
	{
		Document document = templateNode.getOwnerDocument();
		Element textNode = document.createElement("text");
		textNode.setTextContent(excelDataNode.getTextContent());
		Node value = getNodebyRoot("value",templateNode);
		if( value == null)
			return;
		Node exData = getNodebyRoot("exData",value);
		if( exData == null)
			return;
		value.replaceChild(textNode,exData);

	}
	
	private void AdaptTemplateDefaultValue(Node data,Node form)
	{
		//System.out.println("Adapt Default Field in the Template!");
		String templatePath = form.getTextContent();
		//System.out.println("Template Path: " + templatePath);
		Node TemplateNode = findTemplateNodeFromMap(templatePath);
		if( TemplateNode == null)
		{
			System.out.println("Cann't find Template Node for: " + templatePath);
			return;
		}
		Node DefaultValueNode = getDefaultValueNode(TemplateNode);
		if( DefaultValueNode == null)
		//	return;
		{
			Document doc = TemplateNode.getOwnerDocument();
			Element value = doc.createElement("value");
			Element text = doc.createElement("text");
			text.setNodeValue(data.getTextContent());
			text.setTextContent(data.getTextContent());
			value.appendChild(text);
			TemplateNode.appendChild(value);
			return;
		}
		DefaultValueNode.setTextContent(data.getTextContent());
		String status = "Cell(Default Value) : " + data.getTextContent() + " is written back into Template!";
		WriteJList(status);
	}
	
	private Node getDefaultValueNode(Node node)
	{
		Node value = getNodebyRoot("value",node);
		if( value == null)
			return null;
		Node text = getNodebyRoot("text",value);
		if( text != null)
			return text;
		return getNodebyRoot("decimal",value);
	}
	private Node findTemplateNodeFromMap(String path)
	{
		TemplateNodeName Name = new TemplateNodeName(path);
		return TemplateFieldsCollection.get(Name);
	}
	
	/*private Node findExcelNodeFromMap(String path)
	{
		TemplateNodeName Name = new TemplateNodeName(path);
		return ExcelFieldsCollection.get(Name);
	}*/
	private void AdaptTemplateCaptionField(Node data,Node form)
	{
		//System.out.println("Adapt Caption Field in the Template!");
		String templatePath = form.getTextContent();
		//System.out.println("Template Path: " + templatePath);
		Node TemplateNode = findTemplateNodeFromMap(templatePath);
		if( TemplateNode == null)
		{
			System.out.println("Cann't find Template Node for: " + templatePath);
			return;
		}
		Node captionNode = getFieldCaptionNode(TemplateNode);
		if( captionNode == null)
			return;
		captionNode.setTextContent(data.getTextContent());
		String status = "Cell(Caption) : " + data.getTextContent() + " is written back into Template!";
		WriteJList(status);
	}
	public void SetJlistMode(JList list,DefaultListModel mode)
	{
		jList = list;
		ListMode = mode;
		ListMode.clear();
		jList.setModel(ListMode);
	}
	
	private void WriteJList(String data)
	{
		ListMode.addElement(data);
		ListMode.addElement("\n");
	}
	private Node getFieldCaptionNode(Node node)
	{
		Node caption = getNodebyRoot("caption",node);
		if( caption ==  null )
			return null;
		Node value = getNodebyRoot("value",caption);
		if( value == null )
		{
			Document document = caption.getOwnerDocument();
			Element valueNode = document.createElement("value");
			Element textNode = document.createElement("text");
			valueNode.appendChild(textNode);
			caption.appendChild(valueNode);
			return textNode;
		}
		else
			return getNodebyRoot("text",value);
	}
	
	private void getTemplatePath()
	{
		if( rootForExcel.getAttributes().getNamedItem("templatePath") == null )
		{
			Tool.ErrorReport("Invalid Excel Format! Can not Transformed to Template Format!");
			return;
		}
		TemplatePath = rootForExcel.getAttributes().getNamedItem("templatePath").getNodeValue();
	}

	private void getExcelRoot()
	{
		try
		{
			InputStream inputXML = new FileInputStream(ExcelPath);
			docForExcel = dombuilder.parse(inputXML);
			rootForExcel = docForExcel.getDocumentElement();
		}
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
		getTemplatePath();
	}
	private void FillTemplateFields()
	{
		Node template = getNodebyRoot("template",rootForTemplate);
		if( template == null)
		{
			System.out.println("Template Node Missing!");
			return;
		}
		Node FormRootNode = getNodebyRoot("subform",template);
		if( FormRootNode == null)
			return;
		String name = Tool.getAttributeValue("name",FormRootNode);
		System.out.println("Subform Name: " + name);
		TraverseTemplate(FormRootNode);
	}

	private void TraverseTemplate(Node parent) 
	{
		NodeList child = parent.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if( Tool.isFieldHidden(item))
				continue;
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				if( item.getAttributes().getNamedItem("name") == null)
					continue;
				/*
				 * Subform Need not be added into Template Store
				 * String SubformName = item.getAttributes().getNamedItem("name")
						.getNodeValue();
				System.out.println("Subform Name: " + SubformName);
				if( SubformName != null)
				{
					TemplateNodeName name = new TemplateNodeName(SubformName);
					TemplateFieldsCollection.put(name,item);
				}
				*/
				TraverseTemplate(item);
			} 
			else if (item.getNodeName().equals("pageSet")) 
			{
				NodeList masterChild = item.getChildNodes();
				Node masterPageitem = null;
				int masterChildLength = masterChild.getLength();
				for (int j = 0; j < masterChildLength; j++) 
				{
					masterPageitem = masterChild.item(j);
					if (masterPageitem.getNodeName().equals("pageArea"))
					{
						HandlePageArea(masterPageitem);
						// only handle with the first master page
						break;
					}
				}
			}
			else if (item.getNodeName().equals("field"))
			{
				AddTemplateField(item);
			}
			else if (item.getNodeName().equals("draw"))
			{
				AddTemplateDraw(item);
			}
		}
	}
	
	private boolean isLastNodetobeHandled(Node node)
	{
		Node next = node.getNextSibling();
		while( next != null)
		{
			if( !next.getNodeName().equals("Cell"))
			{
				next = next.getNextSibling();
				continue;
			}
			Node data = getNodebyRoot("Data",next);
			if( data == null)
			{
				next = next.getNextSibling();
				continue;
			}
			if( data.getTextContent().length() != 0)
				return false;
			next = next.getNextSibling();
		}
		return true;
	}
	
	private void AddTemplateField(Node node)
	{
		String name = Tool.getAttributeValue("name",node);
		//System.out.println("Add Field Name: " + name);
		if( name != null)
		{
			TemplateNodeName Name = new TemplateNodeName(name);
			TemplateFieldsCollection.put(Name,node);
			System.out.println("Adding..." + name + " into Template Store");
		}
	}
	private void AddTemplateDraw(Node node)
	{
		String name = Tool.getAttributeValue("name",node);
		//System.out.println("Add Draw Name: " + name);
		if( name != null)
		{
			if( name.contains(ConfigDom.getSeparatorNamingConvention()))
				return;
			if( name.contains(ConfigDom.getLogoNamingConvention()))
				return;
			TemplateNodeName Name = new TemplateNodeName(name);
			TemplateFieldsCollection.put(Name,node);
			System.out.println("Adding..." + name + " into Template Store");
		}
	}
	private void HandlePageArea(Node PageArea) 
	{
		NodeList child = PageArea.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if( Tool.isFieldHidden(item))
				continue;
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				TraverseTemplate(item);
			} 
			else if (item.getNodeName().equals("field")) 
			{
				AddTemplateField(item);
			} 
			else if (item.getNodeName().equals("draw")) 
			{
				AddTemplateDraw(item);
			}
		}
	}
	
	/* main engine here
	 * 
	 */
	public void Transform2Template()
	{
		getExcelRoot();
		getTemplateRoot();
		FillTemplateFields();
		// main Transform Engine here
		HandleTableNode();
		SetWidthForDemo();
		//DeleteNecessaryNodeinDesigner();
		if( (getNodebyRoot("x2:MapInfo",rootForExcel) != null ) && ( Tool.getAttributeValue("xmlDataFilePath",rootForExcel) != null))
		{
			PostDataBindingProcess();
		}
		// should remove data file link
		removeDataFileLink();
		SaveAs(SavedTemplatePath);
	}
	
	private void PostDataBindingProcess()
	{
		excelPathExtractor = new excelHandler();
		excelPathExtractor.SetBindingWorkSheetRoot(WorkSheet);
		excelPathExtractor.RetrieveAllMappingPath(rootForExcel);
		XMLContentRetriever = new XMLDataFileRetriever();
		XMLContentRetriever.LoadXMLDataFile("./data.xml");
		HashMap<String,internalPathObject> hashMapExcelCellPathInfo = excelPathExtractor.getExcelBindngPathCollection();
		Iterator iterator = hashMapExcelCellPathInfo.keySet().iterator(); 
		while(iterator.hasNext()) 
		{
			Object key = iterator.next();
			String position = key.toString();
			System.out.println("Position in traverse: " + position);
			String path = hashMapExcelCellPathInfo.get(key).getPath();
			System.out.println("Path in traverse: " + path);
			Node Cell = getNodebyPosition(getRowIndex(position),getColumnIndex(position));
			if( Cell == null)
				continue;
			System.out.println("value: " + getNodebyRoot("Data",Cell).getTextContent());
			String data = XMLContentRetriever.getContentbyExcelPath(path);
			System.out.println("Get Content in the XML: " + data);
			if( data != null)
				WriteBackToDesignerNode(Cell,data);
		}
	}
	private void WriteBackToDesignerNode(Node CellNode,String data)
	{
		TemplateFieldNode DesignerNode = CounterNodeMap.get(CellNode);
		if( DesignerNode == null)
			return;
		Node defaultValueNode = getDefaultValueNode(DesignerNode.getDesignerNode());
		if( defaultValueNode == null)
			return;
		defaultValueNode.setTextContent(data);
	}
	private void removeDataFileLink()
	{
		Node template = getNodebyRoot("template",rootForTemplate);
		if( template == null)
			return;
		Node datalink = null;
		NodeList children = template.getChildNodes();
		int length = children.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeValue() == null )
				continue;
			if( item.getNodeValue().contains("DefaultPreviewDataFileName"))
			{
				datalink = item;
				break;
			}
		}
		if( datalink == null)
			return;
		template.removeChild(datalink);
	}
	private void CleanDataBinding(Node node)
	{
		Node bind = getNodebyRoot("bind",node);
		if( bind == null)
			return;
		if( bind.getAttributes().getNamedItem("ref") == null )
			return;
		bind.getAttributes().removeNamedItem("ref");
		bind.getAttributes().getNamedItem("match").setNodeValue("none");
	}
	
	/*private void DeleteNecessaryNodeinDesigner()
	{
		Iterator iterator = TemplateFieldsCollection.keySet().iterator(); 
		Node ExcelNode = null;
		Node Form = null;
		while(iterator.hasNext()) 
		{
			Object key = iterator.next();
			TemplateNodeName name = (TemplateNodeName)key;
			//System.out.println("Templagte Node Name : " + name.getName());
			ExcelNode = findExcelNodeFromMap(name.getName());
			if( ExcelNode == null)
			{
				// field in the Adobe Designer has not corresponding node
				// in the excel any more,means that the excel node has been 
				System.out.println("Can not find Corresponding Excel Node!");
				DeleteDesignerNode(name.getName());
			}
			else
			{
				Form = getNodebyRoot("Form",ExcelNode);
				if( Form == null)
				{
					Form = getNodebyRoot("ss:Form",ExcelNode);
					if( Form == null)
					{
						DeleteDesignerNode(name.getName());
					}
				}
			}
		}
	}
	*/
	
	/*
	private void DeleteDesignerNode(String DesignerNodeName)
	{
		Node DesignerNode = findTemplateNodeFromMap(DesignerNodeName);
		if( DesignerNode == null)
		{
			System.out.println("Cannot find DesignerNode: " + DesignerNodeName);
			return;
		}
		System.out.println("Try to Delete: " + DesignerNodeName + " in Designer!");
		//stop();
	}
	*/
	public String SaveAs(String path)
	{
		String formattedPath = path;//FormatSavePath(path);
		File newFile = new File(formattedPath);
		if( newFile.exists())
			return null;
		try
		{   
             TransformerFactory tff = TransformerFactory.newInstance();   
             Transformer tf = tff.newTransformer();   
             DOMSource source = new DOMSource(docForTemplate);
             StreamResult rs = new StreamResult(formattedPath);
             tf.transform(source,rs);  
             tf.reset();
        }
		catch(Exception   e1)
		{   
             e1.printStackTrace();   
		}  
		return formattedPath;
	}
	

	private Node getNodebyRoot(String subNodeName,Node root)
	{
		if( root == null)
			return root;
		NodeList child = root.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals(subNodeName))
				return item;
		}
		return null;
	}
	
	private void getTemplateRoot()
	{
		try 
		{
			filecopy = new FileCopyFactory();
			String OutputXMLFile = filecopy.copyFile(TemplatePath);
			if (OutputXMLFile == null)
				return;
			InputStream inputXML = new FileInputStream(OutputXMLFile);
			docForTemplate = dombuilder.parse(inputXML);
			rootForTemplate = docForTemplate.getDocumentElement();
			filecopy.DeleteUnusedXML(OutputXMLFile);
			getContentAreaNode();
			getMaxInfoBlockHeight();
		}

		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
		return;
	}
	
	// some problem when getting index 
	private int getCellRelativeIndex(Node cell)
	{
		int realIndex = 0;
		NodeList child = cell.getParentNode().getChildNodes();
		int length = child.getLength();
		Node item = null;
		String relativeIndex = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("Cell"))
				realIndex++;
			relativeIndex = Tool.getAttributeValue("ss:Index",item);
			if( relativeIndex != null)
				realIndex = Integer.parseInt(relativeIndex);
			if( item.isSameNode(cell))
				return realIndex;
		}
		return -1;
	}

	private Node getNextRow(Node Row)
	{
		Node next = Row.getNextSibling();
		while ( next != null)
		{
			if( next.getNodeName().equals("Row"))
				return next;
			next = next.getNextSibling();
		}
		return null;
	}
	private Node getPreviousRow(Node Row)
	{
		Node pre = Row.getPreviousSibling();
		while ( pre != null)
		{
			if( pre.getNodeName().equals("Row"))
				return pre;
			pre = pre.getPreviousSibling();
		}
		return null;
	}
	//
	private Node getInstancebyIndex(Node Row,int cellIndex,String InstanceType)
	{
		NodeList Cells = Row.getChildNodes();
		int CellNumber = Cells.getLength();
		Node item = null;
		int realColumnIndex = 0;
		String relativeIndex = null;
		for( int i = 0 ; i < CellNumber;i++)
		{
			item = Cells.item(i);
			if( item.getNodeName().equals(InstanceType))
			{
				realColumnIndex++;
				relativeIndex = Tool.getAttributeValue("ss:Index",item);
				if( relativeIndex != null)
					realColumnIndex = Integer.parseInt(relativeIndex);
				if( realColumnIndex == cellIndex)
					return item;
			}
		}
		return null;
	}
	
	
	
	/*private Node getTemlateFieldPrevious(Node current,String NodeType)
	{
		Node pre = current.getPreviousSibling();
		while ( pre != null)
		{
			if( pre.getNodeName().equals("subform"))
			{
				Node child = getNodebyRoot(NodeType,pre);
				if( child != null)
					return child;
			}
			if( pre.getNodeName().equals(NodeType))
				return pre;
			pre = pre.getPreviousSibling();
		}
		return null;
	}*/
	private Node getTemplateFieldNext(Node current,String NodeType)
	{
		Node next = current.getNextSibling();
		while ( next != null)
		{
			// should handle with the situation that some field is wrapped with subform
			if( next.getNodeName().equals("subform"))
			{
				Node child = getNodebyRoot(NodeType,next);
				if( child != null)
					return child;
			}
			if( next.getNodeName().equals(NodeType))
				return next;
			next = next.getNextSibling();
		}
		return null;
	}
	private void stop()
	{
		System.exit(0);
	}
	private void getContentAreaNode()
	{
		Node template = getNodebyRoot("template",rootForTemplate);
		if( template == null)
			return;
		Node bodyPage = getNodebyRoot("subform",template);
		if( bodyPage == null)
			return;
		Node pageSet = getNodebyRoot("pageSet",bodyPage);
		if( pageSet == null)
			return;
		Node pageArea = getNodebyRoot("pageArea",pageSet);
		if( pageArea == null)
			return;
		formContentNode = getNodebyRoot("contentArea",pageArea);
	}
	private void AdaptContentArea()
	{
		int previousheight = previousMaxInfoHeight;
		// refresh
		getMaxInfoBlockHeight();
		System.out.println("Previous: " + previousheight);
		System.out.println("Current: " + previousMaxInfoHeight);
		if( previousMaxInfoHeight <= previousheight)
			return;
		String h = Tool.getAttributeValue("h",formContentNode);
		String y = Tool.getAttributeValue("y",formContentNode);
		int NewHeight = getRealValue(h) - (previousMaxInfoHeight - previousheight);
		int NewYCoordinate = getRealValue(y) + (previousMaxInfoHeight - previousheight);
		formContentNode.getAttributes().getNamedItem("h").setNodeValue("" + NewHeight + "mm");
		formContentNode.getAttributes().getNamedItem("y").setNodeValue("" + NewYCoordinate + "mm");
		AdaptPageCounter(previousMaxInfoHeight - previousheight);
	}
	
	private void AdaptPageCounter(int minus)
	{
		Node next = formContentNode.getNextSibling();
		String name = null;
		Node pageCounter = null;
		while ( next != null)
		{
			if( !next.getNodeName().equals("draw"))
			{
				next = next.getNextSibling();
				continue;
			}
			name = Tool.getAttributeValue("name",next);
			if( (name.contains("page")) || ( name.contains("Page")))
			{
				pageCounter = next;
				break;
			}
			System.out.println("Content Area Sibling Name: " + name);
			next = next.getNextSibling();
		}
		if( pageCounter == null)
			return;
		int newY = getRealValue(pageCounter.getAttributes().getNamedItem("y").getNodeValue()) + minus ;
		pageCounter.getAttributes().getNamedItem("y").setNodeValue("" + newY + "mm");
	}
	
	private void getMaxInfoBlockHeight()
	{
		NodeList children = formContentNode.getParentNode().getChildNodes();
		int length = children.getLength();
		Node item = null;
		String name = null;
		int maxHeight = 0;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( !item.getNodeName().equals("subform"))
				continue;
			name = Tool.getAttributeValue("name",item);
			if( name == null)
				continue;
			if( name.length() < 7)
				continue;
			if( name.substring(0,7).equalsIgnoreCase(ConfigDom.getInfoblockNamingConvention()))
			{
				maxHeight = getTotalHeightofSubform(item);
				if( maxHeight > previousMaxInfoHeight)
					previousMaxInfoHeight = maxHeight;
			}
		}
		System.out.println("Max info height: " + previousMaxInfoHeight);
	}
	private int getTotalHeightofSubform(Node subform)
	{
		NodeList children = subform.getChildNodes();
		int length = children.getLength();
		Node item = null;
		int totalHeight = 0;
		//String name = null;
		for( int i = 0 ; i < length;i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals("subform"))
				totalHeight += getTotalHeightofSubform(item);
			else if ( item.getNodeName().equals("draw") || item.getNodeName().equals("field"))
			{
				totalHeight += getFieldHeight(item);
			}
		}
		//name = getAttributeValue("name",subform);
		//System.out.println("Subform: " + name + " height:" + totalHeight);
		return totalHeight;
	}
	private int getFieldHeight(Node node)
	{
		String height = Tool.getAttributeValue("h",node);
		if( height == null)
		{
			height = Tool.getAttributeValue("minH",node);
			if( height == null)
				return 0;
		}
		int h = getRealValue(height);
		String name = Tool.getAttributeValue("name",node);
		System.out.println("Field: " + name + " height:" + h);
		return h;
	}
	private Node getNodebyPosition(int row,int column)
	{
		Node rowInstance = getRowInstancebyIndex(row);
		if( rowInstance == null)
			return null;
		return getCellInstancebyIndex(column,rowInstance);
	}
	private Node getRowInstancebyIndex(int row)
	{
		Node TableNode = getNodebyRoot("Table",WorkSheet);
		if( TableNode == null)
			return null;
		NodeList Rows = TableNode.getChildNodes();
		int RowNumber = Rows.getLength();
		Node item = null;
		int realRowIndex = 0;
		int relativeIndex = -1;
		for( int i = 0 ; i < RowNumber;i++)
		{
			item = Rows.item(i);
			if( item.getNodeName().equals("Row"))
			{
				realRowIndex++;
				relativeIndex = getRelativeIndex(item,realRowIndex);
				if( relativeIndex != -1)
					realRowIndex = relativeIndex;
				if( realRowIndex == row)
					return item;
			}
		}
		return null;
	}
	private int getRelativeIndex(Node node,int realIndex)
	{
		if( node.getAttributes().getNamedItem("ss:Index") == null)
			return realIndex;
		return Integer.valueOf(node.getAttributes().getNamedItem("ss:Index").getNodeValue());
	}
	private Node getCellInstancebyIndex(int column,Node row)
	{
		NodeList Cells = row.getChildNodes();
		int CellNumber = Cells.getLength();
		Node item = null;
		int realColumnIndex = 0;
		int relativeColumnIndex = -1;
		for( int i = 0 ; i < CellNumber;i++)
		{
			item = Cells.item(i);
			if( item.getNodeName().equals("Cell"))
			{
				realColumnIndex++;
				relativeColumnIndex = getRelativeIndex(item,realColumnIndex);
				if( relativeColumnIndex != -1)
					realColumnIndex = relativeColumnIndex;
				if( relativeColumnIndex == column)
					return item;
			}
		}
		return null;
	}
	private int getColumnIndex(String position)
	{
		int cIndex = position.indexOf('C');
		if( cIndex == -1)
			return cIndex;
		String ColumnIndex = position.substring(++cIndex,position.length());
		System.out.println("Column index: " + ColumnIndex);
		return Integer.parseInt(ColumnIndex);
	}
	private int getRowIndex(String position)
	{
		int rIndex = position.indexOf('R');
		if( rIndex == -1)
			return rIndex;
		int cIndex = position.indexOf('C');
		if( cIndex == -1)
			return cIndex;
		String RowIndex = position.substring(++rIndex,cIndex);
		System.out.println("Row index: " + RowIndex);
		return Integer.parseInt(RowIndex);
	}
}