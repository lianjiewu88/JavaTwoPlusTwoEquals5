package mockupTool;

import utilities.*;
import mockupTool.internalStructure.*;
import configuration.ConfigDom;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class TemplateTransformer
{
	
	private DocumentBuilderFactory domfac;

	private DocumentBuilder dombuilder;
	
	private Document doc;
	
	private FileCopyFactory filecopy;
	
	private Position position = null;
	
	private Vector<TemplateCell> TemplateCellCollection = null;
	
	private String freeTextCollection = "";
	
	private String tablePath = null;
	
	private Node FreeTextBlockRoot = null;
	
	private Node TableNode = null;
	
	private Node hiddenSubform = null;
	
	private HashMap<Node,Position> infoPositionMap = null;
	
	private XMLDataFileRetriever XMLContentRetriever = null;
	
	private boolean isFirstMeetInfoblock = true;
	
	private boolean isFirstMeetTable = true;
	
	private boolean isSummaryBlock = true;
	
	private boolean withXMLData = false;
	
	private int tableCellIndex = 1;
	
	public TemplateTransformer()
	{
		domfac = DocumentBuilderFactory.newInstance();
		position = new Position();
		TemplateCellCollection = new Vector<TemplateCell>();
		infoPositionMap = new HashMap<Node,Position>(); 
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			
			e.printStackTrace();
		}
	}
	public Position getPositionInfo()
	{
		return position;
	}
	public void SetXMLDataFileFlag(String xmlDataFile)
	{
		withXMLData = true;
		XMLContentRetriever = new XMLDataFileRetriever();
		XMLContentRetriever.LoadXMLDataFile(xmlDataFile);
	}
	public Vector<TemplateCell> getTemplateCellCollection()
	{
		return TemplateCellCollection;
	}
	public boolean CheckInputXDPFileExistence(String filename)
	{
		File ForChecking = new File(filename);
		return ForChecking.exists();
	}
	

	public void Transform(String inputXDPName) 
	{
		try 
		{
			filecopy = new FileCopyFactory();
			if( CheckInputXDPFileExistence(inputXDPName) == false)
				return;
			String OutputXMLFile = filecopy.copyFile(inputXDPName);
			if (OutputXMLFile == null)
				return;
			InputStream inputXML = new FileInputStream(OutputXMLFile);
			doc = dombuilder.parse(inputXML);
			Element root = doc.getDocumentElement();
			
			// but only template DOM is our concern...
			filecopy.DeleteUnusedXML(OutputXMLFile);
			Node template = Tool.getNodebyRoot("template",root);
			if( template == null)
				return;
			System.out.println("Begin transfor from Template Node!");
			traverseNode(template);
			//for the moment just put the footer in the last part of the template
			TransformFooterBlock();
		}

		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} catch (SAXException d) {
			d.printStackTrace();
			System.exit(0);
		} catch (IOException d) {
			d.printStackTrace();
		}
		return;
	}
	
	
	private void ErrorReport(String Message)
	{
	    /*JOptionPane.showMessageDialog(new JFrame(), Message, "ERROR",
	        JOptionPane.ERROR_MESSAGE);
		*/
	}
	
	private boolean isInfoBlock(String name)
	{
		if( name.length() < 7)
		{
			ErrorReport("Subform: " + name + "Should have at least 7 CHARS!");
			return false;
		}
		name = name.substring(0,7);
		if( name.equalsIgnoreCase(ConfigDom.getInfoblockNamingConvention()))
			return true;
		return false;
	}
	
	private boolean isFreeTextBlock(String name)
	{
		if( name.length() < 7)
		{
			ErrorReport("Subform: " + name + "Should have at least 7 CHARS!");
			return false;
		}
		name = name.substring(0,7);
		if( name.equalsIgnoreCase(ConfigDom.getFreeblockNamingConvention()))
			return true;
		return false;
	}
	
	private boolean isTable(String name)
	{
		if( name.length() < 3)
		{
			ErrorReport("Subform: " + name + "Should have at least 3 CHARS!");
			return false;
		}
		name = name.substring(0,3);
		if( name.equalsIgnoreCase(ConfigDom.getTableNamingConvention()))
			return true;
		return false;
	}
	
	private boolean isSummaryBlock(String name)
	{
		if( name.length() < 7)
		{
			ErrorReport("Subform: " + name + "Should have at least 7 CHARS!");
			return false;
		}
		name = name.substring(0,7);
		if( name.equalsIgnoreCase(ConfigDom.getSummaryBlockNamingConvention()))
			return true;
		return false;
	}
	
	private boolean isSignatureBlock(String name)
	{
		if( name.length() < 6)
		{
			ErrorReport("Subform: " + name + "Should have at least 6 CHARS!");
			return false;
		}
		name = name.substring(0,6);
		if( name.equalsIgnoreCase(ConfigDom.getSignatureNamingConvention()))
			return true;
		return false;
	}
	private boolean isTableHeader(String name)
	{
		if( name.length() < 3)
		{
			ErrorReport("Subform: " + name + "Should have at least 3 CHARS!");
			return false;
		}
		name = name.substring(0,3);
		if( name.equalsIgnoreCase(ConfigDom.getTableHeaderNamingConvention()))
			return true;
		return false;
	}
	private boolean isTableContentRow(String name)
	{
		if( name.length() < 3)
		{
			ErrorReport("Subform: " + name + "Should have at least 3 CHARS!");
			return false;
		}
		name = name.substring(0,3);
		if( name.equalsIgnoreCase(ConfigDom.getTableRowNamingConvention()))
			return true;
		return false;
	}
	private String getNodeAttributeName(Node node)
	{
		if( node.hasAttributes() == false)
			return null;
		if( node.getAttributes().getNamedItem("name") == null)
			return null;
		return node.getAttributes().getNamedItem("name").getNodeValue();
	}
	
	private Node getPriorNode(Node node)
	{
		Node parent = node.getParentNode();
		if( parent == null)
			return parent;
		System.out.println("Parent Name: " + getNodeAttributeName(parent));
		NodeList Brothers = parent.getChildNodes();
		int BroNumber = Brothers.getLength();
		Node item = null;
		String name = null;
		Vector<Node> temp = new Vector<Node>();
		for( int i = 0 ; i < BroNumber; i++)
		{
			item = Brothers.item(i);
			if( item.getNodeName().equals("subform"))
			{
				name = Tool.getAttributeValue("name",item);
				if( name == null)
					continue;
				if( !name.contains("dummy"))
					temp.add(item);
			}
		}
		int SubformNumber = temp.size();
		for( int j = 0 ; j < SubformNumber; j++)
		{
			item = temp.elementAt(j);
			if( item.isSameNode(node))
			{
				if( j == 0)
				{
					// no prior node!
					return null;
				}
				int index = --j;
				item = temp.elementAt(index);
				System.out.println("Found prior node:" + index + " Name: " + getNodeAttributeName(item));
				return item;		
			}
		}
		return null;
	}
	/* test function
	private void printPriorNodeName(Node node)
	{
		Node prior = getPriorNode(node);
		if( prior == null)
		{
			System.out.println("None prior Node!");
			return;
		}
		String name = getNodeAttributeName(prior);
		System.out.println("Prior Name: " + name);
	}
	*/
	private boolean isInfoblockIntheRight(String name)
	{
		if( name == null)
			return false;
		if( name.endsWith("r"))
			return true;
		if( name.endsWith("R"))
			return true;
		return false;
	}
	
	private void AdaptRightInfoblock(Node node)
	{
		Node prior = getPriorNode(node);
		if( prior == null)
			return;
		Position priorPosition = infoPositionMap.get(prior);
		if( priorPosition == null)
			return;
		position.moveToNewRow(priorPosition.getRow());
		position.moveToNewColumn(ConfigDom.getDefaultRightInfoStartingColumninExcel());
		position.trace();

	}
	
	private void TransformRightInfoBlock(Node node)
	{
		String InfoblockName = getNodeAttributeName(node);
		if( InfoblockName != null)
			System.out.println("Info block:->" + InfoblockName + " Coordinate: (" + position.getRow() + 
				"," + position.getColumn() + ")");
		infoPositionMap.put(node,position.snapShot());
		// node should definitely begin with frminfo
		NodeList child = node.getChildNodes();
		int childNumber = child.getLength();
		//System.out.println("Child Number: " + childNumber);
		Node item = null;
		for( int i = 0 ; i < childNumber;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform"))
			{
				// should handle with nested info block
				if( Tool.isFieldHidden(item))
					continue;
				TransformRightInfoBlock(item);
			}
			else if( item.getNodeName().equals("field"))
			{
				TransformFieldinInfoblock(item);
			}
			else if( item.getNodeName().equals("draw"))
			{
				TransformDrawinInfoblock(item);
			}
		}

	}
	
	private void TransformInfoBlock(Node node)
	{
		//printPriorNodeName(node);
		String InfoblockName = getNodeAttributeName(node);
		if( InfoblockName != null)
			System.out.println("Ready to transform info block:->" + InfoblockName);
		// should judge if it is the info block in the right
		if (isFirstMeetInfoblock)
		{
			position.moveToPosition(ConfigDom.getDefaultInfoStartingRow(),ConfigDom.getDefaultInfoStartingColumn());
			isFirstMeetInfoblock = false;
		}
		System.out.println("Info block:->" + InfoblockName + " Coordinate: (" + position.getRow() + 
				"," + position.getColumn() + ")");
		if( isInfoblockIntheRight(InfoblockName))
		{
			// adjust the starting points of the right info block
			AdaptRightInfoblock(node);
			position.setRightInfoStartRow(position.getRow());
			TransformRightInfoBlock(node);
			position.setRightInfoEndRow(position.getRow() - 1);
			return;
		}
		else
			position.moveToNewColumn(1);
		infoPositionMap.put(node,position.snapShot());
		// node should definitely begin with frminfo
		NodeList child = node.getChildNodes();
		int childNumber = child.getLength();
		//System.out.println("Child Number: " + childNumber);
		Node item = null;
		for( int i = 0 ; i < childNumber;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform"))
			{
				// should handle with nested info block
				if( Tool.isFieldHidden(item))
					continue;
				TransformInfoBlock(item);
			}
			else if( item.getNodeName().equals("field"))
			{
				TransformFieldinInfoblock(item);
			}
			else if( item.getNodeName().equals("draw"))
			{
				TransformDrawinInfoblock(item);
			}
		}
	}
	
	
	private void TransformDrawinInfoblock(Node node)
	{
		/* judge whether it is page counter?
		 * Should all the page counter be put into info block?
		 
		 */
		if( isPageCounter(node))
			TransformPageCounter(node);
			
	}
	
	private boolean isPageCounter(Node node)
	{
		Node value = Tool.getNodebyRoot("value",node);
		if( value == null)
			return false;
		Node exData = Tool.getNodebyRoot("exData",value);
		if( exData == null)
			return false;
		Node body = Tool.getNodebyRoot("body",exData);
		if( body == null)
			return false;
		Node p = Tool.getNodebyRoot("p",body);
		if( p == null)
			return false;
		System.out.println("Value: " + p.getTextContent());
		String pageValue = p.getTextContent();
		if( pageValue.length() < 4)
			return false;
		if( pageValue.substring(0,4).equalsIgnoreCase("Page"))
			return true;
		return false;
	}
	
	private void TransformFreeTextBlock(Node node)
	{
		position.moveToNewColumn(1);
		position.moveToNextRow();
		FreeTextBlockRoot = node;
		NodeList child = node.getChildNodes();
		int number = child.getLength();
		Node item = null;
		for( int i = 0 ;i < number;i++)
		{
			item = child.item(i);
			if( Tool.isFieldHidden(item))
				continue;
			if( item.getNodeName().equals("draw"))
				HandleDrawinFreeTextBlock(item);
			else if ( item.getNodeName().equals("field"))
				HandleFieldinFreeTextBlock(item);
		}
	}
	private void traverseNode(Node parent) 
	{
		NodeList child = parent.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				if( Tool.isFieldHidden(item) == true)
					continue;
				if( item.getAttributes().getNamedItem("name") == null)
				{
					ErrorReport("Subform should have a name attribute!");
					continue;
				}
				String SubformName = item.getAttributes().getNamedItem("name")
						.getNodeValue();
				// check if it is infoblock,currently onlu handle with info block
				if( isInfoBlock(SubformName))
				{
					TransformInfoBlock(item);
				}
				else if ( isFreeTextBlock(SubformName))
				{
					TransformFreeTextBlock(item);
				}
				else if ( isTable(SubformName))
				{
					TransformTable(item);
				}
				else if ( isSummaryBlock(SubformName))
					//|| isSignatureBlock(SubformName))
				{
					position.setSummaryBlockStart(position.getRow());
					TransformSummaryBlock(item);
					position.setSummaryBlockEnd(position.getRow());
				}
				else if ( isSignatureBlock(SubformName))
				{
					isSummaryBlock = false;
					TransformSummaryBlock(item);
				}
				else 
					traverseNode(item);
				
			} 
			else if (item.getNodeName().equals("pageSet")) 
			{
				NodeList masterChild = item.getChildNodes();
				Node masterPageitem = null;
				int masterChildLength = masterChild.getLength();
				for (int j = 0; j < masterChildLength; j++) 
				{
					masterPageitem = masterChild.item(j);
					if (masterPageitem.getNodeName().equals("pageArea"))
					{
						TransformPageArea(masterPageitem);
						/* only the first master page should be handled in order
						 * to avoid double writing operations in the excel file
						 */
						break;
					}
				}
			}
			// field not in the table
			else if (item.getNodeName().equals("field"))
			{
				TransformField(item);
			}
			else if (item.getNodeName().equals("draw"))
			{
				TransformDraw(item);
			}
		}
		
	}
	
	private void TransformFooterBlock()
	{
		int startRow = position.getRow() + 2;
		position.setSignatureBlockEndRow(startRow-1);
		// column1 to column4
		int RowIndex = 1;
		int ColumnIndex = 1;
		String name = null;
		for( int i = 1 ; i <= 4; i++)
		{
			// row start to row start + 4
			// make a space between column 2 and 3
			//if( i == 3 )
			//	i++;
			for( int j = startRow ; j < startRow + 4;j++)
			{
				TemplateCell footerElement = new TemplateCell();
				footerElement.setPosition(j,i);
				System.out.println("Footer: R" + j + "C" + i);
				position.moveToNextRow();
				footerElement.setCellType("Caption");
				footerElement.setCaption("Place Holder of line" + i);
				name = "lbl_A1SFC_FooterBlock" + ColumnIndex + "_line" + RowIndex;
				System.out.println("Name: " + name);
				footerElement.setCorrespondingFieldType("Caption");
				footerElement.setFieldNameforDesigner(name);
				TemplateCellCollection.add(footerElement);
				RowIndex++;
			}
			RowIndex = 1;
			ColumnIndex++;
		}
	}
	private void TransformSummaryBlock(Node node)
	{
		System.out.println("Transform Summary Block!" + Tool.getAttributeValue("name",node));
		
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		//position.moveToNextRow();
		position.moveToNewColumn(1);
		String layout = getSubformLayoutStyle(node);
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform"))
			{
				/* should identify those dummy subform which are used just
				 * to occupy space 
				 */
				String name = Tool.getAttributeValue("name",item);
				System.out.println("Name in Summary block: " + name);
				if( !name.contains("dummy") )
					TransformInSummaryBlock(item,layout);
			}
			else if ( item.getNodeName().equals("draw"))
				TransformDrawInSummaryBlock(item,layout,false);
			else if ( item.getNodeName().equals("field"))
				TransformFieldInSummaryBlock(item,layout,false);
		}
		
	}
	private void TransformDrawInSummaryBlock(Node node,String parentLayout,boolean isRight)
	{
		if( isRight)
			position.moveToNewColumn(ConfigDom.getDefaultSigRightStartingColumninExcel());
		String titleText = getRealDrawValue(node);
		System.out.println("Text in Summary or Signature Block: " + titleText);
		TemplateCell draw = new TemplateCell();
		draw.setPosition(position.getRow(),position.getColumn());
		draw.setCellType("Caption");
		if( isSummaryBlock)
			draw.setCorrespondingFieldType("SummaryField");
		else
			draw.setCorrespondingFieldType("SignatureField");
		draw.setFieldNameforDesigner(Tool.getAttributeValue("name",node));
		draw.setCaption(titleText);
		TemplateCellCollection.add(draw);
		position.trace();
		TraverseElementByLayoutStyle(parentLayout);
		
	}
	
	private void TraverseElementByLayoutStyle(String parentLayout)
	{
		if( parentLayout == null)
		{
			/* how to handle with position subform?
			 * default behavior can be defined the same as western text
			 * 
			 */
			position.moveToNextColumn();
		}
		else if( parentLayout.equals("tb"))
		{
			position.moveToNextRow();
			position.moveToNewColumn(1);
		}
		else if ( parentLayout.equals("lr-tb"))
		{
			position.moveToNextColumn();
		}
	}
	
	private void TransformFieldInSummaryBlock(Node node,String parentLayout,boolean isRight)
	{
		if( isRight)
			position.moveToNewColumn(ConfigDom.getDefaultSigRightStartingColumninExcel());
		String value = getCaptionValue(node);
		if( value != null)
		{
			TemplateCell RowCaption = new TemplateCell();
			RowCaption.setPosition(position.getRow(),position.getColumn());
			position.moveToNextColumn();
			RowCaption.setCellType("Caption");
			if( isSummaryBlock )
				RowCaption.setCorrespondingFieldType("SummaryField");
			else 
				RowCaption.setCorrespondingFieldType("SignatureField");
			RowCaption.setFieldNameforDesigner(Tool.getAttributeValue("name",node));
			RowCaption.setCaption(value);
			System.out.println("Add Field caption in Summary or Signature Block: " + value);
			if( value.equals("ww"))
				System.out.println("here");
			TemplateCellCollection.add(RowCaption);
			position.trace();
		}
		if( withXMLData)
		{
			String path = getDesignerNodeBindingPath(node);
			value = XMLContentRetriever.getContentbyDesignerPath(path);
		}
		else
			value = getDefaultValue(node);
		if( value == null)
		{
			TraverseElementByLayoutStyle(parentLayout);
			return;
		}
		TemplateCell RowCell = new TemplateCell();
		RowCell.setPosition(position.getRow(),position.getColumn());
		RowCell.setCellType("Caption");
		if( isSummaryBlock )
			RowCell.setCorrespondingFieldType("SummaryField");
		else
			RowCell.setCorrespondingFieldType("SignatureField");
		RowCell.setFieldNameforDesigner(Tool.getAttributeValue("name",node));
		RowCell.setCaption(value);
		System.out.println("Add Field content in Summary or Signature Block: " + value);
		TemplateCellCollection.add(RowCell);
		TraverseElementByLayoutStyle(parentLayout);
		position.trace();
		
	}
	private int getChildIndex(Node node)
	{
		NodeList child = node.getParentNode().getChildNodes();
		int ChildNumber = child.getLength();
		Node item = null;
		Vector<Node> SubformInstance = new Vector<Node>();
		for( int i = 0 ; i < ChildNumber;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform"))
				SubformInstance.add(item);
		}
		int SubformNumber = SubformInstance.size();
		for( int j = 0 ; j < SubformNumber;j++)
		{
			item = SubformInstance.elementAt(j);
			if( item.isSameNode(node))
			{
				System.out.println("Index: " + j);
				return j;
			}
		}
		System.out.println("No Index Found!");
		return -1;
	}
	// Should this subform be in the right?
	private boolean AdaptPositionAccordingtoSubformIndex(Node node,String parentLayout)
	{
		String name = getNodeAttributeName(node);
		System.out.println("In AdaptPositionAccordingtoSubformIndex Subform: " + name + " parent layout: " + parentLayout);
		if( parentLayout == null)
			return false;
		if( !parentLayout.equals("lr-tb"))
		{
			System.out.println("Not Western Text,No Need to Adapt!");
			return false;
		}
		int index = getChildIndex(node);
		if( index == 0 || index == -1)
			return false;
		Node prior = getPriorNode(node);
		if( prior == null)
			return false;
		Position priorPosition = infoPositionMap.get(prior);
		if( priorPosition == null)
		{
			System.out.println("None Prior Position Found!");
			return false;
		}
		position.moveToNewRow(priorPosition.getRow());
		position.moveToNextColumn();
		return true;
	}
	private void TransformInSummaryBlock(Node node,String parentLayout)
	{
		
		/* if node is not the first subform, then if the parentLayout
		 * style is western text, its row should be adapted as its' priors
		 * precondition: subform should set western layout style correctly.
		 */ 
		boolean isRight = AdaptPositionAccordingtoSubformIndex(node,parentLayout);
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		String layout = getSubformLayoutStyle(node);
		Position snapShot = position.snapShot();
		infoPositionMap.put(node,snapShot);
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform"))
			{
				/* should identify those dummy subform which are used just
				 * to occupy space 
				 */
				String name = Tool.getAttributeValue("name",item);
				if( !name.contains("dummy") )
					TransformInSummaryBlock(item,layout);
			}
			else if ( item.getNodeName().equals("draw"))
				TransformDrawInSummaryBlock(item,layout,isRight);
			else if ( item.getNodeName().equals("field"))
				TransformFieldInSummaryBlock(item,layout,isRight);
		}
		TraverseElementByLayoutStyle(parentLayout);
	}
	
	
	
	private String getSubformLayoutStyle(Node node)
	{
		if( node.getAttributes().getNamedItem("layout") == null)
			return null;
		return node.getAttributes().getNamedItem("layout").getNodeValue();
	}
	private void MovetoDefaultTablePosition()
	{
		position.moveToNextRow();
		position.moveToNewColumn(1);
		position.markTablePosition(position.getRow(),position.getColumn());
	}
	// node: the root node of table
	private void TransformTable(Node node)
	{
		if( isFirstMeetTable )
		{
			MovetoDefaultTablePosition();
			isFirstMeetTable = false;
		}
		NodeList child = node.getChildNodes();
		Node item = null;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				if( Tool.isFieldHidden(item) == true)
					continue;
				if( item.getAttributes().getNamedItem("name") == null)
				{
					ErrorReport("Subform should have a name attribute!");
					continue;
				}
				String SubformName = item.getAttributes().getNamedItem("name")
						.getNodeValue();
				System.out.println("In table: " + SubformName);
				if( SubformName.equals("rowMaterial"))
					System.out.println("here");
				if( isTable(SubformName))
				{
					// nested table
					TransformTable(node);
				}
				else if ( isTableHeader(SubformName))
				{
					TransformTableHeader(item);
				}
				else if ( isTableContentRow(SubformName))
				{
					if( Tool.getNodebyRoot("bind",item) != null)
					{
						TableNode = item;
						tablePath = getDesignerNodeBindingPath(TableNode);
					}
					TransformTableContentRow(item);
				}
				else if ( isRemarkRow(SubformName))
				{
					TransformRemarkRow(item);
				}
				// ignore the normal subform directly below table
			} 
			else if (item.getNodeName().equals("field"))
			{
				TransformField(item);
			}
			else if (item.getNodeName().equals("draw"))
			{
				TransformDraw(item);
			}
		}
		// this function is used to format the table in the excel transformer process
		CreateDummyCell();
	}
	
	private void TransformTableContentRow(Node node)
	{
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		String name = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( Tool.isFieldHidden(item))
				continue;
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				name = getNodeAttributeName(item);
				if( name == null)
					continue;
				if( isTable(name))
				{
					// nested table
					TransformTable(item);
				}
				else if (isTableContentRow(name))
				{
					// subformSet followed by a detail content row
					if( Tool.getNodebyRoot("bind",item) != null)
					{
						TableNode = item;
						tablePath = getDesignerNodeBindingPath(TableNode);
					}
					TransformTableContentRow(item);
				}
				else if ( isRemarkRow(name))
				{
					TransformRemarkRow(item);
				}
				else
				{
					// wrapper subform
					TransformWrapperSubform(item);
				}
			}
			else if ( item.getNodeName().equals("field"))
				TransformContentRowCell(item);
		}
		position.moveToNextContentRow();
	}
	private void TransformRemarkRow(Node node)
	{
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("field"))
				TransformRemarkRowCell(item);
		}
		position.addTableRowNumber();
				
	}
	// Create a dummy cell to trigger the format Excel Transformer 
	private void CreateDummyCell()
	{
		TemplateCell Dummy = new TemplateCell();
		Dummy.setPosition(-1,-1);
		Dummy.setCellType("Dummy");
		Dummy.setCaption(null);
		TemplateCellCollection.add(Dummy);
		System.out.println("Add Dummy Template Cell to trigger excel format later");
	}
	
	private void TransformRemarkRowCell(Node node)
	{
		String value = getCaptionValue(node);
		if( value != null)
		{
			System.out.println("Remark Cell Caption: " + value);
			TemplateCell RowCaption = new TemplateCell();
			RowCaption.setPosition(position.getRow(),position.getColumn());
			position.moveToNextColumn();
			RowCaption.setCellType("TableCell");
			RowCaption.setFieldNameforDesigner(Tool.getAttributeValue("name",node));
			RowCaption.setCorrespondingFieldType("RemarkCell");
			RowCaption.setCaption(value);
			TemplateCellCollection.add(RowCaption);
			System.out.println("Add Remark Row Caption!");
			position.trace();
		}
		if( withXMLData)
		{
			String path = getDesignerNodeBindingPath(node);
			value = XMLContentRetriever.getContentbyDesignerPath(path);
		}
		else
			value = getDefaultValue(node);
		if( value == null)
			return;
		TemplateCell RowCell = new TemplateCell();
		RowCell.setPosition(position.getRow(),position.getColumn());
		position.moveToNextColumn();
		// remark cell should be merged.
		RowCell.setCellType("RemarkCell");
		RowCell.setCorrespondingFieldType("RemarkCell");
		RowCell.setFieldNameforDesigner(Tool.getAttributeValue("name",node));
		RowCell.setDefaultValue(value);
		TemplateCellCollection.add(RowCell);
		System.out.println("Add Remark Row Content!");
		position.trace();
	}
	private void TransformWrapperSubform(Node node)
	{
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("field"))
				TransformContentRowCell(item);
		}
				
	}
	
	private boolean isRemarkRow(String name)
	{
		if( name.length() < 6)
		{
			ErrorReport("Subform: " + name + "Should have at least 6 CHARS!");
			return false;
		}
		name = name.substring(0,6);
		if( name.equalsIgnoreCase(ConfigDom.getRemarkRowNamingConvention()))
			return true;
		return false;
	}

	private boolean isValueMuitlLined(String value)
	{
		if( value == null)
			return false;
		if( value.contains("\\n"))
			return true;
		System.out.println("Single Line: " + value);
		return false;
	}
	private String[] getMuitlLine(String value)
	{
		String[] ValueTexts = new String[2];
		int index = value.indexOf("\\n");
		if( index == -1)
		{
			System.out.println("Error! no new line mark found!");
			return null;
		}
		String firstText = value.substring(0,index);
		System.out.println("first: " + firstText);
		index += 2;
		String secondText = value.substring(index,value.length());
		System.out.println("second: " + secondText);
		ValueTexts[0] = firstText;
		ValueTexts[1] = secondText;
		position.markMultiLine();
		return ValueTexts;
		
	}
	private boolean isHiddenSubformBefore(Node node)
	{
		Node previous = node.getPreviousSibling();
		while( previous != null)
		{
			System.out.println("Node name: " + previous.getNodeName());
			if( previous.getNodeName().equals("field"))
				return false;
			if( !previous.getNodeName().equals("subform"))
			{
				previous = previous.getPreviousSibling();
				continue;
			}
			if( Tool.isFieldHidden(previous))
			{
				hiddenSubform = previous;
				return true;
			}
			return false;
		}
		return false;
	}
	
	private String getContentRowValueFromXML(Node node)
	{
		if( hiddenSubform == null)
			return null;
		String total = "";
		String nodePath = null;
		String content = null;
		NodeList child = hiddenSubform.getChildNodes();
		String name = Tool.getAttributeValue("name",node);
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("field"))
				continue;
			nodePath = getDesignerNodeBindingPath(item);
			if( nodePath == null)
				continue;
			System.out.println("Node path: " + nodePath);
			content = XMLContentRetriever.getContentbyDesignerPath(nodePath);
			System.out.println("get Content:" + content);
			if( content == null)
				continue;
			total += ( content + "/");
		}
		System.out.println("Totalll: " + total);
		String[] text = total.split("/");
		if( name.startsWith("dec"))
			total = text[0] + " " + text[1];
		else
			total = text[0] + "\\n" + text[1];
		System.out.println("Content: " + total + " for " + name);
		return total;
	}
	
	private String getValueFromXML(Node node)
	{
		String nodePath = getDesignerNodeBindingPath(node);
		if( nodePath == null)
			return null;
		System.out.println("Node path: " + nodePath);
		String content = XMLContentRetriever.getContentbyDesignerPath(nodePath);
		System.out.println("get Content:" + content);
		return content;
	}
	private void TransformContentRowCell(Node node)
	{
		String value = null;
		if(withXMLData && isHiddenSubformBefore(node))
		{
			value = getContentRowValueFromXML(node);
		}
		else if ( withXMLData)
			value = getValueFromXML(node);
		else
			value = getDefaultValue(node);
		System.out.println("Table Cell: " + value);
		String name = Tool.getAttributeValue("name",node);
		if( !isValueMuitlLined(value))
		{
			TemplateCell RowCell = new TemplateCell();
			RowCell.setPosition(position.getRow(),position.getColumn());
			position.moveToNextColumn();
			RowCell.setCellType("TableCell");
			RowCell.setCorrespondingFieldType("TableCell");
			RowCell.setFieldNameforDesigner(name);
			RowCell.setCaption(value);
			TemplateCellCollection.add(RowCell);
			System.out.println("Add Row Cell!");
			position.trace();
			return;
		}
		else
			GenerateMultiCells(value,name);
	
	}
	private void GenerateMultiCells(String value,String AdobeFieldName)
	{
		System.out.println("in GenerateMultiCells():" + value);
		String[] ValueTexts = getMuitlLine(value);
		if( ValueTexts == null)
		// not possible to happen: has \n mark but fail to extract texts
			return;
		int size = ValueTexts.length;
		position.markTableRowNumber(size);
		Position snap = position.snapShot();
		position.trace();
		for( int i = 0 ; i < size;i++)
		{
			TemplateCell RowCell = new TemplateCell();
			RowCell.setPosition(position.getRow(),position.getColumn());
			position.moveToNextRow();
			RowCell.setCellType("TableCell");
			RowCell.setCorrespondingFieldType("TableCell");
			RowCell.setFieldNameforDesigner(AdobeFieldName);
			RowCell.setCaption(ValueTexts[i]);
			System.out.println("Add table Cell: " + ValueTexts[i]);
			position.trace();
			TemplateCellCollection.add(RowCell);
		}
		position.moveToNewRow(snap.getRow());
		position.moveToNextColumn();
		tableCellIndex++;
	}
	private void TransformTableHeader(Node node)
	{
		System.out.println("Transform Table Header!");
		NodeList child = node.getChildNodes();
		Node item = null;
		int headerNumber = 0;
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if (item.getNodeName().equals("draw"))
			{
				headerNumber++;
				TransformTableHeaderCell(item);
			}
		}
		// table header row taverse OK, adapt the current position.
		System.out.println("Total Table Header Number: " + headerNumber);
		position.moveToNextRow();
		position.moveToNewColumn(1);
		position.markTableHeaderNumber(headerNumber);
	}
	private void TransformTableHeaderCell(Node node)
	{
		String value = getRealDrawValue(node);
		System.out.println("Table Header: " + value);
		TemplateCell headerCell = new TemplateCell();
		headerCell.setPosition(position.getRow(),position.getColumn());
		position.moveToNextColumn();
		headerCell.setCellType("TableHeader");
		headerCell.setCorrespondingFieldType("TableHeader");
		String name = Tool.getAttributeValue("name",node);
		if( name != null)
			headerCell.setFieldNameforDesigner(name);
		headerCell.setCaption(value);
		TemplateCellCollection.add(headerCell);
		System.out.println("Add Header Cell!");
		position.trace();
		
	}
	public void TransformPageArea(Node PageArea) 
	{
		NodeList child = PageArea.getChildNodes();
		Node item = null;
		System.out.println("Transform pageArea:");
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				String SubformName = item.getAttributes().getNamedItem("name")
				.getNodeValue();
				// current version only handle with info block
				if( isInfoBlock(SubformName))
					TransformInfoBlock(item);
				else 
					traverseNode(item);
			} 
			else if (item.getNodeName().equals("field")) 
			{
				TransformField(item);
			} 
			else if (item.getNodeName().equals("draw")) 
			{
				TransformDraw(item);
			}
		}

	}
	
	private void TransformField(Node node)
	{
		
	}
	
	private void TransformFieldinInfoblock(Node node)
	{
		if( Tool.isFieldHidden(node))
			return;
		String caption = getCaptionValue(node);
		String defaultValue = getDefaultValue(node);
		/*if( caption != null)
			System.out.println("Field in info block caption:->" + caption);
		if( defaultValue != null)
			System.out.println("Field in info block default value:->" + defaultValue);
			*/
		String name = Tool.getAttributeValue("name",node);
		AddCaptionCell(caption,name);
		AddDefaultValueCell(defaultValue,name,node);
	}
	
	
	private void AddCaptionCell(String captionName,String FieldNameforDesigner)
	{
		TemplateCell caption = new TemplateCell();
		caption.setPosition(position.getRow(), position.getColumn());
		caption.setCellType("Caption");
		caption.setCaption(captionName);
		caption.setFieldNameforDesigner(FieldNameforDesigner);
		caption.setCorrespondingFieldType("Caption");
		TemplateCellCollection.add(caption);
		System.out.println("Add caption cell:->" + captionName );
		position.moveToNextColumn();
		position.trace();
	}
	
	private void AddDefaultValueCell(String defaultValue,String FieldNameforDesigner,
			Node DesignerNode)
	{
		TemplateCell defaultcell = new TemplateCell();
		defaultcell.setPosition(position.getRow(), position.getColumn());
		defaultcell.setCellType("DefalutValue");
		if( withXMLData )
		{
			String path = getDesignerNodeBindingPath(DesignerNode);
			String RealDefaultValue = XMLContentRetriever.getContentbyDesignerPath(path);
			defaultcell.setDefaultValue(RealDefaultValue);
		}
		else
			defaultcell.setDefaultValue(defaultValue);
		defaultcell.setFieldNameforDesigner(FieldNameforDesigner);
		defaultcell.setCorrespondingFieldType("DefalutValue");
		TemplateCellCollection.add(defaultcell);
		System.out.println("Add default value cell:->" + defaultValue );
		position.moveToNextRow();
		position.moveToPreviousColumn();
		position.trace();
	}
	
	private String getDesignerNodeBindingPath(Node node)
	{
		Node bind = Tool.getNodebyRoot("bind",node);
		if( bind == null)
			return null;
		if( bind.getAttributes().getNamedItem("ref") == null)
			return null;
		String path = bind.getAttributes().getNamedItem("ref").getNodeValue();
		if( !path.startsWith("$."))
		{
			if( path.contains("[*]"))
			{
				// table subform
				path = path.replace("[*]","");
				System.out.println("Table Path: " + path);
				return path;
			}
			else
				return path;
		}
		return tablePath + path.substring(1,path.length());
		// in the table
	}
	
	private String getCaptionValue(Node node)
	{
		Node captionNode = Tool.getNodebyRoot("caption",node);
		if( captionNode == null )
			return null;
		Node valueNode = Tool.getNodebyRoot("value",captionNode);
		if( valueNode == null)
			return null;
		Node textNode = Tool.getNodebyRoot("text",valueNode);
		if( textNode == null)
			return null;
		return textNode.getTextContent();
	}
	private String getRealDrawValue(Node node)
	{
		String value = getDefaultValue(node);
		if( value != null)
			return value;
		return getTableHeaderMultiLinesValue(node);
	}
	
	private String getTableHeaderMultiLinesValue(Node node)
	{
		Node value = Tool.getNodebyRoot("value",node);
		if( value == null)
			return null;
		Node exData = Tool.getNodebyRoot("exData",value);
		if( exData == null)
			return null;
		Node body = Tool.getNodebyRoot("body",exData);
		if( body == null)
			return null;
		String multiLines = "";
		NodeList child = body.getChildNodes();
		Node item = null;
		int Number = child.getLength();
		for( int i = 0 ; i < Number;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("p"))
				multiLines = multiLines + item.getTextContent() + "\n";
		}
		return multiLines;
	}
	// should consider decimal
	private String getDefaultValue(Node node)
	{
		Node valueNode = Tool.getNodebyRoot("value",node);
		if( valueNode == null)
			return null;
		Node textNode = Tool.getNodebyRoot("text",valueNode);
		if( textNode == null)
		{
			String decimal = getOtherValue("decimal",valueNode);
			if( decimal != null)
				return decimal;
			return getOtherValue("float",valueNode);
		}
		return textNode.getTextContent();
	}
	// decimal or float
	private String getOtherValue(String valueType,Node value)
	{
		Node other = Tool.getNodebyRoot(valueType,value);
		if( other == null)
			return null;
		return other.getTextContent();
	}
	private void TransformDraw(Node node)
	{
		if( node.getAttributes().getNamedItem("name") == null)
		{
			System.out.println("Node has no name attribute!");
			return;
		}
		String name = node.getAttributes().getNamedItem("name").getNodeValue();
		if( name.equals(ConfigDom.getLogoNamingConvention()))
		{
			// transform logo cell row1,column5.
			TransformLogo(node);
		}
		else if ( name.equals(ConfigDom.getTitleNamingConvention()))
		{
			TransformTitle(node);
		}
		
		else if ( isPageCounter(node))
		{
			// page counter which is put outside a info block
			System.out.println("Found page counter!");
			TransformPageCounter(node);
		}
	}
	private void TransformPageCounter(Node node)
	{
		TemplateCell page = new TemplateCell();
		position.setPageCounterPosition(position.getRow(), position.getColumn());
		page.setPosition(position.getRow(),position.getColumn());
		page.setCellType("PageCounter");
		page.setCorrespondingFieldType("PageCounter");
		page.setFieldNameforDesigner(Tool.getAttributeValue("name",node));
		TemplateCellCollection.add(page);
		System.out.println("Add Page Counter!");
		position.moveToNextRow();
		position.trace();
	}
	private void TransformTitle(Node node)
	{
		Node valueNode = Tool.getNodebyRoot("value",node);
		if( valueNode == null)
			return;
		Node textNode = Tool.getNodebyRoot("text",valueNode);
		if( textNode == null)
			return;
		String name = Tool.getAttributeValue("name",node);
		String titleText = textNode.getTextContent();
		System.out.println("Title Text: " + titleText);
		position.moveToPosition(ConfigDom.getDefaultTitleRow(),ConfigDom.getDefaultTitleColumn());
		TemplateCell title = new TemplateCell();
		title.setPosition(ConfigDom.getDefaultTitleRow(),ConfigDom.getDefaultTitleColumn());
		title.setCellType("Title");
		title.setCaption(titleText);
		title.setCorrespondingFieldType("Title");
		title.setFieldNameforDesigner(name);
		TemplateCellCollection.add(title);
		System.out.println("Add Title!");
		position.trace();
	}
	private void TransformLogo(Node node)
	{
		position.moveToPosition(ConfigDom.getDefaultLogoRowinExcel(),ConfigDom.getDefaultLogoColumninExcel());
		TemplateCell logo = new TemplateCell();
		logo.setPosition(ConfigDom.getDefaultLogoRowinExcel(),ConfigDom.getDefaultLogoColumninExcel());
		logo.setCellType("Logo");
		logo.setCorrespondingFieldType("Logo");
		logo.setFieldNameforDesigner(Tool.getAttributeValue("name",node));
		TemplateCellCollection.add(logo);
		System.out.println("Add logo!");
		position.trace();
	}

	// to be added in the future
	private void HandleFieldinFreeTextBlock(Node node)
	{
		return;
	}
	private void HandleDrawinFreeTextBlock(Node node)
	{
		Node value = Tool.getNodebyRoot("value",node);
		if( value == null)
			return;
		Node exData = Tool.getNodebyRoot("exData",value);
		if( exData == null)
			return;
		Node body = Tool.getNodebyRoot("body",exData);
		if( body == null)
			return;
		// to be added in the future
		NodeList child = body.getChildNodes();
		int number = child.getLength();
		Node item = null;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("p"))
				HandlePNode(item);
		}
		System.out.println("Total: " + freeTextCollection);
		CreateFreeTextCell(node);
	}
	
	private void CreateFreeTextCell(Node node)
	{
		String[] text = freeTextCollection.split("\n");
		int length = text.length;
		for( int i = 0 ; i < length;i++)
		{
			TemplateCell freeTextCell = new TemplateCell();
			freeTextCell.setPosition(position.getRow(),position.getColumn());
			position.moveToNextRow();
			freeTextCell.setCellType("FreeTextCell");
			freeTextCell.setFreeTextIndex(i+1);
			freeTextCell.setCorrespondingFieldType("FreeTextCell");
			freeTextCell.setFieldNameforDesigner(Tool.getAttributeValue("name",node));
			freeTextCell.setCaption(text[i]);
			TemplateCellCollection.add(freeTextCell);
			System.out.println("Add Free Text Cell: " + text[i]);
			position.trace();
		}
	}
	
	private void HandlePNode(Node node)
	{
		NodeList child = node.getChildNodes();
		int number = child.getLength();
		Node item = null;
		boolean isNewLine = true;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			System.out.println("Name: " + item.getNodeName());
			if( item.getNodeName().equals("#text"))
			{
				System.out.println("Value: " + item.getNodeValue());
				freeTextCollection += item.getNodeValue();
				isNewLine = false;
			}
			if ( item.getNodeName().equals("span"))
			{
				HandleSpanNode(item);
			}
			if( isNewLine)
				freeTextCollection += "\n";
		}
	}
	
	private void HandleSpanNode(Node node)
	{
		String link = null;
		String floatingField = null;
		if( node.getAttributes().getNamedItem("xfa:embed") == null)
			return;
		link = node.getAttributes().getNamedItem("xfa:embed").getNodeValue();
		floatingField = getFloatingFieldByID(link);
		if( floatingField != null)
		{
			System.out.println("Found Floating Field:" + floatingField);
			freeTextCollection += floatingField;
		}
	}
	private String getFloatingFieldByID(String link)
	{
		String path = link.substring(1,link.length());
		System.out.println("Want to search floating field: " + path);
		NodeList child = FreeTextBlockRoot.getChildNodes();
		int number = child.getLength();
		Node item = null;
		String ID = null;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("field"))
				continue;
			if( item.getAttributes().getNamedItem("name") == null)
				continue;
			if( item.getAttributes().getNamedItem("id") == null)
				continue;
			ID = item.getAttributes().getNamedItem("id").getNodeValue();
			if( !ID.equals(path))
				continue;
			return "{" + item.getAttributes().getNamedItem("name").getNodeValue() + "}";
		}
		return null;
	}
}