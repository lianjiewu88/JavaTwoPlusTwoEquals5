package PredefineField;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import utilities.FileCopyFactory;
import utilities.Tool;
import configuration.CustomMarkupConfigDom;

public class PredefineFieldExtractor
{
	private DocumentBuilderFactory domfac;

	private DocumentBuilder dombuilder;

	private FileCopyFactory filecopy;

	private Document doc;
	
	private Element root;
	
	private String templatePath = null;
	
	private DefaultListModel ListMode = null;
	
	private JList jList = null;
	
	private Vector<PredefineExtensionField> PredefineFieldList = null;
		
	public PredefineFieldExtractor(String path, Vector<PredefineExtensionField> list,JList inputlist, DefaultListModel mode)
	{
		domfac = DocumentBuilderFactory.newInstance();
		templatePath = path;
		PredefineFieldList = list;
		jList = inputlist;
		ListMode = mode;
		jList.setModel(ListMode);
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}

	
	private void WriteJList(String data)
	{
		ListMode.addElement(data);
	}
	private void NewLine()
	{
		ListMode.addElement("\n");
	}
	
	public Element getRoot()
	{
		return root;
	}

	private void traverse(Node node)
	{
		NodeList child = node.getChildNodes();
		int childNumber = child.getLength();
		Node item = null;
		for( int i = 0 ;i < childNumber; i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				traverse(item);
			}
			else if ( item.getNodeName().equals("field"))
			{
				ExtractPredefineField(item);
			}
			else if (item.getNodeName().equals("pageSet")) 
			{
				NodeList masterChild = item.getChildNodes();
				Node masterPageitem = null;
				int masterChildLength = masterChild.getLength();
				for (int j = 0; j < masterChildLength; j++) 
				{
					masterPageitem = masterChild.item(j);
					if (masterPageitem.getNodeName().equals("pageArea"))
					{
						traversePageArea(masterPageitem);
					}
				}
			}
		}
	}
	
	private void ExtractPredefineField( Node node)
	{
		Node bind = Tool.getNodebyRoot("bind",node);
		if ( bind == null )
			return;
		String path = Tool.getAttributeValue("ref", bind);
		if ( path == null )
			return;
		if ( path.contains( CustomMarkupConfigDom.PredefinedNamingConvention ) )
		{
			PredefineExtensionField field = new PredefineExtensionField(node,path,templatePath);
			PredefineFieldList.add(field);	
			String info = "Field Name:" + Tool.getAttributeValue("name", node) + "Bind Info: " + path;			
			WriteJList(info);
			info = "Path: " + Tool.getHierarchy(node);
			System.out.println(info);
			WriteJList(info);
			info = "Tempate Name: " + templatePath;
			System.out.println(info);
			WriteJList(info);
			NewLine();
		}
	}
	
	private void traversePageArea(Node PageArea) 
	{
		NodeList child = PageArea.getChildNodes();
		Node item = null;
		System.out.println("Traverse pageArea:");
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				traverse(item);
			} 
			else if (item.getNodeName().equals("field")) 
			{
				ExtractPredefineField(item);
			} 
		}
	}
	
	// main logic here
	public void StartExtract()
	{
		LoadTemplateFile(templatePath);
		System.out.println("Load Template Successfully!");
		root = doc.getDocumentElement();
		Node templateNode = Tool.getNodebyRoot("template",root);
		if( templateNode == null )
			return;
		traverse(templateNode);
	}

	public void LoadTemplateFile(String inputXDPName)
	{
		try 
		{
			filecopy = new FileCopyFactory();
			String OutputXMLFile = filecopy.copyFile(inputXDPName);
			if (OutputXMLFile == null)
				return;
			InputStream inputXML = new FileInputStream(OutputXMLFile);
			doc = dombuilder.parse(inputXML);
			root = doc.getDocumentElement();
			// but only template DOM is our concern...
			filecopy.DeleteUnusedXML(OutputXMLFile);
		}

		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
	
	}
}