package PredefineField;

import java.io.File;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JList;

import utilities.Tool;

public class PredefineFieldWrapper
{
	private File[] files = null;
	private JList jlist = null;
	private DefaultListModel jMode = null;
	private Vector<PredefineExtensionField> fieldCollection = null;
	public PredefineFieldWrapper(File[] input,JList list, DefaultListModel mode)
	{
		fieldCollection = new Vector<PredefineExtensionField>();
		files = input;
		jlist = list;
		jMode = mode;
	}
	
	public void StartExtract()
	{
		int FileNumber = files.length;
		System.out.println("Num: " + FileNumber);
		String inputXDPName = null;
		boolean isDirectory = false;
		for( int i = 0; i < FileNumber;i++)
		{
			isDirectory = files[i].isDirectory();
			if( !isDirectory)	// is a file
			{
				inputXDPName = files[i].getAbsolutePath();
				System.out.println("Path: " + inputXDPName );
				if( Tool.isValidTemplate(inputXDPName) )
				{
					PredefineFieldExtractor thread = new PredefineFieldExtractor(inputXDPName,fieldCollection,jlist,jMode);
					thread.StartExtract();
				}
			}
			else
				TraversePath(files[i]);
		}
		System.out.println("Result: " + fieldCollection.size());
	}
	private void TraversePath(File Directory)
	{
		System.out.println("In TraversePath!");
		File[] filecollection = Directory.listFiles();
		int filenumber = filecollection.length;
		File item = null;
		boolean isFileDirectory = false;
		for( int i = 0 ; i < filenumber; i++)
		{
			item = filecollection[i];
			isFileDirectory = item.isDirectory();
			if( !isFileDirectory)
			{
				if( Tool.isValidTemplate(item.getAbsolutePath()) )
				{
					PredefineFieldExtractor thread = new PredefineFieldExtractor(item.getAbsolutePath(),fieldCollection,jlist,jMode);
					thread.StartExtract();
				}
			}
			else
				TraversePath(item);
		}
	}
}