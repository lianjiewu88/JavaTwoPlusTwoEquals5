package PredefineField;

import org.w3c.dom.Node;
import utilities.Tool;
class PredefineExtensionField
{
	private String MappingPath = null;
	private String TemplateName = null;
	private String FieldName = null;
	private String FieldPath = null;
	public  PredefineExtensionField(Node node, String path, String xdpname)
	{
		MappingPath = path;
		FieldName = Tool.getAttributeValue("name", node);
		TemplateName = xdpname;
		String temp = FieldName;
		FieldPath = Tool.getHierarchy(node);
	}
}