package excelFormat.internalStructure;

import org.w3c.dom.Node;

public class CellObject
{
	private int rowNumber = -1;
	private int columnNumber = -1;
	private Node nodeInstance = null;
	private String CellName = null;
	public CellObject(int row,int column,Node node,String FieldName)
	{
		rowNumber = row;
		columnNumber = column;
		nodeInstance = node;
		CellName = FieldName;
		System.out.println("Adding a Cellobject: " + FieldName + " in row: " + row + "column: " + column);
	}

	public int getRowIndex()
	{
		return rowNumber;
	}
	public int getColumnIndex()
	{
		return columnNumber;
	}
	public Node getNodeInstance()
	{
		return nodeInstance;
	}
	public String getCellName()
	{
		return CellName;
	}
}