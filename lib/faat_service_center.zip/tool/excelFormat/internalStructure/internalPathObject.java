package excelFormat.internalStructure;



public class internalPathObject
{
	private String ownPath = null;
	private boolean inTable = false;
	private String parentPath = null;		// only make sense for table cell
	private String relativePath = null;		// only make sense for table cell
	
	public internalPathObject (String own,boolean intable,String parentpath,String re)
	{
		ownPath = own;
		inTable = intable;
		parentPath = parentpath;
		relativePath = re;
	}
	public boolean isInTable()
	{
		return inTable;
	}
	public String getPath()
	{
		return ownPath;
	}
	public String getParentPath()
	{
		return parentPath;
	}
	public String getRelativePath()
	{
		return relativePath;
	}
	

}