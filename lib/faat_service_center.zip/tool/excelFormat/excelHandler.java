package excelFormat;

import excelFormat.internalStructure.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import utilities.Tool;


public class excelHandler
{
	private Document doc;
	private DocumentBuilder dombuilder;
	private DocumentBuilderFactory domfac;
	private HashMap<String,internalPathObject> hashMapExcelCellPathInfo = null;
	private Vector<CellObject> nodeVec = null;
	private Element root = null;
	private int RealColumnIndex = 0;
	private final int FILE_STRUCTURE_ERROR = -1;
	private final int FORMAT_OK = 1;
	private final int NO_NEED_FORMAT = 2;
	private final int NO_BINDING_WORKSHEET = 3;
	private String BoundFieldName = null;
	private JList jList = null;
	private DefaultListModel listMode = null;
	private Node BindingWorkSheetRoot = null;
	public excelHandler()
	{
		domfac = DocumentBuilderFactory.newInstance();
		nodeVec = new Vector<CellObject>();
		hashMapExcelCellPathInfo = new HashMap<String,internalPathObject>();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}
	
	public HashMap<String,internalPathObject> getExcelBindngPathCollection()
	{
		return hashMapExcelCellPathInfo;
	}
	public void SetDisplayMode(JList list,DefaultListModel mode)
	{
		jList = list;
		listMode = mode;
		listMode.clear();
		jList.setModel(listMode);
	}
	
	private boolean checkIfFormattedAlready()
	{
		if( root.getAttributes().getNamedItem("formatted") == null )
			return false;
		String value = root.getAttributes().getNamedItem("formatted").getNodeValue();
		if( value.equals("true"))
			return true;
		return false;
	}
	// found explicit bound path and fill into interal structure
	private int DisplayPath(String path)
	{
		try 
		{
			InputStream inputXML = new FileInputStream(path);
			doc = dombuilder.parse(inputXML);
			root = doc.getDocumentElement();
			if( checkIfFormattedAlready() )
			{
				// already format
				String message = "This is an excel already formatted.Would you like to format it again anyway?";
				int option = JOptionPane.showConfirmDialog(new JFrame(),message, "INFO MESSAGE", JOptionPane.YES_NO_OPTION);
				if( option == JOptionPane.NO_OPTION )
					return NO_NEED_FORMAT;
			}
			Node x2MapInfo = Tool.getNodebyRoot("x2:MapInfo",root);
			if( x2MapInfo != null)
				System.out.println("Found x2:MapInfo!");
			else 
				return FILE_STRUCTURE_ERROR;
			Node x2Map = Tool.getNodebyRoot("x2:Map",x2MapInfo);
			if( x2Map != null)
			{
				System.out.println("Found x2:Map");
			}
			else
				return FILE_STRUCTURE_ERROR;
			NodeList EntryList = x2Map.getChildNodes();
			int EntryNumber = EntryList.getLength();
			Node Entry = null;
			for( int i = 0 ; i < EntryNumber; i++)
			{
				Entry = EntryList.item(i);
				if( Entry.getNodeName().equalsIgnoreCase("x2:Entry"))
				{
					System.out.println("Found entry:" + i);
					String position = GetNodeLocationinExcel(Entry);
					internalPathObject PathObj = GetNodePathinFMT(Entry,position);
					AddPostionPathInfo(position,PathObj);
				}
			}
		}

		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
		if(hashMapExcelCellPathInfo.isEmpty() )
			return NO_NEED_FORMAT;
		return FORMAT_OK;
	}
	
	public void SetBindingWorkSheetRoot(Node bind)
	{
		BindingWorkSheetRoot = bind;
	}
	
	public int RetrieveAllMappingPath(Element root)
	{
		
		Node x2MapInfo = Tool.getNodebyRoot("x2:MapInfo",root);
		if( x2MapInfo != null)
			System.out.println("Found x2:MapInfo!");
		else 
			return FILE_STRUCTURE_ERROR;
		Node x2Map = Tool.getNodebyRoot("x2:Map",x2MapInfo);
		if( x2Map != null)
		{
			System.out.println("Found x2:Map");
		}
		else
			return FILE_STRUCTURE_ERROR;
		NodeList EntryList = x2Map.getChildNodes();
		int EntryNumber = EntryList.getLength();
		Node Entry = null;
		for( int i = 0 ; i < EntryNumber; i++)
		{
			Entry = EntryList.item(i);
			if( Entry.getNodeName().equalsIgnoreCase("x2:Entry"))
			{
				System.out.println("Found entry:" + i);
				String position = GetNodeLocationinExcel(Entry);
				internalPathObject PathObj = GetNodePathinFMT(Entry,position);
				AddPostionPathInfo(position,PathObj);
			}
		}
		if(hashMapExcelCellPathInfo.isEmpty() )
			return NO_NEED_FORMAT;
		return FORMAT_OK;
	}
	
	private Node getBindingWorkSheet()
	{
		NodeList child = root.getChildNodes();
		int ChildNumber = child.getLength();
		Node item = null;
		for( int i = 0 ; i < ChildNumber; i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("Worksheet"))
				continue;
			if( item.getAttributes().getNamedItem("ss:Name").getNodeValue().equals("Binding"))
				return item;
		}
		return null;
	}
	
	private int FillNode()
	{
		BindingWorkSheetRoot = getBindingWorkSheet();
		if( BindingWorkSheetRoot != null)
			System.out.println("Found WorkSheet!");
		else 
			return NO_BINDING_WORKSHEET;
		Node Table = Tool.getNodebyRoot("Table",BindingWorkSheetRoot);
		if( Table != null)
			System.out.println("Found Table");
		else
			return FILE_STRUCTURE_ERROR;
		NodeList TableRows = Table.getChildNodes();
		int RowNumber = TableRows.getLength();
		Node RowInstance = null;
		int RealRowIndex = 0;
		for( int i = 0; i < RowNumber;i++)
		{
			RowInstance = TableRows.item(i);
			if( RowInstance.getNodeName().equals("Row"))
			{
				RealRowIndex++;
				RealRowIndex = HandleRowInstance(RowInstance,RealRowIndex);
			}
		}
		return FORMAT_OK;
		
	}
	
	private int GetRealRowInstance(Node rowInstance,int rowVirtualIndex)
	{
		if( rowInstance.getAttributes().getNamedItem("ss:Index") == null )
			return rowVirtualIndex;
		String number = rowInstance.getAttributes().getNamedItem("ss:Index").getNodeValue();
		System.out.println("Real Row Index: " + Integer.parseInt(number));
		return Integer.parseInt(number);
	}
	private int HandleRowInstance(Node rowInstance,int rowIndex)
	{
		int RealRowIndex = GetRealRowInstance(rowInstance,rowIndex);
		NodeList Cells = rowInstance.getChildNodes();
		int CellNumber = Cells.getLength();
		Node cellInstance = null;
		RealColumnIndex = 0;
		//System.out.println("Cell number: ***************" + CellNumber);
		for( int i = 0 ; i < CellNumber; i ++)
		{
			cellInstance = Cells.item(i);
			if( cellInstance.getNodeName().equalsIgnoreCase("Cell"))
			{
				RealColumnIndex++;
				ExtractCaptionName(cellInstance);
				if( RealColumnIndex == 3)
					BoundFieldName = (getTwiceBoundRealName(cellInstance));
				if( BoundFieldName != null)
				{
					AddCell(cellInstance,RealRowIndex,RealColumnIndex);
				}
				
			}
		}
		return RealRowIndex;
	}

	private void ExtractCaptionName(Node node)
	{
		Node DataNode = Tool.getNodebyRoot("Data",node);
		if( DataNode == null)
			return;
		BoundFieldName = DataNode.getTextContent();
	}


	
	private void AddCell(Node cellInstance,int row,int column)
	// need not add all the node,only those with corresponding node in the message type
	{
		CellObject cell = null;
		if ( cellInstance.getAttributes().getNamedItem("ss:Index") == null )
		{
			System.out.println("Add Cell:" +  BoundFieldName + " row->" + row + " column->" + column);
			cell = new CellObject(row,column,cellInstance,BoundFieldName);
			nodeVec.add(cell);
		}
		else
		{
			String index = cellInstance.getAttributes().getNamedItem("ss:Index").getNodeValue();
			RealColumnIndex = Integer.parseInt(index);
			System.out.println("Index found!Cell Real Index should be: " + RealColumnIndex);
			cell = new CellObject(row,RealColumnIndex,cellInstance,BoundFieldName);
			System.out.println("Add Cell row->" + row + " column->" + RealColumnIndex);
			nodeVec.add(cell);
		}
	}
	
	private int WriteBackPathAccordingtoPosition()
	{
		int ret = FillNode();
		if( ret == FORMAT_OK)
			HandleTaskinMap();
		else
			return ret;
		// should handle with twice-bound nodes
		Node table = Tool.getNodebyRoot("Table",BindingWorkSheetRoot);
		if( table == null )
			return FORMAT_OK;
		NodeList child = table.getChildNodes();
		int number = child.getLength();
		Node item = null;
		for( int i = 0; i < number;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("Row"))
				CheckRowInstanceForRelativePositionLink(item);
		}
		return ret;
	}
	
	private void CheckRowInstanceForRelativePositionLink(Node row)
	{
		System.out.println(" in CheckRowInstanceForRelativePositionLink()");
		NodeList child = row.getChildNodes();
		int number = child.getLength();
		Node item = null;
		for( int i = 0; i < number;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("Cell"))
				FindLinkedNodeAndWriteBack(item);
		}
		
	}
	private void FindLinkedNodeAndWriteBack(Node node)
	{
		Node data = Tool.getNodebyRoot("Data",node);
		if( data == null)
			return;
		System.out.println("Found Data Node!: " + data.getTextContent());
		String position = hasLinkInformation(data.getTextContent());
		if( position == null)
		{
			System.out.println("Is Link Node but Position is invalid!");
			return;
		}
		System.out.println("Position: " + position);
		if( position.equals("R5C3"))
			System.out.println("here");
		// find node which position fits and fetch binding path from that node
		// and write back to this node
		int rowIndex = getRowIndex(position);
		if( rowIndex == -1)
			return;
		int columnIndex = getColumnIndex(position);
		if( columnIndex == -1)
			return;
		String twiceBoundName = getTwiceBoundRealName(node);
		CellObject twiceBoundField = new CellObject(rowIndex,columnIndex,node,
				twiceBoundName);
		System.out.println("Twice Bound Field: " + twiceBoundName);
		HandleWithTwiceBoundCell(twiceBoundField);
	}
	private Node getNodebyPosition(int row,int column)
	{
		Node rowInstance = getRowInstancebyIndex(row);
		if( rowInstance == null)
			return null;
		return getCellInstancebyIndex(column,rowInstance);
	}
	
	private String getTwiceBoundRealName(Node node)
	{
		Node previous = getPreviousNode(node);
		if( previous == null)
			return null;
		Node data = Tool.getNodebyRoot("Data",previous);
		return data.getTextContent();
	}
	private Node getPreviousNode(Node node)
	{
		Node previous = node.getPreviousSibling();
		while( previous != null)
		{
			if( !previous.getNodeName().equals("Cell"))
			{
				previous = previous.getPreviousSibling();
				continue;
			}
			return previous;
		}
		return null;
	}
	//
	private Node getRowInstancebyIndex(int row)
	{
		Node TableNode = Tool.getNodebyRoot("Table",BindingWorkSheetRoot);
		if( TableNode == null)
			return null;
		NodeList Rows = TableNode.getChildNodes();
		int RowNumber = Rows.getLength();
		Node item = null;
		int realRowIndex = 0;
		int relativeIndex = -1;
		for( int i = 0 ; i < RowNumber;i++)
		{
			item = Rows.item(i);
			if( item.getNodeName().equals("Row"))
			{
				realRowIndex++;
				relativeIndex = getRelativeIndex(item,realRowIndex);
				if( relativeIndex != -1)
					realRowIndex = relativeIndex;
				if( realRowIndex == row)
					return item;
			}
		}
		return null;
	}
	
	private int getRelativeIndex(Node node,int realIndex)
	{
		if( node.getAttributes().getNamedItem("ss:Index") == null)
			return realIndex;
		return Integer.valueOf(node.getAttributes().getNamedItem("ss:Index").getNodeValue());
	}
	
	private Node getCellInstancebyIndex(int column,Node row)
	{
		NodeList Cells = row.getChildNodes();
		int CellNumber = Cells.getLength();
		Node item = null;
		int realColumnIndex = 0;
		int relativeColumnIndex = -1;
		for( int i = 0 ; i < CellNumber;i++)
		{
			item = Cells.item(i);
			if( item.getNodeName().equals("Cell"))
			{
				realColumnIndex++;
				relativeColumnIndex = getRelativeIndex(item,realColumnIndex);
				if( relativeColumnIndex != -1)
					realColumnIndex = relativeColumnIndex;
				if( relativeColumnIndex == column)
					return item;
			}
		}
		return null;
	}
		
	private void HandleWithTwiceBoundCell(CellObject cell)
	{
		System.out.println("Trying to find node: " + "row: " + cell.getRowIndex() + " column: " + cell.getColumnIndex());
		Node LinkedCell = getNodebyPosition(cell.getRowIndex(),cell.getColumnIndex());
		if( LinkedCell == null)
		{
			System.out.println("Trying to find node: " + "row: " + cell.getRowIndex() + " column: " + cell.getColumnIndex() + " but failed!");
			return;
		}
		Node dataNode = Tool.getNodebyRoot("Data",LinkedCell);
		if( dataNode == null )
			return;
		internalPathObject obj = new internalPathObject(dataNode.getTextContent(),
				false,null,null);
		WriteBackValueData(cell,obj);
	}
	private String hasLinkInformation(String value)
	{
		if( value == null)
			return null;
		String formatted = value.trim();
		int length = formatted.length();
		int index = formatted.indexOf('@');
		if( index == -1)
			return null;
		return formatted.substring(++index,length);
	}
	
	private void HandleTaskinMap()
	{
		Iterator iterator = hashMapExcelCellPathInfo.keySet().iterator(); 
		while(iterator.hasNext()) 
		{
			Object key = iterator.next();
			System.out.println("Position in traverse: " + key.toString());
			System.out.println("Path in traverse: " + hashMapExcelCellPathInfo.get(key));
			modifyCellDataValue(key.toString());
		}
		MarkWithFormattedAttribute();

	}
	private void MarkWithFormattedAttribute()
	{
		Document CellDocument = root.getOwnerDocument();
		Attr formatFlag = CellDocument.createAttribute("formatted");
		formatFlag.setNodeValue("true");
		root.setAttributeNode(formatFlag);
	}
	private void modifyCellDataValue(String position)
	{
		System.out.println("Want to modify node in position: " + position);
		internalPathObject obj = hashMapExcelCellPathInfo.get(position);
		int rowIndex = getRowIndex(position);
		int columnIndex = getColumnIndex(position);
		int VecNodeNumber = nodeVec.size();
		for( int i = 0 ; i < VecNodeNumber; i ++ )
		{
			CellObject cell = nodeVec.elementAt(i);
			if(( cell.getColumnIndex() == columnIndex ) && ( cell.getRowIndex() == rowIndex))
			{
				System.out.println("One node matched!");
				//WriteBackValueData(cell.getNodeInstance(),path,cell.getCellName());
				WriteBackValueData(cell,obj);
			}
			else
			{
				//System.out.println("Column: " + columnIndex + " row: " + rowIndex);
				//System.out.println("Cell column: " + cell.getColumnIndex() + " Cell row: " + cell.getRowIndex());
			}
		}
	}
	private void DisplayinJList(CellObject cell,String path)
	{
		String item = "Excel Name: " + cell.getCellName();
		listMode.addElement(item);
		item = "      Has Its Path: " + path + " successfully!";
		listMode.addElement(item);
		listMode.addElement("\n");
	}
	/* two situation should be handled:
	 * 1.Create a new Data Node
	 * 2.If already a new Data Node,just assign the value to it.
	 * cell and obj are already matched.
	 */
	private void WriteBackValueData(CellObject cell,internalPathObject obj)
	{
		String formattedPath = FormatPath(obj.getPath());
		if( formattedPath == null)
			return;
		DisplayinJList(cell,formattedPath);
		Node node = cell.getNodeInstance();
		Node OldDataNode = Tool.getNodebyRoot("Data",node);
		if( OldDataNode == null)
		{
			Document CellDocument = node.getOwnerDocument();
			Element DataNode = CellDocument.createElement("Data");
			Attr type = CellDocument.createAttribute("ss:Type");
			type.setNodeValue("String");
			DataNode.setAttributeNode(type);
			DataNode.setTextContent(formattedPath);
			node.appendChild(DataNode);
			node.getAttributes().removeNamedItem("ss:StyleID");
		}
		else
			OldDataNode.setTextContent(formattedPath);
		AddCustomFormDescriptionNode(cell,obj);
	}
	private void AddCustomFormDescriptionNode(CellObject cell,internalPathObject obj)
	{
		Node node = cell.getNodeInstance();
		Document CellDocument = node.getOwnerDocument();
		Element DataNode = CellDocument.createElement("Form");
		Attr nameAtt = CellDocument.createAttribute("fieldname");
		nameAtt.setNodeValue(cell.getCellName());
		DataNode.setAttributeNode(nameAtt);
		
		Attr typeAttr = CellDocument.createAttribute("type");
		// assign type attribute
		if( obj.isInTable() )
			typeAttr.setNodeValue("tablecell");
		else
			typeAttr.setNodeValue("singlefield");
		DataNode.setAttributeNode(typeAttr);
		node.appendChild(DataNode);
		// if it is in table, create a parent node
		if( obj.isInTable())
		{
			Element parentNode = CellDocument.createElement("Parent");
			String formattedParentPath = FormatPath(obj.getParentPath());
			parentNode.setTextContent(formattedParentPath);
			DataNode.appendChild(parentNode);
			Attr RelativeAttr = CellDocument.createAttribute("relative");
			RelativeAttr.setNodeValue(obj.getRelativePath());
			DataNode.setAttributeNode(RelativeAttr);
		}
	}
	
	private String RemoveUnitToken(String path)
	{
		int index = path.indexOf('@');
		if( index == -1)
		{
			// no unit token existing!
			return path;
		}
		String temp = path.substring(0,index) + path.substring(++index,path.length());
		return temp;
	}
	private String FormatPath(String path)
	{
		if( path.contains("$record."))
			return path;
		int indexOfSlash = path.indexOf(':');
		if( indexOfSlash == -1)
			return null;
		String temp = path.substring(++indexOfSlash,path.length());
		temp = temp.replace('/','.');
		
		int indexOfPoint = temp.indexOf('.');
		if( indexOfPoint == -1)
			return null;
		temp = temp.substring(++indexOfPoint,temp.length());
		temp = "$record." + temp;
		temp = RemoveUnitToken(temp);
		System.out.println("Temp: " + temp);
		return temp;
	}
	public String WriteBacktoDisk(String path)
	{
		String formattedPath = FormatSavePath(path);
		File newFile = new File(formattedPath);
		if( newFile.exists())
			return null;
		try
		 {   
             TransformerFactory tff = TransformerFactory.newInstance();   
             Transformer tf = tff.newTransformer();   
             DOMSource source = new DOMSource(doc);
             StreamResult rs = new StreamResult(newFile);
             tf.transform(source,rs);  
             tf.reset();
         }
		 catch(Exception   e1)
		 {   
             e1.printStackTrace();   
		 }  
		 return formattedPath;
	}
	private String FormatSavePath(String path)
	{
		int index = path.lastIndexOf('.');
		if( index != -1)
			return path;
		String newPath = path + ".xml";
		return newPath;
	}
	private int getRowIndex(String position)
	{
		int rIndex = position.indexOf('R');
		if( rIndex == -1)
			return rIndex;
		int cIndex = position.indexOf('C');
		if( cIndex == -1)
			return cIndex;
		String RowIndex = position.substring(++rIndex,cIndex);
		System.out.println("Row index: " + RowIndex);
		return Integer.parseInt(RowIndex);
	}
	private int getColumnIndex(String position)
	{
		int cIndex = position.indexOf('C');
		if( cIndex == -1)
			return cIndex;
		String ColumnIndex = position.substring(++cIndex,position.length());
		System.out.println("Column index: " + ColumnIndex);
		return Integer.parseInt(ColumnIndex);
	}
	private String GetNodeLocationinExcel(Node Entry)
	{
		// take x2:HeaderRange as the first priority
		Node HeaderRangeNode = Tool.getNodebyRoot("x2:HeaderRange",Entry);
		if( HeaderRangeNode != null)
		{
			return HeaderRangeNode.getTextContent();
		}
		Node Location = Tool.getNodebyRoot("x2:Range",Entry);
		if( Location == null)
			return null;
		String loc = Location.getTextContent();
		int index = loc.lastIndexOf('!');
		if( index == -1)
			return null;
		String Position = loc.substring(++index, loc.length());
		System.out.println("Position: " + Position);
		return Position;
	}
	
	private void AddPostionPathInfo(String position,internalPathObject pathObj)
	{
		if( position == null)
			return;
		if(( pathObj.isInTable()) && ( pathObj.getParentPath() == null ))
			return;
		System.out.println("Path: " + pathObj.getPath());
		System.out.println("Pos: " + position);
		hashMapExcelCellPathInfo.put(position,pathObj);
	}
	// should return internal object contain information both itself and parent if has one.
	private internalPathObject GetNodePathinFMT(Node Entry,String position)
	{
		internalPathObject obj = null;
		if( !isNodeTableStructure(Entry))
		{
			Node Path = Tool.getNodebyRoot("x2:XPath",Entry);
			if( Path == null)
				return null;
			String loc = Path.getTextContent();
			obj = new internalPathObject(loc,false,null,null);
			return obj;
		}
		else // table structure,should concat prefix and value together
		{
			Node PrefixNode = Tool.getNodebyRoot("x2:XPath",Entry);
			if( PrefixNode == null)
				return null;
			String prefix = PrefixNode.getTextContent();
			Node FieldNode = Tool.getNodebyRoot("x2:Field",Entry);
			if( FieldNode == null)
				return null;
			//String value = FieldNode.getAttributes().getNamedItem("x2:ID").getNodeValue();
			String value = Tool.getNodebyRoot("x2:XPath",FieldNode).getTextContent();
			String CompletePath = prefix + "/" + value;
			if( isAddressEntry(Entry))
				obj = new internalPathObject(CompletePath,false,null,null);
			else
				obj = new internalPathObject(CompletePath,true,prefix,value);
			// check if there is more than one field subnode?
			Node nextField = getNextField(FieldNode);
			while( nextField != null)
			{
				value = Tool.getNodebyRoot("x2:XPath",nextField).getTextContent();
				CompletePath = prefix + "/" + value;
				obj = new internalPathObject(CompletePath,true,prefix,value);
				AddPostionPathInfo(getAlignCellNewPosition(position),obj);
				nextField = getNextField(nextField);
			}
			return obj;
			
		}
	}
	private boolean isAddressEntry(Node Entry)
	{
		Node x2XPath = Tool.getNodebyRoot("x2:XPath",Entry);
		if( x2XPath.getTextContent().contains("Address"))
			return true;
		return false;
	}
	private String getAlignCellNewPosition(String position)
	{
		int column = getColumnIndex(position);
		int cIndex = position.indexOf('C');
		if( cIndex == -1)
			return null;
		String newPosition = position.substring(0,++cIndex);
		newPosition += ("" + ++column);
		System.out.println("new: " + newPosition);
		return newPosition;
	}
	private Node getNextField(Node field)
	{
		Node next = field.getNextSibling();
		while( next!= null)
		{
			if( next.getNodeName().equals("x2:Field"))
				return next;
			next = next.getNextSibling();
		}
		return null;
	}
	private boolean isNodeTableStructure(Node Entry)
	{
		String type = Entry.getAttributes().getNamedItem("x2:Type").getNodeValue();
		if( type.equalsIgnoreCase("table"))
			return true;
		return false;
	}

	public int FormatExcel(String excelPath)
	{
		int ret = DisplayPath(excelPath);
		if( ret == FORMAT_OK )
			return WriteBackPathAccordingtoPosition();
		return ret;
	}
}