package configuration;


import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import org.w3c.dom.Node;
public class ConfigDom

{
	private static String infoBlockName = "frminfo";
	private static String infoblockLocation = "infoblock";
	private static String freeBlockName = "frmfree";
	private static String freeblockLocation = "freeblock";
	private static String summaryBlockName = "frmsumm";
	private static String summaryblockLocation = "summaryblock";
	private static String SubformName = "frm";
	private static String TableName = "tbl";
	private static String TableColumnNamingConvention = "col";
	private static String StaticTextName = "lbl";
	private static String HiddenSubform = "frmfloatfields";
	private static String HiddenSubformLocation = "HiddenSubform";
	private static String SummaryLabelNamingConvention = "lbl";
	private static String AddressblockNamingConvention = "frmAddr";
	private static String TableLocation = "table";
	private static String TableHeader = "hdr";
	private static String RemarkRow = "frmremark";
	private static String RemarkLocation = "RemarkRow";
	private static String SignatureBlock = "frmSig";
	private static String HeaderLocation = "tableheader";
	private static String TableRow = "row";
	private static String RowLocation = "tablerow";
	private static String MasterPageName = "mst";
	private static String MasterPageLocation = "masterpage";
	private static String FooterBlockLocation = "FooterBlock";
	private static String BodyPageName = "bdy";
	private static String TextFieldName = "txt";
	private static String BodyPageLocation = "bodypage";
	private static String DecimalName = "dec";
	private static String NumericName = "num";
	private static String FormTitleName = "lbl_A1SFC_FormTitle";
	private static String FormLogoName = "pic_A1SFC_HeaderLogo";
	private static String FormFieldLogoName = "img_A1SFC_HeaderLogo";
	private static String FormLogoNamePostfix = "A1SFC_HeaderLogo";
	private static String SenderAddressName = "lbl_A1SFC_SenderAddress";
	private static String SeparatorName = "rec_A1SFC_HeaderSeparator";
	private static String FooterName = "frm_A1SFC_Footer";
	private static String FooterPostfix = "A1SFC_FooterBlock";
	private static String DefaultSubformName = "untitled Subform";
	private static String DefaultAccSetting = "custom";
	private static String DefaultCaptionAccSetting = "caption";
	private static String DefaultAccRightSetting = "none";
	private static String FieldAccessAtributeName = "access";
	private static String FieldAccessReadOnly = "readOnly";
	private static String FiledAccessToolTip = "toolTip";
	private static String TopToBottom = "tb";
	private static String WestenText = "lr-tb";
	private static String RowLayout = "row";
	private static String Positioned = "positioned";
	private static String TableCellLeftMargin = "1mm";
	private static String TableCellRightMargin = "1mm";
	private static String TableCellTopMargin = "1mm";
	private static String TableCellBottomMargin = "1mm";
	private static String InfoblockLeftMargin = "0mm";
	private static String InfoblockRightMargin = "0mm";
	private static String InfoblockTopMargin = "0mm";
	private static String InfoblockBottomMargin = "1.2mm";
	private static String InfoblockBottomMarginwithBlankRow = "6.2mm";
	private static String SummaryblockLeftMargin = "0.1mm";
	private static String SummaryblockRightMargin = "0.1mm";
	private static String SummaryblockTopMargin = "0.1mm";
	private static String SummaryblockBottomMargin = "0.1mm";
	private static String defaultBarcodeMargin = "0mm";
	private static String defaultDrawMargin = "1mm";
	private static String MasterPageDefaultSetting = "a4";
	private static String DefaultFontSize = "10pt";
	private static String DefaultFontFamily = "Arial";
	private static String FormDefaultFontColor = "128,128,128";
	private static String SeparatorDefaultLineColor = "142,142,142";
	private static String SeparatorDefaultFillColor = "220,220,220";
	private static String TableHeaderFillColor = "220,220,220";
	private static String FormTitleDefaultFontSize = "18pt";
	private static String HorizonLeftAligned = "left";
	private static String LogoHeight = "20mm";
	private static String LogoWidth = "40mm";
	private static String DefaultTreeNodeName = "XDP";
	private static String EFECompatiblePostfix = "_EFE_Compatible_Draft";
	private static String DataFileLinkNodeName = "DefaultPreviewDataFileName";
	private static String NormalBinding = "normal";
	private static String DefaultAccessMode = "editable";
	private static String DefaultHeightSetting = "constantHeight";
	private static String DefaultWidthSetting = "constantWidth";
	private static String DefaultLineSetting = "single";
	private static int StandardFormTitleWidth = 120;
	private static int StandardFormTitleHeight = 15;
	private static int StandardPageIndexHeight = 5;
	private static int defaultInfoStartingRowinExcel = 4;
	private static int defaultInfoStartingColumninExcel = 1;
	private static int defaultTitleStartingRowinExcel = 2;
	private static int defaultTitleStartingColumninExcel = 1;
	private static int defaultLogoRowinExcel = 1;
	private static int defaultLogoColumninExcel = 5;
	private static int maxRowNumberinExcelTransformation = 100;
	private static int maxColumnNumberinExcelTransformation = 13;
	private static int defaultRightInfoStartingColumninExcel = 4;
	private static int defaultSigRightStartingColumninExcel = 4;
	private static int defaultSignatureImageHeight = 40;
	private static float SepatatorDefaultHeight = (float) 2.5;
	private static String defaultSenderAddressFont = "8pt";
	private static String defaultTableFont = "9pt";
	private static String ExcelDummyStyle = "s21";
	private static String ExcelStyleForDefautValue = "s23";
	private static String ExcelStyleForLogo = "s28";
	private static String ExcelStyleForPage = "s27";
	private static String ExcelStyleForTitle = "s30";
	private static String ExcelStyleForTable = "s31";
	private static String ExcelStyleForFreeTextBlock = "s32";
	private static String defaultLogo = "Akron Heating Technologies";
	private static float maxFormWidth = 176;
	public  static final String CHINA_TIME_ZONE = "CST";
	public  static final String CZECH_TIME_ZONE = "CEST";
	public  static final int CHINE_TIME_DIFF = 8;
	public  static final int CZECH_TIME_DIFF = 2;
	public  static final int MAX_SAVE_FAIL_TIME = 3;
	public  static final int VERSION_FILE = 1;
	public  static final int PATH_FILE = 2;
	public  static final int NO_MAPPING = -1;
	public  static final int INVALID_RELATIVE_MAPPING = 0;
	public  static final int MAPPING_OK = 1;
	public  static final boolean DescriptionCheckOn = false;
	public  static final String versionFile = "**cnctul000*Root*Service_Center*Content_Service*Misc*Form*35_Layout_AutoTest_Tool*version_DO_NOT_DELETE.txt";
	
	static public String getInfoblockNamingConvention()
	{
		return infoBlockName;
	}
	static public String getFieldAccessToolTip()
	{
		return FiledAccessToolTip;
	}
	static public String getDefaultBarcodeMargin()
	{
		return defaultBarcodeMargin;
	}
	static public String getDefaultDrawMargin()
	{
		return defaultDrawMargin;
	}
	static public String getdefaultSenderAddressFont()
	{
		return defaultSenderAddressFont;
	}
	static public int getStandardPageIndexHeight ()
	{
		return StandardPageIndexHeight;
	}
	static public String getFormLogoNamePostfix()
	{
		return FormLogoNamePostfix;
	}
	static public String getDataFileLinkNodeName()
	{
		return DataFileLinkNodeName;
	}
	static public String getDefaultTreeNodeName()
	{
		return DefaultTreeNodeName;
	}
	static public String getFormFieldLogoName()
	{
		return FormFieldLogoName;
	}
	static public String getHiddenSubformNamingConvention()
	{
		return HiddenSubform;
	}
	static public String getTableHeaderFillColor()
	{
		return TableHeaderFillColor;
	}
	static public String getFieldAccessAtributeName()
	{
		return FieldAccessAtributeName;
	}
	static public String getAddressblockNamingConvention()
	{
		return AddressblockNamingConvention;
	}
	static public String getdefaultTableFont()
	{
		return defaultTableFont;
	}
	static public String getDefaultCaptionAccSetting()
	{
		return DefaultCaptionAccSetting;
	}
	static public String getDefaultLogo()
	{
		return defaultLogo;
	}
	static public String getTextFieldNamingConvention()
	{
		return TextFieldName;
	}
	static public String getFieldAccessReadOnly()
	{
		return FieldAccessReadOnly;
	}
	static public String getHiddenSubformLocation()
	{
		return HiddenSubformLocation;
	}
	static public String getTableColumnNamingConvention()
	{
		return TableColumnNamingConvention;
	}
	static public String getDefaultSubformName()
	{
		return DefaultSubformName;
	}
	static public String getFooterBlockLocation()
	{
		return FooterBlockLocation;
	}
	static public String getEFEPostFix()
	{
		return EFECompatiblePostfix;
	}
	static public String getFooterPostfix()
	{
		return FooterPostfix;
	}
	static public String getSummaryLabelNamingConvention()
	{
		return SummaryLabelNamingConvention;
	}
	static public String getRemarkLocation()
	{
		return RemarkLocation;
	}
	static public float getMaxFormWidth()
	{
		return maxFormWidth;
	}
	static public int getMaxRowinExcelTransformation()
	{
		return maxRowNumberinExcelTransformation;
	}
	static public int getMaxColumninExcelTransformation()
	{
		return maxColumnNumberinExcelTransformation;
	}
	static public String getExcelStyleForTable()
	{
		return ExcelStyleForTable;
	}
	static public String getExcelStyleForFreeTextBlock()
	{
		return ExcelStyleForFreeTextBlock;
	}
	static public String getExcelStyleForPage()
	{
		return ExcelStyleForPage;
	}
	static public String getExcelStyleForDefaultValue()
	{
		return ExcelStyleForDefautValue;
	}
	static public String getExcelStyleForLogo()
	{
		return ExcelStyleForLogo;
	}
	static public String getExcelDummyStyle()
	{
		return ExcelDummyStyle;
	}
	static public String getExcelStyleForTitle()
	{
		return ExcelStyleForTitle;
	}
	static public int getDefaultLogoRowinExcel()
	{
		return defaultLogoRowinExcel;
	}
	static public int getDefaultLogoColumninExcel()
	{
		return defaultLogoColumninExcel;
	}
	static public int getDefaultRightInfoStartingColumninExcel()
	{
		return defaultRightInfoStartingColumninExcel;
	}
	static public int getDefaultSigRightStartingColumninExcel()
	{
		return defaultSigRightStartingColumninExcel;
	}
	static public int getDefaultTitleRow()
	{
		return defaultTitleStartingRowinExcel;
	}
	
	static public int getDefaultTitleColumn()
	{
		return defaultTitleStartingColumninExcel;
	}
	static public int getDefaultSignatureImageHeight()
	{
		return defaultSignatureImageHeight;
	}
	static public int getDefaultInfoStartingRow()
	{
		return defaultInfoStartingRowinExcel;
	}
	static public int getDefaultInfoStartingColumn()
	{
		return defaultInfoStartingColumninExcel;
	}
	static public String getStaticTextNamingConvention()
	{
		return StaticTextName;
	}
	static public String getDefaultLineSetting()
	{
		return DefaultLineSetting;
	}
	static public String getHeaderLocation()
	{
		return HeaderLocation;
	}
	static public String getSignatureNamingConvention()
	{
		return SignatureBlock;
	}
	static public String getMasterPageName()
	{
		return MasterPageName;
	}
	static public String getMasterPageLocation()
	{
		return MasterPageLocation;
	}
	static public String getRemarkRowNamingConvention()
	{
		return RemarkRow;
	}
	static public String getTableLocation()
	{
		return TableLocation;
	}
	static public String getInfoblockLocation()
	{
		return infoblockLocation;
	}
	static public String getBodyPageLocation()
	{
		return BodyPageLocation;
	}
	static public String getFreeblockLocation()
	{
		return freeblockLocation;
	}
	static public String getDefaultWidthSetting()
	{
		return DefaultWidthSetting;
	}
	static public String getsummaryblockLocation()
	{
		return summaryblockLocation;
	}
	static public String getDefaultHeightSetting()
	{
		return DefaultHeightSetting;
	}
	static public String getNormalBinding()
	{
		return NormalBinding;
	}
	static public String getDefaultHorizonAlignStyle()
	{
		return HorizonLeftAligned;
	}
	static public String getPositionedStyle()
	{
		return Positioned;
	}
	static public String getDefaultAccessMode()
	{
		return DefaultAccessMode;
	}
	static public String getFreeblockNamingConvention()
	{
		return freeBlockName;
	}
	static public String getSummaryBlockNamingConvention()
	{
		return summaryBlockName;
	}
	static public String getSubformNamingConvention()
	{
		return SubformName;
	}
	static public String getTableNamingConvention()
	{
		return TableName;
	}
	static public String getTableHeaderNamingConvention()
	{
		return TableHeader;
	}
	static public String getTableRowNamingConvention()
	{
		return TableRow;
	}
	static public String getBodyPageNamingConvention()
	{
		return BodyPageName;
	}
	static public String getDecimalNamingConvention()
	{
		return DecimalName;
	}
	static public String getNumericNamingConvention()
	{
		return NumericName;
	}
	static public String getTitleNamingConvention()
	{
		return FormTitleName;
	}
	static public String getLogoNamingConvention()
	{
		return FormLogoName;
	}
	static public String getSenderAddressNamingConvention()
	{
		return SenderAddressName;
	}
	static public String getSeparatorNamingConvention()
	{
		return SeparatorName;
	}
	static public String getFooterBlockNamingConvention()
	{
		return FooterName;
	}
	static public String getDefaultAccSetting()
	{
		return DefaultAccSetting;
	}
	static public String getDefaultAccRightSetting()
	{
		return DefaultAccRightSetting;
	}
	static public String getTopToBottomSetting()
	{
		return TopToBottom;
	}
	static public String getWestenTextSetting()
	{
		return WestenText;
	}
	static public String getRowLayoutSetting()
	{
		return RowLayout;
	}
	static public String getTableCellLeftMargin()
	{
		return TableCellLeftMargin;
	}
	static public String getTableCellRightMargin()
	{
		return TableCellRightMargin;
	}
	static public String getTableCellTopMargin()
	{
		return TableCellTopMargin;
	}
	static public String getTableCellBottomMargin()
	{
		return TableCellBottomMargin;
	}
	static public String getInfoblockLeftMargin()
	{
		return InfoblockLeftMargin;
	}
	static public String getInfoblockRightMargin()
	{
		return InfoblockRightMargin;
	}
	static public String getInfoblockTopMargin()
	{
		return InfoblockTopMargin;
	}
	static public String getInfoblockBottomMargin()
	{
		return InfoblockBottomMargin;
	}
	static public String getInfoblockBottomMarginwithBlankRow()
	{
		return InfoblockBottomMarginwithBlankRow;
	}
	static public String getSummaryblockLeftMargin()
	{
		return SummaryblockLeftMargin;
	}
	static public String getSummaryblockRightMargin()
	{
		return SummaryblockRightMargin;
	}
	static public String getSummaryblockTopMargin()
	{
		return SummaryblockTopMargin;
	}
	static public String getSummaryblockBottomMargin()
	{
		return SummaryblockBottomMargin;
	}
	static public String getMasterPageDefaultSetting()
	{
		return MasterPageDefaultSetting;
	}
	static public String getRowLocation()
	{
		return RowLocation;
	}
	static public String getDefaultFontSize()
	{
		return DefaultFontSize;
	}
	static public String getDefaultFontFamily()
	{
		return DefaultFontFamily;
	}
	static public String getFormDefaultFontColor()
	{
		return FormDefaultFontColor;
	}
	static public String getSeparatorDefaultLineColor()
	{
		return SeparatorDefaultLineColor;
	}
	static public String getSeparatorDefaultFillColor()
	{
		return SeparatorDefaultFillColor;
	}
	static public String getFormTitleDefaultFontSize()
	{
		return FormTitleDefaultFontSize;
	}
	static public String getLogoHeight()
	{
		return LogoHeight;
	}
	static public String getLogoWidth()
	{
		return LogoWidth;
	}
	static public int getStandardFormTitleWidth()
	{
		return StandardFormTitleWidth;
	}
	static public int getStandardFormTitleHeight()
	{
		return StandardFormTitleHeight;
	}
	static public float getSepatatorDefaultHeight()
	{
		return SepatatorDefaultHeight;
	}

	static private String getLocationbyNamingConvention(String name)
	{
		if( name.length() < 3 )
			return null;
		String subThree = name.substring(0,3);
		if( subThree.equalsIgnoreCase(TableName))
			return TableLocation;
		if( subThree.equalsIgnoreCase(TableHeader))
			return HeaderLocation;
		if( subThree.equalsIgnoreCase(TableRow))
			return RowLocation;
		if( subThree.equalsIgnoreCase(BodyPageName))
			return BodyPageLocation;
		if( subThree.equalsIgnoreCase(MasterPageName))
			return MasterPageLocation;
		if( name.length() < 7 )
			return null;
		String subSeven = name.substring(0,7);
		if( subSeven.equalsIgnoreCase(infoBlockName))
			return infoblockLocation;
		if( subSeven.equalsIgnoreCase(freeBlockName))
			return freeblockLocation;
		if( subSeven.equalsIgnoreCase(summaryBlockName))
			return summaryblockLocation;
		return null;
	}
	
	static public String getNodeLocation(DefaultMutableTreeNode node)
	{
		if( node == null)
		{
			System.out.println("Input node is null");
			System.exit(0);
		}
		String location = null;
		TreeNode[] path = node.getPath();
		int size = path.length;
		for( int i = size - 1; i >= 0; i--)
		{
			String name = path[i].toString();
			location = getLocationbyNamingConvention(name);
			if( location == null)
				continue;
			else
				return location;
		}
		System.out.println("Not found!");
		return location;
	}
	
	static public boolean isHeaderCell(Node node)
	{
		if( node.getAttributes().getNamedItem("name") == null)
			return false;
		String name = node.getAttributes().getNamedItem("name").getNodeValue();
		if( name.substring(0,3).equalsIgnoreCase(TableHeader))
			return true;
		return false;
	}
}