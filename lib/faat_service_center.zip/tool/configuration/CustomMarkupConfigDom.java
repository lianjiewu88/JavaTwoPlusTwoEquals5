package configuration;

public class CustomMarkupConfigDom
{
	private static String CustomNodeName = "sapa1s";
	private static String PreDefinedNamesapce = "http://www.sap.com/a1s/cd/om/forms/config";
	private static String InfoBlockSubformNodeName = "infoblock";
	private static String TableSubformNodeName = "Table";
	private static String ConfigureAttrName = "configurable";
	private static String SummaryLabelNamingConvention = "lbl";
	private static String CopyAttributeName = "copyForCustomFields";
	private static String TableTargetWidthAttributeName = "tableTargetWidth";
	private static String HiddenSubform = "frmfloatfields";
	private static String fixedWidth = "fixedWidth";
	private static String DefaultAttrValue = "true";
	private static String TitleNodeName = "title";
	private static String LangAttrName = "lang";
	private static String LangDefaultValue = "en";
	private static String DefaultTitleValue = "";//"info block title";
	private static String DefaultFreeTitleValue = "";//"free text block title";
	private static String DefaultTableTitle = "";//"Table title";
	private static String InfoBlockItemNodeName = "InfoBlockItem";
	private static String FreeTextBlockSubformName = "FreeTextBlock";
	private static String FreeTextBlockItem = "FreeTextBlockItem";
	private static String DescriptionNodeName = "Description";
	private static String DefaultDescriptionValue = "";//"item description";
	private static String TableColumnNodeName = "TableColumn";
	private static String TableHeaderNodeName = "TableHeaderCell";
	private static String TableHeaderminiumWidth = "miniumWidth";
	private static String SummaryBlockSubformName = "SummaryBlock";
	private static String SummaryLabelName = "SummaryLabel";
	private static String FormTitleNodeName = "FormTitle";
	private static String TableDefaultMiniumWidth = "15mm";
	private static String TableRemarkFieldName = "TableRemarkCell";
	private static String InfoBlockDescriptionDefaultValue = "InfoBlock";
	private static String FreeTextBlockDescriptionDefaultValue = "FreeTextBlock";
	private static String SummaryBlockDescriptionDefaultValue = "SummaryBlock";
	private static String TableDescriptionDefaultValue = "Table";
	private static String EFEPPassedAttributeName = "EFE_Passed";
	public  static String TableTargetWidthType1 = "portraitA4";
	public  static String TableTargetWidthType2 = "portraitLetter";
	public  static String TableTargetWidthType3 = "landscapeA4";
	public  static String TableTargetWidthType4 = "landscapeLetter";
	public  static String PredefinedNamingConvention = "Predefined";
	public  static final int INVALID_TYPE = 0;
	public  static final int INFOBLOCK_SUBFORM = 1;
	public  static final int INFOBLOCK_FIELD = 2;
	public  static final int FREEBLOCK_SUBFORM = 3;
	public  static final int FREEBLOCK_FIELD = 4;
	public  static final int TABLE_SUBFORM = 5;
	public  static final int TABLE_HEADER_SUBFORM = 6;
	public  static final int TABLE_HEADER_FIELD = 7;
	public  static final int REMARK_FIELD = 8;
	public  static final int REMARK_SUBFORM = 9;
	public  static final int SUMM_LABEL = 10;
	public  static final int SUMM_SUBFORM = 11;
	public  static final int FORM_TITLE = 12;
	public  static final boolean checkDuplicateA1SNode = true;

	static public String type2Name(int type)
	{
		String Name = null;
		switch ( type)
		{
			case INVALID_TYPE:
				Name = "INVALID TYPE";
				break;
			case INFOBLOCK_SUBFORM:
				Name = "INFOBLOCK SUBFORM";
				break;
			case INFOBLOCK_FIELD:
				Name = "INFOBLOCK FIELD";
				break;
			case FREEBLOCK_SUBFORM:
				Name = "FREEBLOCK SUBFORM";
				break;
			case FREEBLOCK_FIELD:
				Name = "FREEBLOCK FIELD";
				break;
			case TABLE_SUBFORM:
				Name = "TABLE SUBFORM";
				break;
			case TABLE_HEADER_SUBFORM:
				Name = "TABLE HEADER SUBFORM";
				break;
			case TABLE_HEADER_FIELD:
				Name = "TABLE HEADER FIELD";
				break;
			case REMARK_FIELD:
				Name = "REMARK ROW FIELD";
				break;
			case REMARK_SUBFORM:
				Name = "REMARK SUBFORM";
				break;
			case SUMM_LABEL:
				Name = "SUMMARY BLOCK LABEL FIELD";
				break;
			case SUMM_SUBFORM:
				Name = "SUMMARY BLOCK SUBFORM";
				break;
			default:
				Name = "UNKNOWN TYPE";
		}
		return Name;
	}
	static public String getCustomNodeName()
	{
		return CustomNodeName;
	}
	static public String getTableTargetWidthAttributeName()
	{
		return TableTargetWidthAttributeName;
	}
	static public String getHiddenSubformNamingConvention()
	{
		return HiddenSubform;
	}
	static public String getTableDescriptionDefaultValue()
	{
		return TableDescriptionDefaultValue;
	}
	static public String getEFEPPassedAttributeName()
	{
		return EFEPPassedAttributeName;
	}
	static public String getFormTitleNodeName()
	{
		return FormTitleNodeName;
	}
	static public String getSummaryBlockNamingConvention()
	{
		return SummaryLabelNamingConvention;
	}
	static public String getSummaryBlockDescriptionDefaultValue()
	{
		return SummaryBlockDescriptionDefaultValue;
	}
	static public String getInfoBlockDescriptionDefaultValue()
	{
		return InfoBlockDescriptionDefaultValue;
	}
	static public String getFreeTextBlockDescriptionDefaultValue()
	{
		return FreeTextBlockDescriptionDefaultValue;
	}
	static public String getTableminiumWidthNodeName()
	{
		return TableHeaderminiumWidth;
	}
	static public String getTableDefaultWidth()
	{
		return TableTargetWidthType1;
	}
	static public String getSummaryBlockSubformName()
	{
		return SummaryBlockSubformName;
	}
	static public String getSummaryLabelName()
	{
		return SummaryLabelName;
	}
	static public String getfixedWidthAttributeName()
	{
		return fixedWidth;
	}
	static public String getCopyAttributeName()
	{
		return CopyAttributeName;
	}
	static public String getTableRemarkFieldName()
	{
		return TableRemarkFieldName;
	}
	static public String getTableDefaultMiniumWidth()
	{
		return TableDefaultMiniumWidth;
	}
	static public String getTableHeaderNodeName()
	{
		return TableHeaderNodeName;
	}
	static public String getFreeTextBlockSubformNodeName()
	{
		return FreeTextBlockSubformName;
	}
	static public String getFreeTextItem()
	{
		return FreeTextBlockItem;
	}
	static public String getDefaultFreeTitle()
	{
		return DefaultFreeTitleValue;
	}
	static public String getDefaultTableTitle()
	{
		return DefaultTableTitle;
	}
	static public String getTableSubformNodeName()
	{
		return TableSubformNodeName;
	}
	static public String getTableColumnNodeName()
	{
		return TableColumnNodeName;
	}
	static public String getPreDefinedNamesapce()
	{
		return PreDefinedNamesapce;
	}
	
	static public String getInfoBlockSubformNodeName()
	{
		return InfoBlockSubformNodeName;
	}
	static public String getConfigureAttrName()
	{
		return ConfigureAttrName;
	}
	static public String getDefaultAttrValue()
	{
		return DefaultAttrValue;
	}
	static public String getTitleNodeName()
	{
		return TitleNodeName;
	}
	static public String getLangAttrName()
	{
		return LangAttrName;
	}
	static public String getLangDefaultValue()
	{
		return LangDefaultValue;
	}
	static public String getDefaultTitleValue()
	{
		return DefaultTitleValue;
	}
	static public String getInfoBlockItemNodeName()
	{
		return InfoBlockItemNodeName;
	}
	static public String getDescriptionNodeName()
	{
		return DescriptionNodeName;
	}
	static public String getDefaultDescriptionValue()
	{
		return DefaultDescriptionValue;
	}
	
	
}