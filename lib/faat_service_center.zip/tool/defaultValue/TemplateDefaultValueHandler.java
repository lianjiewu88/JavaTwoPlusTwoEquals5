package defaultValue;

import utilities.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class TemplateDefaultValueHandler
{
	private DocumentBuilderFactory domfac;

	private DocumentBuilder dombuilder;

	private FileCopyFactory filecopy;

	private Document doc;
	
	private Element root;
	
	private String templatePath = null;
	
	private DefaultListModel ListMode = null;
	
	private JList jList = null;
	
	
	public TemplateDefaultValueHandler(String path)
	{
		domfac = DocumentBuilderFactory.newInstance();
		templatePath = path;
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}

	public void SetJlistMode(JList list,DefaultListModel mode)
	{
		jList = list;
		ListMode = mode;
		ListMode.clear();
		jList.setModel(ListMode);
	}
	private void WriteJList(String data)
	{
		ListMode.addElement(data);
		ListMode.addElement("\n");
	}
	public Element getRoot()
	{
		return root;
	}

	private void traverse(Node node)
	{
		NodeList child = node.getChildNodes();
		int childNumber = child.getLength();
		Node item = null;
		for( int i = 0 ;i < childNumber; i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				traverse(item);
			}
			else if ( item.getNodeName().equals("field"))
			{
				DeleteFieldDefaultValue(item);
			}
			else if (item.getNodeName().equals("pageSet")) 
			{
				NodeList masterChild = item.getChildNodes();
				Node masterPageitem = null;
				int masterChildLength = masterChild.getLength();
				for (int j = 0; j < masterChildLength; j++) 
				{
					masterPageitem = masterChild.item(j);
					if (masterPageitem.getNodeName().equals("pageArea"))
					{
						traversePageArea(masterPageitem);
					}
				}
			}
		}
	}
	private void traversePageArea(Node PageArea) 
	{
		NodeList child = PageArea.getChildNodes();
		Node item = null;
		System.out.println("Traverse pageArea:");
		int childLength = child.getLength();
		for (int i = 0; i < childLength; i++) 
		{
			item = child.item(i);
			// Should take subform set into consideration
			if ((item.getNodeName().equals("subform"))
					|| (item.getNodeName().equals("subformSet"))) 
			{
				traverse(item);
			} 
			else if (item.getNodeName().equals("field")) 
			{
				DeleteFieldDefaultValue(item);
			} 
		}
	}
	
	private String getAttributeValue(String AttrName,Node node)
	{
		if( node.getAttributes() == null)
			return null;
		if( node.getAttributes().getNamedItem(AttrName) == null)
			return null;
		return node.getAttributes().getNamedItem(AttrName).getNodeValue();
	}
	
	private void DeleteFieldDefaultValue(Node node)
	{
		String data = null;
		Node value = getNodebyRoot("value",node);
		if( value == null)
			return;
		Node text = getNodebyRoot("text",value);
		if( text != null)
		{
			data = "Deleting Text Node: " + getAttributeValue("name",node) + "'s default value!";
			node.removeChild(value);
		}
		else
		{
			text = getNodebyRoot("decimal",value);
			if( text != null)
			{
				if( text.getTextContent().length() == 0)
					return;
				data = "Deleting Decimal Node: " + getAttributeValue("name",node) + "'s default value!";
				text.setTextContent("");
			}
		}
		System.out.println(data);
		WriteJList(data);
	}
	// main logic here
	public void StartDeleting()
	{
		LoadTemplateFile(templatePath);
		System.out.println("Load Template Successfully!");
		root = doc.getDocumentElement();
		Node templateNode = getNodebyRoot("template",root);
		if( templateNode == null )
			return;
		traverse(templateNode);
	}
	
	private Node getNodebyRoot(String subNodeName,Node root)
	{
		if( root == null)
			return root;
		NodeList child = root.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals(subNodeName))
				return item;
		}
		return null;
	}

	private String FormatSavePath(String path)
	{
		int index = path.lastIndexOf('.');
		if( index != -1)
			return path;
		String newPath = path + ".xdp";
		return newPath;
	}
	
	public String SaveAs(String path)
	{
		String formattedPath = FormatSavePath(path);
		File newFile = new File(formattedPath);
		if( newFile.exists())
			return null;
		try
		{   
             TransformerFactory tff = TransformerFactory.newInstance();   
             Transformer tf = tff.newTransformer();   
             DOMSource source = new DOMSource(doc);
             File newXDPFile = new File(formattedPath);
             StreamResult rs = new StreamResult(newXDPFile);
             tf.transform(source,rs);  
             tf.reset();
              
		}
		catch(Exception   e1)
		{
			e1.printStackTrace();   
        }  
		return path;
	}

	public void LoadTemplateFile(String inputXDPName)
	{
		try 
		{
			filecopy = new FileCopyFactory();
			String OutputXMLFile = filecopy.copyFile(inputXDPName);
			if (OutputXMLFile == null)
				return;
			InputStream inputXML = new FileInputStream(OutputXMLFile);
			doc = dombuilder.parse(inputXML);
			root = doc.getDocumentElement();
			// but only template DOM is our concern...
			filecopy.DeleteUnusedXML(OutputXMLFile);
		}

		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
	
	}
}