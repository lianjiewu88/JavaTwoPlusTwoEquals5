package help;

import java.io.IOException;

public class AboutExcelFormat
{
	public void display()
	{
		try 
		{
			Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " 
					 + "ExcelFormat.doc");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}