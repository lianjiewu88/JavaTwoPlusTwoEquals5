package help;

import java.io.IOException;

public class AboutMockupTool
{
	public void display()
	{
		try 
		{
			Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler mockupTool.doc");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}