package help;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import utilities.Tool;

public class SchemaParser
{
	private Document doc;
	private DocumentBuilder dombuilder;
	private DocumentBuilderFactory domfac;
	private Element root = null;
	private final String ELEMENT = "xsd:element";
	private final String COMPLEX_TYPE = "xsd:complexType";
	private final String SEQUENCE = "xsd:sequence";
	private final String GROUP = "xsd:group";
	private final String SIMPLE_TYPE = "xsd:simpleContent";
	private final String EXTENSION = "xsd:extension";
	private final String ATTRIBUTE = "xsd:attribute";
	private String rootNodeName = null;
	private String ErrorMessage = null;
	private Vector<Node> ComplexNodes = null;
	private Vector<Node> ExtensionNodes = null;
	// child, parent
	private Vector<String> CPRelationMap = null;
	private HashMap<String,String> TypeNameMap = null;
	// parent String name,parent Tree Node
	private HashMap<String,DefaultMutableTreeNode> TreeNodeMap = null;
	private DefaultTreeModel TreeMode = null;
	private DefaultMutableTreeNode rootTreeNode = null;

	public SchemaParser()
	{
		domfac = DocumentBuilderFactory.newInstance();
		ComplexNodes = new Vector<Node>();
		CPRelationMap = new Vector<String>();
		ExtensionNodes = new Vector<Node>();
		TypeNameMap = new HashMap<String,String>();
		TreeNodeMap = new HashMap<String,DefaultMutableTreeNode>();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}
	public String getErrorMessage()
	{
		return ErrorMessage;
	}
	
	public void stop()
	{
		System.exit(0);
	}
	
	private void FillComplexTypeNodes()
	{
		NodeList child = root.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals(COMPLEX_TYPE))
				ComplexNodes.add(item);
			if( item.getNodeName().equals(GROUP))
				ExtensionNodes.add(item);
		}
	}
	
	private void searchComplexNodebyName(String name)
	{
		Node item = null;
		int size = ComplexNodes.size();
		int index = -1;
		String subName = null;
		String ComplexTypeNodeName = null;
		for( int i = 0 ; i < size; i++)
		{
			item = ComplexNodes.elementAt(i);
			ComplexTypeNodeName = Tool.getAttributeValue("name",item);
			if( ComplexTypeNodeName == null)
				continue;
			if( !ComplexTypeNodeName.contains(name))
				continue;
			// search by Global
			index = ComplexTypeNodeName.indexOf("Global");
			if( index == -1)
			{
				TrySearchGDTType(item,name);
				continue;
			}
			index += 6;
			subName = ComplexTypeNodeName.substring(++index,ComplexTypeNodeName.length());
			//System.out.println("hello:" + subName);
			if( subName.equals(name))
			{
				/* found one!
				 * complexType->sequence->element
				 * 
				 */
				HandleChildren(name,item);
			}
		}
	}
	private Node searchComplexTypebyGDT(String GDT)
	{
		Node item = null;
		int size = ComplexNodes.size();
		String name = null;
		for( int i = 0 ; i < size;i++)
		{
			item = ComplexNodes.elementAt(i);
			name = Tool.getAttributeValue("name",item);
			if( name == null)
				continue;
			int index = name.lastIndexOf(".");
			if( index == -1)
				continue;
			name = name.substring(++index,name.length());
			if( name.equals(GDT))
				return item;
		}
		return null;
	}
	
	private void FillContentbySequence(Node sequence,String parentName)
	{
		String parent = TypeNameMap.get(parentName);
		String child = null;
		String type = null;
		NodeList children = sequence.getChildNodes();
		int size = children.getLength();
		Node item = null;
		String temp = parent;
		for( int i = 0 ; i < size; i++)
		{
			item = children.item(i);
			if( item.getNodeName().equals(ELEMENT))
			{
				child = Tool.getAttributeValue("name",item);
				if( child == null)
					continue;
				CPRelationMap.add(child + "%" + parent);
				System.out.println("Add child: " + child + " to Parent: " + parent + "in FillContentbySequence");
				if( child.equals("LastChangeDateTime"))
					System.out.println("here");
				type = Tool.getAttributeValue("type",item);
				type = getSearchNamebyType(type);
				temp = Tool.getAttributeValue("name",item);
				TypeNameMap.put(type,temp);
				Node complexType = searchComplexTypebyGDT(type);
				if( complexType == null)
					continue;
				Node simpleContent = Tool.getNodebyRoot(SIMPLE_TYPE,complexType);
				if( simpleContent == null)
				{
					FillSequence(type);
					continue;
				}
				Node ext = Tool.getNodebyRoot(EXTENSION,simpleContent);
				if( ext == null)
					return;
				FillContent(ext,temp);
			}
		}
	}
	private void FillSequence(String ParentName)
	{
		Node complexType = searchComplexTypebyGDT(ParentName);
		if( complexType == null)
			return;
		Node sequence = Tool.getNodebyRoot(SEQUENCE,complexType);
		if( sequence == null)
			return;
		FillContentbySequence(sequence,ParentName);
	}
	private void TrySearchGDTType(Node node,String GDTName)
	{
		String name = Tool.getAttributeValue("name",node);
		if( name == null)
			return;
		int index = name.lastIndexOf(".");
		if( index == -1)
			return;
		String subName = name.substring(++index,name.length());
		if( !subName.equals(GDTName))
			return;
		// found the complex node , from there we can have attribute
		Node simpleContent = Tool.getNodebyRoot(SIMPLE_TYPE,node);
		if( simpleContent == null)
		{
			Node sequence = Tool.getNodebyRoot(SEQUENCE,node);
			if( sequence != null)
				FillContentbySequence(sequence,GDTName);
			return;
		}
		Node extension = Tool.getNodebyRoot(EXTENSION,simpleContent);
		if( extension == null)
			return;
		String parentName = TypeNameMap.get(GDTName);
		FillContent(extension,parentName);
	}

	// add the content attribute to the node, node should be 
	// complexType->SimpleContent->xsd:Extension
	// there are two kinds of content in the base attribute
	private void FillContent(Node ext,String parentName)
	{
		String base = Tool.getAttributeValue("base",ext);
		if( base == null)
			return;
		String subName = "content";
		Node item = null;
		System.out.println("Add child: " + subName + " to Parent: " + parentName + " in FillContent");
		CPRelationMap.add(subName + "%" + parentName);
		NodeList child = ext.getChildNodes();
		int size = child.getLength();
		for( int j = 0;j < size;j++)
		{
			item = child.item(j);
			if( !item.getNodeName().equals(ATTRIBUTE))
				continue;
			System.out.println("Add child: " + Tool.getAttributeValue("name",item) + " to Parent: " + parentName + "in FillContent");
			CPRelationMap.add(Tool.getAttributeValue("name",item) + "%" + parentName);
		}
	}
	
	private void HandleWithExtendedField(Node extGroup,String parentName)
	{
		String ref = Tool.getAttributeValue("ref",extGroup);
		if( ref == null)
			return;
		int index = ref.lastIndexOf(".");
		if( index == -1)
			return;
		String childName = ref.substring(++index,ref.length());
		System.out.println("Add child: " + childName + " to Parent: " + parentName + " in HandleWithExtendedField");
		CPRelationMap.add(childName + "%" + parentName);
		// should check if there is still sub attribute of that extension field
		SearchAttributeForExtendedField(childName);
	}
	
	// input such as ext_putaway_id
	private void SearchAttributeForExtendedField( String extensionName)
	{
		// search the extensionName in the xsd:groups nodes
		String type = getExtensionNodeDataType(extensionName);
		if( type == null)
			return;
		// search the complex nodes by type
		int size = ComplexNodes.size();
		Node node = null;
		Node item = null;
		for( int i = 0 ; i < size; i++)
		{
			item = ComplexNodes.elementAt(i);
			if( Tool.getAttributeValue("name",item).contains(type))
			{
				node = ComplexNodes.elementAt(i);
				break;
			}
		}
		if( node == null)
			return;
		// begin to fill all the attribute to the extended field
		// should put xsd:extension into the function
		Node simpleContent = Tool.getNodebyRoot(SIMPLE_TYPE,node);
		Node ext = Tool.getNodebyRoot(EXTENSION,simpleContent);
		if( ext == null)
			return;
		FillContent(ext,extensionName);
	}
	
	private String getExtensionNodeDataType(String extensionName)
	{
		int size = ExtensionNodes.size();
		Node node = null;
		Node item = null;
		for( int i = 0 ; i < size;i++)
		{
			item = ExtensionNodes.elementAt(i);
			if( !Tool.getAttributeValue("name",item).contains(extensionName))
				continue;
			node = ExtensionNodes.elementAt(i);
			break;
		}
		if( node == null)
			return null;
		Node sequence = Tool.getNodebyRoot(SEQUENCE,node);
		if( sequence == null)
			return null;
		Node element = Tool.getNodebyRoot(ELEMENT,sequence);
		if( element == null)
			return null;
		String type = Tool.getAttributeValue("type",element);
		if( type == null)
			return null;
		int index = type.lastIndexOf(".");
		if( index == -1)
			return null;
		return type.substring(++index,type.length());
	}
	
	private void FillSimpleType(String GDT)
	{
		Node complexType = searchComplexTypebyGDT(GDT);
		if( complexType == null)
			return;
		Node simpleContent = Tool.getNodebyRoot(SIMPLE_TYPE,complexType);
		if( simpleContent == null)
			return;
		Node ext = Tool.getNodebyRoot(EXTENSION,simpleContent);
		if( ext == null)
			return;
		FillContent(ext,TypeNameMap.get(GDT));
		
	}
	private void HandleChildren(String parentName,Node parentNode)
	{
		String childName = null;
		String searchName = null;
		Node sequence = Tool.getNodebyRoot(SEQUENCE,parentNode);
		if( sequence == null)
		{
			System.out.println("type: " + parentName + " FieldName : " + TypeNameMap.get(parentName));
			FillSimpleType(parentName);
			return;
		}
		NodeList child = sequence.getChildNodes();
		int size = child.getLength();
		Node item = null;
		for( int i = 0 ; i < size; i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals(ELEMENT) && !item.getNodeName().equals(GROUP))
				continue;
			if( item.getNodeName().equals(GROUP))
			{
				HandleWithExtendedField(item,TypeNameMap.get(parentName));
				continue;
			}
			childName = Tool.getAttributeValue("name",item);
			if( childName == null)
				continue;
			System.out.println("Add child: " + childName + " to Parent: " + TypeNameMap.get(parentName) + " in HandleChildren");
			if( childName.equals("LastChangeDateTime"))
				System.out.println("here");
			CPRelationMap.add(childName + "%" + TypeNameMap.get(parentName));
			/* new search should begin with the value after Global
			 * two alternatives
			 * sap.com.xi.AP.Common.GDT.BusinessTransactionDocumentID
			 * sap.com.xi.AP.LogisticsExecution.Global.
			 * FormProductionOrderNotificationProductionOrder
			 */
			String type = Tool.getAttributeValue("type",item);
			searchName = getSearchNamebyType(type);
			TypeNameMap.put(searchName,childName);
			searchComplexNodebyName(searchName);
		}
	}
	private String getSearchNamebyType(String path)
	{
		int index = path.indexOf("Global");
		if( index == -1)
		{
			return getTypebyGDT(path);
		}
		index += 6;
		return path.substring(++index,path.length());
	}
	
	private String getTypebyGDT(String path)
	{
		int index = path.indexOf("GDT");
		if( index == -1)
			return null;
		index += 3;
		return path.substring(++index, path.length());
	}
	
	public DefaultTreeModel getModel()
	{
		return TreeMode;
	}
	
	private boolean BuildTree()
	{
		int size = CPRelationMap.size();
		System.out.println("Size: " + size);
		System.out.println("Root: " + rootNodeName);
		for( int i = 0 ; i < size; i++)
		{
			//System.out.println("Path: " + CPRelationMap.elementAt(i));
			String[] Nodes = CPRelationMap.elementAt(i).toString().split("%");
			//System.out.println("Child: " + Nodes[0] );
			//System.out.println("Parent: " + Nodes[1] );
			if( Nodes[0].equals(Nodes[1]))
			{
				ErrorMessage = "Both Child and Parent Have the Same Name: " + Nodes[0];
				return false;
			}
			if( Nodes[1].equals("null"))
				Nodes[1] = rootNodeName;
			DefaultMutableTreeNode child = new DefaultMutableTreeNode(Nodes[0]);
			TreeNodeMap.put(Nodes[0],child);
			TreeNodeMap.get(Nodes[1]).add(child);
		}
		return true;
	}
	private String getXMLPath(String path)
	{
		int index = path.lastIndexOf(".");
		String XMLPath = path.substring(0,index);
		XMLPath += ".xml";
		// copy a temporary xml file meantime
		File in = new File(path);
		FileInputStream fis;
		try 
		{
			fis = new FileInputStream(in);
			FileOutputStream fos = new FileOutputStream(XMLPath);
			byte[] buf = new byte[1024];
			int i = 0;
			while((i = fis.read(buf))!=-1) 
				fos.write(buf, 0, i);
			fos.close();
			fis.close();
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return XMLPath;
	}
	private void DeleteTemporaryXMLFile(String path)
	{
		File temp = new File(path);
		temp.delete();
	}
	public boolean StartParse(String path)
	{
		try 
		{
			System.out.println("Parse File: " + path);
			String XMLPath = getXMLPath(path);
			InputStream inputXML = new FileInputStream(XMLPath);
			doc = dombuilder.parse(inputXML);
			root = doc.getDocumentElement();
			FillComplexTypeNodes();
			Node rootElement = Tool.getNodebyRoot(ELEMENT,root);
			if( rootElement == null)
				return false;
			rootNodeName = Tool.getAttributeValue("name",rootElement);
			rootTreeNode = new DefaultMutableTreeNode(rootNodeName);
			TreeNodeMap.put(rootNodeName,rootTreeNode);
			System.out.println("Begin to Search: " + rootNodeName);
			String type = Tool.getAttributeValue("type",rootElement);
			TreeMode = new DefaultTreeModel(rootTreeNode);
			searchComplexNodebyName(getSearchNamebyType(type));
			DeleteTemporaryXMLFile(XMLPath);
			return BuildTree();
		}
		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
		return false;
	}
}