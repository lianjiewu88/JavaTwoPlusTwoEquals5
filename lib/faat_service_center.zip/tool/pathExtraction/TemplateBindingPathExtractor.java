package pathExtraction;

import utilities.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class TemplateBindingPathExtractor
{
	private DocumentBuilderFactory domfac;

	private DocumentBuilder dombuilder;

	private FileCopyFactory filecopy;

	private Document doc;
	
	private Element root;
	
	private String SubformPath = null;
	
	private String backupSubformPath = null;
	
	//private HashMap<String,String> pathCollection = null;
	private Vector<String> pathCollection = null;
	
	private String RootPath = null;
	
	private JList jList = null;
	
	private Node rootMessageType = null;
	
	private DefaultListModel ListMode = null;
	
	private boolean isNestedSubformPathAvailable = false;
	
	private boolean isTableRootFound = false;
	
	private HashMap<Node,String> RelativePathMap = null;
	
	public TemplateBindingPathExtractor(JList list,DefaultListModel mode)
	{
		domfac = DocumentBuilderFactory.newInstance();
		jList = list;
		ListMode = mode;
		ListMode.clear();
		RelativePathMap = new HashMap<Node,String>();
		jList.setModel(ListMode);
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
			pathCollection = new Vector<String>();
		} 
		
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}
	
	private String FormatSaveTextPath(String path)
	{
		int index = path.lastIndexOf('.');
		if( index != -1)
			return path;
		String newPath = path + ".txt";
		return newPath;
	}
	public String SaveAsText(String path)
	{
		String formattedPath = FormatSaveTextPath(path);
		File newFile = new File(formattedPath);
		if( newFile.exists())
			return null;
		String item = null;
		String name = null;
		String bindingPath = null;
		int index = -1;
		try 
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(formattedPath));
			int size = pathCollection.size();
			for( int i = 0 ; i < size;i++)
			{
				item = pathCollection.elementAt(i);
				index = item.indexOf('%');
				name = item.substring(0,index);
				bindingPath = item.substring(++index,item.length());
				bw.newLine();
				bw.write(name);
				bw.newLine();
				bw.write(bindingPath);
				bw.newLine();
			}
			/*Iterator iterator = pathCollection.keySet().iterator(); 
			while(iterator.hasNext()) 
			{
				Object key = iterator.next();
				System.out.println("Field Name: " + key.toString());
				System.out.println("Field Path: " + pathCollection.get(key));
				bw.newLine();
				bw.write(key.toString());
				bw.newLine();
				bw.write(pathCollection.get(key));
				bw.newLine();
			}*/
			bw.flush();
			bw.close();
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
		return formattedPath;
	}
	public Vector<String> getPathCollection()
	{
		return pathCollection;
	}
	
	public String getRootPath()
	{
		return RootPath;
	}
	public Element getRoot()
	{
		return root;
	}
	
	private void AddRootElement()
	{
		Node connectionSet = Tool.getNodebyRoot("connectionSet",root);
		if( connectionSet == null)
			return;
		Node xsdConnection = Tool.getNodebyRoot("xsdConnection",connectionSet);
		if( xsdConnection == null)
			return;
		Node rootElement = Tool.getNodebyRoot("rootElement",xsdConnection);
		if( rootElement == null)
			return;
		RootPath = rootElement.getTextContent(); 
	}
	
	private String getElementFieldName(Node node)
	{
		Node caption = Tool.getNodebyRoot("caption",node);
		if( caption == null)
			return Tool.getAttributeValue("name",node);
		Node value = Tool.getNodebyRoot("value",caption);
		if( value == null)
			return Tool.getAttributeValue("name",node);
		Node text = Tool.getNodebyRoot("text",value);
		if( text == null)
			return "DefaultName";
		String TextValue = text.getTextContent();
		if( TextValue == null)
			return Tool.getAttributeValue("name",node);
		// filter out all the dummy value
		if( TextValue.equals("Date/Time Field") || TextValue.equals("Decimal Field")
				 || TextValue.equals("Text Field") || TextValue.equals("Caption:"))
			return Tool.getAttributeValue("name",node);
		return TextValue;
	}
	
	private String RemoveSelectionCode(String path)
	{
		int index = path.indexOf("[");
		if( index == -1)
		// no [ occurrance
			return path;
		int rightIndex = path.indexOf("]");
		if( rightIndex == -1)
		{
			System.out.println("Invalid Mapping Path!");
			System.exit(0);
		}
		String sub = path.substring(++index,rightIndex);
		System.out.println("Sub: " + sub);
		if( sub.equals("*") )
		// table mapping, this is feasible
			return path;
		/* should remove condition :
		 * DunningItem.[DueItemTypeCode == "1"].BaseBusinessTransactionDocumentReference.ID
		 * DunningItem.BaseBusinessTransactionDocumentReference.ID
		 */
		index--;
		sub = path.substring(0,--index) + path.substring(++rightIndex,path.length());
		System.out.println("After removing selection code,the Sub: " + sub);
		return sub;
	}
	private void traverse(Node node)
	{
		printNodeName(node);
		NodeList child = node.getChildNodes();
		int childNumber = child.getLength();
		Node item = null;
		String path = null;
		String fieldName = null;
		for( int i = 0 ;i < childNumber; i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("subform") || item.getNodeName().equals("subformSet"))
			{
				printNodeName(item);
				appendNestedSubformBinding(item);
				traverse(item);
			}
			else if ( item.getNodeName().equals("field"))
			{
				printNodeName(item);
				path = getElementBindingInfo(item);
				fieldName = getElementFieldName(item);
				if( path != null)
				{
					path = FormatPathForDisplay(path);
					path = RemoveSelectionCode(path);
					pathCollection.add(fieldName + "%" + path);
					System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!");
					System.out.println("Name: " + fieldName);
					System.out.println("Path: " + path);
				}
			}
			else if ( item.getNodeName().equals("pageSet"))
				getMasterPageBindingInfo(item);
		}
		if( !Tool.isFieldHidden(node))
			BackTraceSubformPath(node);
		
	}
	
	private Node getPriorNode(Node node)
	{
		Node prior = node.getPreviousSibling();
		while( prior != null)
		{
			if( prior.getNodeName().equals("subform"))
				return prior;
			prior = prior.getPreviousSibling();
		}
		return null;
	}
	
	private boolean isFirstChild(Node node)
	{
		if( getPriorNode(node) == null)
			return true;
		return false;
	}
	private void appendNestedSubformBinding(Node node)
	{
		String nestedPath = getElementBindingInfo(node);
		// add March,20,2008: ignore those hidden subform which has no binding path
		if(( nestedPath == null ) && ( Tool.isFieldHidden(node)))
			return;
		if( nestedPath == null)
		{
			if( isFirstChild(node))
				RelativePathMap.put(node,SubformPath);
			return;
		}
		if( SubformPath == null || nestedPath.contains("$record")) // table root node
		{
			SubformPath = nestedPath;
			return;
		}
		//  $record.FormQuote.Item[*] +  $.PriceAndTax.PriceComponent[*]
		if( !nestedPath.contains("$."))
			nestedPath = "$." + nestedPath;
		isNestedSubformPathAvailable = true;
		backupSubformPath = SubformPath;
		// it is a big issue of how to get SubformPath correctly
		Node prior = getPriorNode(node);
		if( prior == null)
		{
			SubformPath += nestedPath.substring(1,nestedPath.length());
			RelativePathMap.put(node,backupSubformPath);
		}
		else
		{
			String SiblingPath = RelativePathMap.get(prior);
			if( SiblingPath == null)
			{
				String name = prior.getAttributes().getNamedItem("name").getNodeValue();
				System.out.println("SiblingPath Empty,Sibling Node: " + name);
				/* add in 2008-3-14
				 * If still empty, move back to use its parent's mapping path instead
				 * risk here: the parent node may still use RELATIVE MAPPING PATH
				 *  
				 */
				SiblingPath = getElementBindingInfo(node.getParentNode());
				if( SiblingPath == null)
				{
					System.out.println("Parent Node: " + node.getParentNode().getAttributes().getNamedItem("name").getNodeValue() + " 's mapping path also empty!");
					System.exit(0);
				}
			}
			SubformPath = SiblingPath;
			SubformPath += nestedPath.substring(1,nestedPath.length());
			RelativePathMap.put(node,SiblingPath);
		}
		if( SubformPath.equals("$record.FormQuote.Item[*].$record.FormQuote.PriceAndTax.PriceComponent[*]"))
			System.out.println("here");
		System.out.println("Current Subform Parent Path Changed from: " + backupSubformPath + " to:"  + SubformPath);
		System.out.println();
	}
	
	/*private boolean isLastFieldTobeHandled(Node node)
	{
		Node next = node.getNextSibling();
		while( next != null)
		{
			if( next.getNodeName().equals("field"))
			{
				// check if it has mapping path
				System.out.println("Name: " + getNodeName(next));
				Node bind = getNodebyRoot("bind",next);
				if( bind == null)
				{
					next = next.getNextSibling();
					continue;
				}
				if ( bind.getAttributes().getNamedItem("ref") != null)
					return false;
				// none binding field,ignore it and start checking of next field
				next = next.getNextSibling();
			}
			else if( next.getNodeName().equals("subform"))
			{
				if( isFieldHidden(next))
					return false;
				next = next.getNextSibling();
			}
			else 
				next = next.getNextSibling();
		}
		return true;
	}*/
	
	private void BackTraceSubformPath(Node node)
	{
		//System.out.println("*************************************");
		//System.out.println("is Nested Subform Path Available? " +isNestedSubformPathAvailable);
		//System.out.println("is this the last field to be handled? " + isLastFieldTobeHandled(node));
		if( isNestedSubformPathAvailable ) //&& isLastFieldTobeHandled(node))
		{
			SubformPath = backupSubformPath;
			isNestedSubformPathAvailable = false;
			return;
		}
		//System.out.println("Current Subform Path: " + SubformPath);
	}
	
	private void WriteJList(String data)
	{
		ListMode.addElement(data);
		ListMode.addElement("\n");
	}
	private void setAdobeDesignerTableRoot(String path)
	{
		String star = "[*]";
		if( !path.contains(star))
			return;
		int index = path.indexOf(star);
		index += star.length();
		SubformPath = path.substring(0,index);
		System.out.println("Table Root: " + SubformPath);
		isTableRootFound = true;
	}
	/* example: 
	 * $record.PurchasingContract.Item[*].PriceSpecificationElement.[*]
	 * .ScaleLine[*].ScaleAxisStep.Quantity
	 * Remove ".[*]"
	 */
	private String removeDuplicateSlash(String path)
	{
		String duplicateslash = ".[*]";
		int index = path.indexOf(duplicateslash);
		if( index == -1)
			return path;
		path = path.substring(0,index) + path.substring(++index,path.length());
		System.out.println("Formatted Path:" + path);
		return path;
	}
	/* /ns1:FormPurchasingContractNotification/PurchasingContract
	 * /Item/PriceSpecificationElement//Rate/DecimalValue
	 * PriceSpecificationElement.[*].ScaleLine[*].ScaleAxisStep.Quantity
	 */
	private void CheckPathCollection()
	{
		String data = null;
		String bindingPath = null;
		String name = null;
		int index = -1;
		int size = pathCollection.size();
		Vector<String> temp = new Vector<String>();
		for( int i = 0 ; i < size;i++)
		{
			data = pathCollection.elementAt(i);
			index = data.indexOf('%');
			name = data.substring(0,index);
			System.out.println("Name: " + name);
			bindingPath = data.substring(++index,data.length());
			// find the root table item mapping path
			if( isTableRootFound == false )
				setAdobeDesignerTableRoot(bindingPath);
			bindingPath = removeDuplicateSlash(bindingPath);
			data = name + "%" + bindingPath;
			if( !bindingPath.contains("$record"))
			{
				data = name + "%" + SubformPath + "." + bindingPath;
				System.out.println("Data: "+ data);
			}
			temp.add(data);
		}
		pathCollection.clear();
		pathCollection = (Vector<String>) temp.clone();
		temp.clear();
		for( int j = 0 ; j < temp.size();j++)
		{
			System.out.println("In TemplateBindingProcessor: " + temp.elementAt(j));
		}
	}
	// test function
	private void PrintPathCollection()
	{
		String data = null;
		String bindingPath = null;
		int index = -1;
		/*
		Iterator iterator = pathCollection.keySet().iterator(); 
		while(iterator.hasNext()) 
		{
			Object key = iterator.next();
			data = "Path: " + pathCollection.get(key);
			WriteJList(data);
		}*/
		int size = pathCollection.size();
		for( int i = 0 ; i < size;i++)
		{
			data = pathCollection.elementAt(i);
			index = data.indexOf('%');
			bindingPath = data.substring(++index,data.length());
			data = "Path: " + bindingPath;
			WriteJList(data);
		}
	}
	// test function
	private String getNodeName(Node node)
	{
		if( node.getAttributes() == null)
			return null;
		if( node.getAttributes().getNamedItem("name") == null)
			return null;
		return node.getAttributes().getNamedItem("name").getNodeValue();
	}
	// test function
	private void printNodeName(Node node)
	{
		/*String name = getNodeName(node);
		if( name != null)
			System.out.println("Traverse Node: " + name);
			*/
	}
	private String FormatPathForDisplay(String path)
	{
		int index = path.indexOf("$record");
		if( index != -1)
			return path;	// already a absolute path
		index = path.indexOf("$.");
		// suppose that it is impossibe to have an absolute path
		// within a relative bound field
		if( index == -1)
		{
			path = SubformPath + "." + path;
			return path;
		}
		path = SubformPath + "." + path.substring(index+2,path.length());
		System.out.println("Path: " + path);
		return path;
	}
	private String getElementBindingInfo(Node node)
	{
		String bindingPath = null;
		Node BindNode = Tool.getNodebyRoot("bind",node);
		if( BindNode == null)
			return null;
		else
		{
			if( BindNode.getAttributes().getNamedItem("ref") == null)
			// none binding
				return null;
			else
			{
				bindingPath = BindNode.getAttributes().getNamedItem("ref").getNodeValue();
				System.out.println("Node: " + getNodeName(node) + " path: " + bindingPath);
				return removePossibleCondition(bindingPath);
			}
		}
		
	}
	// Some form in CRM has condition decision in mapping path such as
	// $record.ServiceOrder.TextCollection.Text.(TypeCode.value == "10006")
	private String removePossibleCondition(String path)
	{
		int index = path.indexOf('(');
		if( index == -1)
			return path;
		String newPath = path.substring(0,--index) + "[*]";
		return newPath;
	}
	private void getMasterPageBindingInfo(Node item)
	{
		NodeList masterChild = item.getChildNodes();
		Node masterPageitem = null;
		int masterChildLength = masterChild.getLength();
		for (int j = 0; j < masterChildLength; j++) 
		{
			masterPageitem = masterChild.item(j);
			if (masterPageitem.getNodeName().equals("pageArea"))
			{
				traverse(masterPageitem);
				// only handle with the first master page to avoid
				// multi-extracting
				return;
			}
		}
	}

	public Node getMessageTypeRoot()
	{
		return rootMessageType;
	}
	// main logic here
	public void StartExtracting(String path)
	{
		LoadTemplateFile(path);
		System.out.println("Load Template Successfully!");
		root = doc.getDocumentElement();
		Node templateNode = Tool.getNodebyRoot("template",root);
		if( templateNode == null )
			return;
		Node datasets = Tool.getNodebyRoot("xfa:datasets",root);
		if( datasets == null)
			return;
		rootMessageType = Tool.getNodebyRoot("dd:dataDescription",datasets);
		traverse(templateNode);
		CheckPathCollection();
		PrintPathCollection();
		AddRootElement();
	}
	

	private String FormatSavePath(String path)
	{
		int index = path.lastIndexOf('.');
		if( index != -1)
			return path;
		String newPath = path + ".xdp";
		return newPath;
	}
	
	public String SaveAs(String path)
	{
		String formattedPath = FormatSavePath(path);
		File newFile = new File(formattedPath);
		if( newFile.exists())
			return null;
		try
		{   
             TransformerFactory tff = TransformerFactory.newInstance();   
             Transformer tf = tff.newTransformer();   
             DOMSource source = new DOMSource(doc);
             File newXDPFile = new File(formattedPath);
             StreamResult rs = new StreamResult(newXDPFile);
             tf.transform(source,rs);  
             tf.reset();
              
		}
		catch(Exception   e1)
		{
			e1.printStackTrace();   
        }  
		return path;
	}

	public void LoadTemplateFile(String inputXDPName)
	{
		try 
		{
			filecopy = new FileCopyFactory();
			String OutputXMLFile = filecopy.copyFile(inputXDPName);
			if (OutputXMLFile == null)
				return;
			InputStream inputXML = new FileInputStream(OutputXMLFile);
			doc = dombuilder.parse(inputXML);
			root = doc.getDocumentElement();
			// but only template DOM is our concern...
			filecopy.DeleteUnusedXML(OutputXMLFile);
		}

		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
	
	}
}