package pathExtraction;

import java.util.Vector;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import utilities.Tool;

public class pathChecker
{
	private Node root = null;
	private Node X2Map = null;
	private String rootElement = null;
	private Vector<String> errorPath = null;
	public pathChecker(Node node,Node x2Map)
	{
		root = node;
		X2Map = x2Map;
		errorPath = new Vector<String>();
	}
	
	private boolean getRootElement()
	{
		// FormBillOfExchangeReceivableIssueRequest
		rootElement = Tool.getAttributeValue("x2:RootElement",X2Map);
		root = Tool.getNodebyRoot(rootElement,root);
		System.out.println("Root: " + root.getNodeName());
		if( root == null)
		{
			Tool.ErrorReport("Can not find Root Node for MessageType: " + rootElement);
			return false;
		}
		return true;
	}
	public Vector<String> startCheck()
	{
		if( !getRootElement())
			return null;
		NodeList child = X2Map.getChildNodes();
		int size = child.getLength();
		Node item = null;
		String path = null;
		for( int i = 0 ; i < size;i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("x2:Entry"))
				continue;
			path = Tool.getNodebyRoot("x2:XPath",item).getTextContent();
			checkPath(path);
			
		}
		return errorPath;
	}
	/* input : /ns1:FormBillOfExchangeReceivableIssueRequest
	 * /BillOfExchangeReceivable/IssueCityName
	 * root : FormBillOfExchangeReceivableIssueRequest
	 * i:0 Path:
	   i:1 Path:ns1:FormBillOfExchangeReceivableIssueRequest
       i:2 Path:BillOfExchangeReceivable
       i:3 Path:IssueCityName
       so can start from i:2. To gain effificency, we can even start from i:3
	 */
	
	private void checkPath(String path)
	{
		System.out.println("Path1111111" + path);
		String temp = "/ns1:FormPurchasingContractNotification/PurchasingContract/Item/PriceSpecificationElement//Rate/DecimalValue";
		if( path.equals(temp))
			System.out.println("here");
		String[] pathCollection = path.split("/");
		Node parent = null;
		Node child = null;
		/*
		for( int i = 2 ; i < pathCollection.length;i++)
		{
			System.out.println("i:" + i  + " Path:" + pathCollection[i]);
		}*/
		int i = 2;
		parent = root;
		while( i < pathCollection.length)
		{
			if( pathCollection[i].length() == 0)
			{
				i++;
				continue;
			}
			System.out.println("Try to find node: " + 
		pathCollection[i] + " from parent: " + parent.getNodeName());
			if( pathCollection[i].charAt(0) == '@')
			{
				String attri = pathCollection[i].substring(1,pathCollection[i].length());
				System.out.println("Try to find Attribute: " + attri);
				if( parent.getAttributes().getNamedItem(attri) == null)
				{
					Tool.ErrorReport("there is something wrong with mapping path: " + path);
					errorPath.add(path);
					// 2008-05-06 execute here
					// System.exit(0);
				}
				return;
			}
			child = Tool.getNodebyRoot(pathCollection[i],parent);
			if( child == null)
			{
				Tool.ErrorReport("there is something wrong with mapping path: " + path);
				errorPath.add(path);
				return;
			}
			parent = child;
			System.out.println("Found Child: " + pathCollection[i]);
			i++;
		}
	}
}