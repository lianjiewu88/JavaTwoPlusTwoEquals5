package pathExtraction;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import utilities.Tool;

public class PathTransformerForExcel
{
	private Vector<String> templatePathCollection = null;
	
	private Vector<String> tableNodesCollection = null;
	
	private Vector<Node> ExcelRowInstance = null;
	
	private HashMap<Node,Node> X2EntryCell = null;
	
	private String RootPath = null;	// get from form template
	
	private String ExcelRootElement = null;
	
	private String BindingWorkSheetName = null;
	
	private String fieldName = null;
	
	private String WrapTextStyle = null;
	
	// default row height
	private String defaultRowHeight = "28";
	
	private DocumentBuilderFactory domfac;

	private DocumentBuilder dombuilder;

	private Document doc;
	
	private Element root;
	
	private Node x2Map = null;
	
	private Node StyleIDNode = null;
	
	private Node x2Schema = null;
	
	private Node TableNode = null;
	
	private Node rootMessageType = null;
	
	private int x2EntryID = 1;
	
	private int ColumnIndex = 3;
	
	// start row in the excel
	private int RowIndex = 13;
	
	// can display excel node path is debug is on
	private boolean isDebugModeOn = false;
	
	private final int ABSOLUTE_PATH_NONE_UNIT = 1;
	
	private final int ABSOLUTE_PATH_UNIT = 2;
	
	private final int RELATIVE_PATH_NONE_UNIT = 3;
	
	private final int RELATIVE_PATH_UNIT = 4;
	
	private final int TABLE_NODE = 5;
	
	private final int SINGLE_NODE = 6;
	
	private final String ERROR_PATH = "s999";
	
	public PathTransformerForExcel(Vector<String> path,String rootPath)
	{
		domfac = DocumentBuilderFactory.newInstance();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
			templatePathCollection = path;
			RootPath = rootPath;
			tableNodesCollection = new Vector<String>();
			ExcelRowInstance = new Vector<Node>();
			X2EntryCell = new HashMap<Node,Node>();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
		
	}
	// ABSOLUTE_PATH_NONE_UNIT
	private String formatAbsolutePath(String path)
	{
		path = path.replace("$record",RootPath);
		path = path.replace(".","/");
		path = "/ns1:" + path;
		return path;
	}
	
	public void setMessageTypeRoot(Node node)
	{
		rootMessageType = node;
	}
	
	private void fillExcelRowInstance()
	{
		NodeList Rows = TableNode.getChildNodes();
		int RowNumber = Rows.getLength();
		Node item = null;
		for( int i = 0 ; i < RowNumber;i++)
		{
			item = Rows.item(i);
			if( item.getNodeName().equals("Row"))
				ExcelRowInstance.add(item);
		}
	}
	// ABSOLUTE_PATH_UNIT
	private String formatAbsoluteUnitPath(String path)
	{
		int index = path.indexOf("unitCode");
		if( index == -1)
		{
			index = path.indexOf("currencyCode");
			if( index == -1)
			{
				index = path.indexOf("timeZoneCode");
				if( index == -1)
					return null;
				path = path.substring(0,index) + "@" + "timeZoneCode";
			}
			else
				path = path.substring(0,index) + "@" + "currencyCode";
		}
		else
			path = path.substring(0,index) + "@" + "unitCode";
		path = path.replace("$record",RootPath);
		path = path.replace(".","/");
		path = "/ns1:" + path;
		return path;
	}
	// RELATIVE_PATH_NONE_UNIT
	private String formatRelativePath(String path)
	{
		path = path.replace("$record",RootPath);
		path = path.replace(".","/");
		path = path.replace("[*]","");
		path = "/ns1:" + path;
		return path;
	}
	// RELATIVE_PATH_UNIT
	private String formatRelativeUnitPath(String path)
	{
		int index = path.indexOf("unitCode");
		if( index == -1)
		{
			index = path.indexOf("currencyCode");
			if( index == -1)
			{
				index = path.indexOf("timeZoneCode");
				if( index == -1)
					return null;
				else
					path = path.substring(0,index) + "@" + "timeZoneCode";
			}
			else
				path = path.substring(0,index) + "@" + "currencyCode";
		}
		else
			path = path.substring(0,index) + "@" + "unitCode";
		path = path.replace("$record",RootPath);
		path = path.replace("[*]","");
		path = path.replace(".","/");
		path = "/ns1:" + path;
		return path;
	}
	
	/* should handle with type situation very carefully
	 * Sometimes even the path has no [*],but in fact it is really a node within
	 * the table.for example:$record.DeliveryNote.Item.BuyerParty.InternalID
	 * is really a node in the table, we should handle with this situation 
	 */
	private int getPathType(String path)
	{
		if( path.contains("[*]"))
			// already relative path, we need not do checking any more
			return getRelativePathUnitType(path);
		// absolute or still relative,need further checking
		// has one table nodes in the parent path
		if( CheckIfRealTableNode(path) == TABLE_NODE)
			return getRelativePathUnitType(path);
		// single node
		return getAbsolutePathUnitType(path);
	}
	
	private int getAbsolutePathUnitType(String path)
	{
		if ( path.contains("unitCode") || path.contains("currencyCode") 
				|| path.contains("timeZoneCode"))
			return ABSOLUTE_PATH_UNIT;
		return ABSOLUTE_PATH_NONE_UNIT;
	}
	
	private int getRelativePathUnitType(String path)
	{
		if( path.contains("unitCode") || path.contains("currencyCode")
				|| path.contains("timeZoneCode"))
			return RELATIVE_PATH_UNIT;
		return RELATIVE_PATH_NONE_UNIT;
	}
	
	private int CheckIfRealTableNode(String path)
	{
		int index = path.lastIndexOf(".");
		/* impossible to happen
		if( index == -1)
		*/
		String parentPath = path.substring(0,index);
		for( int i = 0 ; i < tableNodesCollection.size();i++)
		{
			if( parentPath.contains(tableNodesCollection.elementAt(i)))
				return TABLE_NODE;
		}
		return SINGLE_NODE;
	}
	
	private void SearchTableNodes()
	{
		Node xsd = Tool.getNodebyRoot("xsd:schema",x2Schema);
		if( xsd == null)
		{
			System.out.println("Can not find xsd:schema!");
			return;
		}
		NodeList child = xsd.getChildNodes();
		int number = child.getLength();
		Node item = null;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( item.getNodeName() == null)
				continue;
			if( !item.getNodeName().equals("xsd:complexType"))
				continue;
			HandleWithComplexType(item);
		}
		tableNodesCollection = DeleteDuplicatedData(tableNodesCollection);
		PrintVector(tableNodesCollection);
	}
	// test function
	private void PrintVector(Vector<String> v)
	{
		for( int i = 0 ; i < v.size() ; i++)
			System.out.println("Value: " + v.elementAt(i));
	}
	
	private void HandleWithComplexType(Node node)
	{
		Node sequence = Tool.getNodebyRoot("xsd:sequence",node);
		if( sequence == null)
			return;
		NodeList child = sequence.getChildNodes();
		int number = child.getLength();
		Node item = null;
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( item.getNodeName() == null)
				continue;
			if( !item.getNodeName().equals("xsd:element"))
				continue;
			CheckTableNodes(item);
		}
	}
	private void CheckTableNodes(Node node)
	{
		String occurance = getAttributeValue("maxOccurs",node);
		if( occurance == null)
			return;
		if( !occurance.equals("unbounded"))
			return;
		String name = getAttributeValue("name",node);
		if( name != null)
		{
			tableNodesCollection.add(name);
			System.out.println("Table Node: " + name);
		}
			
	}
	private String getAttributeValue(String AttrName,Node node)
	{
		if( node.getAttributes() == null)
			return null;
		if( node.getAttributes().getNamedItem(AttrName) == null)
			return null;
		return node.getAttributes().getNamedItem(AttrName).getNodeValue();
		
	}
	// path format as "field name + binding path"
	private void TransformPathforExcel(String path)
	{
		int index = path.indexOf('%');
		fieldName = path.substring(0,index);
		String bindingpath = path.substring(++index,path.length());
		int type = getPathType(bindingpath);
		String formattedPath = null;
		switch (type)
		{
			case ABSOLUTE_PATH_NONE_UNIT:
				formattedPath = formatAbsolutePath(bindingpath);
				CreateSingleNode(formattedPath,bindingpath);
				System.out.println("Absolute Path: " + formattedPath);
				break;
			
			case ABSOLUTE_PATH_UNIT:
				formattedPath = formatAbsoluteUnitPath(bindingpath);
				CreateSingleNode(formattedPath,bindingpath);
				System.out.println("Absolute Unit Path: " + formattedPath);
				break;
				
			case RELATIVE_PATH_NONE_UNIT:
				formattedPath = formatRelativePath(bindingpath);
				CreateSingleNode(formattedPath,bindingpath);
				System.out.println("Relative Path: " + formattedPath);
				break;
				
			case RELATIVE_PATH_UNIT:
				formattedPath = formatRelativeUnitPath(bindingpath);
				CreateSingleNode(formattedPath,bindingpath);
				System.out.println("Relative Unit Path: " + formattedPath);
				break;
			default:
				System.out.println("Invalid Type!");
		}
	}
	
	private Vector<String> DeleteDuplicatedData(Vector<String> v)
	{
		int size = v.size();
		int[] index = new int[size];
		for( int k = 0 ; k < size;k++)
			index[k] = -1;
		String path1 = null;
		String path2 = null;
		int indicator = -1;
		for(int i = 0 ; i < size;i++)
		{
			for( int j = i+1;j < size;j++)
			{
				path1 = v.elementAt(i);
				path2 = v.elementAt(j);
				indicator = path1.indexOf('%');
				path1 = path1.substring(++indicator,path1.length());
				indicator = path2.indexOf('%');
				path2 = path2.substring(++indicator,path2.length());
				if( path1.equals(path2))
				{
					index[j] = 1;
				}
			}
		}
		Vector<String> CleanedVec = new Vector<String>();
		for( int m = 0 ; m < size;m++)
		{
			if( index[m] != 1)
				CleanedVec.add(v.elementAt(m));
		}
		return CleanedVec;
	}
	
	private void WriteBackExcelTotalRow()
	{
		TableNode.getAttributes().getNamedItem("ss:ExpandedRowCount").setNodeValue(String.valueOf(ExcelRowInstance.size()));
		// should make sure the smaller index should appear first
		sortExcelRow();
	}
	
	private void sortExcelRow()
	{
		NodeList child = TableNode.getChildNodes();
		int length = child.getLength();
		Node item = null;
		for( int i =0;i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("Row"))
				SortRowInstance(item);
		}
	}

	private void SortRowInstance(Node node)
	{
		NodeList child = node.getChildNodes();
		int length = child.getLength();
		Node item = null;
		Node temp = null;
		Node[] set = new Node[10];
		int CellNumber = 0;
		for(int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( item.getNodeName().equals("Cell"))
				set[CellNumber++] = item;
		}
		if( CellNumber <= 1)
			return;
		for( int j = 0 ; j < CellNumber;j++)
		{
			for( int k = 0;k < CellNumber -1;k++)
			{
				String lIndex = getAttributeValue("ss:Index",set[k]);
				String rIndex = getAttributeValue("ss:Index",set[k+1]);
				if( (lIndex == null) || ( rIndex == null))
					continue;
				//System.out.println("left:" + lIndex);
				//System.out.println("right:" + rIndex);
				if( Integer.valueOf(lIndex) > Integer.valueOf(rIndex))
				{
					node.removeChild(set[k]);
					if( k + 1 + 1 > CellNumber)
						node.appendChild(set[k]);
					else
						node.insertBefore(set[k],set[k+2]);
					temp = set[k+1];
					set[k+1] = set[k];
					set[k] = temp;
				}
			}
		}
	}
	// some colleagues need not this functionality
	private boolean VerifyMessageType()
	{
		if( ExcelRootElement == null)
			return false;
		if( !ExcelRootElement.equals(RootPath))
			return false;
		return true;
	}
	
	// test function
	private void PrintPathCollection()
	{
		String path = null;
		int size = templatePathCollection.size();
		for( int i = 0 ; i < size; i++)
		{
			path = templatePathCollection.elementAt(i);
			System.out.println("Path in Collection: " + path);
		}
	}
	/* main engine here
	 * 
	 */
	public boolean TransformPath()
	{
		PrintPathCollection();
		if( !VerifyMessageType())
		{
			String error = "Template Message Tpye MisMatched with the one Imported into Excel!\n";
			error += "Message type in Template is : " + RootPath + "\n";
			error += "Message type in Excel is : " + ExcelRootElement + "\n";
			Tool.ErrorReport(error);
			return false;
		}
		formatStyleforWrapText();
		CreateStyleIDforErrorPath();
		System.out.println("Before check Table Nodes!");
		SearchTableNodes();
		//templatePathCollection = DeleteDuplicatedData(templatePathCollection);
		int size = templatePathCollection.size();
		String path = null;
		for( int i = 0 ; i < size;i++)
		{
			path = templatePathCollection.elementAt(i);
			System.out.println("Begin to Transform Path: " + path);
			TransformPathforExcel(path);
		}
		/*Iterator iterator = templatePathCollection.keySet().iterator(); 
		String path = null;
		while(iterator.hasNext()) 
		{
			Object key = iterator.next();
			path = templatePathCollection.get(key);
			TransformPathforExcel(path);
		}*/
		WriteBackExcelTotalRow();
		CheckDuplicateX2Entry();
		CheckValidMappingPath();
		return true;
	}
	
	private void CheckValidMappingPath()
	{
		pathChecker checker = new pathChecker(rootMessageType,x2Map);
		Vector<String> errorPath = checker.startCheck();
		if( errorPath == null )
			return;
		if( errorPath.isEmpty())
			return;
		int size = errorPath.size();
		for( int i = 0;i<size;i++)
		{
			DeleteX2EntrybyPath(errorPath.elementAt(i));
		}
	}
	private void DeleteX2EntrybyPath(String path)
	{
		NodeList child = x2Map.getChildNodes();
		int size = child.getLength();
		Node item = null;
		Node match = null;
		String Matchpath = null;
		for( int i = 0 ; i < size;i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("x2:Entry"))
				continue;
			Matchpath = Tool.getNodebyRoot("x2:XPath",item).getTextContent();
			if( Matchpath.equals(path))
			{
				match = item;
				break;
			}
		}
		if( match == null)
			return;
		x2Map.removeChild(match);
		// mark on the corresponding Cell node
		Node cell = X2EntryCell.get(match);
		cell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ERROR_PATH);
	}
	
	private void CreateStyleIDforErrorPath()
	{
		Node style = Tool.getNodebyRoot("Styles",root);
		if( style == null)
			return;
		Document styleDocument = style.getOwnerDocument();
		Element StyleNode = styleDocument.createElement("Style");

		Attr ID = styleDocument.createAttribute("ss:ID");
		ID.setNodeValue(ERROR_PATH);
		StyleNode.setAttributeNode(ID);
		
		Element Borders = styleDocument.createElement("Borders");
		Element[] border = new Element[4];
		for( int i = 0 ; i < 4;i++)
		{
			border[i] = styleDocument.createElement("Border");
			
			Attr position = styleDocument.createAttribute("ss:Position");
			position.setNodeValue("default");
			border[i].setAttributeNode(position);
			
			Attr lineStyle = styleDocument.createAttribute("ss:LineStyle");
			lineStyle.setNodeValue("Continuous");
			border[i].setAttributeNode(lineStyle);
			
			Attr weight = styleDocument.createAttribute("ss:Weight");
			weight.setNodeValue("1");
			border[i].setAttributeNode(weight);
			Borders.appendChild(border[i]);
		}
		border[0].getAttributes().getNamedItem("ss:Position").setNodeValue("Bottom");
		border[1].getAttributes().getNamedItem("ss:Position").setNodeValue("Left");
		border[2].getAttributes().getNamedItem("ss:Position").setNodeValue("Right");
		border[3].getAttributes().getNamedItem("ss:Position").setNodeValue("Top");
		StyleNode.appendChild(Borders);
		
		Element Alignment = styleDocument.createElement("Alignment");
		Attr Vertical = styleDocument.createAttribute("ss:Vertical");
		Vertical.setNodeValue("Bottom");
		Alignment.setAttributeNode(Vertical);
		
		Attr WrapText = styleDocument.createAttribute("ss:WrapText");
		WrapText.setNodeValue("1");
		Alignment.setAttributeNode(WrapText);
		StyleNode.appendChild(Alignment);
		
		Element font = styleDocument.createElement("Font");
		Attr Family = styleDocument.createAttribute("x:Family");
		Family.setNodeValue("Swiss");
		font.setAttributeNode(Family);
		
		Attr bold = styleDocument.createAttribute("ss:Bold");
		bold.setNodeValue("1");
		font.setAttributeNode(bold);
		StyleNode.appendChild(font);
		
		Element Interior = styleDocument.createElement("Interior");
		Attr Color = styleDocument.createAttribute("ss:Color");
		Color.setNodeValue("#CC99FF");
		Interior.setAttributeNode(Color);
		
		Attr Pattern = styleDocument.createAttribute("ss:Pattern");
		Pattern.setNodeValue("Solid");
		Interior.setAttributeNode(Pattern);
		StyleNode.appendChild(Interior );
		
		style.appendChild(StyleNode);
		
	}
	private boolean isAlreadyWritten(Vector<String> v,String path)
	{
		if( v.isEmpty())
			return false;
		int size = v.size();
		for( int i = 0 ; i < size;i++)
		{
			if( path.equals(v.elementAt(i)))
				return true;
		}
		return false;
	}
	/* especially designed for SRM form, in that application area 
	 * Exmaple:$record.PurchaseOrder.Item.ShipToLocation.FormAddress.
	 * FirstPostalRegulationsCompliantAddressLine.Description(info block)
	 * 
	 * $record.PurchaseOrder.Item[*].ShipToLocation.
	 * FormAddress.FirstPostalRegulationsCompliantAddressLine.Description
	 * (table)
	 */
	private void CheckDuplicateX2Entry()
	{
		/*int size = X2EntryCollection.size();
		Node itemL = null;
		Node itemR = null;
		String pathL = null;
		String pathR = null;
		for( int i = 0 ; i < size;i++)
			for( int j = i+1;j < size;j++)
			{
				itemL = X2EntryCollection.elementAt(i);
				itemR = X2EntryCollection.elementAt(j);
				pathL = getNodebyRoot("x2:XPath",itemL).getTextContent();
				pathR = getNodebyRoot("x2:XPath",itemR).getTextContent();
				if( pathL.equals(pathR))
					duplicateX2Entry.add(itemL);
			}
		if( duplicateX2Entry.isEmpty())
			return;
		System.out.println("Before Delete Duplicate Node!");
		Node parent = duplicateX2Entry.elementAt(0).getParentNode();
		size = duplicateX2Entry.size();
		System.out.println("Parent Node Name: " + parent.getNodeName());
		System.out.println("Duplicate number: " + size);
		Vector<String> tmpDeleted = new Vector<String>();
		String delPath = null;
		for( int k = 0 ; k < size;k++)
		{
			Node del = duplicateX2Entry.elementAt(k);
			delPath = getNodebyRoot("x2:XPath",del).getTextContent();
			//if( canDelete(tmpDeleted,delPath))
			//{
				System.out.println("Deleting Path: " + delPath);
			//	tmpDeleted.add(delPath);
				parent.removeChild(duplicateX2Entry.elementAt(k));
			//	System.out.println("Delete Node: " + k + " OK!");
			//}
		}*/
		// there should be only one exact path in the X2:Map

		Node parent = x2Map;
		NodeList child = parent.getChildNodes();
		int number = child.getLength();
		Node item = null;
		String path = null;
		Vector<String> writtenNode = new Vector<String>();
		Vector<Node> delVec = new Vector<Node>();
		for( int i = 0 ; i < number;i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("x2:Entry"))
				continue;
			path = Tool.getNodebyRoot("x2:XPath",item).getTextContent();
			if( isAlreadyWritten(writtenNode,path))
			// should delete this x2:Entry Node
				delVec.add(item);
			else
				writtenNode.add(path);
		}
		for( int j = 0 ; j < delVec.size();j++)
		{
			parent.removeChild(delVec.elementAt(j));
			System.out.println("Delete : " + delVec.elementAt(j) + " OK!");
		}
	}
	private void WriteCaption(Node priorCell)
	{
		Document CellDocument = priorCell.getOwnerDocument();
		Element DataNode = CellDocument.createElement("Data");
		Attr DataType = CellDocument.createAttribute("ss:Type");
		DataType.setNodeValue("String");
		DataNode.setAttributeNode(DataType);
		DataNode.setTextContent(fieldName);
		priorCell.appendChild(DataNode);
	}
	
	private void SetRowHeight(int RowIndex)
	{
		Node rowInstance = getRowInstancebyIndex(RowIndex);
		if( rowInstance.getAttributes().getNamedItem("ss:Height") != null)
		{
			rowInstance.getAttributes().getNamedItem("ss:Height").setNodeValue(defaultRowHeight);
			return;
		}
		Document CellDocument = rowInstance.getOwnerDocument();
		Attr height = CellDocument.createAttribute("ss:Height");
		height.setNodeValue(defaultRowHeight);
		rowInstance.getAttributes().setNamedItem(height);
	}
	
	private void CreateDebugCell(int row,int column,String path)
	{
		Node debugCell = getCellbyPosition(row,column);
		// to write the debug information in the cell below
		if( debugCell == null )
		{
			System.out.println("Can not find corresponding Debug Cell for Row: " + row  + 
					" Column: " + column);
			return;
		}
		Document CellDocument = debugCell.getOwnerDocument();
		Element DataNode = CellDocument.createElement("Data");
		Attr DataType = CellDocument.createAttribute("ss:Type");
		DataType.setNodeValue("String");
		DataNode.setAttributeNode(DataType);
		DataNode.setTextContent(path);
		debugCell.appendChild(DataNode);
		debugCell.getAttributes().getNamedItem("ss:StyleID").setNodeValue(ERROR_PATH);
	}
	private void CreateSingleNode(String FormattedPath,String path)
	{
		Document x2MapDocument = x2Map.getOwnerDocument();
		Element x2Entry = x2MapDocument.createElement("x2:Entry");

		Attr type = x2MapDocument.createAttribute("x2:Type");
		type.setNodeValue("single");
		x2Entry.setAttributeNode(type);
		
		Attr ID = x2MapDocument.createAttribute("x2:ID");
		ID.setNodeValue(String.valueOf(x2EntryID++));
		x2Entry.setAttributeNode(ID);
		
		Element x2Range = x2MapDocument.createElement("x2:Range");
		// there may be issues here,hard coded "sheet1!R" is dangerous.
		String position = BindingWorkSheetName + "!R" + RowIndex + "C" + ColumnIndex;
		SetRowHeight(RowIndex);
		// user readable text is maintained in position(RowIndex,ColumnIndex)
		Node cell = getCellbyPosition(RowIndex,ColumnIndex);
		if( cell == null)
		{
			System.out.println("Can not find corresponding Cell for Row: " + RowIndex + 
					" Column: " + ColumnIndex);
			return;
		}
		// priorCell is used to display the field caption or name
		Node priorCell = getCellbyPosition(RowIndex,ColumnIndex -1 );
		if( priorCell == null)
		{
			System.out.println("Can not find corresponding Cell for Row: " + RowIndex + 
					" Column: " + String.valueOf(ColumnIndex -1));
			return;
		}
		// Write Caption into Cell
		WriteCaption(priorCell);
		if( isDebugModeOn )
			CreateDebugCell(++RowIndex,ColumnIndex,FormattedPath);
		Document CellDocument = cell.getOwnerDocument();
		Element DataNode = CellDocument.createElement("Data");
		Attr DataType = CellDocument.createAttribute("ss:Type");
		DataType.setNodeValue("String");
		DataNode.setAttributeNode(DataType);
		DataNode.setTextContent(path);
		cell.appendChild(DataNode);
		System.out.println("Position: " + position);
		// change interval here
		RowIndex += 1;
		x2Range.setTextContent(position);
		x2Entry.appendChild(x2Range);
		
		Element xFilterOn = x2MapDocument.createElement("x:FilterOn");
		xFilterOn.setTextContent("False");
		x2Entry.appendChild(xFilterOn);
		
		Element xPath = x2MapDocument.createElement("x2:XPath");
		xPath.setTextContent(FormattedPath);
		x2Entry.appendChild(xPath);
		
		Element xField = x2MapDocument.createElement("x2:Field");
		Element xXSDType = x2MapDocument.createElement("x2:XSDType");
		xXSDType.setTextContent("String");
		xField.appendChild(xXSDType);
		
		Element Cell = x2MapDocument.createElement("ss:Cell");
		xField.appendChild(Cell);
		
		Element xAggregate = x2MapDocument.createElement("x2:Aggregate");
		xAggregate.setTextContent("None");
		xField.appendChild(xAggregate);
		
		x2Entry.appendChild(xField);
		System.out.println("Add X2Entry!");
		x2Map.appendChild(x2Entry);
		
		X2EntryCell.put(x2Entry,cell);
	}
	
	/*private void CreateRelativeNodes(String path,boolean isUnit)
	{
		Document x2MapDocument = x2Map.getOwnerDocument();
		Element x2Entry = x2MapDocument.createElement("x2:Entry");

		Attr type = x2MapDocument.createAttribute("x2:Type");
		type.setNodeValue("table");
		x2Entry.setAttributeNode(type);
		
		Attr ID = x2MapDocument.createAttribute("x2:ID");
		ID.setNodeValue(String.valueOf(x2EntryID++));
		x2Entry.setAttributeNode(ID);
		
		Attr showTotal = x2MapDocument.createAttribute("x2:ShowTotals");
		showTotal.setNodeValue("false");
		x2Entry.setAttributeNode(showTotal);
		
		Element x2HeaderRange = x2MapDocument.createElement("x2:HeaderRange");
		String header = "R" + RowIndex + "C" + ColumnIndex;
		x2HeaderRange.setTextContent(header);
		x2Entry.appendChild(x2HeaderRange);
		RowIndex++;
		
		Element x2Range = x2MapDocument.createElement("x2:Range");
		String position = "Sheet1!R" + RowIndex + "C" + ColumnIndex;
		System.out.println("Position: " + position);
		RowIndex++;
		x2Range.setTextContent(position);
		x2Entry.appendChild(x2Range);
		
		Element xFilterOn = x2MapDocument.createElement("x:FilterOn");
		xFilterOn.setTextContent("True");
		x2Entry.appendChild(xFilterOn);
		
		Element xPath = x2MapDocument.createElement("x2:XPath");
		String parentPath = getParentPath(path);
		xPath.setTextContent(parentPath);
		x2Entry.appendChild(xPath);
		
		Element xField = x2MapDocument.createElement("x2:Field");
		
		Attr ChildID = x2MapDocument.createAttribute("x2:ID");
		String name = getChildPath(path);
		ChildID.setNodeValue(name);
		xField.setAttributeNode(ChildID);
		
		Element childRange = x2MapDocument.createElement("x2:Range");
		childRange.setTextContent("RC");
		xField.appendChild(childRange);
		
		Element xChildPath = x2MapDocument.createElement("x2:XPath");
		if( isUnit )
			xChildPath.setTextContent("@"+name);
		else
			xChildPath.setTextContent(name);
		xField.appendChild(xChildPath);
		
		Element xXSDType = x2MapDocument.createElement("x2:XSDType");
		xXSDType.setTextContent("String");
		xField.appendChild(xXSDType);
		
		Element Cell = x2MapDocument.createElement("ss:Cell");
		xField.appendChild(Cell);
		
		Element xAggregate = x2MapDocument.createElement("x2:Aggregate");
		xAggregate.setTextContent("None");
		xField.appendChild(xAggregate);
		
		x2Entry.appendChild(xField);
		System.out.println("Add X2Entry!");
		x2Map.appendChild(x2Entry);
	}*/
	
	/*private String getParentPath(String path)
	{
		int index = path.lastIndexOf("/");
		if( index == -1)
			return null;
		String parent = path.substring(0,index);
		System.out.println("Parent: " + parent);
		return parent;
	}*/
	
	/*private String getChildPath(String path)
	{
		int index = path.lastIndexOf("/");
		if( index == -1)
			return null;
		String child = path.substring(++index,path.length());
		if( child.charAt(0) == '@')
			child = child.substring(1,child.length());
		System.out.println("child: " + child);
		return child;
	}*/
	
	private void formatStyleforWrapText()
	{
		generateWrapTextStyle(getLastStyleID());
	}
	private String getLastStyleID()
	{
		StyleIDNode= Tool.getNodebyRoot("Styles",root);
		if( StyleIDNode == null)
			return null;
		Node next = StyleIDNode.getFirstChild();
		Node prior = null;
		while( next != null)
		{
			if( !next.getNodeName().equals("Style"))
			{
				next = next.getNextSibling();
				continue;
			}
			prior = next;
			System.out.println("Style ID:" + getAttributeValue("ss:ID",prior));
			next = next.getNextSibling();
		}
		return getAttributeValue("ss:ID",prior);
	}
	private void generateWrapTextStyle(String lastStyleID)
	{
		if( lastStyleID == null)
			return;
		int lastID = Integer.parseInt(lastStyleID.substring(1,lastStyleID.length()));
		lastID++;
		Document ParentDocument = StyleIDNode.getOwnerDocument();
		Element style = ParentDocument.createElement("Style");
		Attr id = ParentDocument.createAttribute("ss:ID");
		WrapTextStyle = "s" + lastID;
		id.setNodeValue(WrapTextStyle);

		style.setAttributeNode(id);
		Element Alignment = ParentDocument.createElement("Alignment");
		Attr Vertical = ParentDocument.createAttribute("ss:Vertical");
		Vertical.setNodeValue("Bottom");
		Alignment.setAttributeNode(Vertical);
		
		Attr WrapText = ParentDocument.createAttribute("ss:WrapText");
		WrapText.setNodeValue("1");
		Alignment.setAttributeNode(WrapText);
		style.appendChild(Alignment);
		StyleIDNode.appendChild(style);
	}
	

	private void getTableNode()
	{
		NodeList child = root.getChildNodes();
		int length = child.getLength();
		Node item = null;
		//String name = null;
		for( int i = 0 ; i < length;i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("Worksheet"))
				continue;
			BindingWorkSheetName = getAttributeValue("ss:Name",item);
			TableNode = Tool.getNodebyRoot("Table",item);
			System.out.println("Table Node Name: " + TableNode.getNodeName());
			return;
			/*name = getAttributeValue("ss:Name",item);
			if( name == null)
				continue;
			if( name.equalsIgnoreCase("EngineeringSpec"))
			{
				TableNode = item;
				return;
			}*/
		}
	}
	
	private void GenerateRowInstance()
	{
		// ColumnIndex is default Column which writes binding paths
		Document ParentDocument = TableNode.getOwnerDocument();
		Element RowNode = ParentDocument.createElement("Row");
		Element cell = generateCell(ColumnIndex,RowNode);
		RowNode.appendChild(cell);
		ExcelRowInstance.add(RowNode);
		TableNode.appendChild(RowNode);
	}
	

	private Element generateCell(int column,Node rowInstance)
	{
		Document ParentDocument = rowInstance.getOwnerDocument();
		Element CellNode = ParentDocument.createElement("Cell");
		Attr Index = ParentDocument.createAttribute("ss:Index");
		Index.setNodeValue(String.valueOf(column));
		CellNode.setAttributeNode(Index);
		
		Attr Style = ParentDocument.createAttribute("ss:StyleID");
		Style.setNodeValue(WrapTextStyle);
		CellNode.setAttributeNode(Style);
		return CellNode;
	}
	// to enhance performance, create a series of cells node at a time instead of
	// only create new cell node when needed
	private Node createNewRowInstance(int row)
	{
		for( int i = 0 ; i < 100;i++)
			GenerateRowInstance();
		int index = row;
		return ExcelRowInstance.elementAt(--index);
	}
	
	/* if required cells on given position does not exist,
	 * it will be generated dynamically
	 */
	private Node getCellbyPosition(int row,int column)
	{
		Node rowInstance = getRowInstancebyIndex(row);
		if( rowInstance == null)
			return null;
		return getCellInstancebyIndex(column,rowInstance);
	}
	
	/* only handle with the situation that other three columns are all empty
	 * if the other three are not empty,the function will fail ,should be improved 
	 * in the future
	 */
	private Node getCellInstancebyIndex(int column,Node row)
	{
		NodeList Cells = row.getChildNodes();
		int CellNumber = Cells.getLength();
		Node item = null;
		String index = null;
		for( int i = 0 ; i < CellNumber;i++)
		{
			item = Cells.item(i);
			if( !item.getNodeName().equals("Cell"))
				continue;
			index = getAttributeValue("ss:Index",item);
			if( index == null)
				continue;
			if( Integer.valueOf(index) == column )
				return item;
		}
		// none cell whose index is column
		Node cell = generateCell(column,row);
		row.appendChild(cell);
		return cell;
	}
	
	private Node getRowInstancebyIndex(int row)
	{
		System.out.println("Currently Available Row Number: " + ExcelRowInstance.size());
		// row instance exhausted
		if ( row > ExcelRowInstance.size())
			return createNewRowInstance(row);
		return ExcelRowInstance.elementAt(--row);
	}
	
	// initialize phase 
	public void LoadExcelSpec(String path)
	{
		try 
		{
			InputStream inputXML = new FileInputStream(path);
			doc = dombuilder.parse(inputXML);
			root = doc.getDocumentElement();
			getTableNode();
			fillExcelRowInstance();
			Node x2MapInfo = Tool.getNodebyRoot("x2:MapInfo",root);
			if( x2MapInfo != null)
				System.out.println("Found x2:MapInfo!");
			else 
				return;
			x2Schema = Tool.getNodebyRoot("x2:Schema",x2MapInfo);
			if( x2Schema == null)
				return;
			x2Map = Tool.getNodebyRoot("x2:Map",x2MapInfo);
			if( x2Map != null)
			{
				System.out.println("Found x2:Map");
				if( x2Map.getAttributes().getNamedItem("x2:RootElement") != null)
					ExcelRootElement = x2Map.getAttributes().getNamedItem("x2:RootElement").getNodeValue();
			}
			else
				return;
		}
		catch (FileNotFoundException d) 
		{
			d.printStackTrace();
		} 
		catch (SAXException d) 
		{
			d.printStackTrace();
			System.exit(0);
		} 
		catch (IOException d) 
		{
			d.printStackTrace();
		}
	}
	
	
	public String SaveAs(String path)
	{
		String formattedPath = FormatSavePath(path);
		File newFile = new File(formattedPath);
		if( newFile.exists())
			return null;
		try
		 {   
             TransformerFactory tff = TransformerFactory.newInstance();   
             Transformer tf = tff.newTransformer();   
             DOMSource source = new DOMSource(doc);
             StreamResult rs = new StreamResult(newFile);
             tf.transform(source,rs);  
             tf.reset();
         }
		 catch(Exception   e1)
		 {   
             e1.printStackTrace();   
		 }  
		 return formattedPath;
	}
	
	private String FormatSavePath(String path)
	{
		int index = path.lastIndexOf('.');
		if( index != -1)
			return path;
		String newPath = path + ".xml";
		return newPath;
	}
	
}