package formAutoBinding;
import excelFormat.internalStructure.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import utilities.Tool;


public class ExcelConfigurationLoader
{
	private HashMap<String,internalPathObject> pathObjectCollection = null;
	private Document doc;
	private DocumentBuilder dombuilder;
	private DocumentBuilderFactory domfac;
	private Element root = null;
	private final int FILE_STRUCTURE_ERROR = -1;
	private final int FILL_OK = 1;
	public HashMap<String,internalPathObject> getBindingPathCollection()
	{
		return pathObjectCollection;
	}
	public ExcelConfigurationLoader()
	{
		domfac = DocumentBuilderFactory.newInstance();
		pathObjectCollection = new HashMap<String,internalPathObject>();
		try 
		{
			dombuilder = domfac.newDocumentBuilder();
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void printPathCollection(DefaultListModel ListMode,JList jList)
	{
		DefaultListModel Mode = ListMode;
		JList ListInstance = jList;
		Mode.clear();
		ListInstance.setModel(Mode);
		Iterator iterator = pathObjectCollection.keySet().iterator(); 
		while(iterator.hasNext()) 
		{
			Object key = iterator.next();
			//System.out.println("Position in traverse: " + key.toString());
			//System.out.println("Path in traverse: " + hashMapExcelCellPathInfo.get(key));
			String item = "Field: " + key.toString();
			Mode.addElement(item);
			item = "Will be bound to path: " + pathObjectCollection.get(key).getPath();
			Mode.addElement(item);
			Mode.addElement("\n");
		}
	}
	private Node getBindingWorkSheet()
	{
		NodeList child = root.getChildNodes();
		int ChildNumber = child.getLength();
		Node item = null;
		for( int i = 0 ; i < ChildNumber; i++)
		{
			item = child.item(i);
			if( !item.getNodeName().equals("Worksheet"))
				continue;
			if( item.getAttributes().getNamedItem("ss:Name").getNodeValue().equals("Binding"))
				return item;
		}
		return null;
	}
	// main logic here.
	public int FillCollection(String filePath)
	{
		InputStream inputXML = null;
		try 
		{
			inputXML = new FileInputStream(filePath);
			doc = dombuilder.parse(inputXML);
			root = doc.getDocumentElement();
			if( root.getAttributes().getNamedItem("formatted") == null )
					return -1;
			Node WorkSheet = getBindingWorkSheet();
			if( WorkSheet != null)
				System.out.println("Found WorkSheet!");
			else 
				return FILE_STRUCTURE_ERROR;
			Node Table = Tool.getNodebyRoot("Table",WorkSheet);
			if( Table != null)
				System.out.println("Found Table");
			else
				return FILE_STRUCTURE_ERROR;
			NodeList TableRows = Table.getChildNodes();
			int RowNumber = TableRows.getLength();
			Node RowInstance = null;
			for( int i = 0; i < RowNumber;i++)
			{
				RowInstance = TableRows.item(i);
				if( RowInstance.getNodeName().equals("Row"))
				{
					HandleWithRowInstance(RowInstance);
				}
			}
		
		} 
		catch (FileNotFoundException e1) 
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		catch (SAXException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return FILL_OK;
		// should check if it is a well format document
	}
	private void HandleWithRowInstance(Node node)
	{
		NodeList Cells = node.getChildNodes();
		Node item = null;
		int Cellnumber = Cells.getLength();
		for( int i = 0 ; i < Cellnumber; i ++)
		{
			item = Cells.item(i);
			if( item.getNodeName().equals("Cell"))
				TryFindCustomFormDataNode(item);
		}
	}
	private internalPathObject getInternalPathObject(String name,String path,Node FormNode)
	{
		boolean isIntable = false;
		String parentPath = null;
		String relativePath = null;
		String type = FormNode.getAttributes().getNamedItem("type").getNodeValue();
		if( type.equals("tablecell"))
		{
			isIntable = true;
			relativePath = FormNode.getAttributes().getNamedItem("relative").getNodeValue();
			Node parent = Tool.getNodebyRoot("Parent",FormNode);
			if( parent == null)
				parent = Tool.getNodebyRoot("ss:Parent",FormNode);
			parentPath = parent.getTextContent();
		}
		internalPathObject obj = new internalPathObject(path,isIntable,parentPath,relativePath);
		return obj;
		
	}
	private void TryFindCustomFormDataNode(Node node)
	{
		Node FormNode = Tool.getNodebyRoot("Form",node);
		if( FormNode == null)
		{
			//System.out.println("Can not find Form Node");
			FormNode = Tool.getNodebyRoot("ss:Form",node);
			if( FormNode == null)
				return;
		}
		Node DataNode = Tool.getNodebyRoot("Data",node);
		if( DataNode == null)
		{
			//System.out.println("Can not find Data Node");
			return;
		}
		String Name = FormNode.getAttributes().getNamedItem("fieldname").getNodeValue();
		String path = DataNode.getTextContent();
		// check 
		internalPathObject pathObj = getInternalPathObject(Name,path,FormNode);
		pathObjectCollection.put(Name,pathObj);
		System.out.println("Add into map: " + Name + " --->" + path);
	}
}