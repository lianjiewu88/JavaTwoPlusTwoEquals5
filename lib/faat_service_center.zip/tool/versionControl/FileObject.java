package versionControl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import utilities.Tool;
public class FileObject
{
	BufferedReader br = null;
	String formattedPath = null;
	private void formatPath(String inputFile)
	{
		formattedPath = inputFile.replace('*', '/');
		System.out.println("r: " + formattedPath);
	}
	public FileObject(String inputFile)
	{
		try 
		{
			formatPath(inputFile);
			br = new BufferedReader(new FileReader(formattedPath));
		} 
		catch (FileNotFoundException e) 
		{
			Tool.ErrorReport("Can Not Open File: " + formattedPath + "\nPlease Check Network Settings");
			e.printStackTrace();
		}   
	}
	public String ReadContent()
	{
		File XML = new File(formattedPath);
		int length = (int)XML.length();
		char[] inputdata = new char [length];
		try 
		{
			br.read(inputdata,0,length);
			String input = new String(inputdata);
			br.close();
			return input;
		} 
		catch (IOException e) 
		{
			Tool.ErrorReport("Can Not Read File: " + formattedPath + " Check Your Network Settings!");
			e.printStackTrace();
		}
		return null;
	}
}