package versionControl;
import configuration.ConfigDom;
import utilities.Tool;
public class versionController
{
	static public boolean checkVersion(String currentVersion)
	{
		FileObject file = new FileObject(ConfigDom.versionFile);
		String latestVersion = file.ReadContent();
		if( currentVersion == null)
		{
			Tool.ErrorReport("Error Happended When Getting Current Tool Version!");
			return false;
		}
		if( !currentVersion.equals(latestVersion))
		{
			String info = "Current Version: " + currentVersion;
			info += ("\nYou Must Get Latest Version: " + latestVersion + "\nFrom Share Folder or SVN!");
			Tool.ErrorReport(info);
			return false;
		}
		return true;
	}
	// 2008-09-04 the title format must be : "Form Automatic Adaptation Tool (Beta Version 2.28)"
	static public String getCurrentVersion(String title)
	{
		String[] col = title.split(" ");
		int length = col.length;
		String end = col[length-1];
		return end.substring(0, end.length() -1 );
	}
}